import React from 'react';
import { theme } from '../theme';
import { getBeatState } from '../rig/beat';
import {
  BonesDrummer,
  SpinnyBassist,
  BooSax,
  PipBat,
} from '../characters/band/BandCharacters';

/**
 * Cute Jack-O'-Lantern Prop (glows & bounces on the beat!).
 */
export const JackOLantern: React.FC<{
  x: number;
  y: number;
  scale?: number;
  frame: number;
}> = ({ x, y, scale = 1, frame }) => {
  const b = getBeatState(frame);
  const bounce = 1 + Math.max(0, -b.hop) * 0.09;
  return (
    <g
      transform={`translate(${x.toFixed(2)}, ${y.toFixed(2)}) scale(${(
        scale * bounce
      ).toFixed(3)}, ${(scale / bounce).toFixed(3)})`}
    >
      <ellipse cx={0} cy={14} rx={48} ry={10} fill="rgba(20,5,15,0.35)" />
      <path
        d="M -6 -44 Q 0 -60 10 -52"
        fill="none"
        stroke="#5A8F28"
        strokeWidth={9}
        strokeLinecap="round"
      />
      <ellipse cx={0} cy={-16} rx={48} ry={35} fill="#E66A12" />
      <ellipse cx={0} cy={-16} rx={34} ry={35} fill="#F57C1F" />
      <ellipse cx={0} cy={-16} rx={18} ry={35} fill="#FF9838" />
      {/* Glowing eyes & grin */}
      <polygon points="-22,-22 -12,-35 -4,-22" fill="#FFF176" />
      <polygon points="4,-22 12,-35 22,-22" fill="#FFF176" />
      <polygon points="-4,-14 0,-21 4,-14" fill="#FFF176" />
      <path
        d="M -28 -8 Q 0 15 28 -8 Q 14 -2 0 -2 Q -14 -2 -28 -8 Z"
        fill="#FFF176"
      />
    </g>
  );
};

/**
 * Section A: Moonlit Castle Window Intro Set (matches sheet_01 tile 1).
 * Includes full overscan bleed (-960..2880 x -600..1680) so camera movement never exposes edges.
 */
export const CastleWindowSet: React.FC<{ frame: number }> = ({ frame }) => {
  const flicker = 1 + Math.sin(frame * 0.6) * 0.08;
  return (
    <g>
      {/* Overscan Interior Castle Wall */}
      <rect x={-960} y={-600} width={3840} height={2280} fill="#260A17" />
      <rect x={60} y={120} width={180} height={90} rx={8} fill="#310E1F" />
      <rect x={1680} y={220} width={180} height={90} rx={8} fill="#310E1F" />
      <rect x={90} y={520} width={160} height={85} rx={8} fill="#310E1F" />

      {/* Night sky behind window */}
      <rect x={310} y={40} width={1300} height={820} fill={theme.night.skyMid} />

      {/* Starfield */}
      {[
        [420, 140, 4],
        [560, 210, 3],
        [1120, 130, 5],
        [1420, 190, 4],
        [1490, 420, 3],
        [450, 480, 4],
        [1180, 490, 3],
      ].map(([sx, sy, sr], idx) => (
        <circle
          key={idx}
          cx={sx}
          cy={sy}
          r={sr * (0.8 + 0.3 * Math.sin(frame * 0.2 + idx))}
          fill="#FFF8D6"
          opacity={0.75}
        />
      ))}

      {/* Big Glowing Full Moon */}
      <circle cx={780} cy={340} r={255} fill="rgba(255, 248, 214, 0.18)" />
      <circle cx={780} cy={340} r={200} fill={theme.night.moon} />
      <circle cx={720} cy={290} r={28} fill="#EFE4B8" opacity={0.55} />
      <circle cx={830} cy={380} r={40} fill="#EFE4B8" opacity={0.45} />

      {/* Distant Halloween Hill Silhouette in Window */}
      <path
        d="M 310 760 Q 560 660 880 740 Q 1240 640 1610 750 L 1610 860 L 310 860 Z"
        fill="#1E0B36"
      />

      {/* Pip the Bat swooping across the Moon with a Mini Burger! */}
      <PipBat
        x={760 + Math.sin(frame * 0.14) * 110}
        y={420 + Math.cos(frame * 0.2) * 28}
        frame={frame}
        scale={1.85}
        holdingMiniBurger
      />

      {/* Window Lattice Panes */}
      <g stroke="#1C0A29" strokeWidth={18}>
        <line x1={640} y1={40} x2={640} y2={860} />
        <line x1={960} y1={40} x2={960} y2={860} />
        <line x1={1280} y1={40} x2={1280} y2={860} />
        <line x1={310} y1={310} x2={1610} y2={310} />
        <line x1={310} y1={580} x2={1610} y2={580} />
      </g>

      {/* Window Frame & Sill */}
      <rect
        x={310}
        y={40}
        width={1300}
        height={820}
        fill="none"
        stroke="#4B206B"
        strokeWidth={34}
      />
      <rect x={180} y={840} width={1560} height={70} rx={12} fill="#5C182C" />
      <rect x={-960} y={910} width={3840} height={770} fill="#360814" />

      {/* Flickering Candles on Left & Right of Sill */}
      {[420, 1420, 1490].map((cx, i) => {
        const h = i === 1 ? 115 : 85;
        return (
          <g key={i} transform={`translate(${cx}, 840)`}>
            <rect x={-22} y={-h} width={44} height={h} rx={6} fill="#FFF8E1" />
            <circle
              cx={0}
              cy={-h - 22}
              r={30 * flicker}
              fill="rgba(255, 210, 63, 0.35)"
            />
            <path
              d={`M 0 ${-h - 44 * flicker} Q -14 ${-h - 14} 0 ${-h - 6} Q 14 ${-h - 14} 0 ${-h - 44 * flicker} Z`}
              fill="#FFD23F"
            />
          </g>
        );
      })}

      {/* Corner Cobweb */}
      <g stroke="rgba(255,255,255,0.45)" strokeWidth={3} fill="none">
        <line x1={1920} y1={0} x2={1640} y2={240} />
        <line x1={1920} y1={0} x2={1580} y2={110} />
        <line x1={1920} y1={0} x2={1760} y2={290} />
        <path d="M 1820 0 Q 1780 65 1850 120" />
        <path d="M 1730 0 Q 1680 110 1790 200" />
      </g>
    </g>
  );
};

/**
 * Studio-Grade Theatre Stage Set.
 * Full overscan bleed (-960..2880), parted velvet curtains, brick theatre back wall,
 * hanging bat garlands, curved wood stage apron, and non-overlapping Halloween Band!
 */
export const TheatreStageSet: React.FC<{
  frame: number;
  showBand?: boolean;
  showBooWithBand?: boolean;
  showPip?: boolean;
  spotlights?: number[]; // x centers of spotlights
}> = ({
  frame,
  showBand = true,
  showBooWithBand = true,
  showPip = true,
  spotlights = [900],
}) => {
  return (
    <g>
      {/* 1. Overscan Deep Maroon Theatre Back Wall */}
      <rect x={-960} y={-600} width={3840} height={1420} fill="#3D0D20" />
      {/* Subtle Studio Brick Blocks */}
      {[
        [420, 140],
        [760, 110],
        [1180, 150],
        [1420, 120],
        [520, 290],
        [1290, 280],
        [680, 430],
        [1120, 440],
      ].map(([bx, by], i) => (
        <rect
          key={i}
          x={bx}
          y={by}
          width={110}
          height={46}
          rx={6}
          fill="#2D0716"
          opacity={0.65}
        />
      ))}

      {/* Center Stage Recessed Archway & Pleated Drapes (overscanned across -480..2400) */}
      <path
        d="M 430 800 L 430 260 A 530 220 0 0 1 1490 260 L 1490 800 Z"
        fill="#2B0715"
      />
      {Array.from({ length: 24 }).map((_, i) => {
        const px = -420 + i * 120;
        const isEdge = px < 320 || px > 1520;
        return (
          <rect
            key={i}
            x={px}
            y={-300}
            width={60}
            height={1100}
            fill={theme.stage.curtainMain}
            opacity={isEdge ? 0.85 : 0.25}
          />
        );
      })}

      {/* Hanging Halloween Bat Garland Across Upper Stage */}
      <path
        d="M 220 120 Q 590 210 960 135 Q 1330 210 1700 120"
        fill="none"
        stroke="#1B0510"
        strokeWidth={4}
      />
      {[360, 580, 780, 960, 1140, 1340, 1560].map((bx, i) => (
        <g
          key={i}
          transform={`translate(${bx}, ${145 + (i % 2) * 22}) rotate(${
            Math.sin(frame * 0.08 + i) * 6
          })`}
        >
          <path
            d="M -28 -6 Q -14 -20 0 -6 Q 14 -20 28 -6 Q 14 8 0 12 Q -14 8 -28 -6 Z"
            fill="#1B0510"
          />
        </g>
      ))}

      {/* 2. Overscanned Curved Warm Wooden Stage Floor */}
      <path
        d="M -960 760 Q 960 720 2880 760 L 2880 1680 L -960 1680 Z"
        fill={theme.stage.woodBase}
      />
      <path
        d="M -960 760 Q 960 720 2880 760 L 2880 780 Q 960 740 -960 780 Z"
        fill={theme.stage.woodEdge}
      />
      {Array.from({ length: 19 }).map((_, i) => {
        const xTop = -390 + i * 150;
        const xBot = -750 + i * 190;
        return (
          <line
            key={i}
            x1={xTop}
            y1={750}
            x2={xBot}
            y2={1400}
            stroke={theme.stage.woodPlank}
            strokeWidth={4}
            opacity={0.55}
          />
        );
      })}
      {/* Curved Stage Apron Rim at Bottom */}
      <path
        d="M -960 970 Q 960 1020 2880 970 L 2880 1680 L -960 1680 Z"
        fill="#3A1510"
      />
      <path
        d="M -960 970 Q 960 1020 2880 970"
        fill="none"
        stroke="#6B2D1A"
        strokeWidth={10}
      />

      {/* 3. Studio-Scale Halloween Band (Positioned cleanly on Left & Right, ZERO overlap with Center Hero at x=880!) */}
      {showBand && (
        <g>
          {/* Band Floor Risers */}
          <ellipse cx={280} cy={855} rx={200} ry={40} fill="#7B441E" />
          <ellipse cx={1640} cy={855} rx={200} ry={40} fill="#7B441E" />
          <BonesDrummer x={280} y={840} frame={frame} scale={1.42} />
          {showBooWithBand && <BooSax x={1310} y={820} frame={frame} scale={1.22} />}
          <SpinnyBassist x={1640} y={845} frame={frame} scale={1.45} />
        </g>
      )}

      {/* Optional Pip the Bat flying high in upper arch (y=195, well above heads!) */}
      {showPip && (
        <PipBat
          x={960 + Math.sin(frame * 0.09) * 360}
          y={195 + Math.cos(frame * 0.14) * 24}
          frame={frame}
          scale={1.12}
        />
      )}

      {/* 4. Stage Spotlights (Floor Oval + Warm Volumetric Cone) */}
      {spotlights.map((sx, idx) => (
        <g key={idx}>
          <ellipse
            cx={sx}
            cy={875}
            rx={290}
            ry={62}
            fill="rgba(255, 232, 148, 0.34)"
          />
          <ellipse
            cx={sx}
            cy={875}
            rx={225}
            ry={44}
            fill="rgba(255, 246, 196, 0.36)"
          />
          <polygon
            points={`${sx - 145},-300 ${sx + 145},-300 ${sx + 315},900 ${sx - 315},900`}
            fill={theme.stage.spotlight}
          />
        </g>
      ))}

      {/* 5. Lush Parted Velvet Side Wing Curtains & Top Scalloped Valance (Overscanned!) */}
      <path
        d="M -600 -300 L 230 -300 Q 175 410 105 790 L -600 790 Z"
        fill={theme.stage.curtainMain}
      />
      <path
        d="M 2520 -300 L 1690 -300 Q 1745 410 1815 790 L 2520 790 Z"
        fill={theme.stage.curtainMain}
      />
      {/* Gold Curtain Tie-Backs */}
      <path
        d="M -60 470 Q 85 495 145 460"
        fill="none"
        stroke="#F5B82E"
        strokeWidth={12}
        strokeLinecap="round"
      />
      <path
        d="M 1980 470 Q 1835 495 1775 460"
        fill="none"
        stroke="#F5B82E"
        strokeWidth={12}
        strokeLinecap="round"
      />

      {/* Top Scalloped Velvet Valance (extended from -510 to 2450) */}
      {Array.from({ length: 18 }).map((_, i) => (
        <circle
          key={i}
          cx={(i - 3) * 170 + 85}
          cy={2}
          r={96}
          fill={theme.stage.curtainMain}
          stroke={theme.stage.curtainTrim}
          strokeWidth={6}
        />
      ))}

      {/* Stage Corner Jack-O'-Lanterns */}
      <JackOLantern x={95} y={925} scale={1.0} frame={frame} />
      <JackOLantern x={1825} y={925} scale={1.0} frame={frame} />
    </g>
  );
};

/**
 * Dancing Mini Food Sidekick Prop (used in K1..K4 choruses & Finale!).
 */
export const MiniFoodDancer: React.FC<{
  kind: 'burger' | 'icecream' | 'donut' | 'hotdog';
  x: number;
  y: number;
  frame: number;
  scale?: number;
  phaseOffset?: number;
}> = ({ kind, x, y, frame, scale = 1, phaseOffset = 0 }) => {
  const b = getBeatState(frame + Math.round(phaseOffset * 15));
  const jumpY = Math.max(0, b.hop * 22);
  const sx = 1 - b.hop * 0.13;
  const sy = 1 / sx;
  const tilt = b.sway * 11;

  return (
    <g
      transform={`translate(${x.toFixed(2)}, ${(y - jumpY).toFixed(
        2
      )}) rotate(${tilt.toFixed(2)}) scale(${(scale * sx).toFixed(3)}, ${(
        scale * sy
      ).toFixed(3)})`}
    >
      {/* Ground Contact Shadow */}
      <ellipse
        cx={0}
        cy={54 + jumpY * 0.7}
        rx={38 * (1 - jumpY * 0.008)}
        ry={9}
        fill="rgba(20, 8, 28, 0.28)"
      />
      {/* Cute little stick legs & shoes */}
      <line
        x1={-16}
        y1={24}
        x2={-18}
        y2={52}
        stroke="#2B1D28"
        strokeWidth={7}
        strokeLinecap="round"
      />
      <line
        x1={16}
        y1={24}
        x2={18}
        y2={52}
        stroke="#2B1D28"
        strokeWidth={7}
        strokeLinecap="round"
      />
      <ellipse cx={-22} cy={53} rx={10} ry={5} fill="#FF5252" />
      <ellipse cx={22} cy={53} rx={10} ry={5} fill="#FF5252" />

      {/* Little waving arms */}
      <path
        d={`M -42 0 Q -66 ${-20 - b.hop * 18} -58 ${-36 - b.hop * 18}`}
        fill="none"
        stroke="#2B1D28"
        strokeWidth={7}
        strokeLinecap="round"
      />
      <path
        d={`M 42 0 Q 66 ${-20 + b.hop * 18} 58 ${-36 + b.hop * 18}`}
        fill="none"
        stroke="#2B1D28"
        strokeWidth={7}
        strokeLinecap="round"
      />

      {kind === 'burger' && (
        <g>
          <ellipse cx={0} cy={22} rx={48} ry={14} fill="#E5943A" />
          <rect x={-50} y={4} width={100} height={18} rx={9} fill="#6B3418" />
          <path d="M -50 4 L -24 18 L 0 6 L 24 20 L 50 4 Z" fill="#FFC71F" />
          <path
            d="M -52 2 Q -25 14 0 2 Q 25 14 52 2 L 48 -8 L -48 -8 Z"
            fill="#65C431"
          />
          <path d="M -48 -4 C -48 -48, 48 -48, 48 -4 Z" fill="#E5943A" />
          <ellipse cx={-16} cy={-24} rx={4} ry={2} fill="#FFF3D1" />
          <ellipse cx={0} cy={-28} rx={4} ry={2} fill="#FFF3D1" />
          <ellipse cx={16} cy={-22} rx={4} ry={2} fill="#FFF3D1" />
        </g>
      )}

      {kind === 'icecream' && (
        <g>
          <polygon points="-32,0 32,0 0,54" fill="#E29E4B" />
          <circle cx={0} cy={-14} r={38} fill="#FF9EC4" />
          <path
            d="M -34 -8 Q -16 6 0 -6 Q 16 6 34 -8"
            fill="#FFF8EE"
          />
          <circle cx={0} cy={-48} r={11} fill="#E62238" />
        </g>
      )}

      {kind === 'donut' && (
        <g>
          <circle cx={0} cy={0} r={48} fill="#F0AE5A" />
          <circle cx={0} cy={0} r={41} fill="#FF6FAE" />
          <circle cx={0} cy={0} r={15} fill="#3B146B" />
          <rect
            x={-24}
            y={-28}
            width={10}
            height={4}
            rx={2}
            fill="#FFE03D"
            transform="rotate(-25 -24 -28)"
          />
          <rect
            x={16}
            y={-26}
            width={10}
            height={4}
            rx={2}
            fill="#5CE1E6"
            transform="rotate(20 16 -26)"
          />
          <rect
            x={-26}
            y={18}
            width={10}
            height={4}
            rx={2}
            fill="#FFFFFF"
            transform="rotate(15 -26 18)"
          />
          <rect
            x={18}
            y={20}
            width={10}
            height={4}
            rx={2}
            fill="#95E84B"
            transform="rotate(-20 18 20)"
          />
        </g>
      )}

      {kind === 'hotdog' && (
        <g>
          <rect x={-56} y={-12} width={112} height={28} rx={14} fill="#C9412C" />
          <path
            d="M -44 0 Q -22 -10 0 0 Q 22 10 44 0"
            fill="none"
            stroke="#FFD21F"
            strokeWidth={5}
            strokeLinecap="round"
          />
          <rect x={-48} y={6} width={96} height={24} rx={12} fill="#E89D48" />
        </g>
      )}

      {/* Cute Mini Eyes & Smile */}
      <circle cx={-12} cy={-12} r={7} fill="#FFFFFF" />
      <circle cx={12} cy={-12} r={7} fill="#FFFFFF" />
      <circle cx={-12} cy={-12} r={4} fill="#1B1B2A" />
      <circle cx={12} cy={-12} r={4} fill="#1B1B2A" />
      <path
        d="M -8 -2 Q 0 6 8 -2"
        fill="none"
        stroke="#1B1B2A"
        strokeWidth={3.5}
        strokeLinecap="round"
      />
    </g>
  );
};

/**
 * Studio Food Chorus Backdrop Set (K1 Burger, K2 Ice Cream, K3 Donut, K4 Hot Dog).
 * Overscanned (-960..2880) with Diner Arches, Striped Awning, Center Spotlight,
 * and 6 Symmetrical MiniFoodDancers (3 on left, 3 on right — zero overlap with center hero!).
 */
export const FoodChorusSet: React.FC<{
  food: 'burger' | 'icecream' | 'donut' | 'hotdog';
  frame: number;
}> = ({ food, frame }) => {
  const b = getBeatState(frame);

  const bgColors: Record<
    typeof food,
    { sky: string; stripe: string; floor: string; awningA: string; awningB: string }
  > = {
    burger: {
      sky: '#321266',
      stripe: '#4A1D91',
      floor: '#D8D4E8',
      awningA: '#E8382B',
      awningB: '#FFF5E4',
    },
    icecream: {
      sky: '#26145C',
      stripe: '#4C2594',
      floor: '#B8F2E6',
      awningA: '#FF7EB6',
      awningB: '#FFF8F0',
    },
    donut: {
      sky: '#421682',
      stripe: '#6226B3',
      floor: '#F7B6D2',
      awningA: '#FF6FAE',
      awningB: '#FFE03D',
    },
    hotdog: {
      sky: '#4A154B',
      stripe: '#6E1E68',
      floor: '#FFE082',
      awningA: '#E8382B',
      awningB: '#FFD21F',
    },
  };
  const pal = bgColors[food];

  return (
    <g>
      {/* Overscanned Striped Party / Diner Backdrop */}
      <rect x={-960} y={-600} width={3840} height={1420} fill={pal.sky} />
      {Array.from({ length: 22 }).map((_, i) => (
        <rect
          key={i}
          x={(i - 5) * 160}
          y={-600}
          width={80}
          height={1420}
          fill={pal.stripe}
          opacity={0.48}
        />
      ))}

      {/* Storefront / Diner Arched Windows in Background */}
      {[320, 960, 1600].map((wx, i) => (
        <g key={i} transform={`translate(${wx}, 480)`}>
          <path
            d="M -170 300 L -170 -80 A 170 150 0 0 1 170 -80 L 170 300 Z"
            fill="rgba(16, 6, 36, 0.45)"
            stroke="rgba(255, 255, 255, 0.14)"
            strokeWidth={8}
          />
        </g>
      ))}

      {/* Decorative Floating Stars / Confetti in Upper Background (behind characters) */}
      {Array.from({ length: 8 }).map((_, i) => {
        const px = 160 + i * 225;
        const py = 220 + (i % 2) * 95 + Math.sin(b.beatFloat * Math.PI + i) * 16;
        return (
          <circle
            key={i}
            cx={px}
            cy={py}
            r={24 + (i % 2) * 10}
            fill="#FFFFFF"
            opacity={0.18}
          />
        );
      })}

      {/* Center Stage Spotlight Cone for Hero + Side Spotlights for Mini Chorus */}
      <polygon
        points="680,-300 1240,-300 1440,920 480,920"
        fill="rgba(255, 255, 255, 0.17)"
      />
      <ellipse
        cx={960}
        cy={875}
        rx={340}
        ry={64}
        fill="rgba(255, 255, 255, 0.24)"
      />

      {/* Overscanned Party Sidewalk / Diner Checkered Floor */}
      <rect x={-960} y={775} width={3840} height={900} fill={pal.floor} />
      <rect x={-960} y={775} width={3840} height={16} fill="rgba(0,0,0,0.18)" />
      {Array.from({ length: 20 }).map((_, i) => {
        const bx = (i - 4) * 160;
        return (
          <polygon
            key={i}
            points={`${bx + 40},791 ${bx + 120},791 ${bx + 90},1400 ${bx - 10},1400`}
            fill="rgba(255,255,255,0.28)"
          />
        );
      })}

      {/* Top Striped Storefront Awning (extended across -480..2400) */}
      {Array.from({ length: 24 }).map((_, i) => {
        const ax = (i - 4) * 120;
        return (
          <g key={i} transform={`translate(${ax}, 0)`}>
            <rect
              x={0}
              y={-200}
              width={120}
              height={278}
              fill={i % 2 === 0 ? pal.awningA : pal.awningB}
            />
            <circle
              cx={60}
              cy={78}
              r={60}
              fill={i % 2 === 0 ? pal.awningA : pal.awningB}
            />
          </g>
        );
      })}

      {/* 6 Symmetrical Dancing Mini Food Sidekicks (3 Left, 3 Right — clear of Center Hero at x=960!) */}
      <MiniFoodDancer kind={food} x={175} y={830} frame={frame} scale={1.22} phaseOffset={0.0} />
      <MiniFoodDancer kind={food} x={385} y={845} frame={frame} scale={1.18} phaseOffset={0.2} />
      <MiniFoodDancer kind={food} x={595} y={830} frame={frame} scale={1.14} phaseOffset={0.4} />
      <MiniFoodDancer kind={food} x={1325} y={830} frame={frame} scale={1.14} phaseOffset={0.6} />
      <MiniFoodDancer kind={food} x={1535} y={845} frame={frame} scale={1.18} phaseOffset={0.8} />
      <MiniFoodDancer kind={food} x={1745} y={830} frame={frame} scale={1.22} phaseOffset={1.0} />

      {/* Jack-O'-Lanterns on Far Corners */}
      <JackOLantern x={70} y={920} scale={0.95} frame={frame} />
      <JackOLantern x={1850} y={920} scale={0.95} frame={frame} />
    </g>
  );
};

/**
 * K1..K4 Bars 7–8 Cutaway: Clean Band Groove Cutaway with Mini Food Sidekicks Beside Them!
 * Zero overlapping shapes over the band's faces or instruments.
 */
export const BandChorusCutawaySet: React.FC<{
  food: 'burger' | 'icecream' | 'donut' | 'hotdog';
  frame: number;
}> = ({ food, frame }) => {
  return (
    <g>
      <TheatreStageSet
        frame={frame}
        showBand={false}
        showPip
        spotlights={[450, 960, 1470]}
      />
      {/* Band Trio in 3 Spotlights */}
      <BonesDrummer x={450} y={845} frame={frame} scale={1.52} />
      <BooSax x={960} y={835} frame={frame} scale={1.52} />
      <SpinnyBassist x={1470} y={850} frame={frame} scale={1.52} />

      {/* 2 Mini Food Dancers Grooving on the Stage Floor BETWEEN the Band Members (zero overlap!) */}
      <MiniFoodDancer kind={food} x={715} y={860} frame={frame} scale={1.15} phaseOffset={0.2} />
      <MiniFoodDancer kind={food} x={1205} y={860} frame={frame} scale={1.15} phaseOffset={0.7} />
    </g>
  );
};

/**
 * Finale F1 Part 2 Set: Moonlit Giant Food Platforms!
 * Each hero stands on top of their EXACT corresponding giant food:
 * - x=280: Burger Bobo on Giant Sesame Burger
 * - x=730: Ice Cream Lulu on Giant Waffle Ice Cream Cone
 * - x=1190: Donut Ziggy on Giant Sprinkled Donut (with unmistakable center donut hole!)
 * - x=1640: Hot Dog Grub on Giant Grilled Hot Dog in a Bun with Mustard Zigzag!
 */
export const MoonlitFoodSkylineSet: React.FC<{ frame: number }> = ({ frame }) => {
  return (
    <g>
      {/* Overscanned Starry Night Sky + Big Glowing Full Moon */}
      <rect x={-960} y={-600} width={3840} height={2280} fill="#2A0F54" />
      {[
        [180, 120],
        [460, 85],
        [780, 140],
        [1480, 110],
        [1760, 180],
        [120, 320],
        [1810, 350],
      ].map(([sx, sy], i) => (
        <circle
          key={i}
          cx={sx}
          cy={sy}
          r={4 + (i % 2) * 2}
          fill="#FFF8D6"
          opacity={0.6 + 0.3 * Math.sin(frame * 0.15 + i)}
        />
      ))}
      <circle cx={960} cy={210} r={175} fill="rgba(255, 248, 214, 0.16)" />
      <circle cx={960} cy={210} r={130} fill={theme.night.moon} />

      {/* 1. GIANT SESAME BURGER PLATFORM (x=280, top surface at y=735) */}
      <g transform="translate(280, 765)">
        {/* Bottom Bun */}
        <path d="M -210 210 L 210 210 C 210 330, -210 330, -210 210 Z" fill="#D9822B" />
        {/* Thick Brown Grilled Beef Patty */}
        <rect x={-225} y={135} width={450} height={85} rx={42} fill="#6B3418" />
        {/* Melted Yellow Cheese Triangles */}
        <polygon points="-215,135 -115,195 -15,135 85,195 185,135 220,155 220,125 -215,125" fill="#FFC71F" />
        {/* Wavy Green Lettuce */}
        <path
          d="M -230 120 Q -150 165 -75 120 Q 0 165 75 120 Q 150 165 230 120 L 215 90 L -215 90 Z"
          fill="#65C431"
        />
        {/* Golden Dome Top Bun + Cream Sesame Seeds */}
        <path d="M -215 105 C -215 -45, 215 -45, 215 105 Z" fill="#E5943A" />
        {[
          [-95, 35, -18],
          [-30, 18, -5],
          [40, 22, 8],
          [105, 42, 20],
          [-55, 62, 10],
          [25, 65, -12],
          [85, 72, 14],
        ].map(([sx, sy, rot], i) => (
          <ellipse
            key={i}
            cx={sx}
            cy={sy}
            rx={14}
            ry={6}
            fill="#FFF3D1"
            transform={`rotate(${rot} ${sx} ${sy})`}
          />
        ))}
      </g>

      {/* 2. GIANT ICE CREAM CONE PLATFORM (x=730, top surface at y=735, waffle cone fully visible!) */}
      <g transform="translate(730, 755)">
        {/* Giant Waffle Cone */}
        <polygon points="-155,80 155,80 0,325" fill="#E29E4B" stroke="#B8742A" strokeWidth={8} />
        <line x1={-105} y1={80} x2={50} y2={245} stroke="#B8742A" strokeWidth={6} />
        <line x1={-35} y1={80} x2={90} y2={205} stroke="#B8742A" strokeWidth={6} />
        <line x1={105} y1={80} x2={-50} y2={245} stroke="#B8742A" strokeWidth={6} />
        <line x1={35} y1={80} x2={-90} y2={205} stroke="#B8742A" strokeWidth={6} />
        {/* Pink Strawberry Ice Cream Scoop + Scalloped Drips */}
        <path d="M -175 85 C -185 -35, 185 -35, 175 85 Z" fill="#FF85B3" />
        <circle cx={-125} cy={85} r={38} fill="#FF85B3" />
        <circle cx={-42} cy={90} r={42} fill="#FF85B3" />
        <circle cx={42} cy={90} r={42} fill="#FF85B3" />
        <circle cx={125} cy={85} r={38} fill="#FF85B3" />
        {/* White Whipped Cream Top Cushion */}
        <ellipse cx={0} cy={8} rx={115} ry={28} fill="#FFF8EE" />
        {/* Sprinkles on Giant Ice Cream */}
        <rect x={-80} y={38} width={22} height={8} rx={4} fill="#FFE03D" transform="rotate(-18 -80 38)" />
        <rect x={-10} y={50} width={22} height={8} rx={4} fill="#5CE1E6" transform="rotate(14 -10 50)" />
        <rect x={60} y={36} width={22} height={8} rx={4} fill="#95E84B" transform="rotate(-22 60 36)" />
      </g>

      {/* 3. GIANT SPRINKLED DONUT PLATFORM (x=1190, top rim at y=735, unmistakable center hole!) */}
      <g transform="translate(1190, 915)">
        {/* Golden Dough Outer Torus */}
        <circle cx={0} cy={0} r={185} fill="#F0AE5A" stroke="#C88232" strokeWidth={8} />
        {/* Pink Strawberry Icing Ring */}
        <circle cx={0} cy={0} r={158} fill="#FF6FAE" />
        {/* UNMISTAKABLE CENTER DONUT HOLE (Dough inner rim + dark night sky center!) */}
        <circle cx={0} cy={0} r={74} fill="#D9923B" />
        <circle cx={0} cy={0} r={58} fill="#2A0F54" />
        {/* Rainbow Sprinkles all around the Donut Ring */}
        {[
          [-95, -95, -30, '#FFE03D'],
          [0, -118, 12, '#FFFFFF'],
          [95, -95, 35, '#5CE1E6'],
          [-122, 0, 75, '#95E84B'],
          [122, 0, -70, '#FFE03D'],
          [-95, 95, 40, '#FFFFFF'],
          [0, 118, -15, '#5CE1E6'],
          [95, 95, -35, '#95E84B'],
        ].map(([sx, sy, rot, col], i) => (
          <rect
            key={i}
            x={Number(sx) - 13}
            y={Number(sy) - 5}
            width={26}
            height={10}
            rx={5}
            fill={String(col)}
            transform={`rotate(${rot} ${sx} ${sy})`}
          />
        ))}
      </g>

      {/* 4. GIANT HOT DOG IN A BUN PLATFORM (x=1640, top surface at y=755) */}
      <g transform="translate(1640, 755)">
        {/* Back Bun Half */}
        <rect x={-195} y={10} width={390} height={110} rx={55} fill="#D98A36" />
        {/* Wavy Green Relish */}
        <path
          d="M -185 55 Q -120 20 -60 55 Q 0 20 60 55 Q 120 20 185 55"
          fill="none"
          stroke="#65C431"
          strokeWidth={24}
          strokeLinecap="round"
        />
        {/* Giant Savory Grilled Hot Dog Sausage */}
        <rect x={-225} y={30} width={450} height={115} rx={57} fill="#C9412C" stroke="#9E2B19" strokeWidth={6} />
        {/* Bright Yellow Wavy Mustard Zigzag Across Sausage */}
        <path
          d="M -175 72 Q -130 38 -85 72 Q -42 106 0 72 Q 42 38 85 72 Q 130 106 175 72"
          fill="none"
          stroke="#FFD21F"
          strokeWidth={18}
          strokeLinecap="round"
        />
        {/* Front Golden Split Hot Dog Bun */}
        <rect x={-200} y={105} width={400} height={135} rx={65} fill="#E89D48" stroke="#C67D2A" strokeWidth={6} />
        <ellipse cx={0} cy={135} rx={155} ry={18} fill="#F5B76B" opacity={0.65} />
      </g>
    </g>
  );
};

/**
 * Finale F3 & O: Moonlit Trick-or-Treat Street Set.
 * Full overscan bleed (-960..2880 x -600..1680) so bottom/side edges NEVER show transparency checkerboard!
 * Removed middle pumpkins that collided with character feet.
 */
export const TrickOrTreatStreetSet: React.FC<{ frame: number }> = ({ frame }) => {
  return (
    <g>
      {/* Overscanned Starry Night Sky + Full Moon */}
      <rect x={-960} y={-600} width={3840} height={1400} fill={theme.night.skyDeep} />
      <circle cx={1480} cy={180} r={115} fill={theme.night.moon} />
      <circle cx={1480} cy={180} r={155} fill="rgba(255, 248, 214, 0.18)" />

      {/* Silhouetted Halloween Houses with Glowing Windows & Roofs (extended across -300..2220) */}
      {[
        { x: -300, w: 300, h: 430, col: '#3B4E7A', roof: '#1B243B' },
        { x: 20, w: 310, h: 460, col: '#2D3A68', roof: '#1A1230' },
        { x: 350, w: 280, h: 390, col: '#4A255E', roof: '#241038' },
        { x: 660, w: 290, h: 430, col: '#6B2D5C', roof: '#2E112D' },
        { x: 980, w: 270, h: 380, col: '#3B4E7A', roof: '#1B243B' },
        { x: 1280, w: 300, h: 420, col: '#7A3B5E', roof: '#331428' },
        { x: 1600, w: 300, h: 450, col: '#2A425E', roof: '#152233' },
        { x: 1920, w: 300, h: 420, col: '#4A255E', roof: '#241038' },
      ].map((h, i) => (
        <g key={i} transform={`translate(${h.x}, ${780 - h.h})`}>
          <polygon
            points={`-24,0 ${h.w * 0.5},-130 ${h.w + 24},0`}
            fill={h.roof}
          />
          <rect x={0} y={0} width={h.w} height={h.h} fill={h.col} />
          <path
            d={`M ${h.w * 0.5 - 32} -25 L ${h.w * 0.5 - 32} -65 A 32 32 0 0 1 ${
              h.w * 0.5 + 32
            } -65 L ${h.w * 0.5 + 32} -25 Z`}
            fill="#FFE066"
          />
          <rect x={36} y={45} width={72} height={95} rx={8} fill="#FFE066" />
          <rect x={h.w - 108} y={45} width={72} height={95} rx={8} fill="#FFE066" />
          <rect x={36} y={185} width={72} height={95} rx={8} fill="#FFD23F" opacity={0.85} />
          <rect x={h.w - 108} y={185} width={72} height={95} rx={8} fill="#FFD23F" opacity={0.85} />
          <line x1={72} y1={45} x2={72} y2={140} stroke={h.col} strokeWidth={6} />
          <line x1={36} y1={92} x2={108} y2={92} stroke={h.col} strokeWidth={6} />
        </g>
      ))}

      {/* Overscanned Sidewalk Pavement with Curb & Slab Lines (extends down to y=1680!) */}
      <rect x={-960} y={765} width={3840} height={915} fill="#C5C1D8" />
      <rect x={-960} y={765} width={3840} height={18} fill="#948FA8" />
      {Array.from({ length: 14 }).map((_, i) => {
        const sx = (i - 3) * 260;
        return (
          <line
            key={i}
            x1={sx}
            y1={783}
            x2={sx - 80}
            y2={1400}
            stroke="#A6A1BA"
            strokeWidth={5}
          />
        );
      })}

      {/* Far Corner Jack-O'-Lanterns (clear of all characters' feet!) */}
      <JackOLantern x={75} y={920} scale={1.0} frame={frame} />
      <JackOLantern x={1845} y={920} scale={1.0} frame={frame} />

      {/* Pip flying high in the night sky (y=155, clear of all costumes!) */}
      <PipBat
        x={960 + Math.sin(frame * 0.09) * 320}
        y={155}
        frame={frame}
        scale={1.25}
        holdingMiniBurger
      />
    </g>
  );
};
