// ============================================================================
// MAIN VIDEO COMPOSITION.
// Keeps a single persistent <ThreeCanvas> across all shots so WebGL contexts
// are never recreated mid-render.
// ============================================================================
import React from 'react';
import '@fontsource/montserrat/900.css';
import { ThreeCanvas } from '@remotion/three';
import {
  AbsoluteFill,
  Html5Audio,
  Sequence,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { CONFIG } from '../project/config';
import { SHOTS } from '../project/shots';
import { SETS } from '../project/world';
import { CameraRig } from './CameraRig';
import { Captions } from './Captions';
import { CharacterCard } from './CharacterCard';
import { FxLayer3D } from './Fx';
import { PostLayer } from './Post';
import { FPS, frameOf, isSpeaking, lastWordEnd, timeOf } from './timing';
import type { Shot } from './types';
import { WorldView } from './World';

export type ResolvedShot = {
  shot: Shot;
  index: number;
  startT: number;
  endT: number;
};

export function resolveTimeline(): ResolvedShot[] {
  const totalEnd = lastWordEnd() + (CONFIG.tail ?? 1.2);
  return SHOTS.map((shot, i) => {
    const startT = i === 0 ? 0 : timeOf(shot.from);
    const endT = i + 1 < SHOTS.length ? timeOf(SHOTS[i + 1].from) : totalEnd;
    return { shot, index: i, startT, endT: Math.max(startT + 0.1, endT) };
  });
}

export function getActiveShot(timeline: ResolvedShot[], t: number): ResolvedShot {
  for (let i = timeline.length - 1; i >= 0; i--) {
    if (t >= timeline[i].startT) return timeline[i];
  }
  return timeline[0];
}

export const CartoonWorldVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height, fps } = useVideoConfig();
  const t = frame / fps;
  const isPortrait = height >= width;

  const timeline = resolveTimeline();
  const active = getActiveShot(timeline, t);
  const { shot, startT, endT } = active;
  const set = SETS[shot.set];
  if (!set) {
    throw new Error(`Shot "${shot.id}" references unknown set "${shot.set}". Available SETS: ${Object.keys(SETS).join(', ')}`);
  }

  // Music volume with automatic voice ducking + dramatic stops
  const baseMusicVol = CONFIG.music.volume ?? 0.18;
  const musicVol = (f: number) => {
    const sec = f / FPS;
    for (const st of CONFIG.music.stops ?? []) {
      const s0 = timeOf(st.at);
      if (sec >= s0 && sec <= s0 + st.dur) return 0;
    }
    return isSpeaking(sec) ? baseMusicVol * 0.55 : baseMusicVol;
  };

  return (
    <AbsoluteFill style={{ backgroundColor: '#1b1622' }}>
      <ThreeCanvas
        width={width}
        height={height}
        camera={{ fov: isPortrait ? 42 : 34, near: 0.1, far: 180, position: [0, 2, 6] }}
      >
        <CameraRig
          shot={shot}
          set={set}
          t={t}
          shotStartT={startT}
          shotEndT={endT}
          isPortrait={isPortrait}
        />
        <WorldView set={set} extraProps={shot.props} t={t} />
        {shot.cast.map((sc, i) => (
          <CharacterCard key={`${shot.id}-${sc.who}-${i}`} sc={sc} t={t} shotEndT={endT} />
        ))}
        <FxLayer3D shot={shot} set={set} t={t} shotEndT={endT} />
      </ThreeCanvas>

      {/* Post-processing, transitions, speedlines & graphic overlays */}
      <PostLayer shot={shot} t={t} shotStartT={startT} shotEndT={endT} />

      {/* Word-by-word captions */}
      {(CONFIG.captions ?? true) && <Captions t={t} isPortrait={isPortrait} />}

      {/* Voice-over track */}
      {CONFIG.voiceFile && <Html5Audio src={staticFile(CONFIG.voiceFile)} volume={1} />}

      {/* Synthesized background music bed */}
      {CONFIG.music.mood !== 'none' && (
        <Html5Audio src={staticFile('audio/music.wav')} volume={musicVol} />
      )}

      {/* Synthesized & user sound effects */}
      {SHOTS.flatMap((s) =>
        (s.sfx ?? []).map((fx, idx) => {
          const fromFrame = Math.max(0, frameOf(fx.at));
          const file = fx.name.startsWith('user:')
            ? `sfx-user/${fx.name.slice(5)}`
            : `audio/sfx-${fx.name}.wav`;
          return (
            <Sequence key={`${s.id}-sfx-${idx}`} from={fromFrame} durationInFrames={90} layout="none">
              <Html5Audio src={staticFile(file)} volume={fx.vol ?? 0.65} />
            </Sequence>
          );
        }),
      )}
    </AbsoluteFill>
  );
};
