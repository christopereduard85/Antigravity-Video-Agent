@echo off
REM Full GPU render. Usage: render_full_gpu.cmd "C:\path\to\workspace" OutputName
set WS=%~1
set NAME=%~2
if "%NAME%"=="" set NAME=FinalVideo
cd /d "%WS%"
.\video\node_modules\.bin\remotion render video/src/index.ts Main out\%NAME%.mp4 --public-dir=video/public --browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe" --gl=angle --codec=h264 --crf=18 --pixel-format=yuv420p
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate,nb_frames,duration -of json out\%NAME%.mp4
