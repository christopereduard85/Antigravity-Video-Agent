import React from 'react';
import { getBeatState } from '../../rig/beat';
import { evalAutoBlink } from '../../rig/spring';
import { ContactShadow } from '../../rig/ContactShadow';

/**
 * B1: BONES — Friendly Cartoon Skeleton Drummer with Red Drum Kit (beat-locked).
 */
export const BonesDrummer: React.FC<{
  x: number;
  y: number;
  frame: number;
  fps?: number;
  scale?: number;
}> = ({ x, y, frame, fps = 30, scale = 1 }) => {
  const b = getBeatState(frame, fps);
  const bobY = -Math.abs(b.hop) * 10;
  const tilt = b.sway * 5;
  const hitL = Math.sin(b.beatFloat * Math.PI) * 28;
  const hitR = -Math.sin(b.beatFloat * Math.PI) * 28;
  const jawDrop = Math.max(0, b.hop) * 5;

  return (
    <g transform={`translate(${x.toFixed(2)}, ${y.toFixed(2)}) scale(${scale})`}>
      <ContactShadow width={210} jumpY={0} squash={b.hop * 0.1} />

      {/* Skeleton Torso & Ribcage */}
      <g transform={`translate(0, ${(-140 + bobY).toFixed(2)}) rotate(${tilt.toFixed(2)})`}>
        {/* Spine */}
        <line x1={0} y1={-40} x2={0} y2={62} stroke="#DFD7C8" strokeWidth={12} strokeLinecap="round" />
        {/* 3 Rounded Ribs */}
        {[-12, 8, 28].map((ry, i) => (
          <path
            key={i}
            d={`M ${-34 + i * 3} ${ry} Q 0 ${ry + 10} ${34 - i * 3} ${ry}`}
            fill="none"
            stroke="#F4EFE6"
            strokeWidth={11}
            strokeLinecap="round"
          />
        ))}
        {/* Pelvis */}
        <ellipse cx={0} cy={62} rx={28} ry={14} fill="#F4EFE6" />

        {/* Left & Right Bone Arms + Drumsticks */}
        <g transform={`translate(-38, -16) rotate(${(-25 + hitL).toFixed(2)})`}>
          <line x1={0} y1={0} x2={-42} y2={38} stroke="#F4EFE6" strokeWidth={10} strokeLinecap="round" />
          <circle cx={-42} cy={38} r={7} fill="#F4EFE6" />
          {/* Drumstick L */}
          <line x1={-42} y1={38} x2={-18} y2={76} stroke="#D99B26" strokeWidth={5} strokeLinecap="round" />
          <circle cx={-18} cy={76} r={5} fill="#FFF3D1" />
        </g>
        <g transform={`translate(38, -16) rotate(${(25 + hitR).toFixed(2)})`}>
          <line x1={0} y1={0} x2={42} y2={38} stroke="#F4EFE6" strokeWidth={10} strokeLinecap="round" />
          <circle cx={42} cy={38} r={7} fill="#F4EFE6" />
          {/* Drumstick R */}
          <line x1={42} y1={38} x2={18} y2={76} stroke="#D99B26" strokeWidth={5} strokeLinecap="round" />
          <circle cx={18} cy={76} r={5} fill="#FFF3D1" />
        </g>

        {/* Cute Round Skull Head */}
        <g transform="translate(0, -82)">
          <ellipse cx={0} cy={-8} rx={58} ry={52} fill="#F4EFE6" />
          {/* Skull right shade */}
          <path
            d="M 20 -54 C 62 -42, 62 18, 22 38 Q 42 0 20 -54 Z"
            fill="#DCD3C2"
          />
          {/* Jaw (bounces on beat!) */}
          <rect x={-30} y={24 + jawDrop} width={60} height={26} rx={12} fill="#F4EFE6" />
          {/* Eye sockets with cute glowing white catchlights */}
          <circle cx={-20} cy={-8} r={14} fill="#231B2E" />
          <circle cx={20} cy={-8} r={14} fill="#231B2E" />
          <circle cx={-24} cy={-12} r={4.5} fill="#FFFFFF" />
          <circle cx={16} cy={-12} r={4.5} fill="#FFFFFF" />
          {/* Cute nose heart inverted */}
          <polygon points="0,2 -6,12 6,12" fill="#231B2E" />
          {/* Stitched toothy smile */}
          <path d="M -22 26 Q 0 36 22 26" fill="none" stroke="#231B2E" strokeWidth={4} strokeLinecap="round" />
          {[-12, 0, 12].map((tx, idx) => (
            <line key={idx} x1={tx} y1={23} x2={tx} y2={33} stroke="#231B2E" strokeWidth={3} strokeLinecap="round" />
          ))}
        </g>
      </g>

      {/* Drum Kit in Front */}
      <g transform="translate(0, -45)">
        {/* Cymbal Left & Right */}
        <line x1={-78} y1={42} x2={-78} y2={-48} stroke="#8E96A8" strokeWidth={5} />
        <ellipse
          cx={-78}
          cy={-48}
          rx={34}
          ry={8}
          fill="#FFD23F"
          transform={`rotate(${(-10 + b.sway * 8).toFixed(2)} -78 -48)`}
        />
        <line x1={78} y1={42} x2={78} y2={-38} stroke="#8E96A8" strokeWidth={5} />
        <ellipse
          cx={78}
          cy={-38}
          rx={30}
          ry={7}
          fill="#FFD23F"
          transform={`rotate(${(12 - b.sway * 8).toFixed(2)} 78 -38)`}
        />

        {/* Snare Drum */}
        <rect x={-68} y={-12} width={52} height={32} rx={6} fill="#E8382B" stroke="#FFF3D1" strokeWidth={4} />
        {/* Kick Drum (pulses on beat!) */}
        <g transform={`scale(${(1 + Math.max(0, -b.hop) * 0.06).toFixed(3)})`}>
          <circle cx={0} cy={14} r={44} fill="#B82116" />
          <circle cx={0} cy={14} r={36} fill="#FFF3D1" />
          <circle cx={0} cy={14} r={14} fill="#E8382B" />
        </g>
      </g>
    </g>
  );
};

/**
 * B2: SPINNY — Cute Purple 6-Legged Spider Monster Bassist (beat-locked).
 */
export const SpinnyBassist: React.FC<{
  x: number;
  y: number;
  frame: number;
  fps?: number;
  scale?: number;
}> = ({ x, y, frame, fps = 30, scale = 1 }) => {
  const b = getBeatState(frame, fps);
  const blink = evalAutoBlink(frame, 'spinny');
  const bobY = -b.hop * 9;
  const swayX = b.sway * 8;

  return (
    <g transform={`translate(${(x + swayX).toFixed(2)}, ${y.toFixed(2)}) scale(${scale})`}>
      <ContactShadow width={190} jumpY={0} squash={-b.hop * 0.15} />

      <g transform={`translate(0, ${(-92 + bobY).toFixed(2)}) rotate(${(b.sway * 4).toFixed(2)})`}>
        {/* 4 Lower Spider Legs arched on stage */}
        {[-1, 1].map((side) =>
          [0, 1].map((row) => {
            const sx = side * (56 + row * 12);
            const sy = 10 + row * 18;
            const ex = side * (95 + row * 22);
            const ey = 88 - bobY;
            const mx = side * (86 + row * 18);
            const my = -12 + row * 12;
            return (
              <path
                key={`leg-${side}-${row}`}
                d={`M ${sx} ${sy} Q ${mx} ${my} ${ex} ${ey}`}
                fill="none"
                stroke="#5A33A8"
                strokeWidth={11}
                strokeLinecap="round"
              />
            );
          })
        )}

        {/* Round Purple Spider Body */}
        <ellipse cx={0} cy={0} rx={68} ry={62} fill="#7B4FD0" />
        {/* Inner bottom-right shade */}
        <path
          d="M 20 -55 C 68 -40, 72 35, 15 58 Q -25 62 -48 38 Q 25 35 20 -55 Z"
          fill="#5A33A8"
          opacity={0.65}
        />
        {/* Top-left highlight */}
        <ellipse cx={-26} cy={-32} rx={18} ry={9} fill="#A882F5" opacity={0.45} transform="rotate(-22 -26 -32)" />

        {/* Big Friendly Eyes + Tiny Fangs */}
        <circle cx={-22} cy={-10} r={16} fill="#FFFFFF" />
        <circle cx={22} cy={-10} r={16} fill="#FFFFFF" />
        <circle cx={-20 + b.sway * 2} cy={-10} r={9.5} fill="#1B1B2A" />
        <circle cx={24 + b.sway * 2} cy={-10} r={9.5} fill="#1B1B2A" />
        <circle cx={-23} cy={-14} r={3.5} fill="#FFFFFF" />
        <circle cx={21} cy={-14} r={3.5} fill="#FFFFFF" />
        {blink > 0.2 && (
          <>
            <ellipse cx={-22} cy={-10} rx={17} ry={16 * blink} fill="#7B4FD0" />
            <ellipse cx={22} cy={-10} rx={17} ry={16 * blink} fill="#7B4FD0" />
          </>
        )}

        {/* Rosy Blush & Cute Fang Smile */}
        <ellipse cx={-42} cy={4} rx={10} ry={5.5} fill="#FF85A6" opacity={0.65} />
        <ellipse cx={42} cy={4} rx={10} ry={5.5} fill="#FF85A6" opacity={0.65} />
        <path d="M -16 12 Q 0 22 16 12" fill="none" stroke="#23143B" strokeWidth={4} strokeLinecap="round" />
        <polygon points="-12,14 -8,22 -4,15" fill="#FFFFFF" />
        <polygon points="12,14 8,22 4,15" fill="#FFFFFF" />

        {/* Electric Bass Guitar */}
        <g transform={`translate(8, 22) rotate(${(-24 + b.hop * 4).toFixed(2)})`}>
          {/* Guitar body */}
          <ellipse cx={-18} cy={8} rx={36} ry={24} fill="#C93B2B" />
          <ellipse cx={-12} cy={10} rx={22} ry={14} fill="#FFF3D1" />
          {/* Guitar neck & headstock */}
          <rect x={10} y={-5} width={78} height={10} rx={4} fill="#8A4A22" />
          <ellipse cx={92} cy={0} rx={12} ry={7} fill="#C93B2B" />
          {/* Strings */}
          <line x1={-28} y1={-1} x2={86} y2={-1} stroke="#E2E8F0" strokeWidth={1.5} />
          <line x1={-28} y1={2} x2={86} y2={2} stroke="#E2E8F0" strokeWidth={1.5} />
        </g>

        {/* 2 Upper Spider Arms strumming the bass */}
        <path
          d={`M -58 -8 Q -42 28 ${(-16 + b.hop * 6).toFixed(2)} ${(28 + b.hop * 8).toFixed(2)}`}
          fill="none"
          stroke="#7B4FD0"
          strokeWidth={10}
          strokeLinecap="round"
        />
        <path
          d={`M 54 -8 Q 68 8 ${(52 + b.sway * 6).toFixed(2)} ${(-2 + b.hop * 4).toFixed(2)}`}
          fill="none"
          stroke="#7B4FD0"
          strokeWidth={10}
          strokeLinecap="round"
        />
      </g>
    </g>
  );
};

/**
 * B3: BOO — Soft Floating White Ghost with Wavy Spring Tail & Golden Saxophone.
 */
export const BooSax: React.FC<{
  x: number;
  y: number;
  frame: number;
  fps?: number;
  scale?: number;
}> = ({ x, y, frame, fps = 30, scale = 1 }) => {
  const b = getBeatState(frame, fps);
  const floatY = Math.sin(b.beatFloat * Math.PI) * 16;
  const tailWave = Math.cos(b.beatFloat * Math.PI) * 22;

  return (
    <g transform={`translate(${x.toFixed(2)}, ${y.toFixed(2)}) scale(${scale})`}>
      <ContactShadow width={150} jumpY={35 + floatY} squash={0} opacity={0.18} />

      <g transform={`translate(0, ${(-145 + floatY).toFixed(2)}) rotate(${(b.sway * 5).toFixed(2)})`}>
        {/* Soft White Ghost Body + Wavy Spring Tail */}
        <path
          d={`M -56 -20
              C -58 -95, 58 -95, 56 -20
              C 58 35, 68 65, ${(78 + tailWave).toFixed(2)} 72
              Q ${(42 + tailWave * 0.5).toFixed(2)} 88 18 68
              Q -6 86 -28 68
              Q -54 82 -56 32 Z`}
          fill="#FFFFFF"
        />
        {/* Soft lavender-blue inner shade */}
        <path
          d={`M 24 -72
              C 56 -55, 56 25, ${(74 + tailWave).toFixed(2)} 70
              Q ${(38 + tailWave * 0.5).toFixed(2)} 84 14 66
              Q 35 20 24 -72 Z`}
          fill="#DCD6F0"
          opacity={0.75}
        />

        {/* Happy Closed Playing Eyes & Rosy Cheeks */}
        <path d="M -28 -28 Q -18 -18 -8 -28" fill="none" stroke="#231B2E" strokeWidth={4.5} strokeLinecap="round" />
        <path d="M 8 -28 Q 18 -18 28 -28" fill="none" stroke="#231B2E" strokeWidth={4.5} strokeLinecap="round" />
        <ellipse cx={-34} cy={-18} rx={9} ry={5} fill="#FF9AA8" opacity={0.65} />
        <ellipse cx={34} cy={-18} rx={9} ry={5} fill="#FF9AA8" opacity={0.65} />

        {/* Golden Saxophone (scales slightly with breath puff on beat!) */}
        <g
          transform={`translate(6, -12) rotate(${(-8 + b.hop * 6).toFixed(
            2
          )}) scale(${(1 + Math.max(0, b.hop) * 0.06).toFixed(3)})`}
        >
          {/* Sax neck + J-body + bell */}
          <path
            d="M -6 0 Q 12 4 14 28 L 8 68 Q 6 88 24 88 Q 40 88 42 64"
            fill="none"
            stroke="#F5B82E"
            strokeWidth={13}
            strokeLinecap="round"
          />
          <ellipse cx={43} cy={60} rx={16} ry={10} fill="#FFD23F" transform="rotate(-15 43 60)" />
          <ellipse cx={43} cy={60} rx={10} ry={6} fill="#9E5A10" transform="rotate(-15 43 60)" />
        </g>

        {/* Cute Ghost Hands holding Sax */}
        <path
          d="M -38 8 Q -16 22 4 18"
          fill="none"
          stroke="#DCD6F0"
          strokeWidth={12}
          strokeLinecap="round"
        />
        <path
          d="M 38 8 Q 28 28 14 32"
          fill="none"
          stroke="#DCD6F0"
          strokeWidth={12}
          strokeLinecap="round"
        />
      </g>
    </g>
  );
};

/**
 * M1: PIP — Cute Dark-Purple Bat with Big Pink Ears & Flapping Wings.
 */
export const PipBat: React.FC<{
  x: number;
  y: number;
  frame: number;
  fps?: number;
  scale?: number;
  holdingMiniBurger?: boolean;
}> = ({ x, y, frame, fps = 30, scale = 1, holdingMiniBurger = false }) => {
  const b = getBeatState(frame, fps);
  const blink = evalAutoBlink(frame, 'pip');
  const flapAngle = Math.sin(b.beatFloat * Math.PI * 2) * 28;
  const hoverY = -Math.sin(b.beatFloat * Math.PI * 2) * 14;

  return (
    <g
      transform={`translate(${x.toFixed(2)}, ${(y + hoverY).toFixed(
        2
      )}) scale(${scale})`}
    >
      {/* Left Wing */}
      <g transform={`translate(-28, -6) rotate(${flapAngle.toFixed(2)})`}>
        <path
          d="M 0 0 C -35 -36, -78 -28, -92 4 Q -68 6 -56 22 Q -36 8 -22 24 Q -10 10 0 14 Z"
          fill="#5B3785"
        />
      </g>
      {/* Right Wing */}
      <g transform={`translate(28, -6) rotate(${(-flapAngle).toFixed(2)})`}>
        <path
          d="M 0 0 C 35 -36, 78 -28, 92 4 Q 68 6 56 22 Q 36 8 22 24 Q 10 10 0 14 Z"
          fill="#5B3785"
        />
      </g>

      {/* Big Pointed Bat Ears */}
      <g transform="translate(-26, -34) rotate(-22)">
        <path d="M -16 0 Q -20 -48 0 -58 Q 20 -48 16 0 Z" fill="#4A2B6E" />
        <path d="M -10 -4 Q -12 -38 0 -46 Q 12 -38 10 -4 Z" fill="#E78CA8" />
      </g>
      <g transform="translate(26, -34) rotate(22)">
        <path d="M -16 0 Q -20 -48 0 -58 Q 20 -48 16 0 Z" fill="#4A2B6E" />
        <path d="M -10 -4 Q -12 -38 0 -46 Q 12 -38 10 -4 Z" fill="#E78CA8" />
      </g>

      {/* Round Chubby Bat Body */}
      <ellipse cx={0} cy={0} rx={38} ry={36} fill="#4A2B6E" />
      <ellipse cx={0} cy={12} rx={24} ry={18} fill="#664091" />

      {/* Big Cute Eyes + Tiny Fangs */}
      <circle cx={-14} cy={-8} r={10.5} fill="#FFFFFF" />
      <circle cx={14} cy={-8} r={10.5} fill="#FFFFFF" />
      <circle cx={-13} cy={-8} r={6.5} fill="#1B1B2A" />
      <circle cx={15} cy={-8} r={6.5} fill="#1B1B2A" />
      <circle cx={-15} cy={-11} r={2.5} fill="#FFFFFF" />
      <circle cx={13} cy={-11} r={2.5} fill="#FFFFFF" />
      {blink > 0.2 && (
        <>
          <ellipse cx={-14} cy={-8} rx={11} ry={11 * blink} fill="#4A2B6E" />
          <ellipse cx={14} cy={-8} rx={11} ry={11 * blink} fill="#4A2B6E" />
        </>
      )}

      {/* Cute Pink Bat Nose & Fang Smile */}
      <ellipse cx={0} cy={0} rx={5.5} ry={4} fill="#FF9AA8" />
      <path d="M -12 8 Q 0 15 12 8" fill="none" stroke="#23143B" strokeWidth={3} strokeLinecap="round" />
      <polygon points="-9,10 -6,16 -3,11" fill="#FFFFFF" />
      <polygon points="9,10 6,16 3,11" fill="#FFFFFF" />

      {/* Optional Mini Burger in Intro A (like reference bat holding pizza slice!) */}
      {holdingMiniBurger && (
        <g transform="translate(0, 32)">
          <ellipse cx={0} cy={8} rx={22} ry={8} fill="#E5943A" />
          <rect x={-22} y={0} width={44} height={9} rx={4.5} fill="#6B3418" />
          <path d="M -22 0 L -8 7 L 4 0 L 14 7 L 22 0 Z" fill="#FFC71F" />
          <path d="M -22 -2 C -22 -18, 22 -18, 22 -2 Z" fill="#E5943A" />
        </g>
      )}
    </g>
  );
};
