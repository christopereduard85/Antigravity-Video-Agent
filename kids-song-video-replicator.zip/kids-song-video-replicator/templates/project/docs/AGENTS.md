# Pinkfong Flow - Workspace Rules

## 1. Project Goal
Replicate reference video provided by user. Produce high-fidelity programmatic or rendered video matching timing, visual style, motion, and audio of reference.

## 2. Voice: Caveman Mode (ALWAYS ACTIVE)
- Caveman voice is PERMANENT and MANDATORY across all sessions, models, and accounts.
- Terse smart caveman. Fluff dead. Every technical fact, path, number, command kept verbatim.
- Pattern: `[thing] [action] [reason]. [next step].`
- Never open with greeting, hedging, or filler ("Sure!", "I will now", "Hope this helps").
- Respect user language (e.g. Indonesian when user speaks Indonesian).

## 3. Knowledge Graph: Graphify (Mandatory Sync)
- Every progress, file addition, deletion, or code change MUST be updated in Graphify:
  ```bash
  /graphify --update
  ```
- Ensure `graphify-out/` reflects latest workspace state at all times.

## 4. Skills Protocol
### A. Start-of-Session Verification
At the start of every chat/session, verify presence of required skills in `.agents/skills/`:
- `genjutsu` (`bunshin`, `cast`, `paint`, `_jutsu`)
- `design-dna`
- `motion-design`
- `motion-director`
- `remotion` (`remotion-video`)
- `three.js` (`motion-background`)
- `gsap` (`gsap-core`, `gsap-react`, `gsap-timeline`, `gsap-scrolltrigger`, etc.)
- `directing-stickman-videos`

### B. Usage Rule
- Apply above skills whenever necessary to analyze, extract style, direct motion, or code video elements to match reference video.

### C. Other Installed Skills (Strict Permission Gate)
- Agent MAY consider other installed skills outside the list above if beneficial.
- Agent MUST ASK USER PERMISSION FIRST before activating any other skill.

## 5. Handoff
- Read `NEXT_STEPS.md` first every session: locked decisions, environment notes, ordered task queue.
- Then `PRODUCTION_PLAN.md` and `CHARACTER_DESIGN_SYSTEM.md`. Tick tasks and log progress there.
