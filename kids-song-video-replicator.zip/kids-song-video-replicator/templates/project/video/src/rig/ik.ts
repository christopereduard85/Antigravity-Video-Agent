import { Vec } from './types';
import { add, sub, scale, len, norm, perp, clamp } from './geom';

/**
 * Analytical 2-bone IK solver in 2D.
 * Given root (shoulder/hip), target (hand/foot), bone lengths l1 & l2, and bendSign (+1 or -1),
 * returns the mid-joint (elbow/knee) and clamped end position.
 */
export function solve2BoneIK(
  root: Vec,
  target: Vec,
  l1: number,
  l2: number,
  bendSign: 1 | -1
): { joint: Vec; end: Vec } {
  const diff = sub(target, root);
  const rawDist = len(diff);
  const maxReach = (l1 + l2) * 0.992;
  const minReach = Math.abs(l1 - l2) + 2;
  const d = clamp(rawDist, minReach, maxReach);
  const dir = norm(diff);
  const end = add(root, scale(dir, d));

  // Law of cosines for angle at root
  const cosA = clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1);
  const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));
  const n = scale(perp(dir), bendSign);

  const joint = {
    x: root.x + dir.x * (l1 * cosA) + n.x * (l1 * sinA),
    y: root.y + dir.y * (l1 * sinA === 0 ? l1 * cosA : 0) + (dir.y * (l1 * cosA) + n.y * (l1 * sinA)),
  };

  return { joint, end };
}
