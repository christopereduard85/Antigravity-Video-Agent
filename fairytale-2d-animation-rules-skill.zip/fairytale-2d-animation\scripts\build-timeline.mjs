#!/usr/bin/env node
/**
 * `build-timeline.mjs` — two jobs in one script:
 *
 * 1. Exports `VO-SCRIPT.md` in the project root (100% English): a clean, numbered
 *    recording sheet grouped by character (plus full sequential script) so the user
 *    can record `.mp3` or `.wav` files and drop them into `public/vo/<lineId>.mp3|wav`.
 *
 * 2. Scans `public/vo/` for matching files. For each found audio file:
 *    - Measures exact duration with `ffprobe` / `ffmpeg`
 *    - Decodes 8kHz mono PCM with `ffmpeg` and computes a 30fps RMS mouth-openness
 *      envelope (`0..1`) so character mouths animate in sync with the user's real voice.
 *    - Writes `src/story/timeline.generated.json`.
 *
 * Usage: node scripts/build-timeline.mjs [projectDir]
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const FPS = 30;
const proj = path.resolve(process.argv[2] ?? path.join(import.meta.dirname, "..", "template"));
const voDir = path.join(proj, "public", "vo");
fs.mkdirSync(voDir, { recursive: true });

// Parse dialogue lines from src/story/script.ts (works without compiling TS)
const scriptPath = path.join(proj, "src", "story", "script.ts");
const charsPath = path.join(proj, "src", "story", "characters.ts");
const scriptSrc = fs.readFileSync(scriptPath, "utf8");
const charsSrc = fs.existsSync(charsPath) ? fs.readFileSync(charsPath, "utf8") : "";

// Helper to extract balanced `{ ... }` blocks and quoted string fields safely (supports apostrophes in English!)
function extractBlocks(src) {
  const blocks = [];
  let depth = 0;
  let start = -1;
  let inStr = null;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inStr) {
      if (ch === "\\") i++;
      else if (ch === inStr) inStr = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === "`") inStr = ch;
    else if (ch === "{") {
      if (depth === 1) start = i;
      depth++;
    } else if (ch === "}") {
      depth--;
      if (depth === 1 && start >= 0) {
        blocks.push(src.slice(start, i + 1));
        start = -1;
      }
    }
  }
  return blocks;
}

function readStrField(block, key) {
  const re = new RegExp(`\\b${key}\\s*:\\s*(?:"((?:[^"\\\\]|\\\\.)*)"|'((?:[^'\\\\]|\\\\.)*)')`);
  const m = block.match(re);
  if (!m) return undefined;
  return (m[1] ?? m[2] ?? "").replace(/\\(["'])/g, "$1");
}

// Extract character names & voice notes from CAST
const charInfo = {};
const castIdx = charsSrc.indexOf("CAST");
if (castIdx >= 0) {
  for (const blk of extractBlocks(charsSrc.slice(castIdx))) {
    const id = readStrField(blk, "id");
    const name = readStrField(blk, "name");
    const voice = readStrField(blk, "voice") ?? "";
    if (id && name) charInfo[id] = { id, name, voice };
  }
}

// Extract dialogue lines in order (supports apostrophes like "father's", "don't", "fish's")
const lineObjRe = /\{[^{}]*?\bid\s*:\s*(?:"[^"]+"|'[^']+')[^{}]*?\bspeaker\s*:\s*(?:"[^"]+"|'[^']+')[^{}]*?\bsubtitle\s*:\s*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')[^{}]*?\}/g;
const lines = [];
for (const m of scriptSrc.matchAll(lineObjRe)) {
  const blk = m[0];
  const id = readStrField(blk, "id");
  const speaker = readStrField(blk, "speaker");
  const subtitle = readStrField(blk, "subtitle");
  const voPrompt = readStrField(blk, "voPrompt") ?? subtitle;
  const fbMatch = blk.match(/\bfallbackSec\s*:\s*([0-9.]+)/);
  if (id && speaker && subtitle) {
    lines.push({
      id,
      speaker,
      subtitle,
      voPrompt,
      fallbackSec: fbMatch ? Number(fbMatch[1]) : 2.8,
    });
  }
}

function findVoFile(id) {
  const files = fs.existsSync(voDir) ? fs.readdirSync(voDir) : [];
  const exact = files.find((f) => {
    const base = path.parse(f).name.toLowerCase();
    return base === id.toLowerCase() && /\.(wav|mp3|m4a|ogg)$/i.test(f);
  });
  if (exact) return path.join(voDir, exact);
  // Also allow prefix match like "01.mp3" for "01_narrator_intro"
  const numPrefix = id.match(/^(\d+)/)?.[1];
  if (numPrefix) {
    const byNum = files.find((f) => {
      const base = path.parse(f).name.toLowerCase();
      return (base === numPrefix || base.startsWith(`${numPrefix}_`) || base.startsWith(`${numPrefix}-`)) && /\.(wav|mp3|m4a|ogg)$/i.test(f);
    });
    if (byNum) return path.join(voDir, byNum);
  }
  return null;
}

function analyzeAudio(filePath) {
  const SR = 8000;
  const res = spawnSync(
    "ffmpeg",
    ["-v", "error", "-i", filePath, "-ac", "1", "-ar", String(SR), "-f", "s16le", "-"],
    { maxBuffer: 64 * 1024 * 1024 },
  );
  if (res.status !== 0 || !res.stdout || res.stdout.length === 0) {
    throw new Error(`ffmpeg failed on ${filePath}: ${res.stderr?.toString()}`);
  }
  const buf = res.stdout;
  const totalSamples = Math.floor(buf.length / 2);
  const durationSec = totalSamples / SR;
  const durationFrames = Math.max(15, Math.ceil(durationSec * FPS));
  const spf = Math.max(1, Math.floor(SR / FPS));

  const rawRms = [];
  let peak = 0.01;
  for (let f = 0; f < durationFrames; f++) {
    const s0 = f * spf;
    const s1 = Math.min(totalSamples, s0 + spf);
    let sum = 0;
    for (let i = s0; i < s1; i++) {
      const v = buf.readInt16LE(i * 2) / 32768;
      sum += v * v;
    }
    const rms = s1 > s0 ? Math.sqrt(sum / (s1 - s0)) : 0;
    rawRms.push(rms);
    if (rms > peak) peak = rms;
  }

  // Normalize & smooth into 0..1 mouth openness values
  const env = rawRms.map((r, i) => {
    const prev = rawRms[Math.max(0, i - 1)];
    const next = rawRms[Math.min(rawRms.length - 1, i + 1)];
    const sm = (prev * 0.25 + r * 0.5 + next * 0.25) / peak;
    const gated = sm < 0.08 ? 0 : Math.min(1, Math.pow((sm - 0.08) / 0.75, 0.75));
    return Number(gated.toFixed(2));
  });

  return { durationFrames, env };
}

const timeline = {
  generatedAt: new Date().toISOString(),
  lines: {},
};

let foundCount = 0;
let estTotalSec = 17.5; // intro + title + outro bumpers
for (const l of lines) {
  const file = findVoFile(l.id);
  if (file) {
    const { durationFrames, env } = analyzeAudio(file);
    timeline.lines[l.id] = {
      id: l.id,
      audioFile: `vo/${path.basename(file)}`,
      durationFrames,
      env,
    };
    estTotalSec += durationFrames / FPS + 0.25;
    foundCount++;
  } else {
    estTotalSec += (l.fallbackSec ?? 2.8) + 0.25;
  }
}

const outTimeline = path.join(proj, "src", "story", "timeline.generated.json");
fs.writeFileSync(outTimeline, JSON.stringify(timeline, null, 2) + "\n");

// Write English VO-SCRIPT.md for the user
const bySpeaker = {};
for (const l of lines) {
  (bySpeaker[l.speaker] ??= []).push(l);
}

let md = `# Voice Over Recording Script (English)\n\n`;
md += `Save your recorded Voice-Over audio files (**.wav** or **.mp3**) into:\n`;
md += `\`public/vo/\`\n\n`;
md += `You can name each file by its full ID (e.g. \`01_timun_intro.wav\`) or just its line number (\`01.wav\` / \`01.mp3\`).\n`;
md += `Once dropped into \`public/vo/\`, run \`npm run timeline\` and then \`npm run render\`.\n\n`;
md += `- **Total Dialogue Lines**: ${lines.length}\n`;
md += `- **Estimated Episode Duration**: ~${(estTotalSec / 60).toFixed(1)} minutes (${Math.round(estTotalSec)}s)\n\n`;

md += `## Character Voice Cast & Acting Notes\n\n`;
for (const sp of Object.keys(bySpeaker)) {
  const info = charInfo[sp] ?? { name: sp, voice: "" };
  md += `- **${info.name}** (\`${sp}\`) — ${info.voice || "Expressive storybook character voice"} (${bySpeaker[sp].length} lines)\n`;
}

md += `\n## Full Sequential Dialogue Script (By Shot Order)\n\n`;
md += `| File Name | Speaker | Voice Acting Prompt & Line (English) | On-Screen Subtitle | Audio Status |\n`;
md += `| --- | --- | --- | --- | --- |\n`;
for (const l of lines) {
  const info = charInfo[l.speaker] ?? { name: l.speaker };
  const hit = timeline.lines[l.id];
  const status = hit ? `OK (${(hit.durationFrames / FPS).toFixed(1)}s)` : `Pending (fallback ${l.fallbackSec}s)`;
  md += `| \`${l.id}.wav\` | **${info.name}** | ${l.voPrompt} | "${l.subtitle}" | ${status} |\n`;
}

md += `\n## Lines Grouped by Character (For Batch Recording)\n\n`;
for (const [sp, list] of Object.entries(bySpeaker)) {
  const info = charInfo[sp] ?? { name: sp, voice: "" };
  md += `### ${info.name} (\`${sp}\`)\n`;
  if (info.voice) md += `> Voice Direction: ${info.voice}\n\n`;
  for (const l of list) {
    md += `- **\`${l.id}.wav\`**: ${l.voPrompt}\n`;
  }
  md += `\n`;
}

fs.writeFileSync(path.join(proj, "VO-SCRIPT.md"), md);
console.log(`Timeline updated: ${foundCount}/${lines.length} VO files matched -> ${outTimeline}`);
console.log(`VO script exported -> ${path.join(proj, "VO-SCRIPT.md")}`);
