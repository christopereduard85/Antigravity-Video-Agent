import React from 'react';
import { Character } from '../../rig/Character';
import { Pose } from '../../rig/types';
import { grubTokens } from './tokens';
import { hotDogCostume } from './costume/HotDog';

export interface GrubProps {
  pose: Pose;
  frame: number;
  fps?: number;
  costume?: 'none' | 'hotdog';
  hasMic?: boolean;
  hatTipProgress?: number;
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId?: string;
}

export const Grub: React.FC<GrubProps> = ({
  pose,
  frame,
  fps = 30,
  costume = 'none',
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1,
  instanceId = 'grub',
}) => {
  return (
    <Character
      tokens={grubTokens}
      pose={pose}
      frame={frame}
      fps={fps}
      costume={costume === 'hotdog' ? hotDogCostume : null}
      hasMic={hasMic}
      hatTipProgress={hatTipProgress}
      hasCandyBucket={hasCandyBucket}
      scale={scale}
      instanceId={instanceId}
    />
  );
};
