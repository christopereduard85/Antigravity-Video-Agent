// ============================================================================
// WORD-BY-WORD INK-OUTLINED CAPTIONS (matches reference style).
// Groups very short function words ("in the", "out of", "a hole") with their
// neighbor when spoken rapidly so captions read naturally at 1-2 words per pop.
// ============================================================================
import React, { useMemo } from 'react';
import { INK } from './drawCharacter';
import { WORDS, type Word } from './timing';
import { clamp, spring } from './util';

type CaptionPhrase = {
  text: string;
  start: number;
  end: number;
};

const SHORT_GLUE = new Set([
  'a', 'an', 'the', 'in', 'on', 'at', 'to', 'of', 'by', 'or', 'so', 'as', 'is', 'it', 'be', 'no', 'up', 'if', 'my', 'he', 'we',
]);

function buildPhrases(words: Word[]): CaptionPhrase[] {
  const out: CaptionPhrase[] = [];
  let i = 0;
  while (i < words.length) {
    const w0 = words[i];
    const clean0 = w0.w.replace(/[^a-zA-Z']/g, '').toLowerCase();
    const hasPunct = /[.,!?;:—\-]$/.test(w0.w);
    const w1 = i + 1 < words.length ? words[i + 1] : null;
    if (
      w1 &&
      !hasPunct &&
      w1.start - w0.end < 0.14 &&
      w0.w.length + w1.w.length <= 12 &&
      (SHORT_GLUE.has(clean0) || w0.end - w0.start < 0.17)
    ) {
      out.push({
        text: `${w0.w} ${w1.w}`,
        start: w0.start,
        end: w1.end,
      });
      i += 2;
    } else {
      out.push({
        text: w0.w,
        start: w0.start,
        end: w0.end,
      });
      i += 1;
    }
  }
  return out;
}

export const Captions: React.FC<{ t: number; isPortrait: boolean }> = ({ t, isPortrait }) => {
  const phrases = useMemo(() => buildPhrases(WORDS), []);

  let active: CaptionPhrase | null = null;
  for (let i = 0; i < phrases.length; i++) {
    const p = phrases[i];
    const nextStart = i + 1 < phrases.length ? phrases[i + 1].start : p.end + 0.25;
    const holdEnd = Math.min(nextStart, p.end + 0.18);
    if (t >= p.start && t < holdEnd) {
      active = p;
      break;
    }
  }

  if (!active) return null;

  const dt = Math.max(0, t - active.start);
  const scale = 0.92 + 0.08 * clamp(spring(dt, 4, 7), 0, 1.15);
  const fontSize = isPortrait ? 52 : 44;

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: isPortrait ? '20.5%' : '14%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          transform: `scale(${scale.toFixed(3)})`,
          fontFamily: 'Montserrat, "Arial Black", sans-serif',
          fontWeight: 900,
          fontSize,
          lineHeight: 1.1,
          color: '#FFFFFF',
          WebkitTextStroke: `11px ${INK}`,
          paintOrder: 'stroke fill',
          textShadow: `0 5px 0 ${INK}, 0 8px 18px rgba(0,0,0,0.45)`,
          letterSpacing: '-0.01em',
          padding: '4px 18px',
          textAlign: 'center',
        }}
      >
        {active.text}
      </div>
    </div>
  );
};
