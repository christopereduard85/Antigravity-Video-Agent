import React from 'react';
import { Character } from '../../rig/Character';
import { Pose } from '../../rig/types';
import { luluTokens } from './tokens';
import { iceCreamCostume } from './costume/IceCream';

export interface LuluProps {
  pose: Pose;
  frame: number;
  fps?: number;
  costume?: 'none' | 'icecream';
  hasMic?: boolean;
  hatTipProgress?: number;
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId?: string;
}

export const Lulu: React.FC<LuluProps> = ({
  pose,
  frame,
  fps = 30,
  costume = 'none',
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1,
  instanceId = 'lulu',
}) => {
  return (
    <Character
      tokens={luluTokens}
      pose={pose}
      frame={frame}
      fps={fps}
      costume={costume === 'icecream' ? iceCreamCostume : null}
      hasMic={hasMic}
      hatTipProgress={hatTipProgress}
      hasCandyBucket={hasCandyBucket}
      scale={scale}
      instanceId={instanceId}
    />
  );
};
