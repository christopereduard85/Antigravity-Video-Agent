"""Auto-align each lyric line to real vocal onsets in Halloween Night.wav.
Shifts every line (whole template) by the offset (-0.6..+0.6s) that best matches
word starts to vocal-band onset strength. Then copies to video/src/data/."""
import json, shutil
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfiltfilt, stft

sr, x = wavfile.read('Halloween Night.wav')
x = x.astype(np.float64)
mid = (x[:, 0] + x[:, 1]) * 0.5
side = (x[:, 0] - x[:, 1]) * 0.5
voc = sosfiltfilt(butter(4, [300, 4000], btype='bandpass', fs=sr, output='sos'), mid - 0.85 * side)

hop = 441  # 10 ms
f, t, Z = stft(voc, fs=sr, nperseg=2048, noverlap=2048 - hop)
S = np.log1p(np.abs(Z) * 50)
flux = np.maximum(0, np.diff(S, axis=1)).sum(axis=0)
flux = np.concatenate([[0], flux])
flux = (flux - np.median(flux)) / (flux.std() + 1e-9)
flux = np.clip(flux, 0, None)
fr = sr / hop  # 100 fps

def score(times):
    s = 0.0
    for tt in times:
        i = int(round(tt * fr))
        if 0 <= i < len(flux):
            s += flux[max(0, i - 3):i + 4].max()  # +-30 ms tolerance
    return s

lyr = json.load(open('analysis/lyrics_timed.json', encoding='utf-8'))
shifts = np.arange(-0.4, 0.401, 0.01)
# One shift per section (4 lines share the beat grid) -> robust vs drum hits
groups = {}
for line in lyr:
    groups.setdefault(line['section'], []).append(line)
for sid, lines in groups.items():
    starts = [w['startSec'] for l in lines for w in l['words']]
    sc = [score([s + d for s in starts]) for d in shifts]
    best = float(shifts[int(np.argmax(sc))])
    for line in lines:
        for w in line['words']:
            w['startSec'] = round(w['startSec'] + best, 3)
            w['endSec'] = round(w['endSec'] + best, 3)
        line['startSec'] = line['words'][0]['startSec']
        line['endSec'] = line['words'][-1]['endSec']
    print(f"{sid:3s} shift {best:+.2f}s -> first line {lines[0]['startSec']:7.2f}s")

# no overlaps between consecutive lines
for a, b in zip(lyr, lyr[1:]):
    if a['endSec'] > b['startSec'] - 0.03:
        a['endSec'] = round(b['startSec'] - 0.03, 3)
        a['words'][-1]['endSec'] = max(a['words'][-1]['startSec'] + 0.08, a['endSec'])
for l in lyr:
    l['startFrame'] = int(round(l['startSec'] * 30))
    l['endFrame'] = int(round(l['endSec'] * 30))

json.dump(lyr, open('analysis/lyrics_timed.json', 'w', encoding='utf-8'), indent=2)
shutil.copy('analysis/lyrics_timed.json', 'video/src/data/lyrics_timed.json')
print('OK')
