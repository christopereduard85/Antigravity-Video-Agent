import React from 'react';
import { CostumeLayerProps, CostumeSpec } from '../../../rig/types';
import { getSquashStretch } from '../../../rig/geom';
import { theme } from '../../../theme';

const dn = theme.foods.donut;

/**
 * Ziggy's Sprinkled Donut Costume:
 * Giant golden donut with glossy wavy pink frosting and colorful sprinkles encircling Ziggy's torso,
 * leaving a cute upper-center window so all 3 of Ziggy's eyes and his mouth stay clearly visible!
 */
const DonutBack: React.FC<CostumeLayerProps> = ({ bodyW, squash, arc }) => {
  const { sx, sy } = getSquashStretch(squash);
  const rOuter = bodyW * 0.72 * sx;
  const shiftX = arc * 12;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, 8)`}>
      <ellipse
        cx={0}
        cy={0}
        rx={rOuter * 1.04}
        ry={rOuter * 0.96 * sy}
        fill="#C98838"
      />
    </g>
  );
};

const DonutFront: React.FC<CostumeLayerProps> = ({
  bodyW,
  squash,
  arc,
}) => {
  const { sx, sy } = getSquashStretch(squash);
  const rx = bodyW * 0.72 * sx;
  const ry = bodyW * 0.68 * sy;
  const holeRx = bodyW * 0.48 * sx;
  const holeRy = bodyW * 0.36 * sy;
  const holeY = -12 * sy;
  const shiftX = arc * 14;

  // Outer ring minus inner face window (even-odd fill rule)
  const doughRing = `M ${(-rx).toFixed(2)} 6
    A ${rx.toFixed(2)} ${ry.toFixed(2)} 0 1 0 ${rx.toFixed(2)} 6
    A ${rx.toFixed(2)} ${ry.toFixed(2)} 0 1 0 ${(-rx).toFixed(2)} 6 Z
    M ${(-holeRx).toFixed(2)} ${holeY.toFixed(2)}
    A ${holeRx.toFixed(2)} ${holeRy.toFixed(2)} 0 1 1 ${holeRx.toFixed(2)} ${holeY.toFixed(2)}
    A ${holeRx.toFixed(2)} ${holeRy.toFixed(2)} 0 1 1 ${(-holeRx).toFixed(2)} ${holeY.toFixed(2)} Z`;

  const irx = rx * 0.92;
  const iry = ry * 0.9;
  const icingRing = `M ${(-irx).toFixed(2)} 4
    A ${irx.toFixed(2)} ${iry.toFixed(2)} 0 1 0 ${irx.toFixed(2)} 4
    A ${irx.toFixed(2)} ${iry.toFixed(2)} 0 1 0 ${(-irx).toFixed(2)} 4 Z
    M ${(-holeRx * 1.05).toFixed(2)} ${holeY.toFixed(2)}
    A ${(holeRx * 1.05).toFixed(2)} ${(holeRy * 1.05).toFixed(2)} 0 1 1 ${(
    holeRx * 1.05
  ).toFixed(2)} ${holeY.toFixed(2)}
    A ${(holeRx * 1.05).toFixed(2)} ${(holeRy * 1.05).toFixed(2)} 0 1 1 ${(
    -holeRx * 1.05
  ).toFixed(2)} ${holeY.toFixed(2)} Z`;

  const sprinkles = [
    { a: -145, r: 0.78, rot: 25, col: dn.sprinkles[0] },
    { a: -115, r: 0.82, rot: -15, col: dn.sprinkles[1] },
    { a: -85, r: 0.8, rot: 10, col: dn.sprinkles[2] },
    { a: -55, r: 0.82, rot: -30, col: dn.sprinkles[3] },
    { a: -25, r: 0.78, rot: 20, col: dn.sprinkles[4] },
    { a: 15, r: 0.76, rot: -22, col: dn.sprinkles[0] },
    { a: 45, r: 0.74, rot: 35, col: dn.sprinkles[1] },
    { a: 72, r: 0.72, rot: -12, col: dn.sprinkles[2] },
    { a: 98, r: 0.75, rot: 18, col: dn.sprinkles[3] },
    { a: 128, r: 0.74, rot: -28, col: dn.sprinkles[4] },
    { a: 162, r: 0.76, rot: 15, col: dn.sprinkles[0] },
    { a: 85, r: 0.56, rot: -8, col: dn.sprinkles[1] },
    { a: 112, r: 0.56, rot: 22, col: dn.sprinkles[4] },
    { a: 62, r: 0.55, rot: -18, col: dn.sprinkles[0] },
  ];

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, 0)`}>
      {/* Golden Donut Dough Ring */}
      <path d={doughRing} fill={dn.dough} fillRule="evenodd" />

      {/* Glossy Pink Icing Ring */}
      <path d={icingRing} fill={dn.icing} fillRule="evenodd" />

      {/* Glossy Top-Left Highlight Arc on Pink Icing */}
      <path
        d={`M ${(-irx * 0.76).toFixed(2)} ${(-iry * 0.35).toFixed(2)} A ${(
          irx * 0.78
        ).toFixed(2)} ${(iry * 0.78).toFixed(2)} 0 0 1 ${(-irx * 0.2).toFixed(
          2
        )} ${(-iry * 0.82).toFixed(2)}`}
        fill="none"
        stroke="#FFAAD2"
        strokeWidth={9}
        strokeLinecap="round"
        opacity={0.65}
      />

      {/* Colorful Sprinkles */}
      {sprinkles.map((s, idx) => {
        const rad = (s.a * Math.PI) / 180;
        const sxPos = Math.cos(rad) * rx * s.r;
        const syPos = Math.sin(rad) * ry * s.r + 4;
        return (
          <rect
            key={idx}
            x={sxPos - 7}
            y={syPos - 3}
            width={14}
            height={6}
            rx={3}
            fill={s.col}
            transform={`rotate(${s.rot} ${sxPos.toFixed(2)} ${syPos.toFixed(2)})`}
          />
        );
      })}
    </g>
  );
};

export const donutCostume: CostumeSpec = {
  Back: DonutBack,
  Front: DonutFront,
  hideAppendages: false, // Ziggy's cute horns poke above the donut!
};
