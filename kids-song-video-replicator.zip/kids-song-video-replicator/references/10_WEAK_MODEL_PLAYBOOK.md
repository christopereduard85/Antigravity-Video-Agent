# 10 — Playbook for Smaller / Weaker AI Models (Step-by-Step SOP)

> **IF YOU ARE A SMALL, FAST, OR NON-REASONING MODEL: FOLLOW THIS CHECKLIST LITERALLY.**
> Do NOT invent a new folder structure. Do NOT rewrite the rig engine (`video/src/rig/*`). Do NOT guess timestamps.

---

## Rule #1: What You NEVER Edit vs What You DO Edit

### NEVER EDIT THESE FILES (The Engine — 100% Reusable):
- `video/src/rig/types.ts`
- `video/src/rig/geom.ts` (superellipse body deformation + volume preservation `sx * sy = 1`)
- `video/src/rig/ik.ts` (2-bone analytic limb solver)
- `video/src/rig/spring.ts` (deterministic spring swings, saccades, auto-blink)
- `video/src/rig/beat.ts` (`getBeatState(frame, fps)` beat & bar phase calculator)
- `video/src/rig/Body.tsx`, `Shading.tsx`, `Limb.tsx`, `Eyes.tsx`, `Mouth.tsx`, `Appendage.tsx`, `ContactShadow.tsx`, `Character.tsx`
- `video/src/rig/poses.ts`, `video/src/rig/actions.tsx` (`makeBeatDancePose`, `evalSpinTransform`, `TornadoSwirl`)
- `video/src/camera/CameraRig.tsx`
- `video/src/timeline.ts` (`getSectionAtFrame`, `getLyricAtFrame`)

### ONLY EDIT THESE FILES FOR A NEW VIDEO:
1. `analysis/audio_beats.py` → Change the `.wav` filename on line 7.
2. `analysis/build_timing.py` → Update:
   - `n_frames` / `totalFrames` = `round(durationSec * 30)`
   - `section_defs` = list of `(id, label, startSec, endSec, hero)`
   - `SEC_TEMPLATES` = word timing offsets `(word, relStartSec, relEndSec)` per phrase pattern
   - `lyric_specs` & `STARTS` = exact vocal onset in seconds for each lyric line
3. `video/src/theme.ts` → Update `durationInFrames` and color palette hex codes if needed.
4. `video/src/characters/<hero>/tokens.ts` & `costume/<Food>.tsx` → Adjust character colors, body width/height, or costume SVG shapes.
5. `video/src/Root.tsx` → Update `CHORUS_CUT_TRANSITIONS` (`cutFrame` MUST equal the endFrame of each Chorus `K1..K4` from `build_timing.py`).
6. `video/src/ui/LogoBug.tsx` → Change the watermark string (default: `"edufam"`).

---

## Rule #2: Exact Math Formulas (Never Guess)

1. **Seconds to Frame (30 fps)**:
   ```python
   frame = int(round(seconds * 30))
   ```
2. **Remotion Studio Timecode `MM:SS.FF` to Frame**:
   - When the user sends a screenshot showing `01:17.18` in Remotion Studio:
   - `MM = 1`, `SS = 17`, `FF = 18` (frames, NOT hundredths of a second!)
   - `frame = (1 * 60 + 17) * 30 + 18 = 77 * 30 + 18 = 2328`
3. **Contiguous Sections (Zero-Gap Law)**:
   - Every section's `startFrame` MUST equal the previous section's `endFrame`:
   ```python
   prev_frame = 0
   for i, (sid, label, s0, s1, hero) in enumerate(section_defs):
       f0 = prev_frame
       f1 = TOTAL_FRAMES if i == len(section_defs) - 1 else int(round(s1 * 30))
       prev_frame = f1
   ```
   - Why: If there is even a 1-frame gap between `K3` and `C4`, `getSectionAtFrame()` will fall back to another section and flash a rogue 1-frame glitch!
4. **Straddling Wipe Cut Frame Law**:
   - Every wipe in `CHORUS_CUT_TRANSITIONS` in `video/src/Root.tsx` spans `[cutFrame - 14, cutFrame + 14]`.
   - At `frame === cutFrame`, the wipe covers 100% of the screen (`progress = 0.5`).
   - Therefore, `cutFrame` MUST equal `K_section.endFrame` (which is also `next_section.startFrame`).

---

## Rule #3: How to Fix User Timing Complaints in 60 Seconds

When the user says:
- **"Lyric terlambat / telat" (Lyrics are late)**:
  1. Do NOT touch `SingAlongOverlays.tsx`.
  2. Open `analysis/build_timing.py` and look at `STARTS = [...]`.
  3. Subtract `0.35` to `0.45` seconds from the affected verse/chorus numbers in `STARTS`.
  4. Run `python analysis/build_timing.py`.
  5. Render 1 still frame to verify.
- **"Lyric kecepatan" (Lyrics are too fast / early)**:
  1. Check if there is an instrumental break, drum roll, or trumpet spin before the singing starts!
  2. Slice the audio around that timestamp (`ffmpeg -y -ss 75 -t 15 -i song.wav slice.mp3`) or check `analysis/whisper.srt`.
  3. Set the `STARTS` entries for that block to the real vocal onset timestamp.
  4. Run `python analysis/build_timing.py`.

---

## Rule #4: 10-Point Self-Audit Before Replying to User

Before you tell the user a task is done, verify ALL 10 items:
- [ ] `tsc -p video/tsconfig.json --noEmit` exits with code `0`.
- [ ] `analysis/beats.json` and `video/src/data/beats.json` are identical (`shutil.copy` ran).
- [ ] `analysis/lyrics_timed.json` and `video/src/data/lyrics_timed.json` are identical.
- [ ] Every section in `beats.json` has `sections[i].endFrame == sections[i+1].startFrame`.
- [ ] Every `cutFrame` in `Root.tsx` (`CHORUS_CUT_TRANSITIONS`) matches its chorus `endFrame` in `beats.json`.
- [ ] Rendered at least 1 PNG still (`remotion still`) and visually inspected it using `read_file`.
- [ ] No transparency checkerboard visible on any edge of the rendered PNG still.
- [ ] Karaoke bar at `y=995..1065` does not overlap the character's feet (`y=870`).
- [ ] Die-cut character/food stickers (`y=125..135`) and `edufam` watermark (`LogoBug.tsx`) never cover the center character (`x=400..1520, y=250..950`).
- [ ] Updated `NEXT_STEPS.md` and `PRODUCTION_PLAN.md` §6 status table.
