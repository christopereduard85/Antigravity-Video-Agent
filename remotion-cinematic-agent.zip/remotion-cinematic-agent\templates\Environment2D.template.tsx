import React from 'react';
import { THEME } from '../../constants/theme';

interface HallwayProps {
  flicker?: number;
}

export const Hallway: React.FC<HallwayProps> = ({ flicker = 1 }) => {
  // Tata letak lorong 1920x1080 yang presisi:
  // Pintu 402 di kiri (x=360), Pintu 404 (Kamar David) di kanan (x=1180)
  const doors = [
    { x: 360, num: '402' },
    { x: 1180, num: '404' }, // Pintu Kamar David
  ];

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        backgroundColor: THEME.colors.bgDeep,
        overflow: 'hidden',
        zIndex: 5,
      }}
    >
      {/* 1. Dinding Belakang dengan Gradien Malam */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '740px',
          background: `linear-gradient(180deg, ${THEME.colors.bgDark} 0%, ${THEME.colors.bgMid} 60%, ${THEME.colors.bgLight} 100%)`,
        }}
      />

      {/* 2. Plin Dinding (Skirting) */}
      <div
        style={{
          position: 'absolute',
          top: '730px',
          left: 0,
          right: 0,
          height: '14px',
          backgroundColor: THEME.colors.wallTrim,
          borderBottom: `2px solid ${THEME.colors.floorBase}`,
        }}
      />

      {/* 3. Lantai Reflektif */}
      <div
        style={{
          position: 'absolute',
          top: '744px',
          left: 0,
          right: 0,
          bottom: 0,
          background: `linear-gradient(180deg, ${THEME.colors.floorReflect} 0%, ${THEME.colors.floorBase} 70%)`,
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 240px, rgba(255,255,255,0.015) 240px, rgba(255,255,255,0.015) 242px)`,
          }}
        />
      </div>

      {/* 4. Deretan Pintu 402 & 404 */}
      {doors.map((door, idx) => (
        <React.Fragment key={idx}>
          {/* Daun Pintu */}
          <div
            style={{
              position: 'absolute',
              left: `${door.x}px`,
              top: '210px',
              width: '380px',
              height: '522px',
              backgroundColor: THEME.colors.doorFrame,
              borderRadius: '4px 4px 0 0',
              boxShadow: 'inset 0 0 25px rgba(0,0,0,0.85), 0 10px 30px rgba(0,0,0,0.6)',
              border: '4px solid #1E2840',
            }}
          >
            <div
              style={{
                position: 'absolute',
                inset: '8px',
                backgroundColor: THEME.colors.doorWood,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                boxShadow: 'inset 0 0 15px rgba(0,0,0,0.5)',
              }}
            >
              {/* Nomor Pintu Kuningan */}
              <div
                style={{
                  marginTop: '45px',
                  padding: '6px 24px',
                  backgroundColor: '#0F1524',
                  borderRadius: '4px',
                  border: `1.5px solid ${THEME.colors.doorGold}`,
                  boxShadow: `0 0 12px rgba(194, 155, 56, 0.35)`,
                }}
              >
                <span
                  style={{
                    fontFamily: THEME.typography.fontFamily,
                    fontWeight: 800,
                    fontSize: '28px',
                    color: THEME.colors.doorGold,
                    letterSpacing: '5px',
                  }}
                >
                  {door.num}
                </span>
              </div>

              {/* Panel Pintu Atas */}
              <div
                style={{
                  marginTop: '30px',
                  width: '82%',
                  height: '140px',
                  border: '2px solid rgba(255,255,255,0.04)',
                  borderRadius: '2px',
                  boxShadow: 'inset 2px 2px 5px rgba(0,0,0,0.4)',
                }}
              />

              {/* Gagang Pintu Logam */}
              <div
                style={{
                  position: 'absolute',
                  right: '25px',
                  top: '280px',
                  width: '14px',
                  height: '55px',
                  backgroundColor: '#7A889B',
                  borderRadius: '7px',
                  boxShadow: '2px 2px 6px rgba(0,0,0,0.7)',
                }}
              >
                <div
                  style={{
                    position: 'absolute',
                    left: '-26px',
                    top: '6px',
                    width: '32px',
                    height: '8px',
                    backgroundColor: '#9AA7B8',
                    borderRadius: '4px',
                  }}
                />
              </div>

              {/* Panel Pintu Bawah */}
              <div
                style={{
                  marginTop: '35px',
                  width: '82%',
                  height: '170px',
                  border: '2px solid rgba(255,255,255,0.04)',
                  borderRadius: '2px',
                  boxShadow: 'inset 2px 2px 5px rgba(0,0,0,0.4)',
                }}
              />

              {/* Celah Bawah Pintu Menyala */}
              <div
                style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: '4px',
                  backgroundColor: '#FFD166',
                  boxShadow: '0 0 16px #FFD166, 0 4px 20px rgba(255, 209, 102, 0.6)',
                  opacity: 0.85,
                }}
              />
            </div>
          </div>

          {/* Lampu Plafon */}
          <div
            style={{
              position: 'absolute',
              left: `${door.x + 140}px`,
              top: 0,
              width: '100px',
              height: '24px',
              backgroundColor: '#1E2638',
              borderRadius: '0 0 10px 10px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 10,
            }}
          >
            <div
              style={{
                width: '60px',
                height: '12px',
                backgroundColor: THEME.colors.ceilingLamp,
                borderRadius: '0 0 6px 6px',
                boxShadow: `0 0 25px ${THEME.colors.ceilingLamp}, 0 0 50px rgba(255, 246, 214, 0.6)`,
                opacity: door.num === '404' ? flicker : 1,
              }}
            />
          </div>

          {/* Volumetric Cone Lampu */}
          <div
            style={{
              position: 'absolute',
              left: `${door.x - 170}px`,
              top: '20px',
              width: '720px',
              height: '724px',
              clipPath: 'polygon(45% 0%, 55% 0%, 100% 100%, 0% 100%)',
              background:
                'linear-gradient(180deg, rgba(255, 246, 214, 0.16) 0%, rgba(200, 220, 255, 0.04) 60%, transparent 100%)',
              pointerEvents: 'none',
              opacity: door.num === '404' ? flicker : 1,
              zIndex: 8,
            }}
          />

          {/* Pantulan Lampu di Lantai */}
          <div
            style={{
              position: 'absolute',
              left: `${door.x + 30}px`,
              top: '744px',
              width: '320px',
              height: '140px',
              background:
                'radial-gradient(ellipse at center top, rgba(255, 246, 214, 0.12) 0%, transparent 70%)',
              opacity: door.num === '404' ? flicker : 1,
              pointerEvents: 'none',
            }}
          />
        </React.Fragment>
      ))}
    </div>
  );
};
