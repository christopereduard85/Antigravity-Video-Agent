// ============================================================================
// 2D CHARACTER DRAWING (Canvas 2D). Bean body, big round head, stick limbs,
// thick ink outline. Drawn in canonical "facing right" orientation; facing left
// is a horizontal mirror. Units: U = character height (feet y=0, top of head
// y=-1). y grows DOWN (canvas convention).
// ============================================================================
import type { CharacterDesign, Emote, Face, Item } from './types';
import { shade } from './util';

export const INK = '#1b1622';
export const CANVAS_UNITS = 1.6; // canvas is 1.6U x 1.6U
export const FOOT_FROM_BOTTOM = 0.12; // feet baseline 0.12U above canvas bottom

export type Limb = [number, number];
export type Pose = {
  x: number; // horizontal offset (U)
  y: number; // lift (U, positive = up)
  lean: number; // radians, + = lean forward (toward facing)
  squash: number; // 1 normal, <1 squashed, >1 stretched
  aF: Limb; // front arm [shoulder, elbow]
  aB: Limb; // back arm
  lF: Limb; // front leg [hip, knee]
  lB: Limb; // back leg
  head: number; // head tilt radians
  headY: number; // head bob (U, + = down)
  rot: number; // whole-body rotation radians (fall/tumble/spin)
  mouth: number; // 0..1 mouth open (talking)
  sit: number; // 0..1 sitting amount
  lie: number; // 0..1 lying down amount (rot handled by caller)
  shiver: number; // 0..1
};

export const BASE_POSE: Pose = {
  x: 0, y: 0, lean: 0, squash: 1,
  aF: [0.18, 0.15], aB: [0.18, 0.15], lF: [0.04, 0], lB: [0.04, 0],
  head: 0, headY: 0, rot: 0, mouth: 0, sit: 0, lie: 0, shiver: 0,
};

export type DrawState = {
  pose: Pose;
  face: Face;
  facing: 1 | -1 | 0 | 2; // 1 right, -1 left, 0 front, 2 back
  blink: boolean;
  item: Item;
  itemText?: string;
  emote: Emote;
  emoteT: number; // seconds since emote started
  t: number; // global seconds (for wobbly bits)
  tint?: string;
};

const LW = 0.019; // ink line width for shapes
const LIMB = 0.017; // limb width

// ---------------------------------------------------------------------------
export function drawCharacter(ctx: CanvasRenderingContext2D, size: number, d: CharacterDesign, s: DrawState) {
  const S = size / CANVAS_UNITS;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, size, size);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const p = s.pose;
  const mirror = s.facing === -1 ? -1 : 1;
  // origin at feet, U units
  ctx.setTransform(S * mirror, 0, 0, S, size / 2 + p.x * S * mirror, size - FOOT_FROM_BOTTOM * S);
  ctx.translate(0, -p.y);
  if (p.shiver) ctx.translate(Math.sin(s.t * 70) * 0.006 * p.shiver, 0);
  // whole-body rotation around the body centre
  if (p.rot) {
    ctx.translate(0, -0.45);
    ctx.rotate(p.rot);
    ctx.translate(0, 0.45);
  }

  const H = d.height ?? 1;
  const W = d.width ?? 1;
  const side = s.facing === 1 || s.facing === -1;
  const back = s.facing === 2;

  // squash & stretch around feet
  ctx.scale(1 / Math.sqrt(p.squash), p.squash);

  // geometry
  const legLen = 0.15 * (0.85 + 0.15 * H);
  const sitDrop = p.sit * legLen * 1.1;
  const hipY = -0.3 * (0.85 + 0.15 * H) + sitDrop;
  const bodyW = 0.27 * W;
  const bodyTop = hipY - 0.36 * (0.9 + 0.1 * H);
  const bodyBot = hipY + 0.035;
  const robe = d.pattern === 'robe';

  // lean: rotate upper body around hips
  const upper = () => {
    ctx.translate(0, hipY);
    ctx.rotate(p.lean);
    ctx.translate(0, -hipY);
  };

  // cape behind everything
  if (d.extras?.includes('cape')) {
    ctx.save();
    upper();
    blob(ctx, () => {
      ctx.moveTo(-bodyW * 0.45, bodyTop + 0.06);
      ctx.quadraticCurveTo(-bodyW * 0.9 - Math.sin(s.t * 3) * 0.02, hipY + 0.05, -bodyW * 0.75, hipY + 0.16);
      ctx.lineTo(bodyW * 0.4, hipY + 0.14);
      ctx.lineTo(bodyW * 0.45, bodyTop + 0.06);
      ctx.closePath();
    }, d.body2 ?? '#B3263A');
    ctx.restore();
  }

  // legs
  const hipX = 0.055 * W;
  const legs = () => {
    if (robe && p.sit < 0.5) {
      // robe hides thighs; show short shins below hem
      drawLeg(ctx, side ? -0.02 : -hipX, hipY + 0.16, [p.lB[0] * 0.4, 0], legLen * 0.55, side, -1);
      drawLeg(ctx, side ? 0.03 : hipX, hipY + 0.16, [p.lF[0] * 0.4, 0], legLen * 0.55, side, 1);
      return;
    }
    if (p.sit > 0.5) {
      // sitting: thighs forward, shins down
      const k = Math.PI / 2;
      drawLeg(ctx, side ? -0.01 : -hipX, hipY, [k * (side ? 1 : 0.15) + p.lB[0] * 0.3, k * (side ? 1 : 0)], legLen, side, -1);
      drawLeg(ctx, side ? 0.02 : hipX, hipY, [k * (side ? 1 : 0.15) + p.lF[0] * 0.3, k * (side ? 1 : 0)], legLen, side, 1);
      return;
    }
    drawLeg(ctx, side ? -0.015 : -hipX, hipY, p.lB, legLen, side, -1);
    drawLeg(ctx, side ? 0.02 : hipX, hipY, p.lF, legLen, side, 1);
  };
  legs();

  ctx.save();
  upper();
  const shoulderY = bodyTop + 0.075;
  const shX = bodyW * 0.42;
  const armLen = 0.135 * (0.9 + 0.1 * H);

  // back arm (behind body)
  drawArm(ctx, side ? -shX * 0.25 : -shX, shoulderY, p.aB, armLen, -1, side, s.item !== 'none' && false, s, d);

  // body
  drawBody(ctx, d, bodyW, bodyTop, robe ? hipY + 0.17 : bodyBot, side, back, s);

  // head
  const headR = 0.205;
  const headCY = bodyTop - headR * 0.62 + p.headY;
  ctx.save();
  ctx.translate(0, headCY + headR * 0.7);
  ctx.rotate(p.head);
  ctx.translate(0, -(headCY + headR * 0.7));
  drawHead(ctx, d, 0, headCY, headR, s, side, back);
  ctx.restore();

  // front arm (in front of body & head)
  drawArm(ctx, side ? shX * 0.55 : shX, shoulderY, p.aF, armLen, 1, side, true, s, d);

  // emote
  if (s.emote !== 'none' && s.emoteT >= 0 && s.emoteT < 1.6) {
    drawEmote(ctx, s.emote, headR * 0.9, headCY - headR * 1.15, s.emoteT, mirror, headR);
  }
  ctx.restore();
}

// ---------------------------------------------------------------------------
function blob(ctx: CanvasRenderingContext2D, path: () => void, fill: string | CanvasGradient, lw = LW) {
  ctx.beginPath();
  path();
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.lineWidth = lw;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

function line(ctx: CanvasRenderingContext2D, pts: number[], w = LIMB, color = INK) {
  ctx.beginPath();
  ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  ctx.lineWidth = w;
  ctx.strokeStyle = color;
  ctx.stroke();
}

function dot(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry = rx, color = INK) {
  ctx.beginPath();
  ctx.ellipse(x, y, Math.max(rx, 0.0005), Math.max(ry, 0.0005), 0, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

function drawLeg(ctx: CanvasRenderingContext2D, x: number, y: number, l: Limb, len: number, side: boolean, which: 1 | -1) {
  const [h, k] = l;
  const hx = side ? h : h * which; // front view: hip angle spreads outward
  const kx = x + Math.sin(hx) * len;
  const ky = y + Math.cos(hx) * len;
  const sh = hx - (side ? k : k * which);
  const fx = kx + Math.sin(sh) * len;
  const fy = ky + Math.cos(sh) * len;
  // smooth bend
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.quadraticCurveTo(kx, ky, (kx + fx) / 2, (ky + fy) / 2);
  ctx.lineTo(fx, fy);
  ctx.lineWidth = LIMB;
  ctx.strokeStyle = INK;
  ctx.stroke();
  // foot (shoe)
  const dir = side ? 1 : which * 0.6;
  ctx.save();
  ctx.translate(fx, fy);
  ctx.rotate(side ? sh * 0.3 : 0);
  dot(ctx, dir * 0.022, -0.004, 0.032, 0.016);
  ctx.restore();
}

function drawArm(
  ctx: CanvasRenderingContext2D, x: number, y: number, a: Limb, len: number, which: 1 | -1, side: boolean,
  isFront: boolean, s: DrawState, d: CharacterDesign,
) {
  const [sAng, e] = a;
  const out = side ? 1 : which; // outward direction
  const ux = Math.sin(sAng) * out;
  const uy = Math.cos(sAng);
  const ex = x + ux * len;
  const ey = y + uy * len;
  const fAng = sAng + e;
  const hx = ex + Math.sin(fAng) * out * len;
  const hy = ey + Math.cos(fAng) * len;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.quadraticCurveTo(ex, ey, (ex + hx) / 2, (ey + hy) / 2);
  ctx.lineTo(hx, hy);
  ctx.lineWidth = LIMB;
  ctx.strokeStyle = INK;
  ctx.stroke();
  if (isFront && s.item !== 'none') {
    ctx.save();
    ctx.translate(hx, hy);
    const handAng = Math.atan2(hy - ey, hx - ex);
    drawItem(ctx, s.item, handAng, s.itemText, s.facing === -1, s.t);
    ctx.restore();
  }
  dot(ctx, hx, hy, 0.024, 0.024);
}

// ---------------------------------------------------------------------------
function beanPath(ctx: CanvasRenderingContext2D, w: number, top: number, bot: number) {
  const h = bot - top;
  const r = w / 2;
  ctx.moveTo(0, top);
  ctx.bezierCurveTo(r * 0.95, top, r * 1.02, top + h * 0.25, r * 1.03, top + h * 0.55);
  ctx.bezierCurveTo(r * 1.06, bot - h * 0.05, r * 0.6, bot, 0, bot);
  ctx.bezierCurveTo(-r * 0.6, bot, -r * 1.06, bot - h * 0.05, -r * 1.03, top + h * 0.55);
  ctx.bezierCurveTo(-r * 1.02, top + h * 0.25, -r * 0.95, top, 0, top);
  ctx.closePath();
}

function drawBody(
  ctx: CanvasRenderingContext2D, d: CharacterDesign, w: number, top: number, bot: number, side: boolean, back: boolean, s: DrawState,
) {
  const base = d.body;
  const g = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
  g.addColorStop(0, shade(base, -0.18));
  g.addColorStop(0.45, base);
  g.addColorStop(1, shade(base, 0.08));
  ctx.beginPath();
  beanPath(ctx, w, top, bot);
  ctx.fillStyle = g;
  ctx.fill();

  // pattern clipped to body
  ctx.save();
  ctx.beginPath();
  beanPath(ctx, w, top, bot);
  ctx.clip();
  const c2 = d.body2 ?? '#FFFFFF';
  const h = bot - top;
  switch (d.pattern) {
    case 'stripes':
      for (let i = 0; i < 7; i++) {
        ctx.fillStyle = c2;
        ctx.fillRect(-w, top + h * (0.08 + i * 0.15), w * 2, h * 0.075);
      }
      break;
    case 'vstripes':
      for (let i = -3; i <= 3; i++) {
        ctx.fillStyle = c2;
        ctx.fillRect(i * w * 0.18 - w * 0.04, top, w * 0.08, h);
      }
      break;
    case 'dots':
      ctx.fillStyle = c2;
      for (let i = 0; i < 5; i++) for (let j = -2; j <= 2; j++) dot(ctx, j * w * 0.22 + (i % 2) * w * 0.11, top + h * (0.12 + i * 0.2), w * 0.04);
      break;
    case 'suit':
      if (!back) {
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.moveTo(-w * 0.18, top);
        ctx.lineTo(w * 0.18, top);
        ctx.lineTo(0, top + h * 0.42);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = INK;
        ctx.lineWidth = LW * 0.6;
        line(ctx, [-w * 0.2, top, 0, top + h * 0.48, w * 0.2, top], LW * 0.6);
        // tie
        ctx.fillStyle = c2 === '#FFFFFF' ? '#C9283E' : c2;
        ctx.beginPath();
        ctx.moveTo(-w * 0.035, top + 0.01);
        ctx.lineTo(w * 0.035, top + 0.01);
        ctx.lineTo(w * 0.05, top + h * 0.36);
        ctx.lineTo(0, top + h * 0.44);
        ctx.lineTo(-w * 0.05, top + h * 0.36);
        ctx.closePath();
        ctx.fill();
        ctx.lineWidth = LW * 0.5;
        ctx.stroke();
      }
      break;
    case 'uniform':
      if (!back) {
        // cross belts + buttons + belt
        ctx.strokeStyle = c2;
        ctx.lineWidth = w * 0.12;
        line(ctx, [-w * 0.55, top, w * 0.55, bot - h * 0.2], w * 0.11, c2);
        line(ctx, [w * 0.55, top, -w * 0.55, bot - h * 0.2], w * 0.11, c2);
        for (let i = 0; i < 4; i++) dot(ctx, 0, top + h * (0.18 + i * 0.17), w * 0.03, w * 0.03, '#F2C14E');
      }
      ctx.fillStyle = c2;
      ctx.fillRect(-w, bot - h * 0.24, w * 2, h * 0.08);
      break;
    case 'robe':
      ctx.fillStyle = shade(base, -0.1);
      ctx.fillRect(-w * 0.02, top + h * 0.1, w * 0.04, h);
      ctx.fillStyle = c2;
      ctx.fillRect(-w, top + h * 0.38, w * 2, h * 0.06);
      break;
    case 'overalls':
      ctx.fillStyle = c2;
      ctx.fillRect(-w, top + h * 0.45, w * 2, h);
      ctx.fillRect(-w * 0.3, top + h * 0.22, w * 0.6, h * 0.3);
      line(ctx, [-w * 0.25, top, -w * 0.25, top + h * 0.25], w * 0.07, c2);
      line(ctx, [w * 0.25, top, w * 0.25, top + h * 0.25], w * 0.07, c2);
      break;
  }
  // extras on body
  const ex = d.extras ?? [];
  if (ex.includes('belt')) {
    ctx.fillStyle = '#3B2A20';
    ctx.fillRect(-w, bot - h * 0.3, w * 2, h * 0.08);
    ctx.fillStyle = '#E8B33A';
    ctx.fillRect(-w * 0.07, bot - h * 0.31, w * 0.14, h * 0.1);
  }
  if (ex.includes('apron') && !back) {
    ctx.fillStyle = '#F4F1EA';
    ctx.fillRect(-w * 0.32, top + h * 0.3, w * 0.64, h);
  }
  if (ex.includes('sash') && !back) line(ctx, [-w * 0.6, top, w * 0.6, bot], w * 0.12, d.body2 ?? '#E8B33A');
  if (ex.includes('collar') && !back) {
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(-w * 0.25, top);
    ctx.lineTo(0, top + h * 0.2);
    ctx.lineTo(w * 0.25, top);
    ctx.closePath();
    ctx.fill();
  }
  if (ex.includes('buttons') && !back) for (let i = 0; i < 4; i++) dot(ctx, side ? w * 0.18 : 0, top + h * (0.2 + i * 0.17), w * 0.028);
  if (ex.includes('tie') && d.pattern !== 'suit' && !back) {
    ctx.fillStyle = '#C9283E';
    ctx.beginPath();
    ctx.moveTo(-w * 0.04, top);
    ctx.lineTo(w * 0.04, top);
    ctx.lineTo(w * 0.055, top + h * 0.4);
    ctx.lineTo(0, top + h * 0.48);
    ctx.lineTo(-w * 0.055, top + h * 0.4);
    ctx.closePath();
    ctx.fill();
  }
  if (ex.includes('badge') && !back) {
    dot(ctx, w * 0.22, top + h * 0.28, w * 0.07, w * 0.07, '#F2C14E');
  }
  if (ex.includes('scarf')) {
    ctx.fillStyle = d.body2 ?? '#D8473B';
    ctx.fillRect(-w, top, w * 2, h * 0.12);
  }
  // soft highlight
  const hl = ctx.createRadialGradient(w * 0.15, top + h * 0.25, 0, w * 0.15, top + h * 0.25, w * 0.6);
  hl.addColorStop(0, 'rgba(255,255,255,0.18)');
  hl.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = hl;
  ctx.fillRect(-w, top, w * 2, h);
  ctx.restore();

  if (ex.includes('epaulettes')) {
    dot(ctx, -w * 0.42, top + 0.04, w * 0.14, w * 0.06, '#F2C14E');
    dot(ctx, w * 0.42, top + 0.04, w * 0.14, w * 0.06, '#F2C14E');
  }
  ctx.beginPath();
  beanPath(ctx, w, top, bot);
  ctx.lineWidth = LW;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

// ---------------------------------------------------------------------------
function drawHead(
  ctx: CanvasRenderingContext2D, d: CharacterDesign, cx: number, cy: number, r: number, s: DrawState, side: boolean, back: boolean,
) {
  const skin = d.skin ?? '#FFFDF7';
  const hat = d.hat ?? 'none';
  const ex = d.extras ?? [];

  // hood / long hair behind head
  if (d.hair === 'long' && hat !== 'hood') {
    blob(ctx, () => {
      ctx.moveTo(cx - r * 1.02, cy - r * 0.2);
      ctx.lineTo(cx - r * 1.08, cy + r * 1.05);
      ctx.lineTo(cx + r * 1.08, cy + r * 1.05);
      ctx.lineTo(cx + r * 1.02, cy - r * 0.2);
      ctx.closePath();
    }, d.hairColor ?? '#2B2230');
  }
  if (d.hair === 'ponytail') {
    blob(ctx, () => ctx.ellipse(cx - r * 1.05, cy + r * 0.1, r * 0.28, r * 0.5, 0.4, 0, Math.PI * 2), d.hairColor ?? '#2B2230');
  }
  if (hat === 'hood') {
    blob(ctx, () => ctx.ellipse(cx, cy + r * 0.05, r * 1.22, r * 1.25, 0, 0, Math.PI * 2), d.hatColor ?? '#6B4E9B');
  }

  // head circle with soft shading
  const g = ctx.createRadialGradient(cx + r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r * 1.1);
  g.addColorStop(0, shade(skin, 0.05));
  g.addColorStop(0.7, skin);
  g.addColorStop(1, shade(skin, -0.12));
  blob(ctx, () => ctx.arc(cx, cy, r, 0, Math.PI * 2), g, LW * 1.1);

  // hair
  ctx.save();
  drawHair(ctx, d, cx, cy, r, side, back, s.t);
  ctx.restore();

  // face
  if (!back && hat !== 'hood') drawFace(ctx, d, cx, cy, r, s, side);
  if (!back && hat === 'hood') {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.clip();
    drawFace(ctx, d, cx, cy, r, s, side);
    ctx.restore();
  }

  // hat
  drawHat(ctx, hat, d.hatColor, cx, cy, r, side, back, s.t);

  // extras on face
  if (!back) {
    const fx = side ? r * 0.32 : 0;
    if (ex.includes('glasses')) {
      ctx.lineWidth = LW * 0.7;
      ctx.strokeStyle = INK;
      for (const k of [-1, 1]) {
        ctx.beginPath();
        ctx.arc(cx + fx + k * r * 0.24, cy - r * 0.05, r * 0.17, 0, Math.PI * 2);
        ctx.stroke();
      }
      line(ctx, [cx + fx - r * 0.07, cy - r * 0.05, cx + fx + r * 0.07, cy - r * 0.05], LW * 0.6);
    }
    if (ex.includes('sunglasses')) {
      for (const k of [-1, 1]) dot(ctx, cx + fx + k * r * 0.24, cy - r * 0.04, r * 0.2, r * 0.14);
      line(ctx, [cx + fx - r * 0.3, cy - r * 0.08, cx + fx + r * 0.3, cy - r * 0.08], LW * 0.7);
    }
    if (ex.includes('eyepatch')) {
      dot(ctx, cx + fx - r * 0.25, cy - r * 0.05, r * 0.15, r * 0.13);
      line(ctx, [cx - r * 0.95, cy - r * 0.45, cx + r * 0.9, cy + r * 0.15], LW * 0.6);
    }
    if (ex.includes('mustache')) {
      ctx.fillStyle = d.hairColor ?? INK;
      ctx.beginPath();
      const my = cy + r * 0.28;
      ctx.ellipse(cx + fx - r * 0.13, my, r * 0.16, r * 0.07, -0.25, 0, Math.PI * 2);
      ctx.ellipse(cx + fx + r * 0.13, my, r * 0.16, r * 0.07, 0.25, 0, Math.PI * 2);
      ctx.fill();
    }
    if (ex.includes('beard')) {
      blob(ctx, () => {
        ctx.moveTo(cx - r * 0.85, cy + r * 0.35);
        ctx.quadraticCurveTo(cx - r * 0.6, cy + r * 1.35, cx + fx, cy + r * 1.3);
        ctx.quadraticCurveTo(cx + r * 0.6, cy + r * 1.35, cx + r * 0.85, cy + r * 0.35);
        ctx.quadraticCurveTo(cx + fx, cy + r * 0.75, cx - r * 0.85, cy + r * 0.35);
      }, d.hairColor ?? '#D9D4CC', LW * 0.8);
    }
    if (ex.includes('stubble')) {
      ctx.fillStyle = 'rgba(40,30,40,0.55)';
      for (let i = 0; i < 26; i++) {
        const a = 0.35 + (i / 26) * 2.4;
        const rr = r * (0.62 + ((i * 37) % 10) / 40);
        dot(ctx, cx + Math.cos(a) * rr * 0.9, cy + Math.sin(a) * rr * 0.75 + r * 0.1, r * 0.018, r * 0.018, 'rgba(40,30,40,0.55)');
      }
    }
    if (ex.includes('freckles')) {
      for (const k of [-1, 1]) for (let i = 0; i < 3; i++) dot(ctx, cx + fx + k * r * (0.35 + i * 0.07), cy + r * (0.18 + (i % 2) * 0.05), r * 0.02, r * 0.02, '#B5735A');
    }
  }
}

function drawHair(ctx: CanvasRenderingContext2D, d: CharacterDesign, cx: number, cy: number, r: number, side: boolean, back: boolean, t: number) {
  const hair = d.hair ?? 'none';
  const col = d.hairColor ?? '#2B2230';
  if (hair === 'none' || hair === 'bald') {
    if (hair === 'bald') dot(ctx, cx + r * 0.35, cy - r * 0.55, r * 0.14, r * 0.07, 'rgba(255,255,255,0.7)');
    return;
  }
  const hl = shade(col, 0.35);
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.0, 0, Math.PI * 2);
  ctx.clip();
  ctx.fillStyle = col;
  const cover = back ? 0.55 : 0;
  switch (hair) {
    case 'bowl':
    case 'bun':
    case 'long':
    case 'ponytail':
      ctx.beginPath();
      ctx.moveTo(cx - r * 1.1, cy + r * (0.05 + cover));
      ctx.quadraticCurveTo(cx - r * 0.2, cy - r * (0.2 - cover), cx + r * 1.1, cy + r * (0.0 + cover));
      ctx.lineTo(cx + r * 1.1, cy - r * 1.2);
      ctx.lineTo(cx - r * 1.1, cy - r * 1.2);
      ctx.closePath();
      ctx.fill();
      break;
    case 'side':
      ctx.beginPath();
      ctx.moveTo(cx - r * 1.1, cy + r * (0.0 + cover));
      ctx.quadraticCurveTo(cx - r * 0.5, cy - r * (0.55 - cover), cx + r * 0.15, cy - r * (0.42 - cover));
      ctx.quadraticCurveTo(cx + r * 0.6, cy - r * (0.32 - cover), cx + r * 1.1, cy + r * (0.05 + cover));
      ctx.lineTo(cx + r * 1.1, cy - r * 1.2);
      ctx.lineTo(cx - r * 1.1, cy - r * 1.2);
      ctx.closePath();
      ctx.fill();
      break;
    case 'curly':
    case 'spiky':
    case 'mohawk':
      ctx.beginPath();
      ctx.moveTo(cx - r * 1.1, cy - r * (0.25 - cover));
      ctx.quadraticCurveTo(cx, cy - r * (0.6 - cover), cx + r * 1.1, cy - r * (0.25 - cover));
      ctx.lineTo(cx + r * 1.1, cy - r * 1.2);
      ctx.lineTo(cx - r * 1.1, cy - r * 1.2);
      ctx.closePath();
      if (hair !== 'mohawk') ctx.fill();
      break;
  }
  // highlight strands
  if (hair !== 'mohawk') {
    ctx.strokeStyle = hl;
    ctx.lineWidth = r * 0.07;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(cx + r * 0.1, cy + r * 0.25, r * (0.75 + i * 0.12), -2.3, -1.0);
      ctx.stroke();
    }
  }
  ctx.restore();
  // hairline ink
  ctx.lineWidth = LW * 0.8;
  ctx.strokeStyle = INK;
  if (hair === 'bowl' || hair === 'bun' || hair === 'long' || hair === 'ponytail') {
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.99, cy + r * (0.05 + cover));
    ctx.quadraticCurveTo(cx - r * 0.2, cy - r * (0.2 - cover), cx + r * 0.99, cy + r * (0.0 + cover));
    ctx.stroke();
  }
  if (hair === 'side') {
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.99, cy + r * (0.0 + cover));
    ctx.quadraticCurveTo(cx - r * 0.5, cy - r * (0.55 - cover), cx + r * 0.15, cy - r * (0.42 - cover));
    ctx.quadraticCurveTo(cx + r * 0.6, cy - r * (0.32 - cover), cx + r * 0.99, cy + r * (0.05 + cover));
    ctx.stroke();
  }
  if (hair === 'bun') {
    blob(ctx, () => ctx.arc(cx - r * 0.05, cy - r * 1.1, r * 0.3, 0, Math.PI * 2), col);
    line(ctx, [cx - r * 0.55, cy - r * 1.18, cx + r * 0.55, cy - r * 1.02], LW * 0.6, '#E8B33A');
    dot(ctx, cx - r * 0.58, cy - r * 1.19, r * 0.07, r * 0.07, '#2FB39A');
  }
  if (hair === 'spiky' || hair === 'curly' || hair === 'mohawk') {
    blob(ctx, () => {
      const n = hair === 'mohawk' ? 4 : 7;
      const span = hair === 'mohawk' ? 0.45 : 1.05;
      ctx.moveTo(cx - r * span, cy - r * 0.45);
      for (let i = 0; i <= n; i++) {
        const a = -span + (2 * span * i) / n;
        const px = cx + r * a;
        const py = cy - r * Math.sqrt(Math.max(0, 1 - a * a)) * 0.95;
        if (hair === 'curly') ctx.arc(px, py, r * 0.2, Math.PI, 0);
        else {
          ctx.lineTo(px - r * 0.08, py);
          ctx.lineTo(px, py - r * 0.32);
          ctx.lineTo(px + r * 0.08, py);
        }
      }
      ctx.lineTo(cx + r * span, cy - r * 0.45);
      ctx.quadraticCurveTo(cx, cy - r * 0.55, cx - r * span, cy - r * 0.45);
    }, col, LW * 0.8);
  }
}

function drawHat(ctx: CanvasRenderingContext2D, hat: string, color: string | undefined, cx: number, cy: number, r: number, side: boolean, back: boolean, t: number) {
  if (hat === 'none' || hat === 'hood') return;
  const c = color;
  const top = cy - r;
  const brimDir = back ? -1 : 1;
  switch (hat) {
    case 'cap':
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.45, r * 1.02, r * 0.62, 0, Math.PI, 0), c ?? '#2F5FD0');
      blob(ctx, () => ctx.ellipse(cx + brimDir * r * (side ? 0.85 : 0.2), cy - r * 0.45, r * (side ? 0.55 : 0.75), r * 0.12, 0, 0, Math.PI * 2), shade(c ?? '#2F5FD0', -0.25));
      break;
    case 'police':
      blob(ctx, () => {
        ctx.moveTo(cx - r * 1.0, cy - r * 0.45);
        ctx.lineTo(cx - r * 1.15, cy - r * 1.05);
        ctx.quadraticCurveTo(cx, cy - r * 1.35, cx + r * 1.15, cy - r * 1.05);
        ctx.lineTo(cx + r * 1.0, cy - r * 0.45);
        ctx.closePath();
      }, c ?? '#22326E');
      blob(ctx, () => ctx.ellipse(cx + (side ? r * 0.4 : 0), cy - r * 0.42, r * 0.9, r * 0.14, 0, 0, Math.PI), '#111');
      if (!back) star(ctx, cx + (side ? r * 0.3 : 0), cy - r * 0.85, r * 0.16, '#F2C14E');
      break;
    case 'top':
      blob(ctx, () => ctx.rect(cx - r * 0.62, top - r * 1.05, r * 1.24, r * 1.25), c ?? '#1E1A24');
      ctx.fillStyle = '#B88A2E';
      ctx.fillRect(cx - r * 0.6, top - r * 0.05, r * 1.2, r * 0.18);
      blob(ctx, () => ctx.ellipse(cx, top + r * 0.18, r * 1.05, r * 0.16, 0, 0, Math.PI * 2), c ?? '#1E1A24');
      break;
    case 'shako':
      blob(ctx, () => {
        ctx.moveTo(cx - r * 0.7, top + r * 0.3);
        ctx.lineTo(cx - r * 0.6, top - r * 0.85);
        ctx.lineTo(cx + r * 0.6, top - r * 0.85);
        ctx.lineTo(cx + r * 0.7, top + r * 0.3);
        ctx.closePath();
      }, c ?? '#1E1A24');
      ctx.fillStyle = '#E8B33A';
      ctx.fillRect(cx - r * 0.66, top + r * 0.05, r * 1.32, r * 0.1);
      if (!back) star(ctx, cx, top - r * 0.3, r * 0.17, '#E8B33A');
      blob(ctx, () => ctx.ellipse(cx, top - r * 1.0, r * 0.13, r * 0.25, 0, 0, Math.PI * 2), '#F4F1EA', LW * 0.7);
      blob(ctx, () => ctx.ellipse(cx + brimDir * r * 0.35, top + r * 0.32, r * 0.55, r * 0.1, 0, 0, Math.PI * 2), '#111');
      break;
    case 'bowler':
      blob(ctx, () => ctx.ellipse(cx, top + r * 0.1, r * 0.72, r * 0.62, 0, Math.PI, 0), c ?? '#2A2430');
      blob(ctx, () => ctx.ellipse(cx, top + r * 0.12, r * 1.05, r * 0.15, 0, 0, Math.PI * 2), c ?? '#2A2430');
      break;
    case 'bandana': {
      const bc = c ?? '#D7263D';
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.38, r * 1.04, r * 0.7, 0, Math.PI, 0), bc);
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(cx, cy - r * 0.38, r * 1.0, r * 0.66, 0, Math.PI, 0);
      ctx.clip();
      for (let i = 0; i < 7; i++) dot(ctx, cx - r * 0.75 + i * r * 0.25, cy - r * (0.6 + (i % 2) * 0.25), r * 0.05, r * 0.05, '#FFFFFF');
      ctx.restore();
      blob(ctx, () => {
        ctx.moveTo(cx - r * 0.95, cy - r * 0.45);
        ctx.lineTo(cx - r * 1.4, cy - r * 0.25 + Math.sin(t * 5) * r * 0.05);
        ctx.lineTo(cx - r * 1.3, cy - r * 0.05);
        ctx.closePath();
      }, bc, LW * 0.8);
      break;
    }
    case 'crown':
      blob(ctx, () => {
        ctx.moveTo(cx - r * 0.65, top + r * 0.25);
        ctx.lineTo(cx - r * 0.75, top - r * 0.45);
        ctx.lineTo(cx - r * 0.38, top - r * 0.1);
        ctx.lineTo(cx, top - r * 0.6);
        ctx.lineTo(cx + r * 0.38, top - r * 0.1);
        ctx.lineTo(cx + r * 0.75, top - r * 0.45);
        ctx.lineTo(cx + r * 0.65, top + r * 0.25);
        ctx.closePath();
      }, c ?? '#F2C14E');
      dot(ctx, cx, top + r * 0.05, r * 0.08, r * 0.08, '#2FB39A');
      break;
    case 'helmet':
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.35, r * 1.08, r * 0.78, 0, Math.PI, 0), c ?? '#8C949E');
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.35, r * 1.2, r * 0.12, 0, 0, Math.PI * 2), shade(c ?? '#8C949E', -0.2));
      break;
    case 'hardhat':
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.4, r * 1.0, r * 0.75, 0, Math.PI, 0), c ?? '#F5C518');
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.4, r * 1.2, r * 0.12, 0, 0, Math.PI * 2), c ?? '#F5C518');
      line(ctx, [cx, cy - r * 1.12, cx, cy - r * 0.45], LW * 0.8);
      break;
    case 'beret':
      blob(ctx, () => ctx.ellipse(cx + r * 0.15, cy - r * 0.8, r * 1.0, r * 0.38, -0.15, 0, Math.PI * 2), c ?? '#C0283A');
      break;
    case 'beanie':
      blob(ctx, () => ctx.ellipse(cx, cy - r * 0.35, r * 1.04, r * 0.85, 0, Math.PI, 0), c ?? '#2E8B57');
      blob(ctx, () => ctx.rect(cx - r * 1.04, cy - r * 0.5, r * 2.08, r * 0.22), shade(c ?? '#2E8B57', -0.15));
      blob(ctx, () => ctx.arc(cx, cy - r * 1.25, r * 0.15, 0, Math.PI * 2), '#FFFFFF');
      break;
    case 'chef':
      blob(ctx, () => ctx.rect(cx - r * 0.6, top - r * 0.2, r * 1.2, r * 0.5), '#FFFFFF');
      blob(ctx, () => {
        ctx.arc(cx - r * 0.4, top - r * 0.45, r * 0.38, 0, Math.PI * 2);
      }, '#FFFFFF');
      blob(ctx, () => ctx.arc(cx + r * 0.4, top - r * 0.45, r * 0.38, 0, Math.PI * 2), '#FFFFFF');
      blob(ctx, () => ctx.arc(cx, top - r * 0.7, r * 0.42, 0, Math.PI * 2), '#FFFFFF');
      break;
    case 'cowboy':
    case 'straw': {
      const hc = c ?? (hat === 'straw' ? '#E8C872' : '#8A5A35');
      blob(ctx, () => ctx.ellipse(cx, top + r * 0.2, r * 1.5, r * 0.22, 0, 0, Math.PI * 2), hc);
      blob(ctx, () => ctx.ellipse(cx, top + r * 0.15, r * 0.7, r * 0.6, 0, Math.PI, 0), hc);
      ctx.fillStyle = shade(hc, -0.3);
      ctx.fillRect(cx - r * 0.7, top + r * 0.02, r * 1.4, r * 0.12);
      break;
    }
    case 'tricorn':
      blob(ctx, () => {
        ctx.moveTo(cx - r * 1.35, top + r * 0.2);
        ctx.quadraticCurveTo(cx, top - r * 1.0, cx + r * 1.35, top + r * 0.2);
        ctx.quadraticCurveTo(cx, top + r * 0.05, cx - r * 1.35, top + r * 0.2);
      }, c ?? '#2A2430');
      line(ctx, [cx - r * 1.1, top + r * 0.1, cx + r * 1.1, top + r * 0.1], LW * 0.7, '#E8B33A');
      break;
    case 'wizard':
      blob(ctx, () => {
        ctx.moveTo(cx - r * 0.95, top + r * 0.3);
        ctx.lineTo(cx + r * 0.35, top - r * 1.6);
        ctx.lineTo(cx + r * 0.95, top + r * 0.3);
        ctx.closePath();
      }, c ?? '#3B4BB5');
      star(ctx, cx, top - r * 0.3, r * 0.15, '#F2C14E');
      break;
  }
}

function star(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rr = i % 2 === 0 ? r : r * 0.45;
    ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
  }
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.lineWidth = LW * 0.5;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

// ---------------------------------------------------------------------------
function drawFace(ctx: CanvasRenderingContext2D, d: CharacterDesign, cx: number, cy: number, r: number, s: DrawState, side: boolean) {
  const fx = cx + (side ? r * 0.32 : 0);
  const ey = cy - r * 0.05;
  const sp = side ? r * 0.24 : r * 0.27; // eye spacing (half)
  const exL = fx - sp;
  const exR = fx + sp;
  const er = r * 0.085;
  const my = cy + r * 0.38;
  const lw = LW * 0.85;
  const f = s.face;
  const blink = s.blink && !['grin', 'laugh', 'proud', 'sleepy', 'cry', 'pain', 'dizzy', 'love', 'deadpan'].includes(f);

  const eyesDot = (sx = 1, sy = 1.25) => {
    if (blink) {
      line(ctx, [exL - er, ey, exL + er, ey], lw);
      line(ctx, [exR - er, ey, exR + er, ey], lw);
    } else {
      dot(ctx, exL, ey, er * sx, er * sy);
      dot(ctx, exR, ey, er * sx, er * sy);
    }
  };
  const happyEyes = (up = true) => {
    for (const x of [exL, exR]) {
      ctx.beginPath();
      if (up) ctx.arc(x, ey + er * 0.6, er * 1.2, Math.PI * 1.1, Math.PI * 1.9);
      else ctx.arc(x, ey - er * 0.8, er * 1.2, Math.PI * 0.1, Math.PI * 0.9);
      ctx.lineWidth = lw;
      ctx.strokeStyle = INK;
      ctx.stroke();
    }
  };
  const bigEyes = (pupil = 0.4) => {
    for (const x of [exL, exR]) {
      blob(ctx, () => ctx.arc(x, ey, er * 2.0, 0, Math.PI * 2), '#FFFFFF', lw * 0.8);
      dot(ctx, x + (side ? er * 0.5 : 0), ey, er * 2.0 * pupil);
    }
  };
  const brows = (inner: number, outer: number, y = -r * 0.33, len = r * 0.2) => {
    // inner/outer: vertical offsets (negative = up)
    line(ctx, [exL - len * 0.6, ey + y + outer, exL + len * 0.5, ey + y + inner], lw * 1.05);
    line(ctx, [exR - len * 0.5, ey + y + inner, exR + len * 0.6, ey + y + outer], lw * 1.05);
  };
  const lids = (amt = 0.5) => {
    for (const x of [exL, exR]) line(ctx, [x - er * 1.6, ey - er * (1.3 - amt * 1.6), x + er * 1.6, ey - er * (1.3 - amt * 1.6)], lw);
  };
  const mouthLine = (w = r * 0.18, curve = 0, ox = 0) => {
    ctx.beginPath();
    ctx.moveTo(fx + ox - w, my);
    ctx.quadraticCurveTo(fx + ox, my + curve, fx + ox + w, my);
    ctx.lineWidth = lw;
    ctx.strokeStyle = INK;
    ctx.stroke();
  };
  const mouthOpen = (w: number, h: number, fill = '#5A1E2A', teeth = false) => {
    blob(ctx, () => ctx.ellipse(fx, my + h * 0.3, w, h, 0, 0, Math.PI * 2), fill, lw * 0.9);
    if (teeth) {
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(fx, my + h * 0.3, w, h, 0, 0, Math.PI * 2);
      ctx.clip();
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(fx - w, my + h * 0.3 - h, w * 2, h * 0.7);
      ctx.restore();
    }
  };
  const teethGrid = (w = r * 0.32, h = r * 0.2, smile = true) => {
    blob(ctx, () => {
      ctx.moveTo(fx - w, my - h * 0.3);
      ctx.quadraticCurveTo(fx, my + (smile ? h * 0.6 : -h * 0.2), fx + w, my - h * 0.3);
      ctx.lineTo(fx + w * 0.92, my + h * 0.55);
      ctx.quadraticCurveTo(fx, my + h * (smile ? 1.5 : 0.8), fx - w * 0.92, my + h * 0.55);
      ctx.closePath();
    }, '#FFFFFF', lw * 0.9);
    ctx.lineWidth = lw * 0.6;
    for (let i = 1; i < 4; i++) line(ctx, [fx - w + (2 * w * i) / 4, my - h * 0.1, fx - w + (2 * w * i) / 4, my + h * 0.9], lw * 0.55);
    line(ctx, [fx - w * 0.95, my + h * 0.42, fx + w * 0.95, my + h * 0.42], lw * 0.55);
  };
  const talk = s.pose.mouth > 0.05;

  switch (f) {
    case 'happy':
      eyesDot();
      if (talk) mouthOpen(r * 0.14, r * 0.1 * (0.5 + s.pose.mouth));
      else mouthLine(r * 0.2, r * 0.16);
      break;
    case 'grin':
      happyEyes();
      teethGrid();
      break;
    case 'laugh':
      happyEyes();
      mouthOpen(r * 0.22, r * 0.16 + Math.abs(Math.sin(s.t * 18)) * r * 0.04, '#5A1E2A');
      dot(ctx, fx, my + r * 0.13, r * 0.1, r * 0.05, '#E86A7A');
      break;
    case 'smug':
      eyesDot(1, 0.9);
      lids(0.55);
      brows(-r * 0.02, -r * 0.1);
      mouthLine(r * 0.17, r * 0.08, r * 0.05);
      break;
    case 'proud':
      happyEyes();
      mouthLine(r * 0.2, r * 0.14);
      break;
    case 'sad':
      eyesDot();
      brows(-r * 0.08, r * 0.04);
      mouthLine(r * 0.16, -r * 0.1);
      break;
    case 'cry':
      happyEyes(false);
      brows(-r * 0.1, r * 0.05);
      mouthOpen(r * 0.14, r * 0.08 + Math.abs(Math.sin(s.t * 9)) * r * 0.03);
      for (const x of [exL, exR]) {
        ctx.fillStyle = '#5BB8F0';
        const flow = (s.t * 0.9) % 1;
        ctx.fillRect(x - er * 0.5, ey + er, er, r * (0.5 + 0.3 * flow));
      }
      break;
    case 'angry':
      eyesDot();
      brows(r * 0.08, -r * 0.06);
      if (talk) teethGrid(r * 0.22, r * 0.14, false);
      else mouthLine(r * 0.16, -r * 0.08);
      break;
    case 'shocked':
      bigEyes(0.32);
      brows(-r * 0.12, -r * 0.1, -r * 0.42);
      mouthOpen(r * 0.11, r * 0.15);
      break;
    case 'scared':
      bigEyes(0.25);
      brows(-r * 0.12, -r * 0.02, -r * 0.42);
      teethGrid(r * 0.24, r * 0.15, false);
      break;
    case 'worried':
    case 'nervous':
      eyesDot();
      brows(-r * 0.1, r * 0.02);
      if (f === 'nervous') teethGrid(r * 0.24, r * 0.14, true);
      else {
        ctx.beginPath();
        ctx.moveTo(fx - r * 0.18, my);
        for (let i = 1; i <= 4; i++) ctx.lineTo(fx - r * 0.18 + (i * r * 0.36) / 4, my + (i % 2 ? -1 : 1) * r * 0.04);
        ctx.lineWidth = lw;
        ctx.strokeStyle = INK;
        ctx.stroke();
      }
      break;
    case 'sleepy':
      lids(1);
      dot(ctx, fx, my + r * 0.02, r * 0.05, r * 0.06);
      break;
    case 'wink':
      dot(ctx, exL, ey, er, er * 1.25);
      happyEyes();
      mouthLine(r * 0.2, r * 0.15);
      break;
    case 'determined':
      eyesDot();
      brows(r * 0.06, -r * 0.02);
      mouthLine(r * 0.16, -r * 0.02);
      break;
    case 'confused':
      eyesDot();
      line(ctx, [exL - r * 0.12, ey - r * 0.38, exL + r * 0.1, ey - r * 0.3], lw);
      line(ctx, [exR - r * 0.1, ey - r * 0.48, exR + r * 0.12, ey - r * 0.52], lw);
      ctx.beginPath();
      ctx.moveTo(fx - r * 0.15, my);
      ctx.bezierCurveTo(fx - r * 0.05, my - r * 0.08, fx + r * 0.05, my + r * 0.08, fx + r * 0.15, my);
      ctx.lineWidth = lw;
      ctx.stroke();
      break;
    case 'deadpan':
      for (const x of [exL, exR]) line(ctx, [x - er * 1.7, ey - er * 0.3, x + er * 1.7, ey - er * 0.3], lw * 1.1);
      for (const x of [exL, exR]) line(ctx, [x - er * 1.2, ey + er * 0.6, x + er * 1.2, ey + er * 0.6], lw * 0.8);
      mouthLine(r * 0.13, 0);
      break;
    case 'evil':
      eyesDot(1, 1);
      brows(r * 0.1, -r * 0.08);
      teethGrid(r * 0.3, r * 0.17, true);
      break;
    case 'disgust':
      lids(0.6);
      eyesDot(1, 0.8);
      brows(r * 0.04, -r * 0.04);
      mouthLine(r * 0.15, -r * 0.06, -r * 0.03);
      dot(ctx, fx + r * 0.05, my + r * 0.06, r * 0.05, r * 0.04, '#E86A7A');
      break;
    case 'love':
      for (const x of [exL, exR]) heart(ctx, x, ey, er * 1.6 * (1 + 0.1 * Math.sin(s.t * 12)), '#E8364E');
      mouthLine(r * 0.2, r * 0.16);
      break;
    case 'dizzy':
      for (const x of [exL, exR]) {
        ctx.beginPath();
        for (let a = 0; a < 12; a += 0.3) ctx.lineTo(x + Math.cos(a + s.t * 8) * a * er * 0.15, ey + Math.sin(a + s.t * 8) * a * er * 0.15);
        ctx.lineWidth = lw * 0.6;
        ctx.strokeStyle = INK;
        ctx.stroke();
      }
      mouthOpen(r * 0.08, r * 0.06);
      break;
    case 'pain':
      line(ctx, [exL - er, ey - er, exL + er, ey, exL - er, ey + er], lw);
      line(ctx, [exR + er, ey - er, exR - er, ey, exR + er, ey + er], lw);
      teethGrid(r * 0.24, r * 0.14, false);
      break;
    case 'cold':
      eyesDot();
      brows(-r * 0.08, r * 0.02);
      teethGrid(r * 0.22, r * 0.12, false);
      dot(ctx, fx - r * 0.5, cy + r * 0.25, r * 0.12, r * 0.07, 'rgba(110,170,255,0.55)');
      dot(ctx, fx + r * 0.5, cy + r * 0.25, r * 0.12, r * 0.07, 'rgba(110,170,255,0.55)');
      break;
    default: // neutral
      eyesDot();
      if (talk) mouthOpen(r * 0.1, r * 0.08 * (0.6 + s.pose.mouth));
      else mouthLine(r * 0.12, 0);
  }
  if (talk && !['happy', 'neutral', 'angry', 'laugh', 'shocked', 'cry', 'dizzy'].includes(f)) {
    // small extra open mouth for talking on other faces
    dot(ctx, fx, my + r * 0.12, r * 0.07 * s.pose.mouth, r * 0.06 * s.pose.mouth, '#5A1E2A');
  }
  if ((d.extras ?? []).includes('blush') || f === 'love' || f === 'proud') {
    dot(ctx, fx - r * 0.5, cy + r * 0.22, r * 0.12, r * 0.07, 'rgba(240,110,120,0.45)');
    dot(ctx, fx + r * 0.5, cy + r * 0.22, r * 0.12, r * 0.07, 'rgba(240,110,120,0.45)');
  }
  if (f === 'nervous' || f === 'scared') {
    drop(ctx, cx + r * 0.95, cy - r * 0.35, r * 0.13);
  }
}

function heart(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  ctx.beginPath();
  ctx.moveTo(x, y + r * 0.9);
  ctx.bezierCurveTo(x - r * 1.6, y - r * 0.2, x - r * 0.6, y - r * 1.3, x, y - r * 0.4);
  ctx.bezierCurveTo(x + r * 0.6, y - r * 1.3, x + r * 1.6, y - r * 0.2, x, y + r * 0.9);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.lineWidth = LW * 0.5;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

function drop(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  blob(ctx, () => {
    ctx.moveTo(x, y - r * 1.6);
    ctx.quadraticCurveTo(x + r * 1.1, y, x, y + r);
    ctx.quadraticCurveTo(x - r * 1.1, y, x, y - r * 1.6);
  }, '#8FD3FF', LW * 0.5);
}

// ---------------------------------------------------------------------------
function drawEmote(ctx: CanvasRenderingContext2D, e: Emote, x: number, y: number, t: number, mirror: number, r: number) {
  const pop = Math.min(1, t / 0.12);
  const sc = (0.6 + 0.4 * pop) * (t > 1.3 ? Math.max(0, 1 - (t - 1.3) / 0.3) : 1);
  if (sc <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sc, sc);
  if (mirror === -1) ctx.scale(-1, 1);
  const txt = (s: string, color: string) => {
    ctx.font = `900 ${r * 1.1}px Montserrat, Arial Black, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = LW * 1.2;
    ctx.strokeStyle = INK;
    ctx.strokeText(s, 0, 0);
    ctx.fillStyle = color;
    ctx.fillText(s, 0, 0);
  };
  switch (e) {
    case '!':
      txt('!', '#FF4D4D');
      break;
    case '?':
      txt('?', '#FFD23F');
      break;
    case '!?':
      txt('!?', '#FF4D4D');
      break;
    case 'sweat':
      drop(ctx, r * 0.3, r * 0.6 + t * r * 0.3, r * 0.18);
      break;
    case 'anger':
      for (let i = 0; i < 4; i++) {
        ctx.save();
        ctx.rotate((i * Math.PI) / 2);
        line(ctx, [r * 0.08, r * 0.08, r * 0.28, r * 0.08, r * 0.08, r * 0.28], LW, '#E8283E');
        ctx.restore();
      }
      break;
    case 'sparkle':
      for (let i = 0; i < 3; i++) star(ctx, Math.cos(i * 2.1 + t * 3) * r * 0.5, Math.sin(i * 2.1 + t * 3) * r * 0.3, r * (0.15 + 0.05 * Math.sin(t * 10 + i)), '#FFE14D');
      break;
    case 'heart':
      heart(ctx, 0, -t * r * 0.3, r * 0.3, '#E8364E');
      break;
    case 'zzz':
      ctx.font = `900 ${r * 0.5}px Montserrat, sans-serif`;
      for (let i = 0; i < 3; i++) {
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = INK;
        ctx.lineWidth = LW * 0.6;
        const yy = -i * r * 0.4 - (t * r * 0.3) % (r * 0.4);
        ctx.strokeText('z', i * r * 0.25, yy);
        ctx.fillText('z', i * r * 0.25, yy);
      }
      break;
    case 'idea':
      blob(ctx, () => ctx.arc(0, 0, r * 0.32, 0, Math.PI * 2), '#FFE14D');
      blob(ctx, () => ctx.rect(-r * 0.14, r * 0.28, r * 0.28, r * 0.18), '#B0B0B0', LW * 0.6);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        line(ctx, [Math.cos(a) * r * 0.45, Math.sin(a) * r * 0.45, Math.cos(a) * r * 0.62, Math.sin(a) * r * 0.62], LW * 0.6, '#E8A100');
      }
      break;
    case 'tears':
      drop(ctx, -r * 0.6, r * 1.2 + t * r * 0.5, r * 0.14);
      drop(ctx, r * 0.6, r * 1.2 + t * r * 0.6, r * 0.14);
      break;
    case 'music':
      txt('♪', '#FFFFFF');
      break;
    case 'dizzy':
      for (let i = 0; i < 4; i++) star(ctx, Math.cos(i * 1.57 + t * 6) * r * 0.7, r * 0.6 + Math.sin(i * 1.57 + t * 6) * r * 0.2, r * 0.12, '#FFE14D');
      break;
    case 'steam':
      for (let i = 0; i < 2; i++) blob(ctx, () => ctx.arc((i ? 1 : -1) * r * 0.7, r * 0.4 - t * r * 0.5, r * (0.18 + t * 0.1), 0, Math.PI * 2), '#FFFFFF', LW * 0.5);
      break;
    case 'shiver':
    case 'motion':
      for (let i = 0; i < 3; i++) {
        line(ctx, [-r * 1.3, r * (0.4 + i * 0.35), -r * 1.05, r * (0.5 + i * 0.35)], LW * 0.6);
        line(ctx, [r * 1.3, r * (0.4 + i * 0.35), r * 1.05, r * (0.5 + i * 0.35)], LW * 0.6);
      }
      break;
    case 'check':
      txt('✓', '#34C759');
      break;
  }
  ctx.restore();
}

// ---------------------------------------------------------------------------
function drawItem(ctx: CanvasRenderingContext2D, item: Item, handAng: number, text: string | undefined, mirrored: boolean, t: number) {
  const L = LW * 0.8;
  ctx.save();
  const up = () => ctx.rotate(0); // items are drawn upright in world space
  up();
  switch (item) {
    case 'phone':
      blob(ctx, () => ctx.roundRect(-0.03, -0.1, 0.06, 0.11, 0.01), '#1F2430', L);
      ctx.fillStyle = '#6FD3FF';
      ctx.fillRect(-0.022, -0.09, 0.044, 0.08);
      break;
    case 'cup':
    case 'mug':
      blob(ctx, () => ctx.roundRect(-0.03, -0.07, 0.06, 0.07, 0.008), item === 'mug' ? '#E8E2D6' : '#C9283E', L);
      ctx.beginPath();
      ctx.arc(0.035, -0.035, 0.018, -1.4, 1.4);
      ctx.lineWidth = L;
      ctx.strokeStyle = INK;
      ctx.stroke();
      break;
    case 'bottle':
      blob(ctx, () => ctx.roundRect(-0.022, -0.1, 0.044, 0.1, 0.01), '#3FA34D', L);
      blob(ctx, () => ctx.rect(-0.009, -0.14, 0.018, 0.04), '#3FA34D', L);
      break;
    case 'sword':
      blob(ctx, () => ctx.rect(-0.012, -0.32, 0.024, 0.28), '#DDE3EA', L);
      blob(ctx, () => ctx.rect(-0.05, -0.045, 0.1, 0.02), '#B88A2E', L);
      break;
    case 'spear':
    case 'rifle':
    case 'broom':
    case 'brush':
    case 'flag':
    case 'torch':
    case 'pickaxe':
    case 'hammer':
    case 'umbrella':
    case 'wrench':
    case 'telescope': {
      const long = ['spear', 'rifle', 'broom', 'flag'].includes(item);
      const len = long ? 0.62 : 0.26;
      const col = item === 'rifle' ? '#5B3A25' : '#8A5A35';
      line(ctx, [0, len * 0.25, 0, -len * 0.75], L * 1.4, INK);
      line(ctx, [0, len * 0.25, 0, -len * 0.75], L * 0.8, col);
      const tipY = -len * 0.75;
      if (item === 'spear') blob(ctx, () => { ctx.moveTo(-0.025, tipY); ctx.lineTo(0, tipY - 0.08); ctx.lineTo(0.025, tipY); ctx.closePath(); }, '#DDE3EA', L);
      if (item === 'rifle') blob(ctx, () => ctx.rect(-0.012, tipY - 0.05, 0.024, 0.08), '#5A5F66', L);
      if (item === 'broom' || item === 'brush') blob(ctx, () => { ctx.moveTo(-0.01, len * 0.25); ctx.lineTo(-0.06, len * 0.42); ctx.lineTo(0.06, len * 0.42); ctx.lineTo(0.01, len * 0.25); ctx.closePath(); }, '#E2B65A', L);
      if (item === 'flag') blob(ctx, () => { ctx.moveTo(0, tipY); ctx.quadraticCurveTo(0.1, tipY + 0.02 + Math.sin(t * 6) * 0.01, 0.2, tipY + 0.01); ctx.lineTo(0.2, tipY + 0.12); ctx.quadraticCurveTo(0.1, tipY + 0.13 + Math.sin(t * 6 + 1) * 0.01, 0, tipY + 0.11); ctx.closePath(); }, '#D7263D', L);
      if (item === 'torch') {
        blob(ctx, () => ctx.ellipse(0, tipY - 0.03 - Math.sin(t * 20) * 0.005, 0.03, 0.05, 0, 0, Math.PI * 2), '#FFB52E', L * 0.6);
        dot(ctx, 0, tipY - 0.025, 0.015, 0.025, '#FFF2A8');
      }
      if (item === 'pickaxe') blob(ctx, () => { ctx.moveTo(-0.09, tipY + 0.03); ctx.quadraticCurveTo(0, tipY - 0.04, 0.09, tipY + 0.03); ctx.lineTo(0, tipY + 0.0); ctx.closePath(); }, '#9AA3AD', L);
      if (item === 'hammer') blob(ctx, () => ctx.rect(-0.05, tipY - 0.02, 0.1, 0.05), '#6D747C', L);
      if (item === 'wrench') blob(ctx, () => ctx.arc(0, tipY, 0.03, 0, Math.PI * 2), '#9AA3AD', L);
      if (item === 'telescope') blob(ctx, () => ctx.rect(-0.02, tipY - 0.05, 0.04, 0.18), '#B88A2E', L);
      if (item === 'umbrella') blob(ctx, () => ctx.ellipse(0, tipY, 0.2, 0.1, 0, Math.PI, 0), '#D7263D', L);
      break;
    }
    case 'shield':
      blob(ctx, () => ctx.arc(0.02, -0.02, 0.11, 0, Math.PI * 2), '#2FB39A', L);
      blob(ctx, () => ctx.arc(0.02, -0.02, 0.04, 0, Math.PI * 2), '#DDE3EA', L);
      break;
    case 'sign':
    case 'paper':
    case 'clipboard':
    case 'scroll':
    case 'blueprint':
    case 'map':
    case 'book': {
      const big = item === 'sign';
      const w = big ? 0.32 : 0.14;
      const h = big ? 0.2 : 0.18;
      if (big) line(ctx, [0, 0.05, 0, -0.25], L * 1.4);
      const col = item === 'book' ? '#7A3B9B' : item === 'blueprint' ? '#2563EB' : item === 'map' ? '#EBD9A6' : item === 'clipboard' ? '#B8854F' : '#FAF6EC';
      blob(ctx, () => ctx.rect(-w / 2, (big ? -0.25 : -0.12) - h / 2, w, h), col, L);
      if (text) {
        ctx.save();
        ctx.translate(0, big ? -0.25 : -0.12);
        if (mirrored) ctx.scale(-1, 1);
        ctx.font = `900 ${big ? 0.05 : 0.026}px Montserrat, sans-serif`;
        ctx.fillStyle = INK;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const lines = text.split('\n');
        lines.forEach((ln, i) => ctx.fillText(ln, 0, (i - (lines.length - 1) / 2) * (big ? 0.055 : 0.03)));
        ctx.restore();
      } else if (item !== 'book') {
        for (let i = 0; i < 4; i++) line(ctx, [-w * 0.35, -0.17 + i * 0.03, w * 0.35, -0.17 + i * 0.03], L * 0.4);
      }
      break;
    }
    case 'lantern':
      line(ctx, [0, 0, 0, 0.04], L);
      blob(ctx, () => ctx.roundRect(-0.035, 0.04, 0.07, 0.09, 0.01), '#FFD27A', L);
      break;
    case 'bag':
      blob(ctx, () => ctx.roundRect(-0.06, 0.0, 0.12, 0.1, 0.02), '#8A5A35', L);
      break;
    case 'money':
    case 'coin':
      blob(ctx, () => ctx.arc(0, -0.03, 0.04, 0, Math.PI * 2), '#F2C14E', L);
      break;
    case 'key':
      blob(ctx, () => ctx.arc(0, -0.08, 0.025, 0, Math.PI * 2), '#F2C14E', L);
      line(ctx, [0, -0.055, 0, 0.0, 0.02, 0.0], L * 1.2, '#B88A2E');
      break;
    case 'fish':
      blob(ctx, () => ctx.ellipse(0.05, 0, 0.07, 0.03, 0, 0, Math.PI * 2), '#7FB7D9', L);
      break;
    case 'mic':
      line(ctx, [0, 0.02, 0, -0.07], L * 1.6);
      blob(ctx, () => ctx.arc(0, -0.09, 0.025, 0, Math.PI * 2), '#9AA3AD', L);
      break;
    case 'camera':
      blob(ctx, () => ctx.roundRect(-0.06, -0.08, 0.12, 0.08, 0.01), '#2A2A30', L);
      blob(ctx, () => ctx.arc(0, -0.04, 0.025, 0, Math.PI * 2), '#6FD3FF', L * 0.6);
      break;
    case 'gift':
      blob(ctx, () => ctx.rect(-0.06, -0.1, 0.12, 0.1), '#E8364E', L);
      ctx.fillStyle = '#FFE14D';
      ctx.fillRect(-0.012, -0.1, 0.024, 0.1);
      break;
    case 'drum':
      blob(ctx, () => ctx.rect(-0.08, -0.02, 0.16, 0.12), '#C9283E', L);
      blob(ctx, () => ctx.ellipse(0, -0.02, 0.08, 0.025, 0, 0, Math.PI * 2), '#F4F1EA', L);
      break;
    case 'trumpet':
      line(ctx, [0, 0, 0.14, -0.04], L * 1.6, '#E8B33A');
      blob(ctx, () => ctx.ellipse(0.16, -0.045, 0.02, 0.04, 0.3, 0, Math.PI * 2), '#E8B33A', L);
      break;
    case 'bucket':
      blob(ctx, () => { ctx.moveTo(-0.06, 0.02); ctx.lineTo(0.06, 0.02); ctx.lineTo(0.05, 0.13); ctx.lineTo(-0.05, 0.13); ctx.closePath(); }, '#9AA3AD', L);
      break;
    case 'rope':
      ctx.beginPath();
      ctx.arc(0, 0.05, 0.05, 0, Math.PI * 2);
      ctx.lineWidth = L * 1.4;
      ctx.strokeStyle = '#B8854F';
      ctx.stroke();
      break;
    case 'plank':
      blob(ctx, () => ctx.rect(-0.2, -0.03, 0.4, 0.05), '#B8854F', L);
      break;
  }
  ctx.restore();
}
