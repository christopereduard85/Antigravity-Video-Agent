import type { WorldSet } from '../engine/types';

export const SETS: Record<string, WorldSet> = {
  bostonTank: {
    sky: 'morning',
    ground: 'cobble',
    groundColor: '#8E96A0',
    fog: 0.3,
    ambience: 'city',
    backdrop: 'city',
    items: [
      // Cobblestone street in foreground
      { k: 'road', at: [0, 0, 0.4], len: 28, c: '#7B838E' },

      // The 50-foot Riveted Steel Tank (sits at z = -3.2 so its cylindrical silhouette, roof, and city backdrop frame cleanly in 9:16)
      {
        k: 'tank',
        id: 'tank',
        at: [0, 0, -3.2],
        s: [2.8, 3.2, 2.8],
        c: '#5B6673',
        anim: [
          { at: 'w4', to: 'w6', do: 'shake', amt: 1.5 },
          { at: 'w5', to: 'w8e', do: 'explode', amt: 1.15 },
          { at: 'w50', to: 'w63e', do: 'wobble', amt: 0.6 },
          { at: 'w83', to: 'w100e', do: 'shake', amt: 1.9 },
          { at: 'w101', to: 'w118e', do: 'explode', amt: 1.3 },
          { at: 'w101', to: 'w118e', do: 'tilt', amt: 1.4 },
        ],
      },
      // Conical tank roof
      {
        k: 'cone',
        at: [0, 3.2, -3.2],
        s: [2.5, 0.95, 2.5],
        c: '#464F5B',
        anim: [
          { at: 'w5', to: 'w8e', do: 'rise', amt: 1.35 },
          { at: 'w5', to: 'w8e', do: 'tilt', amt: -1.6 },
          { at: 'w83', to: 'w100e', do: 'shake', amt: 2.1 },
          { at: 'w101', to: 'w118e', do: 'rise', amt: 1.5 },
          { at: 'w101', to: 'w118e', do: 'tilt', amt: 1.8 },
        ],
      },
      // Brown paint shell that appears when the manager paints the tank brown (w72..w101, and callback w213+)
      {
        k: 'tank',
        id: 'brownCoat',
        at: [0, 0, -3.2],
        s: [2.88, 3.18, 2.88],
        c: '#7A3E1D',
        anim: [
          { at: 0, do: 'hide' },
          { at: 'w72', do: 'show' },
          { at: 'w83', to: 'w100e', do: 'shake', amt: 1.9 },
          { at: 'w101', to: 'w118e', do: 'explode', amt: 1.3 },
          { at: 'w101', to: 'w118e', do: 'tilt', amt: 1.4 },
          { at: 'w213', do: 'show' },
        ],
      },
      // Molasses leak puddle at base of tank (organic glossy puddle)
      {
        k: 'puddle',
        at: [0.2, 0.02, -0.3],
        s: [2.2, 0.08, 1.3],
        c: '#5C2E14',
      },
      // Giant 25-foot Molasses Tsunami Wave that erupts at w101 ("BOOM!") behind the fleeing characters
      {
        k: 'wave',
        id: 'syrupWave',
        at: [0, 0, -1.8],
        s: [0.85, 0.65, 0.45],
        c: '#633215',
        anim: [
          { at: 0, do: 'hide' },
          { at: 'w101', do: 'show' },
          { at: 'w101', to: 'w118e', do: 'pop', amt: 1.15 },
          { at: 'w105', to: 'w118e', do: 'move', pos: [0, 0, -0.35] },
          { at: 'w119', do: 'hide' },
        ],
      },

      // Company sign & North End buildings in background (framed within 9:16 portrait view)
      {
        k: 'sign',
        id: 'tankSign',
        at: [-1.85, 0, -1.6],
        rot: 18,
        s: 0.72,
        c: '#FAF3E0',
        text: 'BOSTON MOLASSES\n2,300,000 GAL · 1919',
      },
      { k: 'factory', at: [-3.8, 0, -5.8], rot: 14, s: 0.85, c: '#A84A38', c2: '#FFE08A' },
      { k: 'shop', at: [3.6, 0, -5.4], rot: -16, s: 0.9, c: '#E8D6B8', c2: '#2E5B9E', text: 'NORTH END CAFE' },
      { k: 'building', at: [5.6, 0, -7.2], rot: -10, s: 0.9, c: '#5B6D84' },

      // Street props
      { k: 'lamp', at: [-2.4, 0, -0.8] },
      { k: 'lamp', at: [2.4, 0, -0.8] },
      { k: 'barrel', at: [-1.9, 0, -0.9], c: '#7A4824' },
      { k: 'barrel', at: [1.9, 0, -0.9], c: '#7A4824' },
      { k: 'crate', at: [2.3, 0, -1.1], c: '#A67442' },
    ],
  },

  floodedStreet: {
    sky: 'overcast',
    ground: 'dirt',
    groundColor: '#7A4222',
    fog: 0.25,
    ambience: 'city',
    backdrop: 'city',
    items: [
      // Thick wavy puddles of glossy brown molasses across the street
      { k: 'puddle', at: [0, 0.02, 0], s: [14, 0.08, 10], c: '#5E3016' },
      { k: 'puddle', at: [-1.2, 0.05, 0.4], s: [4.5, 0.08, 3.2], c: '#854824' },
      { k: 'puddle', at: [1.5, 0.05, 0.2], s: [4.2, 0.08, 3.0], c: '#854824' },

      // Crushed elevated train girder & tilted truck in background
      {
        k: 'arch',
        id: 'crushedTrack',
        at: [-2.8, -0.2, -2.6],
        rot: 18,
        c: '#748294',
        anim: [{ at: 0, to: 120, do: 'tilt', amt: 1.1 }],
      },
      {
        k: 'car',
        id: 'gluedTruck',
        at: [2.4, -0.1, -1.9],
        rot: -24,
        c: '#C9382E',
        c2: '#8FD3FF',
        anim: [{ at: 0, to: 120, do: 'tilt', amt: -0.8 }],
      },
      { k: 'barrel', at: [-2.1, -0.2, -0.6], rot: 42, c: '#8A5632' },
      { k: 'crate', at: [2.2, -0.22, -0.5], rot: -30, c: '#A67442' },
      { k: 'shop', at: [-5.5, 0, -5.2], rot: 12, c: '#F2E2C4', c2: '#C84638', text: 'FRESH WAFFLES' },
      { k: 'building', at: [5.8, 0, -5.8], rot: -12, c: '#5E7088' },
      { k: 'lamp', at: [-3.4, -0.1, -1.4], rot: 15 },
    ],
  },

  ketchupLab: {
    sky: 'day',
    ground: 'tile',
    groundColor: '#C8D6E2',
    fog: 0.22,
    ambience: 'none',
    backdrop: 'hills',
    items: [
      // Demonstration table in foreground
      { k: 'desk', id: 'labTable', at: [0, 0, -0.35], s: [1.65, 0.9, 1.0], c: '#E8DFCE', c2: '#3B434F' },
      // Shaped 3D Ketchup Bottle on the left of the table
      {
        k: 'bottle',
        id: 'ketchupBottle',
        at: [-0.82, 0.56, -0.35],
        s: 0.95,
        c: '#D92632',
        c2: '#FAF3E0',
        anim: [
          { at: 'w149', to: 'w163e', do: 'shake', amt: 1.4 },
          { at: 'w154', to: 'w163e', do: 'tilt', amt: 2.2 },
        ],
      },
      // Wide-mouth 3D Molasses Jar on the right of the table
      {
        k: 'jar',
        id: 'molassesJar',
        at: [0.82, 0.56, -0.35],
        s: 0.95,
        c: '#5C2E14',
        c2: '#FAF3E0',
        anim: [{ at: 'w168', to: 'w184e', do: 'squash', amt: 0.6 }],
      },
      // Ground-anchored explanation board behind the scientist
      {
        k: 'board',
        id: 'physicsBoard',
        at: [0, 1.22, -3.2],
        s: 0.92,
        c: '#FAF3E0',
        text: 'SHEAR-THINNING FLUID\nWARM = WAVE · COLD = GLUE',
      },
      { k: 'plant', at: [-2.6, 0, -2.0], s: 1.15 },
      { k: 'plant', at: [2.6, 0, -2.0], s: 1.15 },
      { k: 'house', at: [-5.8, 0, -6.5], rot: 15 },
      { k: 'house', at: [5.8, 0, -6.5], rot: -15 },
    ],
  },

  cityHall: {
    sky: 'indoor',
    ground: 'carpet',
    groundColor: '#234B9E',
    fog: 0.12,
    ambience: 'office',
    backdrop: 'none',
    items: [
      { k: 'room', at: [0, 0, 0], c: '#EAE2CE', c2: '#234B9E' },
      {
        k: 'desk',
        id: 'lawDesk',
        at: [0, 0, 0.1],
        s: [1.35, 0.9, 1.0],
        c: '#8A5632',
        c2: '#3B2818',
        anim: [
          { at: 'w199', to: 'w201', do: 'shake', amt: 0.6 },
          { at: 'w208', to: 'w210e', do: 'bounce', amt: 0.35 },
        ],
      },
      {
        k: 'board',
        id: 'lawBoard',
        at: [0, 1.22, -3.6],
        s: 0.92,
        c: '#FAF3E0',
        text: 'BOSTON BUILDING CODE\nENGINEER STAMP REQUIRED',
      },
      { k: 'flag', at: [-2.8, 0, -3.6], c: '#D92B3A' },
      { k: 'flag', at: [2.8, 0, -3.6], c: '#234B9E' },
      { k: 'shelf', at: [-3.4, 0, -3.5], s: 1.1 },
      { k: 'shelf', at: [3.4, 0, -3.5], s: 1.1 },
      { k: 'plant', at: [-2.4, 0, -1.6], s: 1.1 },
      { k: 'plant', at: [2.4, 0, -1.6], s: 1.1 },
    ],
  },
};
