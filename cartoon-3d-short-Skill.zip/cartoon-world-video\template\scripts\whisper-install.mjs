#!/usr/bin/env node
// Optional installer for local Whisper.cpp word-level timestamp extraction.
import path from 'node:path';
import { installWhisperCpp, downloadWhisperModel } from '@remotion/install-whisper-cpp';

const to = path.join(process.cwd(), 'whisper.cpp');
console.log('[whisper] Installing whisper.cpp into', to);
await installWhisperCpp({ to, version: '1.5.5' });
console.log('[whisper] Downloading ggml-base.en.bin model...');
await downloadWhisperModel({ folder: to, model: 'base.en' });
console.log('[whisper] Ready! Run `npm run timings` after placing public/vo.mp3.');
