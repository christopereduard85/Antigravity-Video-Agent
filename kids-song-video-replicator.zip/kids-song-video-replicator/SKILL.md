---
name: kids-song-video-replicator
description: End-to-end pipeline to replicate a "Super Simple Songs / Pinkfong"-style children's music video in Remotion (React + procedural SVG) from a reference video + a new song (.wav) + lyrics (.txt). Covers reference analysis, beat/lyric timing (Whisper + onset re-anchoring), procedural character rigs with food costumes, theatre/food sets, straddling wipe transitions, karaoke lyric bar, die-cut sticker overlays, pop-out watermark, QA stills and GPU render. Use when the user says "replicate this kids video", "make a nursery-rhyme / kids song video like this reference", "Pinkfong style", "costume party song video", or gives a reference MP4 + song WAV + lyric TXT. Ships a complete, proven working template project (Halloween Night, 3997 frames) to copy and adapt.
---

# Kids Song Video Replicator (Remotion)

Proven pipeline. Produced `HalloweenNight.mp4` (1920x1080, 30 fps, 3997 frames, 133.2 s) that the user approved.
**Do not improvise a new architecture. Copy the template, then change data + characters + sets.**

## 0. Golden rules (read before anything)

1. **Template first.** `templates/project/` is a complete working Remotion project. Copy it, `npm install`, render a still. Only then edit.
2. **One source of truth for time.** All section/lyric timing lives in `analysis/build_timing.py` → generates `video/src/data/beats.json` + `video/src/data/lyrics_timed.json`. Never hand-edit the JSON. Never hard-code frame numbers in components except the wipe `cutFrame` list (must equal section boundaries).
3. **Sections must be contiguous.** `section[i].endFrame === section[i+1].startFrame`. A gap = rogue frames of the wrong scene (real bug we hit at 01:17). See `references/07_LESSONS_LEARNED.md`.
4. **No pasted PNG characters.** Characters are procedural SVG rigs (body path + eyes + mouth visemes + IK limbs + springs). Rules in `templates/project/docs/CHARACTER_DESIGN_SYSTEM.md`.
5. **Never cover the character.** Overlays (karaoke, stickers, watermark) live only in the safe periphery: top corners y<260, side margins x<260 or x>1660, karaoke bar y=995..1065.
6. **Verify by rendering stills, not by reasoning.** After every change render 1–3 still frames at the affected moments and LOOK at them.
7. **Ask the user before** choosing characters/designs and before the full render. Show QA sheets.
8. **Log progress** in `NEXT_STEPS.md` + `PRODUCTION_PLAN.md` §6 after every task (handoff for the next model).

## 1. Inputs you need from the user

| Input | Example | Notes |
|---|---|---|
| Reference video | `ReferenceVideo.mp4` | the style + structure to copy |
| New song audio | `Halloween Night.wav` | duration decides total frames = `round(sec*30)` |
| Lyrics text | `PROJECTlyric.txt` | verses / choruses / finale labelled |
| Logo / watermark text | `edufam` | used by `LogoBug.tsx` |

## 2. Phase map (do in order, each has an acceptance gate)

| # | Phase | Output | Gate | Details |
|---|---|---|---|---|
| P0 | Setup & tools check | node, ffmpeg, python+numpy+scipy, Chrome | commands print versions | `references/01_SETUP.md` |
| P1 | Reference analysis | frames, contact sheets, cut list, style DNA, structure table | `PRODUCTION_PLAN.md` §1–§2 filled | `references/02_REFERENCE_ANALYSIS.md` |
| P2 | Audio timing | BPM, downbeats, sections, 40-ish timed lyric lines, mouth envelope | stills + audio slices confirm onsets | `references/03_TIMING_AND_LYRICS.md` |
| P3 | Cast & design | roster table, model sheets, user approval | user says OK | `references/04_CHARACTERS.md` |
| P4 | Scaffold | Remotion project from template, audio in `public/` | `remotion still` frame 15 renders | `references/01_SETUP.md` |
| P5 | Rigs & costumes | 1 hero end-to-end + QA sheet, then rest | `QA-Bobo`, `QA-Cast` stills OK | `references/04_CHARACTERS.md` |
| P6 | Sets & transitions | stage/food/skyline/street sets, curtain/drip/stripe/iris wipes | no checkerboard on any camera move | `references/05_SCENES_SETS_TRANSITIONS.md` |
| P7 | Block all sections | `SceneBodyAtFrame` switch for every section id | `QA-AllSections` 20-tile sheet OK | `references/05_SCENES_SETS_TRANSITIONS.md` |
| P8 | Lip-sync + beat dance | visemes from lyrics + amplitude envelope | mouths move on syllables | `references/03_TIMING_AND_LYRICS.md` |
| P9 | Sing-along overlays | karaoke bar, die-cut stickers, edufam watermark | stickers never cover cast | `references/06_OVERLAYS.md` |
| P10 | QA + feedback loop | user notes fixed one by one | user approves preview | `references/08_QA_AND_RENDER.md` |
| P11 | Final render | `out/<Name>.mp4` H.264 CRF 18 | ffprobe = expected frames | `references/08_QA_AND_RENDER.md` |

## 3. Quick start (copy-paste)

```powershell
# from the NEW workspace root that contains ReferenceVideo.mp4, <song>.wav, <lyrics>.txt
powershell -ExecutionPolicy Bypass -File <skill>/scripts/setup_project.ps1 -Song "Halloween Night.wav"
# then:
python analysis/audio_beats.py          # raw bpm/beats/downbeats -> analysis/beats.json
python analysis/build_timing.py         # sections + lyrics + mouth env -> video/src/data/*.json
./video/node_modules/.bin/tsc -p video/tsconfig.json --noEmit
powershell -File <skill>/scripts/render_qa_stills.ps1 -Frames 15,380,2328
```

Remotion still/render needs network-free Chrome: always pass
`--browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe"` (Windows). In a sandboxed agent, run remotion commands with sandbox bypass (headless shell download fails offline).

## 4. Template file map (what to edit for a new song)

| File | Role | Edit for new song? |
|---|---|---|
| `analysis/audio_beats.py` | BPM + beat grid from WAV | path only |
| `analysis/build_timing.py` | **sections, lyric line starts, word templates, visemes, total frames** | YES – main edit |
| `analysis/whisper_align.py`, `refine_lyrics.py`, `section_lag.py`, `tempo_drift.py` | helpers to find vocal onsets | run as needed |
| `video/src/theme.ts` | palette, fps, size, `durationInFrames` | durationInFrames |
| `video/src/timeline.ts` | `getSectionAtFrame`, `getLyricAtFrame` (reads JSON) | no |
| `video/src/rig/*` | shared rig engine (body, eyes, mouth, limbs, IK, springs, poses, spin) | no |
| `video/src/characters/<hero>/` | tokens.ts (shape+colour) + costume/*.tsx | YES – new cast |
| `video/src/sets/Sets.tsx` | all backgrounds | adapt theme |
| `video/src/transitions/Wipes.tsx` | Curtain / Drip / Stripe / Iris wipes | colours |
| `video/src/Root.tsx` | `SceneBodyAtFrame` per section + `CHORUS_CUT_TRANSITIONS` + compositions | YES – section ids & cutFrames |
| `video/src/ui/SingAlongOverlays.tsx` | karaoke bar + die-cut stickers per section | sticker kinds |
| `video/src/ui/LogoBug.tsx` | pop-out watermark sticker | text |

## 5. Hard-won lessons (top 8 — full list in `references/07_LESSONS_LEARNED.md`)

1. Lyrics "late" → user perceives text late when it appears at the sung onset. Use real Whisper onsets + `LEAD = -0.06 s` + karaoke **0.4 s line lead-in** (line shows 0.4 s before first word, word highlight exactly on time).
2. Do NOT trust a constant BPM grid for line starts; tempo drifts and there are breaks (drum roll, "Everybody!" shout, spin/trumpet). Anchor every line to measured onsets; re-check each verse block separately.
3. Section gaps → `getSectionAtFrame` fallback rendered last section (Outro) for 12 frames. Build sections with `f0 = prev_frame`.
4. Wipes must **straddle** the cut: enter last 14 frames of section A, full cover exactly at `cutFrame`, exit first 14 frames of section B.
5. Camera zoom/pan exposed transparent edges → every set draws an overscan bleed rect `x=-960 y=-600 w=3840 h=2280`.
6. Hats/buckets drifting off characters → attach props inside `Character.tsx` using `deformBodyPoint` / `pose.handL`, never as separate absolutely positioned layers.
7. "Label" the user wanted = **character/food die-cut stickers popping on cue**, NOT text banners.
8. Watermark = small die-cut pill "edufam", pops in (spring overshoot) at a different safe corner every ~12 s cycle (2.4 s visible), never center.

## 6. Communication protocol with user (what worked)

- Show contact sheets / QA grids, not walls of text.
- When user reports timing ("telat", "kecepetan"), ask nothing — measure that block's onsets (audio slice + Whisper), shift only that block, re-render 1 still, report new seconds.
- When user sends a screenshot with timecode `mm:ss.ff`, convert: `frame = (mm*60+ss)*30 + ff`. Render that frame + neighbours, find root cause in data, not in pixels.
- Keep a numbered changelog row per fix in `PRODUCTION_PLAN.md` §6.

## 7. Reference docs

- `references/01_SETUP.md` – tools, install, sandbox notes, scaffold
- `references/02_REFERENCE_ANALYSIS.md` – ffmpeg frame/contact-sheet/cut extraction, style DNA template
- `references/03_TIMING_AND_LYRICS.md` – beat grid, Whisper, onset anchoring, word templates, visemes
- `references/04_CHARACTERS.md` – cast design, model-sheet prompts, rig engine, costumes
- `references/05_SCENES_SETS_TRANSITIONS.md` – section blocking, camera rig, sets, wipes
- `references/06_OVERLAYS.md` – karaoke bar, die-cut stickers, watermark
- `references/07_LESSONS_LEARNED.md` – every bug + fix from the original run
- `references/08_QA_AND_RENDER.md` – QA stills, contact sheet comp, GPU render, ffprobe check
- `references/09_FEEDBACK_HISTORY.md` – chronological user requests → what was done (replay order)
- `references/10_WEAK_MODEL_PLAYBOOK.md` – **MANDATORY for smaller/weaker models**: literal checklist, exact math formulas, "never edit vs edit here" file rules, and 60-second timing fix SOP
- `templates/project/docs/` – PRODUCTION_PLAN, CHARACTER_DESIGN_SYSTEM, NEXT_STEPS, AGENTS.md (filled examples)
- `examples/` – approved model sheets + QA sheets (visual target)
