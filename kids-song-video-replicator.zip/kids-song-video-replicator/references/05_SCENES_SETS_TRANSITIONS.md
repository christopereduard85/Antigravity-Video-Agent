# 05 — Scenes, sets, camera, transitions

## Architecture (Root.tsx)

```
MainVideo (composition "Main", durationInFrames = theme.durationInFrames)
  <Audio src={staticFile('HalloweenNight.wav')} />
  RenderSceneAtFrame(frame)            <svg 1920x1080>
    SceneBodyAtFrame(frame)            ← picks scene by getBeatState(frame).section.id
    SingAlongOverlays(frame)           ← karaoke + stickers (see 06)
    StraddlingWipeOverlay(frame)       ← chorus→next-section wipes
    LogoBug(frame)                     ← pop-out watermark (see 06)
QAAllSections  (composition "QA-AllSections": 20 sample frames in a 5x4 grid)
QABobo / QACast (character QA)
```

Everything is a pure function of `frame` → deterministic, any frame renders standalone (needed for parallel rendering).

Inside `SceneBodyAtFrame`: `localFrame = frame - sec.startFrame`, `secProgress = localFrame / secDuration`. Each section branch returns `<CameraRig shot={…}> <Set/> <Characters/> </CameraRig>` (+ optional full-screen wipe like `CurtainWipe`).

## Section recipes used (copy, change hero/food)

| Section | Set | Characters | Camera (secProgress sub-shots) |
|---|---|---|---|
| A intro | `CastleWindowSet` (moon, window, candles, Pip bat) | Pip | slow push-in 1.04→1.24, slight rotate |
| B band intro | `TheatreStageSet showBand` + `CurtainWipe openProgress=secProgress` | hero 1 walks in with mic | zoom 1.16→1.05 |
| C1..C4 verse | `TheatreStageSet showBand spotlights=[900]` | solo hero `mode=sing`, mic, bowler hat tip in first 36% | 4 cuts: 0–28% wide push, 28–56% close 1.28–1.36, 56–84% pan 1080→880, 84–100% punch 1.34→1.44 + rotate + beatPulse |
| T1..T4 transform | same stage | `evalSpinTransform` pose + `TornadoSwirl` (3 colours) | zoom 1.16 + sin punch 0.22, rotate sin·2.2 |
| K1..K4 chorus | `FoodChorusSet food=…` (6 mini food dancers) 0–78%, then `BandChorusCutawaySet` 78–100% | costumed hero `mode=dance` | 3 sub-shots + band cutaway |
| I1 interlude | stage band only | Bones, Spinny, Boo | pan 820→1100 |
| F1 finale | stage lineup (4 heroes) then `MoonlitFoodSkylineSet` (heroes on giant foods) | all 4 costumed | multi-shot |
| F2 | 4-panel colour grid (one hero per quadrant, beat pops) | all | static |
| F3 | `TrickOrTreatStreetSet` | all 4 with candy buckets | pan then pull back |
| O outro | stage, curtain closes, Boo sax, `IrisWipe` closes to black | Boo | static |

Rule: **strict solo progression** — verse/transform/chorus N show only hero N (+band). All heroes only reunite in F1..F3. (User found mixed heroes confusing.)

## CameraRig

`camera/CameraRig.tsx`: `CameraShot = {focusX, focusY, zoom, rotate?, beatPulse?}`; transforms the world group so (focusX,focusY) is centred, zoom ≥ 1.04 always (never below 1 → edges show). `beatPulse` adds tiny zoom kick on beats. Helpers `lerp`, `easeInOutCubic`, `easeOutCubic`, `clamp01`.

## Sets (`sets/Sets.tsx`)

- Every set first draws an **overscan bleed rect** `x=-960 y=-600 width=3840 height=2280` in its background colour. Mandatory (camera zoom/rotate showed checkerboard before).
- Sets animate with beat (spotlight sway, mini dancers hop, stars twinkle).
- Exports: `CastleWindowSet`, `TheatreStageSet`, `FoodChorusSet`, `BandChorusCutawaySet`, `MoonlitFoodSkylineSet`, `TrickOrTreatStreetSet`, `MiniFoodDancer`, `JackOLantern`.

## Transitions (`transitions/Wipes.tsx`) + straddling rule

- `CurtainWipe openProgress` (0 closed … 1 open), `DripWipe progress color`, `StripeWipe progress frame`, `IrisWipe cx cy radius`.
- Chorus → next section uses `StraddlingWipeOverlay` with list:
```ts
const CHORUS_CUT_TRANSITIONS = [
  { cutFrame: 789,  kind: 'stripe' },                    // K1 -> I1
  { cutFrame: 1576, kind: 'drip', color: '#FF9EC4' },    // K2 -> C3
  { cutFrame: 2330, kind: 'drip', color: '#FF6FAE' },    // K3 -> C4
  { cutFrame: 3102, kind: 'stripe' },                    // K4 -> F1
];
// halfSpan = 14 frames: progress 0→0.5 over [cut-14, cut] (covering), 0.5→1 over [cut, cut+14] (revealing)
```
`cutFrame` MUST equal the K-section `endFrame` from beats.json. After every timing rebuild, re-copy these numbers (print them from build_timing.py output).
- Wipe is drawn after overlays so it covers karaoke too.

## Checklist after blocking

- Render `QA-AllSections` (5x4 grid of sample frames; edit `QA_SAMPLE_FRAMES` with your section mid-points + wipe frames).
- Each tile: right hero, right set, nothing cropped, no checkerboard, no empty frame.
