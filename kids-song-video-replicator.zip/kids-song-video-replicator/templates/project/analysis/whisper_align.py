"""Whisper word timestamps -> align to PROJECTlyric lines -> shift each line so its first word matches."""
import json, re, shutil
from faster_whisper import WhisperModel

m = WhisperModel('small.en', device='cpu', compute_type='int8')
segs, _ = m.transcribe('Halloween Night.wav', word_timestamps=True, language='en',
                       vad_filter=False, condition_on_previous_text=False,
                       initial_prompt=open('PROJECTlyric.txt', encoding='utf-8').read()[:400])
words = []
for s in segs:
    for w in s.words:
        words.append((re.sub(r"[^a-z']", '', w.word.lower()), w.start, w.end))
json.dump(words, open('analysis/whisper_words.json', 'w'), indent=0)
print(len(words), 'words')

norm = lambda s: re.sub(r"[^a-z']", '', s.lower().replace('’', "'"))
lyr = json.load(open('analysis/lyrics_timed.json', encoding='utf-8'))
wi = 0
for line in lyr:
    target = [norm(w['w']) for w in line['words']]
    # search forward window for best match of first 3 words near expected time
    best = None
    for j in range(wi, min(len(words), wi + 60)):
        if words[j][1] > line['startSec'] + 4: break
        if words[j][1] < line['startSec'] - 4: continue
        sc = sum(1 for k in range(min(3, len(target))) if j + k < len(words) and words[j + k][0] == target[k])
        if sc and (best is None or sc > best[0] or (sc == best[0] and abs(words[j][1]-line['startSec']) < abs(words[best[1]][1]-line['startSec']))):
            best = (sc, j)
    if best and best[0] >= 2:
        j = best[1]
        # per-word: use whisper starts where words match in sequence, else keep template offset
        shift = words[j][1] - line['words'][0]['startSec']
        for k, w in enumerate(line['words']):
            if j + k < len(words) and words[j + k][0] == target[k]:
                w['startSec'] = round(words[j + k][1], 3)
                w['endSec'] = round(max(words[j + k][2], words[j + k][1] + 0.12), 3)
            else:
                w['startSec'] = round(w['startSec'] + shift, 3)
                w['endSec'] = round(w['endSec'] + shift, 3)
        for a, b in zip(line['words'], line['words'][1:]):  # monotonic, no gaps
            if b['startSec'] < a['startSec'] + 0.05: b['startSec'] = round(a['startSec'] + 0.05, 3)
            a['endSec'] = b['startSec']
        line['startSec'] = line['words'][0]['startSec']; line['endSec'] = line['words'][-1]['endSec']
        wi = j + len(target)
        print(f"OK  {line['section']} {line['startSec']:7.2f} shift {shift:+.2f}  {line['line']}")
    else:
        print(f"--  {line['section']} {line['startSec']:7.2f} (kept)  {line['line']}")
for a, b in zip(lyr, lyr[1:]):
    if a['endSec'] > b['startSec'] - 0.03:
        a['endSec'] = round(b['startSec'] - 0.03, 3); a['words'][-1]['endSec'] = max(a['words'][-1]['startSec'] + 0.08, a['endSec'])
for l in lyr:
    l['startFrame'] = round(l['startSec'] * 30); l['endFrame'] = round(l['endSec'] * 30)
json.dump(lyr, open('analysis/lyrics_timed.json', 'w', encoding='utf-8'), indent=2)
shutil.copy('analysis/lyrics_timed.json', 'video/src/data/lyrics_timed.json')
