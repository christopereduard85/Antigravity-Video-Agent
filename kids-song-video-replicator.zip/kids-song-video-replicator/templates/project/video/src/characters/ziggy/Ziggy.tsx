import React from 'react';
import { Character } from '../../rig/Character';
import { Pose } from '../../rig/types';
import { ziggyTokens } from './tokens';
import { donutCostume } from './costume/Donut';

export interface ZiggyProps {
  pose: Pose;
  frame: number;
  fps?: number;
  costume?: 'none' | 'donut';
  hasMic?: boolean;
  hatTipProgress?: number;
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId?: string;
}

export const Ziggy: React.FC<ZiggyProps> = ({
  pose,
  frame,
  fps = 30,
  costume = 'none',
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1,
  instanceId = 'ziggy',
}) => {
  return (
    <Character
      tokens={ziggyTokens}
      pose={pose}
      frame={frame}
      fps={fps}
      costume={costume === 'donut' ? donutCostume : null}
      hasMic={hasMic}
      hatTipProgress={hatTipProgress}
      hasCandyBucket={hasCandyBucket}
      scale={scale}
      instanceId={instanceId}
    />
  );
};
