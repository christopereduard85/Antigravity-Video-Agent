# Universal Remotion Cinematic Storytelling Agent (v2.0)

Paket Skill ini mengubah AI Agent (Antigravity, Claude, Cursor, ChatGPT, dll.) menjadi **Autonomous Animation Director** lengkap untuk memproduksi video cerita animasi sinematik di Remotion (16:9 & 9:16, 720p - 4K @ 30fps).

---

## 🚀 Fitur Unggulan v2.0:

1. **One-Shot Intake Questionnaire**:
   - Menanyakan sekali di awal (dengan pilihan tombol/formulir terstruktur):
     - Voiceover (wajib)
     - Script (SRT/VTT/JSON/TXT [mm:ss], teks polos, atau tanpa script)
     - Aspek (16:9 atau 9:16)
     - Resolusi (720p / 1080p / 1440p / 4K)
     - Caption (default aktif untuk 9:16)
     - Musik (generate, file sendiri, tanpa musik) & SFX (on/off)
     - Judul / slug proyek
2. **Deep Reference Video Forensics (Bukan Sekadar Beberapa Gambar)**:
   - Chat memeriksa video referensi pada **30 fps secara mendalam di sepanjang durasi**, bukan hanya melihat 2-3 gambar acak.
   - Menganalisis secara detail: Struktur cerita, hook detik 0-5, lighting volumetrik, kontras gelap-terang, sudut & gerak kamera, style visual (2D/3D), biomekanika gerak, efek vignette/partikel, serta ritme cuts.
   - Hasil analisis otomatis disimpan ke dalam **`story/reference_analysis.json`** dan **`story/reference_analysis.md`** sebagai dokumen pengingat baku yang wajib dipatuhi di semua tahap berikutnya.
3. **Automated Project Scaffolding (`new_project.py`)**:
   - Membangun `projects/<slug>/` dengan subfolder `input`, `timeline`, `story`, `scenes`, `build`, `out`, `audio`.
   - Mengukur durasi audio presisi dengan `ffprobe` dan menulis `config.json`.
3. **3-Path Timestamp Engine**:
   - **Jalur A (Script Bertimestamp)**: `parse_script.py` mengimpor SRT/VTT/JSON/TXT `[mm:ss]` dengan distribusi kata proporsional panjang karakter.
   - **Jalur B (Script Teks Polos)**: `transcribe.py --script` menjalankan Whisper dan menyelaraskan kata naskah ke timing audio dengan `difflib` (validasi kecocokan `>= 90%`).
   - **Jalur C (Tanpa Script)**: `transcribe.py` menjalankan Whisper murni (small default, base untuk mesin hemat, large-v3 untuk audio sulit, CUDA GPU / CPU int8).
   - Menghasilkan `timeline/words.json`, `sentences.json`, `transcript.txt` dan mengecek kesesuaian durasi akhir audio.
4. **Beat Segmentation Engine (`beats.py`)**:
   - Memecah kalimat menjadi "beat" visual (target 3.0s, min 1.2s, max 6.5s).
   - Menghasilkan `beats.json` dan draf `story/shots.json` (`scene: "TODO"`).
5. **Story Bible & Shot Director**:
   - Menulis `story/bible.md` (logline, cast dengan 1 warna khas, lokasi, motif, musik) dan `scenes/cast.js` (kostum).
   - Menulis ulang `shots.json`: shot berurutan tanpa celah, pre-cut 0.1-0.2s sebelum frasa, median 2-3.5s, shot pembuka tiap lokasi baru, pacing 15-25 shot/menit.
6. **Library 36 SFX & 6 Ambience Loops (`sfx_library.py`)**:
   - 36 efek suara prosedural murni (whoosh, impact, riser, heartbeat, footstep bersih, pintu terkunci kayu tebal, getar HP, pop chime, glitch, glass shatter, clock tick, dll.) ditempatkan per shot dengan `at` (detik dari awal shot) dan `gain`.
   - Ambience (`rain`, `wind`, `city`, `roomtone`, `murmur`, `hum`) dilooping mulus dengan **crossfade 0.4 detik**.

---

## 📦 Struktur File di Dalam Skill:
- `SKILL.md`: Manual lengkap SOP AI Agent.
- `scripts/`:
  - `new_project.py`: Otomasi scaffolding folder dan pembacaan durasi `ffprobe`.
  - `parse_script.py`: Parser SRT/VTT/JSON/TXT dengan timing kata proporsional.
  - `transcribe.py`: Whisper transkripsi & penyelarasan teks `difflib`.
  - `beats.py`: Segmentasi kalimat ke beat visual 3.0s & draf shots.
  - `sfx_library.py`: Generator 36 sound effects dan ambience crossfade 0.4s.
  - `audio_synthesizer.mjs`: Generator audio Node.js instan tanpa Python.
- `templates/`:
  - `CharacterRig2D.template.tsx`: Rig stickman biomekanis berlayer dengan pose paket & HP anti-terbalik.
  - `Environment2D.template.tsx`: Template lingkungan lorong volumetrik.
  - `Smartphone.template.tsx`: Mockup smartphone modern dengan getaran dan chat pop-in.
  - `CloseUpDetail.template.tsx`: Detail objek close-up.
  - `SubtitleDisplay.template.tsx`: Subtitle karaoke dinamis word-by-word.

---

## 🚀 Cara Memasang & Memakai di Chat Baru:
1. Ekstrak file zip ini ke folder `.agents/skills/remotion-cinematic-agent/`.
2. Di chat baru mana pun, cukup panggil:
   > *"Gunakan skill remotion-cinematic-agent untuk membuat video animasi cerita ini."*
3. Agent akan langsung menampilkan **One-Shot Intake Questionnaire**, melakukan scaffolding, menjalankan transkripsi/alignment, menyusun story bible, dan memandu Anda tahap demi tahap dengan preview persis seperti SOP kita!
