#!/usr/bin/env node
// Render a single frame to out/still.jpg (usage: npm run still -- 150)
import { execSync } from 'node:child_process';
import fs from 'node:fs';

const frame = process.argv[2] || '30';
fs.mkdirSync('out', { recursive: true });
const cmd = `npx remotion still src/index.ts CartoonWorld out/frame-${frame}.jpg --frame=${frame} --gl=angle`;
console.log('[still]', cmd);
execSync(cmd, { stdio: 'inherit' });
