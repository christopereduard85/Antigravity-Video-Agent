import { BEATS, getLyricAtFrame, getSectionAtFrame, SectionInfo } from '../timeline';
import { Viseme } from './types';

export interface BeatState {
  frame: number;
  fps: number;
  sec: number;
  bpm: number;
  beatPeriodSec: number;
  beatFloat: number;
  beatIndex: number;
  phase: number; // 0..1 within current beat
  barFloat: number;
  barIndex: number;
  barPhase: number; // 0..1 within current 4-beat bar
  hop: number; // -1 (down squash on beat) .. +1 (up stretch off-beat)
  sway: number; // -1..+1 alternating every beat
  barWave: number; // -1..+1 smooth over 1 bar
  section: SectionInfo;
  mouthOpen: number;
  viseme: Viseme;
  activeLyric: string | null;
}

export function getBeatState(frame: number, fps = 30): BeatState {
  const sec = frame / fps;
  const bpm = BEATS.bpm;
  const beatPeriodSec = BEATS.beatPeriodSec;
  const beatFloat = Math.max(0, (sec - BEATS.offsetSec) / beatPeriodSec);
  const beatIndex = Math.floor(beatFloat);
  const phase = beatFloat - beatIndex;

  const barFloat = Math.max(0, (sec - BEATS.downbeats[0]) / BEATS.barPeriodSec);
  const barIndex = Math.floor(barFloat);
  const barPhase = barFloat - barIndex;

  // Classic Super Simple Songs bounce: squash down right on the beat (phase 0), hop up at phase 0.5
  const hop = -Math.cos(phase * Math.PI * 2);
  const sway = Math.sin((beatFloat * Math.PI) / 2);
  const barWave = Math.sin(barPhase * Math.PI * 2);

  const section = getSectionAtFrame(frame);
  const lyr = getLyricAtFrame(frame, fps);

  return {
    frame,
    fps,
    sec,
    bpm,
    beatPeriodSec,
    beatFloat,
    beatIndex,
    phase,
    barFloat,
    barIndex,
    barPhase,
    hop,
    sway,
    barWave,
    section,
    mouthOpen: lyr.mouthOpen,
    viseme: lyr.viseme,
    activeLyric: lyr.line?.line ?? null,
  };
}
