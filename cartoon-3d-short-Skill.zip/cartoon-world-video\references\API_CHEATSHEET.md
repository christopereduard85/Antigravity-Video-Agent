# Cartoon World Video — Declarative API Cheat-Sheet (`src/project/*`)

This reference lists every valid union value for `src/project/cast.ts`, `src/project/world.ts`, `src/project/shots.ts`, and `src/project/config.ts`.

---

## 1. Time Reference (`T` and `WordRef`)
- `'w0'`, `'w12'`, `'w69'` — Start of word `#N` (from `src/project/words.md`).
- `'w12e'` — End of word `#12`.
- `'w12+0.3'` / `'w12-0.2'` — Offset in seconds from word `#12`.

---

## 2. Character Design (`src/project/cast.ts`)
- **`pattern`**: `'plain' | 'stripes' | 'vstripes' | 'dots' | 'suit' | 'robe' | 'uniform' | 'overalls'`
- **`hair`**: `'none' | 'bowl' | 'side' | 'spiky' | 'bun' | 'long' | 'curly' | 'bald' | 'ponytail' | 'mohawk'`
- **`hat`**: `'none' | 'cap' | 'top' | 'bowler' | 'bandana' | 'crown' | 'police' | 'helmet' | 'shako' | 'beret' | 'tricorn' | 'hardhat' | 'chef' | 'cowboy' | 'wizard' | 'beanie' | 'straw' | 'hood'`
- **`extras`**: `'mustache' | 'beard' | 'glasses' | 'sunglasses' | 'tie' | 'belt' | 'blush' | 'freckles' | 'eyepatch' | 'scarf' | 'badge' | 'buttons' | 'collar' | 'apron' | 'cape' | 'sash' | 'epaulettes' | 'stubble'`

---

## 3. Character Performance Beats (`src/project/shots.ts`)
- **`do` (`Act`)**:
  - Locomotion: `'idle' | 'walk' | 'run' | 'march' | 'sneak' | 'tiptoe' | 'jump' | 'hop' | 'climb' | 'swim' | 'fly'`
  - Dialogue & Gesture: `'talk' | 'point' | 'wave' | 'cheer' | 'clap' | 'shrug' | 'think' | 'nod' | 'shake' | 'bow' | 'salute' | 'facepalm' | 'lookaround' | 'laugh' | 'dance'`
  - Physical & Impact: `'fall' | 'tumble' | 'sit' | 'lie' | 'panic' | 'cower' | 'recoil' | 'push' | 'pull' | 'carry' | 'lift' | 'throw' | 'punch' | 'hammer' | 'stomp' | 'spin' | 'reach' | 'flail' | 'shiver'`
  - Desk / Everyday: `'type' | 'phone' | 'drink' | 'eat' | 'read' | 'write'`
- **`face` (`Face`)**:
  `'neutral' | 'happy' | 'grin' | 'laugh' | 'smug' | 'sad' | 'cry' | 'angry' | 'shocked' | 'scared' | 'worried' | 'sleepy' | 'wink' | 'determined' | 'confused' | 'deadpan' | 'evil' | 'disgust' | 'love' | 'dizzy' | 'pain' | 'proud' | 'nervous' | 'cold'`
- **`hold` (`Item`)**:
  `'none' | 'phone' | 'cup' | 'mug' | 'sword' | 'spear' | 'shield' | 'sign' | 'paper' | 'book' | 'lantern' | 'torch' | 'hammer' | 'flag' | 'bag' | 'umbrella' | 'key' | 'money' | 'telescope' | 'map' | 'bottle' | 'pickaxe' | 'broom' | 'fish' | 'mic' | 'camera' | 'gift' | 'rifle' | 'drum' | 'trumpet' | 'scroll' | 'wrench' | 'clipboard' | 'coin' | 'bucket' | 'rope' | 'plank'`
- **`emote` (`Emote`)**:
  `'none' | '!' | '?' | '!?' | 'sweat' | 'anger' | 'sparkle' | 'heart' | 'zzz' | 'idea' | 'tears' | 'music' | 'dizzy' | 'steam' | 'shiver' | 'motion'`

---

## 4. 3D World Set & Props (`src/project/world.ts`)
- **`sky`**: `'day' | 'morning' | 'sunset' | 'dusk' | 'night' | 'overcast' | 'storm' | 'indoor'`
- **`ground`**: `'grass' | 'dirt' | 'cobble' | 'sand' | 'snow' | 'wood' | 'tile' | 'carpet' | 'stone' | 'water' | 'none'`
- **`backdrop`**: `'mountains' | 'hills' | 'city' | 'sea' | 'forest' | 'desert' | 'none'`
- **`k` (`Kind`)**:
  - Nature: `'tree' | 'pine' | 'palm' | 'bush' | 'rock' | 'hill' | 'mountain' | 'flowers' | 'grass' | 'river' | 'pond' | 'cliff'`
  - Town/Outdoor & Industrial: `'house' | 'shop' | 'tower' | 'castle' | 'wall' | 'church' | 'building' | 'lamp' | 'fence' | 'bench' | 'barrel' | 'crate' | 'cart' | 'well' | 'banner' | 'flag' | 'sign' | 'tent' | 'stall' | 'haystack' | 'windmill' | 'road' | 'bridge' | 'chainbridge' | 'swing' | 'boat' | 'ship' | 'cannon' | 'campfire' | 'statue' | 'column' | 'arch' | 'car' | 'train' | 'rails' | 'pier' | 'lighthouse' | 'factory' | 'chimney' | 'tank' | 'puddle' | 'wave' | 'bottle' | 'jar' | 'glue' | 'animal' | 'horse' | 'bird' | 'balloon' | 'scale' | 'seesaw' | 'pendulum' | 'spring' | 'gauge' | 'thermometer' | 'bomb'`
  - Interior: `'room' | 'desk' | 'chair' | 'table' | 'shelf' | 'bed' | 'door' | 'window' | 'clock' | 'frame' | 'plant' | 'computer' | 'counter' | 'rug' | 'throne' | 'fireplace' | 'chandelier' | 'board' | 'locker'`
  - Primitives: `'box' | 'cyl' | 'ball' | 'cone' | 'plane' | 'text'`
- **`anim[].do`**:
  `'shake' | 'wobble' | 'bounce' | 'fall' | 'tilt' | 'spin' | 'pop' | 'hide' | 'show' | 'move' | 'flow' | 'sway' | 'squash' | 'collapse' | 'explode' | 'rupture' | 'glow' | 'open' | 'sink' | 'rise'`

---

## 5. Camera, FX, Overlays & SFX (`src/project/shots.ts`)
- **`cam.move` (`CamMove`)**: `'push' | 'pull' | 'orbit' | 'truck' | 'pan' | 'crane' | 'drop' | 'follow' | 'top' | 'low' | 'close' | 'fly' | 'tilt' | 'hold'`
- **`fx[].k` (`FxKind`)**: `'dust' | 'smoke' | 'puff' | 'splinters' | 'debris' | 'sparks' | 'rivets' | 'confetti' | 'splash' | 'liquid' | 'pour' | 'shockwave' | 'impact' | 'stars' | 'hearts' | 'speedlines' | 'explosion' | 'flash' | 'shake' | 'bubbles' | 'leaves' | 'snow' | 'rain' | 'fire' | 'steam' | 'coins'` (plus optional `color?: string` on any `fx`, e.g. `color: '#633215'` for brown syrup splash)
- **`sfx[].name`**:
  - Built-in synthesized WAVs: `'pop' | 'ding' | 'boing' | 'whoosh' | 'thud' | 'stomp' | 'march' | 'creak' | 'whistle' | 'snap' | 'crash' | 'explosion' | 'splash' | 'bubbles' | 'sad' | 'stamp' | 'clang'`
  - Custom user WAV/MP3 in `public/sfx-user/`: `'user:filename.wav'`
