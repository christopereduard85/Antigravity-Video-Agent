import React from 'react';
import { CharacterTokens, Pose } from './types';
import { closedSmoothPath, deformBodyPoint, sampleBodyRing } from './geom';

/**
 * Rule 3 & 12: Shading and highlight deform WITH the body and assume top-left light source.
 * Rendered inside the body's <clipPath>.
 */
export const Shading: React.FC<{
  tokens: CharacterTokens;
  pose: Pose;
}> = ({ tokens, pose }) => {
  const { w, h, topTaper, squareness } = tokens.body;

  // Inner cutout shifted up-left so the exposed crescent on bottom-right forms the rim shade
  const litRing = sampleBodyRing(
    w,
    h,
    topTaper,
    squareness,
    pose.squash,
    pose.arc,
    -w * 0.085,
    -h * 0.095,
    0.985
  );
  const litD = closedSmoothPath(litRing, 0.21);

  // Soft glossy highlight patch on top-left forehead
  const hlPos = deformBodyPoint(-0.36, -0.56, w, h, topTaper, pose.squash, pose.arc);

  return (
    <g>
      {/* Fill whole clipped area with shade, then overlay shifted lit body */}
      <rect
        x={-w * 1.2}
        y={-h * 1.2}
        width={w * 2.4}
        height={h * 2.4}
        fill={tokens.colors.shade}
      />
      <path d={litD} fill={tokens.colors.base} />

      {/* Top-left studio highlight */}
      <ellipse
        cx={hlPos.x}
        cy={hlPos.y}
        rx={w * 0.14}
        ry={h * 0.075}
        fill={tokens.colors.highlight}
        opacity={0.42}
        transform={`rotate(-26 ${hlPos.x} ${hlPos.y})`}
      />
    </g>
  );
};
