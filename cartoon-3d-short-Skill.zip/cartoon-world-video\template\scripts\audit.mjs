#!/usr/bin/env node
// ============================================================================
// FULL-TIMELINE FRAME AUDITOR (scripts/audit.mjs)
// 1. Bundles the Remotion project once.
// 2. Renders 2 frames per shot (Beat A @ 22% + Beat B @ 78% of each shot)
//    across the entire timeline from start to finish using GPU WebGL (--gl=angle).
// 3. Computes pixel-difference motion scores between Beat A and Beat B of every
//    shot to detect frozen cameras, blank frames, or passive characters.
// 4. Stitches labeled contact sheets (out/audit/sheet-1.jpg, sheet-2.jpg) so
//    AI review agents can inspect every shot's ink, color, depth, camera
//    movement, and character interaction in one pass.
// ============================================================================
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { bundle } from '@remotion/bundler';
import { renderStill, selectComposition } from '@remotion/renderer';
import { findBrowserExecutable } from './browser.mjs';

const ROOT = process.cwd();
const AUDIT_DIR = path.join(ROOT, 'out/audit');
const FRAMES_DIR = path.join(AUDIT_DIR, 'frames');
const browserExecutable = findBrowserExecutable();

// Extract shot schedule via tsx (pure TS modules, no CSS imports)
const scheduleJson = execSync(
  `npx tsx -e "import { SHOTS } from './src/project/shots.ts'; import { CONFIG } from './src/project/config.ts'; import { timeOf, lastWordEnd } from './src/engine/timing.ts'; const end = lastWordEnd() + (CONFIG.tail ?? 1.2); const tl = SHOTS.map((shot, index) => ({ shot, index, startT: index === 0 ? 0 : timeOf(shot.from), endT: index + 1 < SHOTS.length ? timeOf(SHOTS[index + 1].from) : end })); console.log(JSON.stringify(tl));"`,
  { encoding: 'utf8' },
).trim();
const timeline = JSON.parse(scheduleJson);

fs.mkdirSync(FRAMES_DIR, { recursive: true });

console.log(`[audit] Bundling project to audit all ${timeline.length} shots (${timeline.length * 2} frames)...`);
const bundled = await bundle({
  entryPoint: path.join(ROOT, 'src/index.ts'),
});

const comp = await selectComposition({
  serveUrl: bundled,
  id: 'CartoonWorld',
  browserExecutable,
  chromiumOptions: { gl: 'angle' },
});

const sampleList = [];
for (const item of timeline) {
  const { shot, index, startT, endT } = item;
  const dur = Math.max(0.2, endT - startT);
  const tA = startT + dur * 0.24;
  const tB = startT + dur * 0.76;
  const fA = Math.min(comp.durationInFrames - 1, Math.max(0, Math.round(tA * comp.fps)));
  const fB = Math.min(comp.durationInFrames - 1, Math.max(0, Math.round(tB * comp.fps)));
  sampleList.push({ shotId: shot.id, beat: shot.beat, phase: 'A', frame: fA, time: Number(tA.toFixed(2)) });
  sampleList.push({ shotId: shot.id, beat: shot.beat, phase: 'B', frame: fB, time: Number(tB.toFixed(2)) });
}

for (let i = 0; i < sampleList.length; i++) {
  const s = sampleList[i];
  const file = path.join(FRAMES_DIR, `s${String(i).padStart(2, '0')}_${s.shotId}_${s.phase}_f${s.frame}.jpg`);
  s.file = file;
  await renderStill({
    composition: comp,
    serveUrl: bundled,
    output: file,
    frame: s.frame,
    imageFormat: 'jpeg',
    jpegQuality: 90,
    scale: 0.5, // 540x960 for fast, crisp QA inspection
    browserExecutable,
    chromiumOptions: { gl: 'angle' },
  });
  process.stdout.write(`[audit] Rendered ${i + 1}/${sampleList.length}: ${s.shotId} (${s.phase}) @ f=${s.frame} (${s.time}s)\n`);
}

// Assemble contact sheets (12 frames per 4x3 grid) using ffmpeg
const perSheet = 12;
const sheets = [];
for (let p = 0; p < sampleList.length; p += perSheet) {
  const chunk = sampleList.slice(p, p + perSheet);
  const sheetIdx = Math.floor(p / perSheet) + 1;
  const sheetPath = path.join(AUDIT_DIR, `sheet-${sheetIdx}.jpg`);
  const inputs = chunk.map((c) => `-i "${c.file}"`).join(' ');
  const cols = 4;
  const rows = Math.ceil(chunk.length / cols);
  const filter =
    chunk.map((_, i) => `[${i}:v]scale=360:-1[v${i}];`).join('') +
    chunk.map((_, i) => `[v${i}]`).join('') +
    `xstack=inputs=${chunk.length}:layout=` +
    chunk
      .map((_, i) => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        return `${col * 360}_${row * 640}`;
      })
      .join('|');
  try {
    execSync(`ffmpeg -y -v error ${inputs} -filter_complex "${filter}" -frames:v 1 "${sheetPath}"`);
    sheets.push(sheetPath);
  } catch {
    // Fallback if chunk has 1 image
    fs.copyFileSync(chunk[0].file, sheetPath);
    sheets.push(sheetPath);
  }
}

const report = {
  generatedAt: new Date().toISOString(),
  composition: { width: comp.width, height: comp.height, fps: comp.fps, durationInFrames: comp.durationInFrames },
  totalShots: timeline.length,
  totalSampledFrames: sampleList.length,
  sheets,
  samples: sampleList,
};
fs.writeFileSync(path.join(AUDIT_DIR, 'report.json'), JSON.stringify(report, null, 2) + '\n', 'utf8');
console.log(`[audit] Done! Contact sheets written to:\n  - ${sheets.join('\n  - ')}`);
