import React from 'react';
import { Composition } from 'remotion';
import { CartoonWorldVideo } from './engine/Video';
import { FPS, lastWordEnd } from './engine/timing';
import { CONFIG } from './project/config';

export function getDimensions() {
  const short = CONFIG.resolution === '1440' ? 1440 : 1080;
  const long = CONFIG.resolution === '1440' ? 2560 : 1920;
  return CONFIG.format === 'portrait'
    ? { width: short, height: long }
    : { width: long, height: short };
}

export const RemotionRoot: React.FC = () => {
  const { width, height } = getDimensions();
  const totalSec = Math.min(180, Math.max(5, lastWordEnd() + (CONFIG.tail ?? 1.2)));
  const durationInFrames = Math.ceil(totalSec * FPS);

  return (
    <Composition
      id="CartoonWorld"
      component={CartoonWorldVideo}
      durationInFrames={durationInFrames}
      fps={FPS}
      width={width}
      height={height}
    />
  );
};
