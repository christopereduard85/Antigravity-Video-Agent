import os
import sys
import json
import shutil
import subprocess
import argparse

def measure_duration(audio_path):
    """Mengukur durasi audio menggunakan ffprobe jika ada, atau fallback."""
    try:
        cmd = [
            'ffprobe', '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            audio_path
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return float(result.stdout.strip())
    except Exception:
        # Fallback jika ffprobe belum terpasang di path
        print("[WARN] ffprobe tidak ditemukan di PATH, menggunakan estimasi fallback 100.0s.")
        return 100.0

def main():
    parser = argparse.ArgumentParser(description="Scaffold Remotion Story Project")
    parser.add_argument("--slug", required=True, help="Project slug / nama folder")
    parser.add_argument("--audio", required=True, help="Path ke file voiceover")
    parser.add_argument("--script", default=None, help="Path ke script jika ada")
    parser.add_argument("--aspect", choices=["16:9", "9:16"], default="16:9")
    parser.add_argument("--resolution", choices=["720p", "1080p", "1440p", "4k"], default="1080p")
    parser.add_argument("--caption", choices=["on", "off"], default="auto")
    parser.add_argument("--music", choices=["generate", "custom", "none"], default="generate")
    parser.add_argument("--sfx", choices=["on", "off"], default="on")
    parser.add_argument("--title", default="Untitled Story")

    args = parser.parse_args()

    # Tentukan dimensi resolusi
    res_map = {
        "16:9": {
            "720p": (1280, 720),
            "1080p": (1920, 1080),
            "1440p": (2560, 1440),
            "4k": (3840, 2160)
        },
        "9:16": {
            "720p": (720, 1280),
            "1080p": (1080, 1920),
            "1440p": (1440, 2560),
            "4k": (2160, 3840)
        }
    }
    width, height = res_map[args.aspect][args.resolution]

    # Caption default aktif jika 9:16
    caption_enabled = True if args.caption == "on" or (args.caption == "auto" and args.aspect == "9:16") else False

    base_dir = os.path.join("projects", args.slug)
    subfolders = ["input", "timeline", "story", "scenes", "build", "out", "audio"]
    for sub in subfolders:
        os.makedirs(os.path.join(base_dir, sub), exist_ok=True)

    # Copy voiceover
    input_audio = os.path.join(base_dir, "input", "voiceover" + os.path.splitext(args.audio)[1])
    shutil.copy2(args.audio, input_audio)

    # Copy script jika ada
    input_script = None
    if args.script and os.path.exists(args.script):
        input_script = os.path.join(base_dir, "input", "script" + os.path.splitext(args.script)[1])
        shutil.copy2(args.script, input_script)

    duration = measure_duration(input_audio)
    fps = 30
    duration_frames = int(round(duration * fps))

    config = {
        "slug": args.slug,
        "title": args.title,
        "aspect": args.aspect,
        "resolution": args.resolution,
        "width": width,
        "height": height,
        "fps": fps,
        "durationSec": duration,
        "durationFrames": duration_frames,
        "caption": caption_enabled,
        "music": args.music,
        "sfx": args.sfx == "on",
        "audioFile": input_audio,
        "scriptFile": input_script
    }

    config_path = os.path.join(base_dir, "config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    print(f"[SUCCESS] Project scaffolded at {base_dir}")
    print(f"  - Title: {args.title}")
    print(f"  - Format: {args.aspect} ({width}x{height}) @ {fps}fps")
    print(f"  - Duration: {duration:.2f}s ({duration_frames} frames)")
    print(f"  - Caption: {'Enabled' if caption_enabled else 'Disabled'}")
    print(f"  - Config saved to {config_path}")

if __name__ == "__main__":
    main()
