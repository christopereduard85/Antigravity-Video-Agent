"""T1 audio analysis: tempo, beat grid, loudness profile. Output analysis/beats_raw.json"""
import json
import numpy as np
from scipy.io import wavfile
from scipy.signal import stft, find_peaks

sr, x = wavfile.read('Halloween Night.wav')
x = x.astype(np.float64)
if x.ndim > 1:
    x = x.mean(axis=1)
x /= (np.abs(x).max() + 1e-9)
dur = len(x) / sr

# spectral flux onset envelope
hop = 512
f, t, Z = stft(x, fs=sr, nperseg=2048, noverlap=2048 - hop)
S = np.log1p(np.abs(Z) * 100)
flux = np.maximum(0, np.diff(S, axis=1)).sum(axis=0)
flux = np.concatenate([[0], flux])
flux = (flux - flux.mean()) / (flux.std() + 1e-9)
fps_env = sr / hop

# tempo via autocorrelation in 70-180 BPM
ac = np.correlate(flux, flux, mode='full')[len(flux) - 1:]
lags = np.arange(len(ac))
bpm_range = (60 * fps_env / lags[1:]).astype(float)
best, best_score = None, -1
for bpm in np.arange(70, 180, 0.25):
    lag = 60 * fps_env / bpm
    sc = np.interp(lag, lags, ac) + 0.5 * np.interp(lag * 2, lags, ac)
    if sc > best_score:
        best, best_score = bpm, sc
bpm = float(best)
period = 60.0 / bpm

# phase: maximize onset sum on grid
tt = np.arange(len(flux)) / fps_env
best_off, best_s = 0, -1e9
for off in np.arange(0, period, 0.005):
    grid = np.arange(off, dur, period)
    idx = np.clip((grid * fps_env).astype(int), 0, len(flux) - 1)
    s = flux[idx].sum()
    if s > best_s:
        best_off, best_s = off, s
beats = np.arange(best_off, dur, period)

# downbeat: which of 4 phases has strongest low-freq energy
low = S[f < 150].sum(axis=0)
scores = []
for k in range(4):
    idx = np.clip((beats[k::4] * fps_env).astype(int), 0, len(low) - 1)
    scores.append(low[idx].mean())
dk = int(np.argmax(scores))
downbeats = beats[dk::4]

# loudness per bar
rms_bar = []
for i, b in enumerate(downbeats):
    e = downbeats[i + 1] if i + 1 < len(downbeats) else dur
    seg = x[int(b * sr):int(e * sr)]
    rms_bar.append(float(np.sqrt((seg ** 2).mean() + 1e-12)))
rms_bar = np.array(rms_bar)
db = 20 * np.log10(rms_bar / rms_bar.max() + 1e-9)

# vocal-ish band energy per bar (300-3000Hz) relative
band = S[(f > 300) & (f < 3000)].sum(axis=0)
vb = []
for i, b in enumerate(downbeats):
    e = downbeats[i + 1] if i + 1 < len(downbeats) else dur
    vb.append(float(band[int(b * fps_env):int(e * fps_env)].mean()))
vb = np.array(vb); vb = vb / vb.max()

out = {
    'durationSec': dur, 'bpm': round(bpm, 2), 'beatPeriodSec': period,
    'offsetSec': float(best_off), 'downbeatPhase': dk,
    'beats': [round(float(b), 3) for b in beats],
    'downbeats': [round(float(b), 3) for b in downbeats],
    'bars': [{'i': i, 'startSec': round(float(b), 2), 'db': round(float(d), 1), 'mid': round(float(v), 2)}
             for i, (b, d, v) in enumerate(zip(downbeats, db, vb))],
}
json.dump(out, open('analysis/beats_raw.json', 'w'), indent=1)
print(f"dur {dur:.2f}s bpm {bpm:.2f} offset {best_off:.3f} downbeatPhase {dk} bars {len(downbeats)}")
print(' '.join(f"{i}:{b:.1f}/{d:.0f}/{v:.2f}" for i, (b, d, v) in enumerate(zip(downbeats, db, vb))))
