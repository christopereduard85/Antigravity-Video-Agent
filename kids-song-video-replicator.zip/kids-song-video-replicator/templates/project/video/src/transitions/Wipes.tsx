import React from 'react';
import { clamp } from '../rig/geom';
import { theme } from '../theme';

/**
 * Theatre Curtain Open / Close Wipe.
 * openProgress = 0 (fully closed) .. 1 (fully open at sides).
 */
export const CurtainWipe: React.FC<{
  openProgress: number;
}> = ({ openProgress }) => {
  const p = clamp(openProgress, 0, 1);
  // Ease out cubic
  const ease = 1 - Math.pow(1 - p, 3);
  const halfW = 980 * (1 - ease * 0.86);

  return (
    <g>
      {/* Left Curtain Wing */}
      <g transform={`translate(${(-960 + halfW).toFixed(2)}, 0)`}>
        <rect x={0} y={0} width={980} height={1080} fill={theme.stage.curtainMain} />
        {Array.from({ length: 8 }).map((_, i) => (
          <rect
            key={i}
            x={i * 120}
            y={0}
            width={58}
            height={1080}
            fill={theme.stage.curtainDark}
            opacity={0.45}
          />
        ))}
        <rect x={966} y={0} width={14} height={1080} fill={theme.stage.curtainTrim} />
      </g>

      {/* Right Curtain Wing */}
      <g transform={`translate(${(1920 - halfW).toFixed(2)}, 0)`}>
        <rect x={0} y={0} width={980} height={1080} fill={theme.stage.curtainMain} />
        {Array.from({ length: 8 }).map((_, i) => (
          <rect
            key={i}
            x={i * 120 + 30}
            y={0}
            width={58}
            height={1080}
            fill={theme.stage.curtainDark}
            opacity={0.45}
          />
        ))}
        <rect x={0} y={0} width={14} height={1080} fill={theme.stage.curtainTrim} />
      </g>

      {/* Top Scalloped Valance */}
      {Array.from({ length: 12 }).map((_, i) => (
        <circle
          key={i}
          cx={i * 170 + 85}
          cy={8}
          r={92}
          fill={theme.stage.curtainMain}
          stroke={theme.stage.curtainTrim}
          strokeWidth={6}
        />
      ))}
    </g>
  );
};

/**
 * Melting Ice Cream / Pink Donut Glaze Drip Wipe.
 * progress = 0..0.5 (enters from top and covers 100% of screen at 0.5)
 * progress = 0.5..1.0 (exits through bottom, revealing the new scene underneath).
 */
export const DripWipe: React.FC<{
  progress: number;
  color?: string;
  HighlightColor?: string;
}> = ({ progress, color = '#FF85B8', HighlightColor = '#FFC2DF' }) => {
  if (progress <= 0.005 || progress >= 0.995) return null;
  const p = clamp(progress, 0, 1);

  // Phase 1 (0..0.5): yBottom moves from 0 to 1200 while yTop stays at -40 (100% cover at p=0.5)
  // Phase 2 (0.5..1.0): yTop moves from -40 to 1200 while yBottom moves from 1200 to 2400
  const yTop = p <= 0.5 ? -60 : -60 + ((p - 0.5) / 0.5) * 1260;
  const yBottom = p <= 0.5 ? (p / 0.5) * 1160 : 1160 + ((p - 0.5) / 0.5) * 1160;

  const drips = [
    { x: 120, w: 180, len: 190 },
    { x: 340, w: 160, len: 95 },
    { x: 540, w: 200, len: 240 },
    { x: 780, w: 170, len: 120 },
    { x: 980, w: 210, len: 260 },
    { x: 1220, w: 175, len: 110 },
    { x: 1440, w: 195, len: 220 },
    { x: 1680, w: 180, len: 140 },
    { x: 1860, w: 160, len: 200 },
  ];

  return (
    <g>
      <rect
        x={-40}
        y={yTop}
        width={2000}
        height={Math.max(0, yBottom - yTop)}
        fill={color}
      />
      {drips.map((d, idx) => (
        <g key={idx}>
          <path
            d={`M ${d.x - d.w * 0.5} ${yBottom}
                Q ${d.x - d.w * 0.45} ${yBottom + d.len} ${d.x} ${yBottom + d.len}
                Q ${d.x + d.w * 0.45} ${yBottom + d.len} ${d.x + d.w * 0.5} ${yBottom} Z`}
            fill={color}
          />
          <ellipse
            cx={d.x - d.w * 0.12}
            cy={yBottom + d.len * 0.65}
            rx={14}
            ry={28}
            fill={HighlightColor}
            opacity={0.55}
          />
        </g>
      ))}
    </g>
  );
};

/**
 * Wavy Ketchup & Mustard Stripe Wipe.
 * progress = 0..0.5 (slides in from right to cover 100% of screen at p=0.5)
 * progress = 0.5..1.0 (slides out to left, revealing the new scene underneath).
 */
export const StripeWipe: React.FC<{
  progress: number;
  frame: number;
}> = ({ progress, frame }) => {
  if (progress <= 0.005 || progress >= 0.995) return null;
  const p = clamp(progress, 0, 1);
  const xOffset = (1 - p * 2) * 2050;
  const stripes = 8;
  const sh = 1080 / stripes;

  return (
    <g transform={`translate(${xOffset.toFixed(2)}, 0)`}>
      {/* Solid backing rect so wavy top/bottom edges never leak a gap */}
      <rect x={-120} y={-60} width={2160} height={1200} fill="#D9261C" />
      {Array.from({ length: stripes }).map((_, i) => {
        const y0 = i * sh;
        const col = i % 2 === 0 ? '#D9261C' : '#FFC71F';
        const wave = Math.sin(frame * 0.25 + i) * 16;
        return (
          <path
            key={i}
            d={`M -120 ${y0}
                Q 480 ${y0 + wave} 960 ${y0}
                Q 1440 ${y0 - wave} 2040 ${y0}
                L 2040 ${y0 + sh + 20}
                L -120 ${y0 + sh + 20} Z`}
            fill={col}
          />
        );
      })}
    </g>
  );
};

/**
 * Outro Circle Spotlight Iris Close.
 * Renders a full-screen dark maroon mask with a circular cutout of radius `radius` at (cx, cy).
 * Must be rendered ON TOP of the spotlighted character so shrinking `radius` to 0 covers the character!
 */
export const IrisWipe: React.FC<{
  cx?: number;
  cy?: number;
  radius: number;
}> = ({ cx = 960, cy = 620, radius }) => {
  const r = Math.max(0, radius);
  if (r <= 0.5) {
    return <rect x={-40} y={-40} width={2000} height={1160} fill="#360814" />;
  }
  const path = `M -40 -40 H 1960 V 1120 H -40 Z
    M ${(cx - r).toFixed(2)} ${cy.toFixed(2)}
    A ${r.toFixed(2)} ${r.toFixed(2)} 0 1 0 ${(cx + r).toFixed(2)} ${cy.toFixed(2)}
    A ${r.toFixed(2)} ${r.toFixed(2)} 0 1 0 ${(cx - r).toFixed(2)} ${cy.toFixed(2)} Z`;

  return <path d={path} fill="#360814" fillRule="evenodd" />;
};
