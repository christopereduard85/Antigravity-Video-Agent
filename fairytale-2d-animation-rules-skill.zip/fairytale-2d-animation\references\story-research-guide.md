# Story Research, Full-Length Structure & English Voice-Over Guide

Every episode created by this skill MUST be grounded in **real, documented folklore, legend, or fairy-tale research** — never improvised — and MUST be written and presented in **100% English**.

---

## 1. Mandatory Research & English-Only Protocol

1. **100% English Output (Regardless of Origin Country)**:
   - Even when the user asks for an Indonesian legend (*Timun Mas*, *Malin Kundang*, *The Origin of Lake Toba*, *Bawang Merah and Bawang Putih*, *Lutung Kasarung*, *Si Kancil*) or a folktale from any other culture, **every topic proposal, research summary, character description, Voice-Over script (`VO-SCRIPT.md`), spoken line, and subtitle MUST be written in fluent, expressive English**.
   - Keep iconic proper nouns (e.g., *Timun Mas*, *Mbok Srini*, *Buto Ijo*, *Toba*) while translating all narration, dialogue, and titles into English (e.g., *"Timun Mas & the Green Giant"*).
2. **Propose 3 Researched Story Options in English** (unless the user already picked a topic):
   - Option A: **Indonesian Archipelago Legend / Folktale** (presented in English).
   - Option B: **Asian or Middle Eastern Folktale / Fable** (presented in English).
   - Option C: **Classic World Fairy Tale (Grimm / Aesop / Andersen / Perrault)** (presented in English).
3. **Verify Primary / Folkloristic Sources**:
   - Use `search_web` (when available) or documented folklore indices (Aarne–Thompson–Uther ATU classification, Balai Pustaka / regional folklore collections, Grimm KHM numbers, Aesop Perry Index).
   - Record the verified origin, moral lesson, plot summary, and at least **2 named sources** inside `EPISODE.research` in `src/story/script.ts`.

---

## 2. Full-Length Unshortened Episodes (Up to ~8 Minutes)

Do **NOT** compress or abridge a legend into a 30–60 second clip unless the user explicitly asks for a short test preview. Full episodes must match the pacing and completeness of the 8-minute reference videos:

| Episode Act | Target Shots | Target Duration | Narrative Beats & Choreography |
| --- | --- | --- | --- |
| **Bumpers** | Intro + Book Title | `~11.5s` | Night stage intro + open illustrated storybook title card |
| **Act I — Setup & World** | `8–15 shots` | `~60–90s` | Introduce home/village, family warmth, daily activity (sitting, cooking, pushing carts, gathering wood), and the inciting promise or quest |
| **Act II — Rising Obstacles (Rule of Three)** | `20–40 shots` | `~180–270s` | Full unshortened sequence of trials/encounters (e.g. building all 3 houses, throwing all 3–4 magical pouches, or meeting each forest creature) with multi-beat action, crouching, hiding, knocking, chasing, and comedic set pieces |
| **Act III — Climax & Resolution** | `10–18 shots` | `~60–110s` | Big climax (collapsing house, magic transformation, river splash, villain defeated comedically), heartfelt reunion, moral lesson, and celebration |
| **Outro** | End Card | `~6.0s` | Lead character waves + Subscribe animation |
| **Total Full Episode** | **40–75 shots** | **~5 to 8 minutes** | **80–140 English VO lines** across 3–6 speaking roles |

---

## 3. Signature Panda Main Character / Narrator + Unlocked Story Cast

- Every episode includes the studio's signature **Chubby Giant Panda (`createMainPanda()` / `PANDA_MAIN` from `src/kit/character/types.ts`, `species: "panda"`, `build: "chubby"`)** as either:
  - **The On-Stage Storyteller / Narrator (`narrator`)** for human legends and fairy tales (walking, hopping, reacting beside the characters, and leading the intro/outro bumpers), **OR**
  - **The Main Protagonist (`panda`)** for animal fables and adventures.
- Design a fresh, story-specific supporting cast in `src/story/characters.ts` (`CAST`) for every episode (never use "Rubi" or "Mimi"), and never render a top-left corner watermark.

---

## 4. Two-Phase Human-in-the-Loop Voice-Over Workflow

### Phase A — Topic, Research & Multi-Character English VO Script

1. Define all characters in `src/story/characters.ts` (`CAST`) with clear English `voice` acting notes.
2. Write the shot-by-shot episode in `src/story/script.ts` (`EPISODE`), giving every dialogue line:
   - `id`: Sequential ID + speaker + slug (e.g., `01_mbok_morning`, `02_timun_greeting`).
   - `speaker`: Character ID in `CAST`.
   - `subtitle`: Clean English on-screen text (`<= 46 characters`).
   - `voPrompt`: Full English voice-acting line with emotion cue in parentheses, e.g. `"(Booming, comical giant roar) BWAHAHA! Little Timun Mas, come out!"`.
   - `fallbackSec`: Estimated duration in seconds before real VO files are provided.
3. Run `node scripts/build-timeline.mjs <projectDir>` to generate `VO-SCRIPT.md` (100% English) and present it to the user so they can record/generate and return `.mp3` or `.wav` files.

### Phase B — Audio Ingestion, Lip-Sync & Full Video Render

1. Place returned `.mp3` / `.wav` files into `<projectDir>/public/vo/`.
   - Supported naming: exact ID (`01_mbok_morning.mp3`) **or** numeric prefix (`01.mp3`, `01.wav`).
   - If the user provides one combined audio file per character or one master file, split it on silence into per-line files in `public/vo/` using `ffmpeg -af silencedetect`.
2. Run `node scripts/build-timeline.mjs <projectDir>` to probe exact durations and extract 30fps RMS mouth-openness envelopes (`src/story/timeline.generated.json`).
3. Render visual QA stills (`npx remotion still`), inspect them with `read_file` to verify poses, framing, and zero visual bugs, and then render the full MP4 (`npx remotion render Episode out/episode.mp4 --gl=angle`).
