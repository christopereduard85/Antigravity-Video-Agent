#!/usr/bin/env node
/**
 * High-Fidelity Storybook Audio & SFX Synthesizer
 * Generates rich, multi-harmonic cartoon SFX + a warm orchestral marimba/music-box loop into `<project>/public/sfx/`.
 * Pure Node PCM synthesizer with multi-voice additive synthesis, physical modeling & FM acoustics.
 *
 * Usage: node scripts/generate-sfx.mjs [projectDir]
 */
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const proj = path.resolve(process.argv[2] ?? path.join(import.meta.dirname, "..", "template"));
const outDir = path.join(proj, "public", "sfx");
fs.mkdirSync(outDir, { recursive: true });

function writeWav(name, samples) {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20); // PCM
  buf.writeUInt16LE(1, 22); // mono
  buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(s * 32767), 44 + i * 2);
  }
  fs.writeFileSync(path.join(outDir, `${name}.wav`), buf);
}

// 1. pop — crisp, bubbly pop with gentle wooden resonance
{
  const dur = 0.16;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const f = 280 + Math.pow(u, 0.6) * 580;
    const env = Math.sin(u * Math.PI) * Math.exp(-u * 3.5);
    out[i] = (Math.sin(2 * Math.PI * f * t) + 0.3 * Math.sin(4 * Math.PI * f * t)) * env * 0.75;
  }
  writeWav("pop", out);
}

// 2. boing — warm elastic cartoon spring with FM modulation
{
  const dur = 0.65;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const pitch = 140 + u * 320;
    const fm = Math.sin(2 * Math.PI * 34 * t) * 45 * (1 - u);
    const env = (1 - u) * Math.exp(-u * 1.8);
    out[i] = (Math.sin(2 * Math.PI * (pitch + fm) * t) + 0.35 * Math.sin(4 * Math.PI * (pitch + fm) * t)) * env * 0.7;
  }
  writeWav("boing", out);
}

// 3. whoosh — dynamic wind swipe with resonant pink-ish noise sweep
{
  const dur = 0.42;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    b0 = 0.99 * b0 + white * 0.05;
    b1 = 0.96 * b1 + white * 0.11;
    b2 = 0.86 * b2 + white * 0.25;
    const pink = (b0 + b1 + b2) * 0.4;
    const env = Math.sin(u * Math.PI);
    const fCenter = 220 + Math.sin(u * Math.PI) * 540;
    const tone = Math.sin(2 * Math.PI * fCenter * t) * 0.25;
    out[i] = (pink * 0.6 + tone) * env * 0.65;
  }
  writeWav("whoosh", out);
}

// 4. magic / magicChime — celestial crystalline wind chimes & sparkling glockenspiel
{
  const dur = 1.6;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  const chimeNotes = [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093.0, 2637.02];
  chimeNotes.forEach((f0, idx) => {
    const startT = idx * 0.12;
    const startIdx = Math.floor(startT * SR);
    for (let i = startIdx; i < n; i++) {
      const t = (i - startIdx) / SR;
      const env = Math.exp(-t * 3.2);
      // Multi-harmonic glockenspiel bell physics (1.0f, 2.76f, 5.4f)
      const s =
        Math.sin(2 * Math.PI * f0 * t) * 0.55 +
        Math.sin(2 * Math.PI * f0 * 2.76 * t) * 0.22 +
        Math.sin(2 * Math.PI * f0 * 5.4 * t) * 0.12;
      out[i] += s * env * 0.28;
    }
  });
  writeWav("magic", out);
  writeWav("magicChime", out);
}

// 5. twinkle — gentle fairy star bell chime
{
  const dur = 0.75;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  const chord = [1046.5, 1318.51, 1567.98, 2093.0];
  chord.forEach((f0, idx) => {
    const startT = idx * 0.06;
    const startIdx = Math.floor(startT * SR);
    for (let i = startIdx; i < n; i++) {
      const t = (i - startIdx) / SR;
      const env = Math.exp(-t * 4.5);
      out[i] += (Math.sin(2 * Math.PI * f0 * t) + 0.3 * Math.sin(4 * Math.PI * f0 * t)) * env * 0.24;
    }
  });
  writeWav("twinkle", out);
}

// 6. thud — deep wooden / earthy impact with acoustic sub-bass
{
  const dur = 0.38;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const f = 110 * Math.exp(-u * 7) + 38;
    const env = Math.exp(-u * 6.5);
    const click = u < 0.08 ? (Math.random() * 2 - 1) * (1 - u / 0.08) * 0.35 : 0;
    out[i] = (Math.sin(2 * Math.PI * f * t) * 0.85 + click) * env * 0.85;
  }
  writeWav("thud", out);
}

// 7. thunder — deep cinematic rolling thunder rumble with crackle
{
  const dur = 2.4;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let rumble = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    rumble = 0.985 * rumble + white * 0.08;
    // Initial crackle strike + rolling low-frequency rumble
    const strike = u < 0.15 ? Math.exp(-u * 18) * Math.sin(2 * Math.PI * 75 * t) * 0.7 : 0;
    const roll = Math.sin(2 * Math.PI * (42 + Math.sin(t * 7) * 12) * t) * 0.45;
    const env = Math.sin(Math.pow(u, 0.4) * Math.PI) * Math.exp(-u * 1.2);
    out[i] = (rumble * 0.65 + roll + strike) * env * 0.75;
  }
  writeWav("thunder", out);
}

// 8. wind — deep whistling storm tempest gale
{
  const dur = 2.5;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let wFltr = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    const fWhistle = 280 + Math.sin(t * 3.5) * 140 + Math.sin(t * 9) * 60;
    wFltr = 0.96 * wFltr + white * 0.09;
    const whistle = Math.sin(2 * Math.PI * fWhistle * t) * 0.22;
    const env = Math.sin(u * Math.PI) * (0.8 + 0.2 * Math.sin(t * 6));
    out[i] = (wFltr * 0.65 + whistle) * env * 0.65;
  }
  writeWav("wind", out);
}

// 9. splash — crisp liquid water splash & bubbling drops
{
  const dur = 0.75;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let waterNoise = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    waterNoise = 0.93 * waterNoise + white * 0.12;
    const dropFreq = 340 + Math.sin(t * 42) * 120 - u * 160;
    const drop = Math.sin(2 * Math.PI * dropFreq * t) * 0.3 * Math.exp(-u * 4);
    const env = Math.exp(-u * 3.8);
    out[i] = (waterNoise * 0.7 + drop) * env * 0.7;
  }
  writeWav("splash", out);
}

// 10. laugh — cheerful 3-note chuckle
{
  const dur = 0.62;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  const notes = [587.33, 659.25, 783.99];
  notes.forEach((f0, idx) => {
    const startT = idx * 0.18;
    const startIdx = Math.floor(startT * SR);
    for (let i = startIdx; i < Math.min(n, startIdx + Math.floor(0.24 * SR)); i++) {
      const t = (i - startIdx) / SR;
      const env = Math.sin((t / 0.24) * Math.PI) * Math.exp(-t * 2.5);
      out[i] += (Math.sin(2 * Math.PI * f0 * t) + 0.25 * Math.sin(4 * Math.PI * f0 * t)) * env * 0.55;
    }
  });
  writeWav("laugh", out);
}

// 11. cry — gentle cartoon wah-wah
{
  const dur = 0.85;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const f = 520 - u * 190 + Math.sin(t * 32) * 30;
    const env = Math.sin(u * Math.PI) * Math.exp(-u * 1.2);
    out[i] = (Math.sin(2 * Math.PI * f * t) + 0.35 * Math.sin(4 * Math.PI * f * t)) * env * 0.55;
  }
  writeWav("cry", out);
}

// 12. run — light rhythmic pitter-patter footsteps
{
  const dur = 0.85;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  const steps = 7;
  for (let s = 0; s < steps; s++) {
    const startIdx = Math.floor((s / steps) * dur * SR);
    for (let i = startIdx; i < Math.min(n, startIdx + Math.floor(0.09 * SR)); i++) {
      const t = (i - startIdx) / SR;
      const f = 190 + (s % 2) * 55;
      const env = Math.exp(-t * 35);
      const tap = (Math.random() * 2 - 1) * 0.25;
      out[i] += (Math.sin(2 * Math.PI * f * t) * 0.7 + tap) * env * 0.55;
    }
  }
  writeWav("run", out);
}

// 13. gasp — quick startled breath
{
  const dur = 0.32;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let whiteFltr = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    whiteFltr = 0.92 * whiteFltr + white * 0.12;
    const fChirp = 380 + Math.pow(u, 0.8) * 320;
    const tone = Math.sin(2 * Math.PI * fChirp * t) * 0.35;
    const env = Math.sin(u * Math.PI);
    out[i] = (whiteFltr * 0.45 + tone) * env * 0.55;
  }
  writeWav("gasp", out);
}

// 14. knock — realistic 3 wooden door knocks
{
  const dur = 0.65;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  [0, 0.22, 0.44].forEach((startT) => {
    const startIdx = Math.floor(startT * SR);
    for (let i = startIdx; i < Math.min(n, startIdx + Math.floor(0.15 * SR)); i++) {
      const t = (i - startIdx) / SR;
      const f = 220;
      const env = Math.exp(-t * 28);
      const click = (Math.random() * 2 - 1) * Math.exp(-t * 70) * 0.4;
      out[i] += (Math.sin(2 * Math.PI * f * t) * 0.65 + click) * env * 0.65;
    }
  });
  writeWav("knock", out);
}

// 15. tada — rich brassy fanfare chord
{
  const dur = 1.35;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  const chordNotes = [523.25, 659.25, 783.99, 1046.5];
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const env = (1 - u * 0.65) * Math.exp(-u * 1.5);
    let s = 0;
    chordNotes.forEach((f0) => {
      s += Math.sin(2 * Math.PI * f0 * t) + 0.3 * Math.sin(4 * Math.PI * f0 * t) + 0.15 * Math.sin(6 * Math.PI * f0 * t);
    });
    out[i] = s * 0.22 * env;
  }
  writeWav("tada", out);
}

// 16. pageTurn — crisp paper rustle
{
  const dur = 0.45;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  let pFltr = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const u = t / dur;
    const white = Math.random() * 2 - 1;
    pFltr = 0.88 * pFltr + white * 0.16;
    const env = Math.sin(u * Math.PI) * Math.sin(u * Math.PI);
    out[i] = pFltr * env * 0.55;
  }
  writeWav("pageTurn", out);
}

// 17. bgm — 16-Second Seamless Orchestral Storybook Marimba & Music Box Loop
// Warm wooden acoustic bar resonance (fundamental + 3.9f + 9.2f), harp arpeggios & warm pizzicato bass!
{
  const dur = 16.0;
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);

  // 16-bar melodic phrase in warm C Major / A Minor pentatonic
  const melody = [
    523.25, 659.25, 783.99, 659.25, 880.0, 783.99, 659.25, 523.25,
    587.33, 659.25, 783.99, 880.0, 1046.5, 880.0, 783.99, 659.25,
    659.25, 783.99, 880.0, 1046.5, 880.0, 783.99, 659.25, 523.25,
    587.33, 659.25, 523.25, 440.0, 523.25, 587.33, 523.25, 523.25,
  ];

  // Warm acoustic pizzicato cello/bass foundation
  const bass = [
    261.63, 261.63, 349.23, 349.23, 392.0, 392.0, 261.63, 261.63,
    220.0, 220.0, 349.23, 349.23, 392.0, 392.0, 261.63, 261.63,
  ];

  const stepDur = dur / melody.length;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const step = Math.floor(t / stepDur) % melody.length;
    const local = (t % stepDur) / stepDur;

    // Acoustic marimba mallet strike envelope
    const env = Math.exp(-local * 3.8);
    const mf = melody[step];

    // Marimba bar physics: fundamental + weak overtone at 3.9f + glitter sparkle at 9.2f
    const marimbaTone =
      Math.sin(2 * Math.PI * mf * t) * 0.28 +
      Math.sin(2 * Math.PI * mf * 3.9 * t) * 0.06 * Math.exp(-local * 6.5) +
      Math.sin(2 * Math.PI * mf * 9.2 * t) * 0.02 * Math.exp(-local * 12);

    // Warm pizzicato bass (fundamental + sub)
    const bassStep = Math.floor(step / 2) % bass.length;
    const bf = bass[bassStep];
    const bassLocal = ((t % (stepDur * 2)) / (stepDur * 2));
    const bassEnv = Math.exp(-bassLocal * 2.2);
    const bassTone =
      (Math.sin(2 * Math.PI * bf * t) * 0.16 + Math.sin(2 * Math.PI * (bf * 0.5) * t) * 0.08) * bassEnv;

    // Soft celestial music-box glockenspiel sparkle on beat 1 & 3
    const sparkleTone =
      (step % 2 === 0 ? Math.sin(2 * Math.PI * mf * 2 * t) * 0.05 * Math.exp(-local * 5.0) : 0);

    out[i] = marimbaTone * env + bassTone + sparkleTone;
  }

  writeWav("bgm", out);
}

console.log(`Generated 17 high-fidelity WAV files in ${outDir}`);
