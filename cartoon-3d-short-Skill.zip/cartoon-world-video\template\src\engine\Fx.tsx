// ============================================================================
// 3D STUDIO CARTOON PHYSICS & PARTICLE FX ENGINE (src/engine/Fx.tsx)
// - Multi-stage cartoon explosions (shockwave ring + billowing fire/smoke + bouncing shrapnel)
// - True world-space ground ballistic fluid splashes (no floating mid-air pancakes!)
// - Sticky glue/syrup trap strands ('glue') & saltwater scrubbing foam ('foam' / 'splash')
// - Popping 3D steel rivets with spark streaks & steam jets
// ============================================================================
import React from 'react';
import * as THREE from 'three';
import { resolveTargetPos } from './CameraRig';
import { INK } from './drawCharacter';
import { timeOf } from './timing';
import type { Fx, Shot, Vec3, WorldSet } from './types';
import { clamp, hashStr, rng, shade } from './util';

const INK_COLOR = new THREE.Color(INK);
const BALL = new THREE.SphereGeometry(0.5, 16, 14);
const BOX = new THREE.BoxGeometry(1, 1, 1);
const CYL = new THREE.CylinderGeometry(0.5, 0.5, 1, 14);
const RING = new THREE.TorusGeometry(0.6, 0.06, 10, 24);

/** Smooth ink-outlined particle mesh (no internal wireframe cage lines on curved shapes). */
const ToonParticle: React.FC<{
  geometry: THREE.BufferGeometry;
  color: string;
  position: Vec3;
  rotation?: Vec3;
  scale: Vec3;
  inkWidth?: number;
  glow?: boolean;
  glossy?: boolean;
}> = ({ geometry, color, position, rotation = [0, 0, 0], scale, inkWidth = 0.06, glow = false, glossy = false }) => {
  const outScale: Vec3 = [1 + inkWidth, 1 + inkWidth, 1 + inkWidth];
  return (
    <group position={position} rotation={rotation} scale={scale}>
      <mesh geometry={geometry}>
        {glow ? (
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={1.15} roughness={0.25} />
        ) : (
          <meshStandardMaterial
            color={color}
            roughness={glossy ? 0.18 : 0.75}
            metalness={glossy ? 0.15 : 0.04}
          />
        )}
      </mesh>
      {inkWidth > 0 && (
        <mesh geometry={geometry} scale={outScale}>
          <meshBasicMaterial color={INK_COLOR} side={THREE.BackSide} toneMapped={false} />
        </mesh>
      )}
    </group>
  );
};

export const FxLayer3D: React.FC<{
  shot: Shot;
  set: WorldSet;
  t: number;
  shotEndT: number;
}> = ({ shot, set, t, shotEndT }) => {
  return (
    <group>
      {(shot.fx ?? []).map((fx, idx) => (
        <SingleFx3D key={idx} fx={fx} idx={idx} shot={shot} set={set} t={t} shotEndT={shotEndT} />
      ))}
    </group>
  );
};

/** Simulate ballistic trajectory in WORLD Y coordinates with ground bounce at floorY. */
function worldBallisticY(
  startY: number,
  vy: number,
  grav: number,
  dt: number,
  floorY = 0.03,
  bounce = 0.38,
): { y: number; vyNow: number; landed: boolean } {
  const rawY = startY + vy * dt - 0.5 * grav * dt * dt;
  if (rawY > floorY) {
    return { y: rawY, vyNow: vy - grav * dt, landed: false };
  }
  const h0 = Math.max(0, startY - floorY);
  const disc = Math.max(0, vy * vy + 2 * grav * h0);
  const tImpact = (vy + Math.sqrt(disc)) / Math.max(0.1, grav);
  const dtAfter = Math.max(0, dt - tImpact);
  const vyBounce = Math.sqrt(disc) * bounce;
  const bounceY = floorY + vyBounce * dtAfter - 0.5 * grav * dtAfter * dtAfter;
  if (bounceY > floorY) {
    return { y: bounceY, vyNow: vyBounce - grav * dtAfter, landed: false };
  }
  return { y: floorY, vyNow: 0, landed: true };
}

const SingleFx3D: React.FC<{
  fx: Fx;
  idx: number;
  shot: Shot;
  set: WorldSet;
  t: number;
  shotEndT: number;
}> = ({ fx, idx, shot, set, t, shotEndT }) => {
  if (fx.k === 'flash' || fx.k === 'shake' || fx.k === 'speedlines') return null;

  const t0 = timeOf(fx.at);
  const defaultDur =
    fx.k === 'explosion'
      ? 1.45
      : fx.k === 'splash' || fx.k === 'liquid' || fx.k === 'pour'
        ? 1.15
        : fx.k === 'rivets' || fx.k === 'debris' || fx.k === 'splinters'
          ? 1.1
          : fx.k === 'rain' || fx.k === 'snow' || fx.k === 'fire' || fx.k === 'steam'
            ? 3.5
            : 0.9;
  const dur = fx.dur ?? defaultDur;
  if (t < t0 || t > t0 + dur) return null;

  const dt = t - t0;
  const u = clamp(dt / dur);
  const size = fx.size ?? 1;
  const origin: Vec3 = fx.pos
    ? resolveTargetPos(fx.pos, shot, set, t, shotEndT)
    : [0, 0.5, 0];

  const rand = rng(hashStr(`${shot.id}-${fx.k}-${idx}`));

  // -------------------------------------------------------------------------
  // 1. MULTI-STAGE CARTOON EXPLOSION (Shockwave + Billowing Fire/Smoke + Shrapnel)
  // -------------------------------------------------------------------------
  if (fx.k === 'explosion' || fx.k === 'shockwave') {
    const startY = Math.max(0.6, origin[1] + 0.4);
    const shockScale = (0.4 + Math.pow(u, 0.55) * 3.8) * size;
    const shockFade = Math.max(0, 1 - u * 1.35);

    return (
      <group position={[origin[0], 0, origin[2] + 0.35]}>
        {/* Expanding Shockwave Ring */}
        {shockFade > 0.05 && (
          <ToonParticle
            geometry={RING}
            color={u < 0.25 ? '#FFF7B0' : '#FF8A2B'}
            position={[0, startY + 0.1, 0.2]}
            rotation={[Math.PI * 0.42, 0, dt * 2]}
            scale={[shockScale, shockScale, shockScale * (0.3 + shockFade * 0.7)]}
            inkWidth={0.04}
            glow
          />
        )}

        {/* Billowing Cartoon Fireball & Smoke Cloud Cluster */}
        {fx.k === 'explosion' &&
          Array.from({ length: 20 }).map((_, i) => {
            const ang = (i / 20) * Math.PI * 2 + (rand() - 0.5) * 0.35;
            const elev = -0.2 + rand() * 0.95;
            const spd = (1.1 + rand() * 2.2) * size;
            const rad = spd * Math.pow(u, 0.58);
            const px = Math.cos(ang) * rad;
            const py = Math.max(0.15, startY + elev * rad + u * 0.9 * size);
            const pz = Math.sin(ang) * rad * 0.55;

            const isCore = i < 7;
            const col =
              u < 0.22
                ? isCore
                  ? '#FFF380'
                  : '#FF771A'
                : u < 0.52
                  ? isCore
                    ? '#FF6B1A'
                    : '#D9381E'
                  : i % 2 === 0
                    ? '#4A4352'
                    : '#686070';

            const env = u < 0.15 ? u / 0.15 : Math.max(0, 1 - (u - 0.15) / 0.85);
            const r = (0.28 + rand() * 0.36) * size * (0.55 + env * 0.75);

            return (
              <ToonParticle
                key={`cloud-${i}`}
                geometry={BALL}
                color={col}
                position={[px, py, pz]}
                scale={[r, r * 0.92, r]}
                inkWidth={0.055}
                glow={u < 0.45 && isCore}
              />
            );
          })}

        {/* Ballistic Flying Steel Shrapnel Plates & Rivets */}
        {fx.k === 'explosion' &&
          Array.from({ length: 18 }).map((_, i) => {
            const ang = rand() * Math.PI * 2;
            const vx = Math.cos(ang) * (1.8 + rand() * 2.8) * size;
            const vz = (0.3 + Math.sin(ang) * 0.7) * (1.2 + rand() * 1.8) * size;
            const vy = (2.4 + rand() * 3.2) * size;
            const { y } = worldBallisticY(startY, vy, 9.8, dt, 0.04, 0.45);
            const px = vx * dt;
            const pz = vz * dt;
            const fade = Math.max(0, 1 - Math.pow(u, 2.5));
            const s = (0.14 + rand() * 0.16) * size * fade;
            const isPlate = i % 2 === 0;

            return (
              <ToonParticle
                key={`shrap-${i}`}
                geometry={isPlate ? BOX : CYL}
                color={i % 3 === 0 ? '#6E3B1E' : '#525C68'}
                position={[px, y, pz]}
                rotation={[dt * 11 * (i % 2 ? 1 : -1), ang + dt * 7, dt * 9]}
                scale={isPlate ? [s * 2.2, s * 1.4, s * 0.22] : [s * 0.7, s * 0.9, s * 0.7]}
                inkWidth={0.06}
              />
            );
          })}
      </group>
    );
  }

  // -------------------------------------------------------------------------
  // 2. BALLISTIC LIQUID SPLASH / POUR / FLUID STREAM (True World-Y Physics!)
  // -------------------------------------------------------------------------
  if (fx.k === 'splash' || fx.k === 'liquid' || fx.k === 'pour' || fx.k === 'bubbles') {
    const isKetchup = fx.pos === 'ketchupBottle';
    const isSyrupTarget = fx.pos === 'tank' || fx.pos === 'syrupWave' || fx.pos === 'manager';
    const primaryFluid =
      fx.color ??
      (isKetchup
        ? '#D92632'
        : isSyrupTarget && fx.k !== 'bubbles'
          ? '#6B3618'
          : '#38B6FF');
    const highlightFluid = shade(primaryFluid, 0.22);
    const foamColor = isSyrupTarget && !fx.color ? '#D49B6A' : '#FFFFFF';

    // If splashing on tabletop (ketchupBottle), land on tabletop y = 0.56; otherwise land on ground y = 0.03
    const surfaceY = isKetchup ? 0.56 : 0.03;
    const emitY = isKetchup ? 0.88 : Math.max(surfaceY + 0.08, origin[1] + 0.15);

    return (
      <group position={[origin[0], 0, origin[2] + 0.12]}>
        {/* Ballistic Teardrop Fluid Droplets & Suds */}
        {Array.from({ length: 20 }).map((_, i) => {
          const ang = (i / 20) * Math.PI * 2 + (rand() - 0.5) * 0.3;
          const speedH = (0.45 + rand() * 1.05) * size;
          const vx = (isKetchup ? 0.45 : 0) + Math.cos(ang) * speedH;
          const vz = Math.sin(ang) * speedH * 0.55;
          const vy = fx.k === 'bubbles' ? 0.55 + rand() * 0.85 : (1.35 + rand() * 1.75) * size;
          const grav = fx.k === 'bubbles' ? -0.45 : 9.2;

          const { y, vyNow } = worldBallisticY(emitY, vy, grav, dt, surfaceY, 0.3);
          const px = vx * dt;
          const pz = vz * dt;
          const fade = Math.sin(u * Math.PI);
          const r = Math.max(0.025, (0.055 + rand() * 0.055) * size * fade);

          // Keep droplets round/teardrop-shaped (never flatten into wide floating disks!)
          const stretchY = fx.k === 'bubbles' ? 1.0 : clamp(1 + Math.abs(vyNow) * 0.12, 0.9, 1.55);
          const stretchXZ = 1 / Math.sqrt(stretchY);
          const tiltZ = Math.atan2(vx, vyNow || 0.1) * 0.35;
          const col = i % 3 === 0 ? foamColor : i % 2 === 0 ? primaryFluid : highlightFluid;

          return (
            <ToonParticle
              key={`drop-${i}`}
              geometry={BALL}
              color={col}
              position={[px, y, pz]}
              rotation={[0, 0, -tiltZ]}
              scale={[r * stretchXZ, r * stretchY, r * stretchXZ]}
              inkWidth={0.05}
              glossy
            />
          );
        })}
      </group>
    );
  }

  // -------------------------------------------------------------------------
  // 3. POPPING STEEL RIVETS + SPARK STREAKS + STEAM PUFFS
  // -------------------------------------------------------------------------
  if (fx.k === 'rivets' || fx.k === 'sparks') {
    const startY = Math.max(0.65, origin[1] + 0.45);
    return (
      <group position={[origin[0], 0, origin[2] + 0.45]}>
        {Array.from({ length: 14 }).map((_, i) => {
          const side = i % 2 === 0 ? -1 : 1;
          const vx = side * (1.2 + rand() * 2.4) * size;
          const vy = (1.4 + rand() * 2.6) * size;
          const vz = (0.8 + rand() * 1.6) * size;
          const { y } = worldBallisticY(startY, vy, 9.5, dt, 0.04, 0.5);
          const px = vx * dt;
          const pz = vz * dt;
          const fade = Math.max(0, 1 - u * 0.9);
          const r = (0.07 + rand() * 0.05) * size * fade;
          const isSpark = i % 2 === 1;

          return (
            <ToonParticle
              key={`riv-${i}`}
              geometry={isSpark ? BOX : CYL}
              color={isSpark ? (i % 4 === 1 ? '#FFF480' : '#FF7B1A') : '#464F5B'}
              position={[px, y, pz]}
              rotation={[dt * 14, dt * 10, Math.atan2(vy - 9.5 * dt, vx)]}
              scale={isSpark ? [r * 2.8, r * 0.32, r * 0.32] : [r * 1.1, r * 1.4, r * 1.1]}
              inkWidth={0.05}
              glow={isSpark}
            />
          );
        })}
      </group>
    );
  }

  // -------------------------------------------------------------------------
  // 4. GENERAL FX (confetti, splinters, debris, steam, smoke, dust, stars, hearts)
  // -------------------------------------------------------------------------
  const count = fx.k === 'confetti' || fx.k === 'splinters' || fx.k === 'debris' ? 18 : 12;
  const startY =
    fx.k === 'dust'
      ? 0.08
      : fx.k === 'confetti' || fx.k === 'stars'
        ? Math.max(0.8, origin[1] + 0.65)
        : Math.max(0.35, origin[1] + 0.25);

  return (
    <group position={[origin[0], 0, origin[2] - 0.1]}>
      {Array.from({ length: count }).map((_, i) => {
        const a = rand() * Math.PI * 2;
        const elev = 0.4 + rand() * 0.9;
        const speed = (0.9 + rand() * 1.5) * size;
        const grav =
          fx.k === 'smoke' || fx.k === 'steam'
            ? -1.2
            : fx.k === 'splinters' || fx.k === 'debris' || fx.k === 'coins' || fx.k === 'confetti'
              ? 4.2
              : 1.4;

        const px = Math.cos(a) * speed * (0.2 + dt * 0.85);
        const py = Math.max(0.04, startY + elev * speed * dt - 0.5 * grav * dt * dt);
        const pz = Math.sin(a) * speed * (0.2 + dt * 0.65);
        const fade = Math.sin(u * Math.PI);
        const sc = Math.max(0.03, (0.075 + rand() * 0.085) * size * fade);

        if (fx.k === 'splinters' || fx.k === 'debris' || fx.k === 'confetti') {
          const col =
            fx.color ??
            (fx.k === 'splinters'
              ? i % 2 === 0
                ? '#B87E44'
                : '#8C5828'
              : fx.k === 'debris'
                ? i % 2 === 0
                  ? '#7B848F'
                  : '#4E555E'
                : ['#FF4D6D', '#FFD23F', '#38C976', '#4DA8FF'][i % 4]);
          return (
            <ToonParticle
              key={i}
              geometry={BOX}
              color={col}
              position={[px, py, pz]}
              rotation={[dt * 9 * (i % 2 ? 1 : -1), a, dt * 7]}
              scale={fx.k === 'confetti' ? [sc * 0.95, sc * 0.2, sc * 0.65] : [sc * 2.2, sc * 0.4, sc * 0.48]}
              inkWidth={0.05}
            />
          );
        }

        const col =
          fx.color ??
          (fx.k === 'fire'
            ? i % 2 === 0
              ? '#FF8A2B'
              : '#FFE14D'
            : fx.k === 'coins' || fx.k === 'stars'
              ? '#FFD23F'
              : fx.k === 'hearts'
                ? '#FF4D6D'
                : '#F2EFE9');

        return (
          <ToonParticle
            key={i}
            geometry={BALL}
            color={col}
            position={[px, py, pz]}
            scale={[sc * 1.25, sc * 1.15, sc * 1.25]}
            inkWidth={0.05}
            glow={fx.k === 'fire' || fx.k === 'stars'}
          />
        );
      })}
    </group>
  );
};
