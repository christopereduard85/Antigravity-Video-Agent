import React from 'react';
import { clamp } from './geom';

export const ContactShadow: React.FC<{
  width: number;
  jumpY: number;
  squash: number;
  opacity?: number;
}> = ({ width, jumpY, squash, opacity = 0.24 }) => {
  const heightAtten = clamp(1 - jumpY / 220, 0.35, 1);
  const rx = width * 0.52 * (1 + squash * 0.18) * heightAtten;
  const ry = Math.max(8, width * 0.11 * heightAtten);
  const alpha = opacity * heightAtten;
  return (
    <ellipse
      cx={0}
      cy={6}
      rx={rx}
      ry={ry}
      fill={`rgba(20, 8, 28, ${alpha.toFixed(3)})`}
    />
  );
};
