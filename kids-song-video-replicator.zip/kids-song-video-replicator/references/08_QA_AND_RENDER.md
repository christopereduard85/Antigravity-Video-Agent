# 08 — QA stills, preview, final render

All commands from workspace root. Windows paths shown; on mac/linux drop `--browser-executable` or point to Chrome.

## Still frames (fast QA)

```powershell
$CH = "C:\Program Files\Google\Chrome\Application\chrome.exe"
./video/node_modules/.bin/remotion still video/src/index.ts Main analysis/qa/f0380.png --frame=380 --public-dir=video/public --browser-executable="$CH"
./video/node_modules/.bin/remotion still video/src/index.ts QA-AllSections analysis/qa/all_sections_qa_sheet.png --frame=0 --public-dir=video/public --browser-executable="$CH"
```
Or `scripts/render_qa_stills.ps1 -Frames 20,380,2328`.

Which frames to check after a change:
- timing change → first word of each changed line + each affected wipe `cutFrame-2, cutFrame, cutFrame+4`.
- overlay change → one frame per section type (verse, transform, chorus, finale) + a watermark-visible frame (`cycle*360 + 30`).
- character change → `QA-Cast`.

## Short preview clip

```powershell
./video/node_modules/.bin/remotion render video/src/index.ts Main out/preview.mp4 --frames=0-840 --public-dir=video/public --browser-executable="$CH" --codec=h264 --crf=18
```

## Live preview (user browser)

```powershell
./video/node_modules/.bin/remotion studio video/src/index.ts --public-dir=video/public --port=3000
```
(outside sandbox). Hot-reloads on save. Stop it before final render.

## Final render (GPU, what the user used)

CMD:
```cmd
cd /d "<workspace>"
.\video\node_modules\.bin\remotion render video/src/index.ts Main out\<Name>.mp4 --public-dir=video/public --browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe" --gl=angle --codec=h264 --crf=18 --pixel-format=yuv420p
```
or `cd video && npm run render:gpu` (script defined in template package.json).
`--gl=angle` = Chrome GPU (D3D11 on Windows). Concurrency default = cores/2; add `--concurrency=8` if CPU idle.

## Verify output

```powershell
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate,nb_frames,duration -of json out/<Name>.mp4
```
Expect h264, 1920x1080, 30/1, nb_frames = total frames. Original: 3997 frames, 133.23 s, 137.7 MB.

## Final handoff
- Tick T10 in NEXT_STEPS.md, add changelog row, move QA stills into `analysis/qa/`.
