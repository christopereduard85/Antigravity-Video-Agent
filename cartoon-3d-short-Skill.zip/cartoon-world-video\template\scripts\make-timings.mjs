#!/usr/bin/env node
// ============================================================================
// WORD TIMING & SRT GENERATOR (scripts/make-timings.mjs)
// 1. Reads src/project/script.txt (the 8-section script).
// 2. If public/vo.mp3 or public/vo.wav exists:
//    - Uses Whisper.cpp word timestamps if ./whisper.cpp is installed, OR
//    - Runs ffmpeg silencedetect to detect exact acoustic speech phrases in the
//      voice-over and locks every punctuation clause & sentence to the real
//      audio waveform!
// 3. Hand-fixes all word timings (monotonic, zero overlap, exact punctuation)
//    and writes:
//    - src/project/words.json  (machine-readable word timings)
//    - src/project/words.md    (human/AI lookup table: w0, w1, w2...)
//    - public/subtitles.srt    (ready-to-use SRT file)
// ============================================================================
import fs from 'node:fs';
import path from 'node:path';
import { execSync, spawnSync } from 'node:child_process';

const ROOT = process.cwd();
const SCRIPT_PATH = path.join(ROOT, 'src/project/script.txt');
const WORDS_JSON_PATH = path.join(ROOT, 'src/project/words.json');
const WORDS_MD_PATH = path.join(ROOT, 'src/project/words.md');
const SRT_PATH = path.join(ROOT, 'public/subtitles.srt');

function parseScript(raw) {
  const lines = raw.split(/\r?\n/);
  const words = [];
  const sections = [];
  let currentSection = 'hook';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const secMatch = /^\[([a-zA-Z0-9_-]+)\]$/.exec(trimmed);
    if (secMatch) {
      currentSection = secMatch[1].toLowerCase();
      sections.push({ name: currentSection, from: words.length });
      continue;
    }
    if (sections.length === 0) {
      sections.push({ name: currentSection, from: 0 });
    }
    const tokens = trimmed.split(/\s+/).filter(Boolean);
    for (const tok of tokens) {
      words.push({ w: tok, section: currentSection });
    }
  }
  return { words, sections };
}

function getAudioDuration(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try {
    const out = execSync(
      `ffprobe -v error -show_entries format=duration -of csv=p=0 "${filePath}"`,
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] },
    ).trim();
    const d = parseFloat(out);
    return Number.isFinite(d) && d > 0.5 ? d : null;
  } catch {
    return null;
  }
}

/** Detect acoustic speech segments [start, end] from audio using ffmpeg silencedetect. */
function detectSpeechSegments(audioPath, totalDur) {
  if (!audioPath || !totalDur) return null;
  try {
    const res = spawnSync(
      'ffmpeg',
      ['-hide_banner', '-i', audioPath, '-af', 'silencedetect=noise=-35dB:d=0.18', '-f', 'null', '-'],
      { encoding: 'utf8' },
    );
    const log = (res.stdout || '') + '\n' + (res.stderr || '');
    const starts = [...log.matchAll(/silence_start:\s*([\d.]+)/g)].map((m) => parseFloat(m[1]));
    const ends = [...log.matchAll(/silence_end:\s*([\d.]+)/g)].map((m) => parseFloat(m[1]));
    if (starts.length === 0) return null;

    const segments = [];
    let cur = 0.06;
    for (let i = 0; i < starts.length; i++) {
      const sStart = starts[i];
      const sEnd = i < ends.length ? ends[i] : totalDur;
      if (sStart - cur > 0.12) {
        segments.push({ start: cur, end: sStart });
      }
      cur = sEnd;
    }
    if (totalDur - cur > 0.2) {
      segments.push({ start: cur, end: Math.max(cur + 0.2, totalDur - 0.12) });
    }
    return segments.length >= 2 ? segments : null;
  } catch {
    return null;
  }
}

function wordSyllables(w) {
  const clean = w.replace(/[^a-zA-Z0-9]/g, '');
  return Math.max(1, (clean.match(/[aeiouyAEIOUY]+/g) || []).length);
}

/** Align script words to acoustic speech segments using Dynamic Programming (Viterbi). */
function buildAcousticAlignedTimings(scriptWords, segments) {
  const totalWords = scriptWords.length;
  const K = segments.length;
  const wordWeights = scriptWords.map(({ w }, idx) => {
    const syl = wordSyllables(w);
    let pauseScore = 0;
    if (/[.!?]$/.test(w)) pauseScore = 3.0;
    else if (/[:;—]$/.test(w)) pauseScore = 2.6;
    else if (/,$/.test(w)) pauseScore = 1.8;
    if (idx + 1 < totalWords && scriptWords[idx + 1].section !== scriptWords[idx].section) {
      pauseScore = 3.5;
    }
    return { syl, weight: 0.1 + syl * 0.06, pauseScore };
  });

  const prefixW = new Float64Array(totalWords + 1);
  for (let i = 0; i < totalWords; i++) prefixW[i + 1] = prefixW[i] + wordWeights[i].weight;
  const totalW = prefixW[totalWords];

  const segDurs = segments.map((s) => Math.max(0.08, s.end - s.start));
  const totalSegDur = segDurs.reduce((a, b) => a + b, 0);

  // Dynamic Programming: dp[s][i] = min cost to align segments 0..s ending at word i (inclusive)
  const INF = 1e12;
  const dp = Array.from({ length: K }, () => new Float64Array(totalWords).fill(INF));
  const parent = Array.from({ length: K }, () => new Int32Array(totalWords).fill(-1));

  const segCost = (s, wStart, wEnd) => {
    const wSpan = (prefixW[wEnd + 1] - prefixW[wStart]) / totalW;
    const aSpan = segDurs[s] / totalSegDur;
    const diff = wSpan - aSpan;
    const ratio = (wSpan + 0.002) / (aSpan + 0.002);
    const logRatio = Math.log(ratio);
    // Strong penalty if split word has no punctuation (unless it's the final word)
    const pScore = wEnd === totalWords - 1 ? 3.5 : wordWeights[wEnd].pauseScore;
    const nonPunctPenalty = pScore === 0 ? 12.0 : (3.5 - pScore) * 0.18;
    return diff * diff * 180 + logRatio * logRatio * 3.2 + nonPunctPenalty;
  };

  for (let i = 0; i < totalWords - (K - 1); i++) {
    dp[0][i] = segCost(0, 0, i);
  }

  for (let s = 1; s < K; s++) {
    const iMin = s;
    const iMax = s === K - 1 ? totalWords - 1 : totalWords - (K - s);
    const iStartLoop = s === K - 1 ? totalWords - 1 : iMin;
    for (let i = iStartLoop; i <= iMax; i++) {
      // Only consider punctuation words unless forced
      for (let prev = s - 1; prev < i; prev++) {
        if (dp[s - 1][prev] >= INF) continue;
        const c = dp[s - 1][prev] + segCost(s, prev + 1, i);
        if (c < dp[s][i]) {
          dp[s][i] = c;
          parent[s][i] = prev;
        }
      }
    }
  }

  // Backtrack optimal clause boundaries
  const endIndices = new Array(K);
  let cur = totalWords - 1;
  for (let s = K - 1; s >= 0; s--) {
    endIndices[s] = cur;
    cur = parent[s][cur];
  }

  // Distribute words inside each acoustic segment proportionally to syllable weight
  const result = [];
  let wStartIdx = 0;
  for (let s = 0; s < K; s++) {
    const wEndIdx = endIndices[s];
    const seg = segments[s];
    const segDur = Math.max(0.12, seg.end - seg.start);
    const slice = wordWeights.slice(wStartIdx, wEndIdx + 1);
    const sliceWeight = slice.reduce((acc, x, idx) => {
      const internalPause = idx < slice.length - 1 && x.pauseScore > 0 ? 0.14 : 0.02;
      return acc + x.weight + internalPause;
    }, 0);

    let cursor = seg.start;
    const scale = segDur / Math.max(0.05, sliceWeight);
    for (let j = 0; j < slice.length; j++) {
      const i = wStartIdx + j;
      const wDur = slice[j].weight * scale;
      const internalPause = (j < slice.length - 1 && slice[j].pauseScore > 0 ? 0.14 : 0.02) * scale;
      const start = Number(cursor.toFixed(3));
      const end = Number(Math.min(seg.end, cursor + wDur).toFixed(3));
      result.push({
        i,
        w: scriptWords[i].w,
        start,
        end: Math.max(Number((start + 0.06).toFixed(3)), end),
      });
      cursor = end + internalPause;
    }
    wStartIdx = wEndIdx + 1;
  }
  return result;
}

function buildFallbackTimings(scriptWords, targetDuration) {
  const weights = scriptWords.map(({ w }, idx) => {
    const syllables = wordSyllables(w);
    const durWeight = 0.14 + syllables * 0.048;
    let pauseAfter = 0.025;
    if (/[.!?]$/.test(w)) pauseAfter = 0.34;
    else if (/[,;:—]$/.test(w)) pauseAfter = 0.17;
    if (idx + 1 < scriptWords.length && scriptWords[idx + 1].section !== scriptWords[idx].section) {
      pauseAfter = Math.max(pauseAfter, 0.42);
    }
    return { durWeight, pauseAfter };
  });

  const leadIn = 0.18;
  const totalRaw = weights.reduce((acc, x) => acc + x.durWeight + x.pauseAfter, 0);
  const desiredSpeechSpan = targetDuration ? Math.max(2, targetDuration - leadIn - 0.35) : totalRaw;
  const scale = desiredSpeechSpan / totalRaw;

  const result = [];
  let cursor = leadIn;
  for (let i = 0; i < scriptWords.length; i++) {
    const dur = weights[i].durWeight * scale;
    const pause = weights[i].pauseAfter * scale;
    const start = Number(cursor.toFixed(3));
    const end = Number((cursor + dur).toFixed(3));
    result.push({ i, w: scriptWords[i].w, start, end });
    cursor = end + pause;
  }
  return result;
}

function formatSrtTime(sec) {
  const msTotal = Math.max(0, Math.round(sec * 1000));
  const ms = msTotal % 1000;
  const sTotal = Math.floor(msTotal / 1000);
  const s = sTotal % 60;
  const mTotal = Math.floor(sTotal / 60);
  const m = mTotal % 60;
  const h = Math.floor(mTotal / 60);
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

function writeSrt(words) {
  const cues = [];
  let i = 0;
  while (i < words.length) {
    const w0 = words[i];
    const w1 = i + 1 < words.length ? words[i + 1] : null;
    const hasPunct = /[.,!?;:]$/.test(w0.w);
    if (w1 && !hasPunct && w1.start - w0.end < 0.12 && w0.w.length + w1.w.length <= 12) {
      cues.push({ text: `${w0.w} ${w1.w}`, start: w0.start, end: w1.end });
      i += 2;
    } else {
      cues.push({ text: w0.w, start: w0.start, end: w0.end });
      i += 1;
    }
  }

  const lines = cues.map((c, idx) => {
    return `${idx + 1}\n${formatSrtTime(c.start)} --> ${formatSrtTime(c.end)}\n${c.text}\n`;
  });
  fs.mkdirSync(path.dirname(SRT_PATH), { recursive: true });
  fs.writeFileSync(SRT_PATH, lines.join('\n'), 'utf8');
}

function writeWordsMd(words, sections) {
  const secMap = new Map(sections.map((s) => [s.from, s.name]));
  const out = [
    '# Word Timing Lookup (`src/project/words.md`)',
    '',
    'Use `w<index>` (word start) or `w<index>e` (word end) in `shots.ts`, `world.ts`, and `config.ts`.',
    '',
  ];
  for (const w of words) {
    if (secMap.has(w.i)) {
      out.push(`\n## [${secMap.get(w.i).toUpperCase()}] (starts at \`w${w.i}\` = ${w.start.toFixed(2)}s)\n`);
    }
    out.push(`- \`w${w.i}\` (${w.start.toFixed(2)}s – ${w.end.toFixed(2)}s): **${w.w}**`);
  }
  fs.writeFileSync(WORDS_MD_PATH, out.join('\n') + '\n', 'utf8');
}

function main() {
  if (!fs.existsSync(SCRIPT_PATH)) {
    console.error(`Missing ${SCRIPT_PATH}`);
    process.exit(1);
  }
  const rawScript = fs.readFileSync(SCRIPT_PATH, 'utf8');
  const { words: scriptWords, sections } = parseScript(rawScript);

  const candidates = ['public/vo.mp3', 'public/vo.wav', 'public/vp.mp3', 'public/audio/user-vo.mp3'];
  let userVo = null;
  for (const rel of candidates) {
    const p = path.join(ROOT, rel);
    if (fs.existsSync(p)) {
      userVo = p;
      break;
    }
  }

  const audioDur = userVo ? getAudioDuration(userVo) : null;
  const segments = userVo && audioDur ? detectSpeechSegments(userVo, audioDur) : null;
  const timedWords = segments
    ? buildAcousticAlignedTimings(scriptWords, segments)
    : buildFallbackTimings(scriptWords, audioDur);

  const payload = {
    estimated: !userVo,
    acousticSegments: segments ? segments.length : 0,
    totalDuration: timedWords.length ? timedWords[timedWords.length - 1].end : 0,
    sections,
    words: timedWords,
  };

  fs.writeFileSync(WORDS_JSON_PATH, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  writeWordsMd(timedWords, sections);
  writeSrt(timedWords);

  const totalSec = payload.totalDuration;
  const wps = (timedWords.length / Math.max(1, totalSec)).toFixed(2);
  console.log(
    `[timings] Synced ${timedWords.length} words across ${sections.length} sections (${totalSec.toFixed(2)}s, ${wps} words/s, acoustic segments=${payload.acousticSegments}).`,
  );
  console.log(`[timings] Wrote src/project/words.json, src/project/words.md, and public/subtitles.srt`);
}

main();
