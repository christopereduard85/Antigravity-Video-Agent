# Animation Logic, Architectural Laws & Heuristics (Production Standard)

This document codifies the core animation logic, kinematic laws, architectural safety principles, and anti-glitch heuristics reverse-engineered and battle-tested across broadcast production episodes. Every AI agent generating or editing animations within this studio MUST strictly follow these rules.

---

## 1. Architectural Safety: The "Zero-White-Screen" Law

### 1.1 Never Use Heavy WebGL Overlays for 2D Flat-Vector Shows
* **Failure Mode**: In headless Chromium and Remotion preview/rendering pipelines, WebGL canvases (`@remotion/three`, `<ThreeCanvas>`, `@react-three/fiber`) frequently fail to clear transparently, spawning an opaque, solid white 1920×1080 canvas (`#FFFFFF`) between the SVG stage and the subtitle layer. This completely blacks/whites out the characters, scenery, and animation.
* **The Rule**: All atmospheric overlays—such as magical sparkles, drifting blossom petals, party confetti, glowing fireflies, wind streams, and driving storm rain—**must be authored as 100% transparent vector SVG layers** driven deterministically by Remotion's `frame`.
* **Zero WebGL Context Loss**: Pure vector SVG particles render with zero GPU context stalls, zero memory leaks, zero Suspense delay locks, and 100% transparency across all operating systems and browsers.

### 1.2 Zero Full-Canvas Screen Bloom Overlays
* **Failure Mode**: Using full-viewport rectangles with white or radial gradients (`<rect width={W} height={H} fill="white" />` or `<rect fill="url(#screen-bloom)" />`) completely blows out the camera, washing out the characters and scenery into an unreadable blinding haze.
* **The Rule**: Never render full-screen white/radial bloom rects. All glow effects, transformation halos, and impact flashes must be **spatially bounded to the character silhouette** (`rx, ry` tied to character scale), utilizing warm, soft golden/amber tints (`#FEF08A`, `#FDE047`, `#F59E0B`) with subtle opacity (maximum `0.45–0.65`).

### 1.3 Transient VFX Lifecycle (Max 45–60 Frames)
* **Failure Mode**: Allowing transformation VFX (`MetamorphosisVFX`) or magic wipes to remain active across an entire 200–250 frame shot blinds the audience and conceals character expressions during dialogue.
* **The Rule**: Magical bursts and transformations are **transient events**:
  ```tsx
  // Transformation burst executes only during the initial transition moment
  if (frame > duration) return null; // Default duration: 45–60 frames (1.5–2s)
  ```
  Once the transformation is complete, the VFX component returns `null`, leaving the characters and backdrop 100% visible, crisp, and unobstructed while lines are spoken.

---

## 2. Anatomical & Articulation Precision: The Clean Silhouette Law

### 2.1 Calf-to-Ankle Joint Separation (Preventing Double-Cuff Bulbing)
* **Failure Mode**: In 2-bone articulated limbs (`hip -> knee -> ankle/foot`), using `strokeLinecap="round"` for the calf path down to ground level causes a round circle to protrude underneath the foot, creating a disjointed "bell-bottom cuff" or double-cap bulb.
* **The Rule**:
  1. Terminate the calf stroke cleanly above the sole:
     ```tsx
     const ankY = Ft[1] - limbW * 0.35;
     ```
  2. Use `strokeLinecap={isPanda ? "butt" : "round"}`.
  3. Seamlessly match the paw/shoe width to the calf width (`footCx - dir * limbW * 0.48` to `0.46`), producing continuous, solid cub legs and paws.

### 2.2 Mathematical Ground-Plane Stability
* **The Rule**: The bottom-most point of the planted foot must clamp strictly to `y = 0` in body local space:
  ```tsx
  const Ft: Pt = [Kn[0] + v[0] * segLeg, Math.min(0, Kn[1] + v[1] * segLeg)];
  ```
  Feet must never penetrate the ground line. During contact and cushion, the ankle pitch dynamically adjusts (`pitchDeg = -thighDeg * 0.65`) so the sole sits completely flat against the ground plane.

---

## 3. Action Props & Mechanical Kinematics: The Synchronization Law

### 3.1 Separation of Character Prop Mesh vs World Action Rig
* **Failure Mode**: Hardcoding action lines, strings, ropes, or floating bobbers inside `Character.tsx` (`case "rod":`). Because `Character.tsx` has no knowledge of water targets, fish positions, or shot phases, local lines inevitably dangle into empty space or float absurdly in the sky.
* **The Rule**:
  - `Character.tsx` **only renders the physical held prop mesh** (the bamboo rod, the hoe, the wooden basket).
  - External mechanics (the fishing line, flight parabola, splash ripples, tension struggle) are managed exclusively by dedicated Scene Rigs (`<FishingSceneRig/>`, `<ProjectileView/>`) at the world SVG root.

### 3.2 Strict Analytical Tip Derivation
* **The Rule**: Prop tip coordinates must never be guessed. Derive them dynamically from the character's arm FK/IK joint vectors, body lean, and prop dimensions:
  - Resting/Crouch: `(casterX + dir * 255 * scale, casterY - 195 * scale)`
  - Battle Pull (lean -22°): `(casterX + dir * 282 * scale, casterY - 225 * scale)`
  - Backswing: `(casterX - dir * 110 * scale, casterY - 330 * scale)`

### 3.3 Phase Inactivity Discipline (Zero Mid-Air Artifacts)
* **The Rule**: Never render detached action lines, floating bobbers, or strings in midair before the action begins:
  ```tsx
  // Before casting wind-up begins, the line is stowed along the rod:
  if (frame < castStart) return null;
  ```

### 3.4 Active Action Phases & Realistic Physics
1. **Backswing Anticipation** (`frame >= castStart && frame < castStart + 18`): The rod tip swings back and up; the line trails behind in a gentle trailing curve.
2. **Forward Whip & Parabolic Flight** (`frame >= castStart + 18 && frame < hitFrame`): The rod snaps forward rapidly to full extension; the line and bobber travel along a true gravity parabola `arc([rodTipX, rodTipY], [waterX, waterY], 115, uFlight)`.
3. **Surface Impact & Settle** (`frame >= hitFrame`):
   - Bobber lands at `(waterX, waterY)` and bobs softly (`bobY = waterY + Math.sin(frame * 0.12) * 3`).
   - Expanding water ripple rings (`rx = 12 + p * 78, ry = 4 + p * 24`) and water spray fountain droplets disperse from the impact point.
   - The line forms a natural dipping catenary curve connecting the rod tip smoothly to the floating bobber.
4. **Tug-of-War Battle**:
   - The fishing line is a taut, vibrating filament (`tensionVib = Math.sin(frame * 2.2) * 2.4`).
   - Concentric expanding shockwave ripples rush outward from the struggle point.
   - Underwater golden thrash shadow quivers beneath the foam prior to breaching.
5. **Clean Prop Release**: When a character drops a prop (e.g. `prop: "none"` or gasping in surprise with `handsCheeks`), tension lines and struggle effects terminate immediately.

---

## 4. Background Purity & Geographical Authenticity

### 4.1 Geographical Integrity in Folklore
* **The Rule**: Respect the geographical truth of the folklore. In legends like *Lake Toba*, the setting is a **Danau (Lake)**, not a river. Water horizons, pier docks, and mountain ridges must reflect lake geography.

### 4.2 The "Hanya Padang Hijau" Purity Principle
* **Failure Mode**: Cluttering outdoor celebration or meadow scenes with unrelated trees, busy autumn leaves, or heavy foreground floral occluders that crowd the characters.
* **The Rule**: When a scene specifies an open meadow or field celebration ("padang hijau"):
  - Use the dedicated `backdrop: "greenPasture"` preset.
  - Render layered rolling emerald hills (`#86EFAC`, `#4ADE80`, `#22C55E`, `#16A34A`), crisp blue sky, and drifting fluffy white clouds.
  - Feature softly swaying grass tufts across the meadow.
  - Omit background trees and foreground floral occluders (`foreground: "none"`) so the characters and the open landscape take center stage.

---

## 5. Continuous Travel & Motion-Director Staging

### 5.1 Continuous Side-Scroll vs Edge-Freezing
* **Failure Mode**: Having a character run across the screen, reach the right edge of the frame, and freeze in place while dialogue continues.
* **The Rule**: For travel, errands, and chases:
  - Transition from the departure scene into a **centered tracking shot**.
  - Keep the running character centered (`x = 960` or two-shot with companion).
  - Drive continuous multi-plane background displacement (`scrollX: [0, -850]` or `[0, -1200]`).
  - The scenery scrolls smoothly beneath their feet while their stride cycle stays perfectly synchronized, conveying true long-distance travel.

### 5.2 Multi-Beat Choreography Within Single Shots
* **The Rule**: Never let a character remain static in a single pose throughout a shot. Use `beats: ActorBeat[]` to divide every shot into 2–3 expressive acting beats (e.g., `walk -> idle`, `pull -> surprised`, `handsCheeks -> cheer`).

---

## 6. Channel Branding & Outro Customization

* **The Rule**: All series bumpers must support parameterized channel identity:
  - `brandName`: Defined in `script.ts` (e.g., `"EduFam"`).
  - Outro search card: The YouTube search input must dynamically type out the configured `channelName` (`"EduFam"`) and render the subtext `"Search EduFam."`.
