"""Generate analysis/beats.json and analysis/lyrics_timed.json, and copy to video/src/data/."""
import json
import shutil
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfiltfilt

raw = json.load(open('analysis/beats.json'))
bpm = raw['bpm']  # 152.0
dur = raw['durationSec']  # 133.207
beats = raw['beats']
db = raw['downbeats']  # 85 bars, bar 0 = 0.525s, period = 1.57895s

def sec_to_frame(s: float) -> int:
    return min(3997, max(0, int(round(s * 30))))

# Section table mapped to exact timestamps verified against Halloween Night.wav vocal onsets
section_defs = [
    ('A',  'Intro Window (Pip)',             0.00,  1.20, 'pip'),
    ('B',  'Curtain Open & Band Intro',      1.20,  1.80, 'bobo'),
    ('C1', 'Verse 1 — Bobo on Stage',        1.80, 12.80, 'bobo'),
    ('T1', 'Transform 1 — Spin to Burger',  12.80, 14.55, 'bobo'),
    ('K1', 'Chorus 1 — Burger Party',       14.55, 26.30, 'bobo'),
    ('I1', 'Interlude 1 — Band Groove',     26.30, 26.85, 'band'),
    ('C2', 'Verse 2 — Lulu on Stage',       26.85, 37.95, 'lulu'),
    ('T2', 'Transform 2 — Spin to IceCream',37.95, 39.75, 'lulu'),
    ('K2', 'Chorus 2 — Ice Cream Party',    39.75, 52.55, 'lulu'),
    ('C3', 'Verse 3 — Ziggy on Stage',      52.55, 63.25, 'ziggy'),
    ('T3', 'Transform 3 — Spin to Donut',   63.25, 64.95, 'ziggy'),
    ('K3', 'Chorus 3 — Donut Party',        64.95, 77.65, 'ziggy'),
    ('C4', 'Verse 4 — Grub on Stage',       77.65, 89.60, 'grub'),
    ('T4', 'Transform 4 — Spin to HotDog',  89.60, 91.10, 'grub'),
    ('K4', 'Chorus 4 — Hot Dog Party',      91.10,103.40, 'grub'),
    ('F1', 'Finale Lineup — All Stage',    103.40,116.30, 'all'),
    ('F2', 'Finale 4-Panel Color Grid',    116.30,122.60, 'all'),
    ('F3', 'Finale Trick-or-Treat Street', 122.60,129.95, 'all'),
    ('O',  'Outro — Ukulele & Curtain',    129.95,133.21, 'all'),
]

sections = []
prev_frame = 0
for i, (sid, label, s0, s1, hero) in enumerate(section_defs):
    f0 = prev_frame
    f1 = 3997 if sid == 'O' or i == len(section_defs) - 1 else sec_to_frame(s1)
    prev_frame = f1
    sections.append({
        'id': sid,
        'label': label,
        'hero': hero,
        'startBar': round(max(0.0, (s0 - 0.525) / 1.57895), 2),
        'endBar': round((s1 - 0.525) / 1.57895, 2),
        'startSec': round(s0, 3),
        'endSec': round(dur if sid == 'O' else s1, 3),
        'startFrame': f0,
        'endFrame': f1,
    })

# Vocal amplitude envelope at 30 fps for lip-sync
sr, x = wavfile.read('Halloween Night.wav')
x = x.astype(np.float64)
mid = (x[:, 0] + x[:, 1]) * 0.5 if x.ndim > 1 else x
side = (x[:, 0] - x[:, 1]) * 0.5 if x.ndim > 1 else np.zeros_like(x)
voc_sig = mid - 0.75 * side
sos = butter(4, [400, 3200], btype='bandpass', fs=sr, output='sos')
voc = sosfiltfilt(sos, voc_sig)

n_frames = 3997
spf = sr / 30.0
env = np.zeros(n_frames)
for i in range(n_frames):
    s0 = int(i * spf)
    s1 = min(len(voc), int((i + 1) * spf))
    if s1 > s0:
        env[i] = np.sqrt(np.mean(voc[s0:s1] ** 2))
p95 = np.percentile(env, 95) + 1e-9
p20 = np.percentile(env, 20)
env = np.clip((env - p20) / (p95 - p20), 0.0, 1.0)
env_smooth = np.convolve(env, [0.25, 0.5, 0.25], mode='same')

# Phoneme/viseme heuristic per word
def guess_viseme(word: str) -> str:
    w = word.lower().strip(".,!'’")
    if any(k in w for k in ['oo', 'oh', 'cone', 'so', 'cold', 'donut', 'donuts', 'round', 'all', 'warm', 'dog', 'dogs', 'costume']):
        return 'O'
    if any(k in w for k in ['ee', 'be', 'sweet', 'treat', 'neat', 'cream', 'we', 'party', 'juicy']):
        return 'E'
    if any(k in w for k in ['ah', 'at', 'my', 'our', 'bite', 'right', 'tonight', 'hot', 'yum', 'sprinkled']):
        return 'open'
    return 'mid'

# Exact vocal-synced word rhythmic templates in SECONDS relative to phrase onset t0!
# (1 beat = 0.3947s, 2 beats = 0.7895s, 4 beats = 1.5789s)
SEC_TEMPLATES = {
    'PARTY_TONIGHT': [
        ("At",       0.00, 0.20),
        ("the",      0.20, 0.40),
        ("costume",  0.40, 1.18),
        ("party",    1.18, 1.82),
        ("tonight,", 1.82, 2.75),
    ],
    'FAVORITE_BITE_SOLO': [
        ("I'm",      0.00, 0.22),
        ("gonna",    0.22, 0.62),
        ("be",       0.62, 0.98),
        ("my",       0.98, 1.35),
        ("favorite", 1.35, 2.15),
        ("bite.",    2.15, 2.80),
    ],
    'FAVORITE_BITE_ALL': [
        ("We're",    0.00, 0.22),
        ("all",      0.22, 0.45),
        ("gonna",    0.45, 0.78),
        ("be",       0.78, 1.05),
        ("our",      1.05, 1.38),
        ("favorite", 1.38, 2.15),
        ("bite!",    2.15, 2.80),
    ],
    'REVEAL_BURGER': [
        ("I'm",      0.00, 0.20),
        ("gonna",    0.20, 0.54),
        ("be",       0.54, 0.76),
        ("a",        0.76, 0.95),
        ("juicy",    0.95, 1.48),
        ("burger,",  1.48, 2.12),
        ("right!",   2.12, 2.70),
    ],
    'CHORUS_BURGER': [
        ("Burger,",  0.00, 0.76),
        ("burger,",  0.76, 1.52),
        ("yum",      1.54, 1.94),
        ("yum",      1.94, 2.34),
        ("yum!",     2.34, 2.85),
    ],
    'REVEAL_ICECREAM': [
        ("I'm",      0.00, 0.20),
        ("gonna",    0.20, 0.52),
        ("be",       0.52, 0.72),
        ("an",       0.72, 0.90),
        ("ice",      0.90, 1.22),
        ("cream",    1.22, 1.56),
        ("cone",     1.56, 1.92),
        ("so",       1.92, 2.20),
        ("sweet!",   2.20, 2.70),
    ],
    'CHORUS_ICECREAM': [
        ("Ice",      0.00, 0.38),
        ("cream,",   0.38, 0.76),
        ("ice",      0.76, 1.14),
        ("cream,",   1.14, 1.52),
        ("cold",     1.54, 1.94),
        ("and",      1.94, 2.34),
        ("sweet!",   2.34, 2.85),
    ],
    'REVEAL_DONUT': [
        ("I'm",      0.00, 0.20),
        ("gonna",    0.20, 0.54),
        ("be",       0.54, 0.76),
        ("a",        0.76, 0.95),
        ("sprinkled",0.95, 1.56),
        ("donut",    1.56, 2.12),
        ("treat!",   2.12, 2.70),
    ],
    'CHORUS_DONUT': [
        ("Donut,",   0.00, 0.76),
        ("donut,",   0.76, 1.52),
        ("round",    1.54, 1.94),
        ("and",      1.94, 2.34),
        ("round!",   2.34, 2.85),
    ],
    'REVEAL_HOTDOG': [
        ("I'm",      0.00, 0.20),
        ("gonna",    0.20, 0.52),
        ("be",       0.52, 0.72),
        ("a",        0.72, 0.90),
        ("hot",      0.90, 1.22),
        ("dog,",     1.22, 1.56),
        ("hot",      1.56, 1.90),
        ("and",      1.90, 2.20),
        ("neat!",    2.20, 2.70),
    ],
    'CHORUS_HOTDOG': [
        ("Hot",      0.00, 0.38),
        ("dog,",     0.38, 0.76),
        ("hot",      0.76, 1.14),
        ("dog,",     1.14, 1.52),
        ("warm",     1.54, 1.94),
        ("and",      1.94, 2.34),
        ("neat!",    2.34, 2.85),
    ],
    'FINALE_FOODS': [
        ("Burgers,", 0.00, 0.76),
        ("ice",      0.76, 1.14),
        ("cream,",   1.14, 1.54),
        ("donuts,",  1.54, 2.10),
        ("and",      2.10, 2.36),
        ("hot",      2.36, 2.66),
        ("dogs!",    2.66, 3.05),
    ],
}

# Exact verified vocal onset timestamps (in seconds) for all 40 lines in Halloween Night.wav
# Including -0.06s perceptual anticipation lead so lyrics feel 100% immediate & snappy with the singer!
LEAD = -0.06

lyric_specs = [
    # Verse 1 (starts at 1.85s)
    ('C1', 'bobo',   1.85, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C1', 'bobo',   5.00, 'FAVORITE_BITE_SOLO', "I'm gonna be my favorite bite."),
    ('C1', 'bobo',   8.15, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C1', 'bobo',  11.30, 'REVEAL_BURGER',      "I'm gonna be a juicy burger, right!"),
    # Chorus 1 (starts at 14.65s)
    ('K1', 'bobo',  14.65, 'CHORUS_BURGER',      "Burger, burger, yum yum yum!"),
    ('K1', 'bobo',  17.80, 'CHORUS_BURGER',      "Burger, burger, yum yum yum!"),
    ('K1', 'bobo',  20.95, 'CHORUS_BURGER',      "Burger, burger, yum yum yum!"),
    ('K1', 'bobo',  24.00, 'REVEAL_BURGER',      "I'm gonna be a juicy burger, right!"),

    # Verse 2 (starts at 28.15s)
    ('C2', 'lulu',  28.15, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C2', 'lulu',  31.30, 'FAVORITE_BITE_SOLO', "I'm gonna be my favorite bite."),
    ('C2', 'lulu',  34.45, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C2', 'lulu',  37.60, 'REVEAL_ICECREAM',    "I'm gonna be an ice cream cone so sweet!"),
    # Chorus 2 (starts at 41.50s)
    ('K2', 'lulu',  41.50, 'CHORUS_ICECREAM',    "Ice cream, ice cream, cold and sweet!"),
    ('K2', 'lulu',  44.65, 'CHORUS_ICECREAM',    "Ice cream, ice cream, cold and sweet!"),
    ('K2', 'lulu',  47.80, 'CHORUS_ICECREAM',    "Ice cream, ice cream, cold and sweet!"),
    ('K2', 'lulu',  50.85, 'REVEAL_ICECREAM',    "I'm gonna be an ice cream cone so sweet!"),

    # Verse 3 (starts at 52.00s — overlapping right after Chorus 2!)
    ('C3', 'ziggy', 52.00, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C3', 'ziggy', 55.15, 'FAVORITE_BITE_SOLO', "I'm gonna be my favorite bite."),
    ('C3', 'ziggy', 58.30, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C3', 'ziggy', 61.45, 'REVEAL_DONUT',       "I'm gonna be a sprinkled donut treat!"),
    # Chorus 3 (starts at 65.20s)
    ('K3', 'ziggy', 65.20, 'CHORUS_DONUT',       "Donut, donut, round and round!"),
    ('K3', 'ziggy', 68.35, 'CHORUS_DONUT',       "Donut, donut, round and round!"),
    ('K3', 'ziggy', 71.50, 'CHORUS_DONUT',       "Donut, donut, round and round!"),
    ('K3', 'ziggy', 74.55, 'REVEAL_DONUT',       "I'm gonna be a sprinkled donut treat!"),

    # Verse 4 (starts at 77.25s)
    ('C4', 'grub',  77.25, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C4', 'grub',  80.40, 'FAVORITE_BITE_SOLO', "I'm gonna be my favorite bite."),
    ('C4', 'grub',  83.55, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('C4', 'grub',  86.70, 'REVEAL_HOTDOG',      "I'm gonna be a hot dog, hot and neat!"),
    # Chorus 4 (starts at 90.45s)
    ('K4', 'grub',  90.45, 'CHORUS_HOTDOG',      "Hot dog, hot dog, warm and neat!"),
    ('K4', 'grub',  93.60, 'CHORUS_HOTDOG',      "Hot dog, hot dog, warm and neat!"),
    ('K4', 'grub',  96.75, 'CHORUS_HOTDOG',      "Hot dog, hot dog, warm and neat!"),
    ('K4', 'grub',  99.80, 'REVEAL_HOTDOG',      "I'm gonna be a hot dog, hot and neat!"),

    # Finale F1 (starts at 104.70s after "Everybody!" shout at 103.6s)
    ('F1', 'all',  104.70, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('F1', 'all',  107.85, 'FAVORITE_BITE_ALL',  "We're all gonna be our favorite bite!"),
    ('F1', 'all',  111.00, 'PARTY_TONIGHT',      "At the costume party tonight,"),
    ('F1', 'all',  114.15, 'FAVORITE_BITE_ALL',  "We're all gonna be our favorite bite!"),

    # Finale F2 & F3 (starts at 117.30s)
    ('F2', 'all',  117.30, 'FINALE_FOODS',       "Burgers, ice cream, donuts, and hot dogs!"),
    ('F2', 'all',  120.45, 'FINALE_FOODS',       "Burgers, ice cream, donuts, and hot dogs!"),
    ('F3', 'all',  123.60, 'FINALE_FOODS',       "Burgers, ice cream, donuts, and hot dogs!"),
    ('F3', 'all',  126.75, 'FINALE_FOODS',       "Burgers, ice cream, donuts, and hot dogs!"),
]

# Line starts re-anchored to whisper transcription and audio onset inspection.
# V4 and K4 exact vocal onsets:
# C4 begins at 77.65s (after drum roll). K4 begins at 91.60s (after spin/trumpet break).
# F1 begins at 104.00s (after "Everybody!"). F2 begins at 116.40s.
STARTS = [
    1.85, 5.00, 8.15, 11.30,          14.65, 17.80, 20.95, 23.95,      # C1 K1
    27.05, 30.26, 33.46, 36.67,       39.87, 43.08, 46.29, 49.49,      # C2 K2
    52.70, 55.79, 58.88, 61.96,       65.05, 68.14, 71.23, 74.31,      # C3 K3
    77.65, 80.75, 83.85, 86.95,       91.20, 94.35, 97.45, 100.55,     # C4 K4 (K4 shifted 0.40s earlier)
    103.55, 106.70, 109.80, 112.90,                                    # F1 (shifted 0.45s earlier)
    116.40, 119.55, 122.70, 125.85,                                    # F2 F3
]
lyric_specs = [(s[0], s[1], b, s[3], s[4]) for s, b in zip(lyric_specs, STARTS)]

lyrics_timed = []
for idx, (sec_id, hero, base_sec, tpl_key, text) in enumerate(lyric_specs):
    tpl = SEC_TEMPLATES[tpl_key]
    words_out = []
    for w_str, rel_start, rel_end in tpl:
        w0 = round(max(0.0, base_sec + LEAD + rel_start), 3)
        w1 = round(max(w0 + 0.05, base_sec + LEAD + rel_end), 3)
        words_out.append({
            'w': w_str,
            'startSec': w0,
            'endSec': w1,
            'viseme': guess_viseme(w_str),
        })
    line_start = words_out[0]['startSec']
    line_end = words_out[-1]['endSec']
    # Clamp line_end if next line starts earlier (e.g., K2 L4 -> C3 L1 transition)
    if idx + 1 < len(lyric_specs):
        next_start = round(max(0.0, lyric_specs[idx + 1][2] + LEAD - 0.04), 3)
        if line_end > next_start:
            line_end = next_start
            words_out[-1]['endSec'] = max(words_out[-1]['startSec'] + 0.08, line_end)

    lyrics_timed.append({
        'index': idx,
        'section': sec_id,
        'hero': hero,
        'line': text,
        'startSec': line_start,
        'endSec': line_end,
        'startFrame': sec_to_frame(line_start),
        'endFrame': sec_to_frame(line_end),
        'words': words_out,
    })

beats_out = {
    'durationSec': round(dur, 3),
    'totalFrames': 3997,
    'fps': 30,
    'bpm': bpm,
    'beatPeriodSec': round(60.0 / bpm, 5),
    'barPeriodSec': round(240.0 / bpm, 5),
    'offsetSec': raw['offsetSec'],
    'downbeatPhase': raw['downbeatPhase'],
    'beats': raw['beats'],
    'downbeats': raw['downbeats'],
    'sections': sections,
    'mouthEnvelope': [round(float(v), 2) for v in env_smooth],
}

json.dump(beats_out, open('analysis/beats.json', 'w', encoding='utf-8'), indent=2)
json.dump(lyrics_timed, open('analysis/lyrics_timed.json', 'w', encoding='utf-8'), indent=2)
shutil.copy('analysis/beats.json', 'video/src/data/beats.json')
shutil.copy('analysis/lyrics_timed.json', 'video/src/data/lyrics_timed.json')

print(f"Wrote analysis/beats.json ({len(sections)} sections) and analysis/lyrics_timed.json ({len(lyrics_timed)} lines)")
for s in sections:
    print(f"  {s['id']:2s}: {s['startSec']:6.2f}s - {s['endSec']:6.2f}s (frames {s['startFrame']:4d}..{s['endFrame']:4d}) {s['label']}")
