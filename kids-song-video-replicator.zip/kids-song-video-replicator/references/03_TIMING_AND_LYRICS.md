# 03 — Audio timing, lyrics, lip-sync

This phase decides whether the video "feels right". Most user complaints in the original run were lyric timing. Do it carefully.

## Data flow

```
<Song>.wav ──audio_beats.py──► analysis/beats_raw.json  (bpm, offsetSec, downbeatPhase, beats[], downbeats[], durationSec)
           (first time)  copy beats_raw.json -> analysis/beats.json
ffmpeg whisper filter ───► analysis/whisper.srt (+ whisper12.srt with different segmenting)
build_timing.py  reads analysis/beats.json (bpm/beats/downbeats) + WAV
                 writes analysis/beats.json  (+sections +mouthEnvelope)   → copied to video/src/data/beats.json
                        analysis/lyrics_timed.json                       → copied to video/src/data/lyrics_timed.json
timeline.ts      imports both JSON files (getSectionAtFrame, getLyricAtFrame)
```

`build_timing.py` is idempotent (it keeps bpm/beats keys when rewriting beats.json). Re-run after every timing edit.

## Step 1 — beat grid

`python analysis/audio_beats.py` (edit WAV filename on line 7). Prints `bpm`, offset, bars. Original: 152.0 BPM, beat 0.3947 s, bar 1.57895 s, bar 0 at 0.525 s, 85 bars. Update the hard-coded `0.525` / `1.57895` in `build_timing.py` (`startBar/endBar` only, cosmetic) and replace every `3997` with your total frames.

## Step 2 — real vocal onsets (Whisper)

```powershell
ffmpeg -i "<Song>.wav" -vn -af "whisper=model=analysis/models/ggml-base.en.bin:language=en:queue=3:destination=analysis/whisper.srt:format=srt" -f null -
ffmpeg -i "<Song>.wav" -vn -af "whisper=model=analysis/models/ggml-base.en.bin:language=en:queue=12:destination=analysis/whisper12.srt:format=srt" -f null -
```
Read both SRTs; for each lyric line take the earliest believable start. Cross-check with audio slices:
```powershell
ffmpeg -y -ss 77.0 -t 12 -i "<Song>.wav" analysis/audio_check/slice_77s.mp3
```
(Optional helpers in template: `refine_lyrics.py` (onset scoring), `section_lag.py`, `tempo_drift.py`, `whisper_align.py` (needs faster-whisper; optional).)

## Step 3 — fill build_timing.py

1. `section_defs`: `(id, label, startSec, endSec, hero)` for every section. Boundaries = musical events (verse vocal onset, spin break, chorus onset). End of section i must equal start of section i+1 in seconds; frames are forced contiguous in code (`f0 = prev_frame`). **Never remove that logic.**
2. `SEC_TEMPLATES`: per phrase type, list of `(word, relStart, relEnd)` seconds from phrase onset. Built from the beat (1 beat = 0.3947 s at 152 BPM). Each distinct lyric line shape gets one template (verse line, "I'm gonna be…" reveal, chorus chant, finale list).
3. `lyric_specs`: one row per sung line `(section, hero, approxStart, templateKey, text)`.
4. `STARTS`: the **measured** onset for every line (overrides approxStart). This list is what you tweak when the user says "telat"/"kecepetan".
5. `LEAD = -0.06` s anticipation. Keep.
6. Line end is clamped to next line start − 0.04 s.

Original measured STARTS (152 BPM song, for scale): verse lines every ~3.15 s; C1 1.85, K1 14.65, C2 27.05, K2 39.87, C3 52.70, K3 65.05, C4 77.65, K4 91.20, F1 103.55, F2 116.40.

## Step 4 — visemes + mouth

- `guess_viseme(word)` maps vowels → `O`, `E`, `open`, `mid` (+ `closed`).
- `mouthEnvelope`: vocal band-pass (400–3200 Hz, mid−0.75·side to suppress stereo instruments) RMS per frame, normalised p20..p95, smoothed. Stored in beats.json.
- `getLyricAtFrame` (timeline.ts): inside a word → consonant closure at first/last 8% of word, else open = env·0.55 + pulse·0.35 + syllable wave·0.35; long words cycle extra visemes; between words follow envelope; outside lines animate only if env > 0.22.
- The singing hero uses `mode: 'sing'`; others `dance`.

## Timing QA loop (do for EACH verse/chorus block)

1. Render a still at the first word of each line (`frame = round(start*30)`), check the karaoke word highlight is on the first word.
2. Listen to an audio slice of the block; compare to SRT.
3. If the user says the block is late: shift only that block's `STARTS` earlier (0.3–0.45 s steps), rebuild, update affected wipe `cutFrame`s, re-render 1 still. Report the new seconds.
4. Never shift the whole song with one offset — drift differs per block.

## Gotchas seen

- A phantom 1.5 s interlude assumption made verse 2+ late by ~1 s. Real verse 2 started at 27.05 s.
- Chorus 4 was placed 1.8 s too early (before trumpet/spin break) then later ~0.4 s late. Measure, don't assume symmetric structure.
- Verse 3 started overlapping the end of chorus 2 → clamp works, section boundary chosen at vocal onset.
