param(
  [int[]]$Frames = @(15, 380),
  [string]$Comp = 'Main',
  [string]$OutDir = 'analysis/qa',
  [string]$Chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
)
# Render QA still frames. Run from workspace root (outside sandbox if no network / headless shell).
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
foreach ($f in $Frames) {
  $out = Join-Path $OutDir ("{0}_f{1:D4}.png" -f $Comp, $f)
  & ./video/node_modules/.bin/remotion still video/src/index.ts $Comp $out "--frame=$f" --public-dir=video/public "--browser-executable=$Chrome"
  Write-Host "-> $out"
}
