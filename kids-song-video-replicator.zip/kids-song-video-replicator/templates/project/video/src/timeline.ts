import beatsData from './data/beats.json';
import lyricsData from './data/lyrics_timed.json';
import { Viseme } from './rig/types';

export interface SectionInfo {
  id: string;
  label: string;
  hero: string;
  startBar: number;
  endBar: number;
  startSec: number;
  endSec: number;
  startFrame: number;
  endFrame: number;
}

export interface TimedWord {
  w: string;
  startSec: number;
  endSec: number;
  viseme: Viseme;
}

export interface TimedLyricLine {
  index: number;
  section: string;
  hero: string;
  line: string;
  startSec: number;
  endSec: number;
  startFrame: number;
  endFrame: number;
  words: TimedWord[];
}

export const BEATS = beatsData;
export const SECTIONS: SectionInfo[] = beatsData.sections as SectionInfo[];
export const LYRICS: TimedLyricLine[] = lyricsData as TimedLyricLine[];

export function getSectionAtFrame(frame: number): SectionInfo {
  if (frame <= SECTIONS[0].startFrame) return SECTIONS[0];
  for (let i = 0; i < SECTIONS.length; i++) {
    const s = SECTIONS[i];
    if (frame >= s.startFrame && frame < s.endFrame) {
      return s;
    }
    if (frame < s.startFrame) {
      return SECTIONS[Math.max(0, i - 1)];
    }
  }
  return SECTIONS[SECTIONS.length - 1];
}

export function getSectionById(id: string): SectionInfo {
  const found = SECTIONS.find((s) => s.id === id);
  if (!found) throw new Error(`Unknown section id: ${id}`);
  return found;
}

const SYLLABLE_VISEMES: Viseme[] = ['open', 'E', 'mid', 'O', 'open', 'mid'];

export function getLyricAtFrame(frame: number, fps = 30): {
  line: TimedLyricLine | null;
  word: TimedWord | null;
  viseme: Viseme;
  mouthOpen: number;
} {
  const sec = frame / fps;
  const envIdx = Math.min(
    BEATS.mouthEnvelope.length - 1,
    Math.max(0, Math.floor(frame))
  );
  const envVal = BEATS.mouthEnvelope[envIdx] ?? 0;

  // Natural syllable articulation oscillation (~5.5 syllables/sec)
  const sylWave = 0.5 + 0.5 * Math.sin(frame * 0.72);
  const sylSlot = Math.floor(frame / 4);

  for (const l of LYRICS) {
    if (sec >= l.startSec && sec <= l.endSec) {
      for (const w of l.words) {
        if (sec >= w.startSec && sec <= w.endSec) {
          const wDur = Math.max(0.06, w.endSec - w.startSec);
          const wPhase = (sec - w.startSec) / wDur;
          // Brief consonant closure at very start/end of word so consecutive words clearly articulate
          if (wPhase < 0.08 || wPhase > 0.92) {
            return { line: l, word: w, viseme: 'closed', mouthOpen: 0.08 };
          }
          // Multi-syllable modulation inside longer words
          const pulse = Math.sin(wPhase * Math.PI);
          const open = Math.min(
            1,
            Math.max(0.18, envVal * 0.55 + pulse * 0.35 + sylWave * 0.35)
          );
          const viseme: Viseme =
            open < 0.24
              ? 'closed'
              : wDur > 0.38 && sylSlot % 3 === 1
              ? SYLLABLE_VISEMES[sylSlot % SYLLABLE_VISEMES.length]
              : w.viseme;
          return { line: l, word: w, viseme, mouthOpen: open };
        }
      }
      // Inside a lyric line between words: follow audio envelope
      if (envVal > 0.16) {
        const open = Math.min(0.85, envVal * 0.65 + sylWave * 0.25);
        return {
          line: l,
          word: null,
          viseme: open < 0.22 ? 'closed' : SYLLABLE_VISEMES[sylSlot % SYLLABLE_VISEMES.length],
          mouthOpen: open,
        };
      }
      return { line: l, word: null, viseme: 'closed', mouthOpen: 0.05 };
    }
  }

  // Fallback: if vocal envelope has energy outside nominal line timestamps, still animate mouth!
  if (envVal > 0.22) {
    const open = Math.min(0.85, (envVal - 0.1) * 0.8 + sylWave * 0.25);
    if (open > 0.22) {
      return {
        line: null,
        word: null,
        viseme: SYLLABLE_VISEMES[sylSlot % SYLLABLE_VISEMES.length],
        mouthOpen: open,
      };
    }
  }

  return { line: null, word: null, viseme: 'closed', mouthOpen: 0 };
}
