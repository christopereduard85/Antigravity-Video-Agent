#!/usr/bin/env node
// ============================================================================
// GPU VIDEO RENDERER (scripts/render.mjs)
// Renders the full video to out/video.mp4 using ANGLE GPU hardware WebGL
// acceleration and H.264 encoding. Pass --draft for a fast half-res preview.
// ============================================================================
import { execSync } from 'node:child_process';
import fs from 'node:fs';

const isDraft = process.argv.includes('--draft');
fs.mkdirSync('out', { recursive: true });

const outFile = isDraft ? 'out/draft.mp4' : 'out/video.mp4';
const scaleArg = isDraft ? '--scale=0.5 --CRF=23' : '--CRF=18';
const cmd = `npx remotion render src/index.ts CartoonWorld ${outFile} --gl=angle --codec=h264 ${scaleArg}`;

console.log(`[render] Starting ${isDraft ? 'DRAFT' : 'FINAL GPU'} render...`);
console.log(`[render] Command: ${cmd}`);
execSync(cmd, { stdio: 'inherit' });
console.log(`[render] Finished: ${outFile}`);
