---
name: cartoon-world-video
description: >
  Universal AI skill to create "2D characters in a colourful 3D world" short explainer & storytelling videos (flat bean-head cartoon cards with thick ink outlines, painted 3D town/world with black ink lines, saturated sky, depth-of-field backgrounds, gliding 3D cameras, word-timed captions, voice narration, synthesized SFX + background music) rendered with Three.js inside Remotion. Works identically across Antigravity, Claude Code, Codex, ChatGPT, Cursor, and free/premium AI models.
---

# Cartoon World Video Skill (`2D Characters in a Colourful 3D World`)

You are producing a high-retention animated explainer video in the **"2D bean-head cartoon cards inside a painted ink-outlined 3D world"** style using **Remotion + Three.js**.

To guarantee **identical, studio-grade quality whether run by a free AI model or a flagship AI model**, **NEVER write Three.js shaders, WebGL boilerplate, or Canvas 2D rigging from scratch**. Always copy or work inside the pre-built `template/` directory bundled with this skill and edit **only the 6 declarative files in `src/project/`**:

1. `src/project/config.ts` — Format (`portrait` | `landscape`), resolution (`1080` | `1440` 2K), voice file, music mood & comedic stops.
2. `src/project/script.txt` — The 8-section narration script (`~3.7 words/s`, strictly `< 180 seconds`).
3. `src/project/words.json` & `src/project/words.md` — Auto-generated & hand-fixed word timings + `public/subtitles.srt` via `npm run timings`.
4. `src/project/cast.ts` — Persistent 2D bean-head character designs (outfits, hats, hair, props, proportions).
5. `src/project/world.ts` — Painted 3D sets with ink outlines, saturated skies, atmospheric fog, and timed 3D prop animations (`wobble`, `collapse`, `shake`, `bounce`).
6. `src/project/shots.ts` — Word-locked shot plan (`w0`, `w12`, ...), gliding 3D cameras, multi-beat character performances, particle FX, overlays, and SFX triggers.

---

## Visual & Audio Style Pillars (Non-Negotiable)

- **2D Characters**: Flat white/tinted round heads (`#FFFDF7`), expressive eyes/brows/mouths, colored bean-shaped bodies (`plain`, `stripes`, `uniform`, `suit`, `robe`, `overalls`), curved stick limbs, and bold dark ink outlines (`#1b1622`). Rendered on 512x512 offscreen Canvas 2D and upright-billboarded in 3D space with ground contact shadows.
- **Painted 3D World**: Every 3D building, bridge, tree, prop, and terrain feature has a warm painted surface, an inverted-hull black ink outline, and hard-edge crease lines (`<InkMesh>`).
- **Saturated Sky & Depth**: Gradient painted sky dome with storybook clouds, distance fog haze (`fog: 0.28–0.4`), and foreground / midground / background depth layering in every set.
- **Gliding Cameras**: The camera **never sits still**. Every shot uses a continuous 3D camera glide (`push`, `pull`, `orbit`, `truck`, `crane`, `drop`, `follow`, `top`, `low`, `close`, `tilt`) plus subtle handheld breathing and impact shake on hits.
- **Word-Locked Everything**: Every shot cut, character beat, 3D world animation, particle burst, music stop, and SFX cue is anchored to a word reference (`'w12'`, `'w69'`, `'w84e'`) so changing the voice-over never breaks visual sync.
- **Synthesized Audio**: Background music (`whimsical`, `mystery`, `tense`, `night`, `medieval`, `shanty`) and 17+ cartoon/physics SFX are synthesized purely from code into `public/audio/*.wav` via `npm run audio`, with automatic ducking under the voice-over and dramatic silence stops on the `[snap]` beat.

---

## The 11-Step Production Workflow

Follow these steps **in exact order**. Stop and wait for the user at **Step 1–2** and **Step 3**.

### Step 1: Ask Topic + Offer Reference Ideas
Greet the user briefly and ask what story or topic they want to turn into a video. Always provide **4 ready-made reference hooks** in this exact style so they can pick one or give their own:
1. **The Broughton Suspension Bridge (1831)** — *74 soldiers knocked down an iron bridge just by marching across it in step (mechanical resonance).*
2. **The Great Molasses Flood (Boston, 1919)** — *A 50-foot steel tank burst and sent a 35-mph tsunami of warm pancake syrup through downtown Boston.*
3. **The 1904 Olympic Marathon in St. Louis** — *The winner rode in a car, the second-place runner took rat poison as a stimulant, and fourth place napped under a pear tree.*
4. **Japan's "Banishment Room" (Madogiwa-zoku)** — *When strict labor laws make firing someone impossible, companies promote them to an empty room with zero work until they quit.*

### Step 2: Ask Format & Resolution
In the same prompt (or right after), ask the user to choose:
- **Aspect Ratio (`format`)**:
  - `portrait` (9:16 vertical — Shorts, Reels, TikTok) *(Recommended)*
  - `landscape` (16:9 horizontal — YouTube, desktop)
- **Resolution (`resolution`)**:
  - `1080` (Full HD: `1080x1920` portrait or `1920x1080` landscape) *(Recommended for fast GPU render)*
  - `1440` (2K QHD: `1440x2560` portrait or `2560x1440` landscape)

### Step 3: Write the 8-Beat Script (`~3.7 words/s`, `< 180s`) & Request Voice-Over
Once the user gives the topic and format:
1. Write the narration script following this **mandatory 8-beat structure**:
   - **`[hook]`**: The absurd fact in one punchy sentence (*e.g., "Seventy-four soldiers knocked down an iron bridge just by walking across it."*).
   - **`[setting]`**: Year, place, and what people were proud of (*e.g., "England, eighteen thirty-one. Broughton had just built a shiny new chain bridge, and the whole town was proud of it."*).
   - **`[action]`**: Escalation over 3–4 beats, each a little bigger (*e.g., marching onto the deck -> Left, right, left, right -> planks bounce -> officer whistles so everyone stomps harder*).
   - **`[snap]`**: The exact moment it breaks (*e.g., "Crack! An iron bolt sheared in two, and the entire bridge dropped into the river."*).
   - **`[deadpan]`**: Deadpan double line contrasting `"Luckily ... / Unluckily ..."` (*e.g., "Luckily, the water was only waist-deep. Unluckily, forty soldiers landed in a pile of wet rifles and bruised egos."*).
   - **`[explanation]`**: One clear physics/system idea explained through an everyday analogy (*e.g., "Every bridge has a natural wobble, like a kid on a swing..."*).
   - **`[consequence]`**: The real-world rule or law it created (*e.g., "That very week, the British Army issued a brand-new order: break step on every bridge."*).
   - **`[twist]`**: Callback twist ending (*e.g., "Which means to this day, the world's most disciplined soldiers are required to cross a bridge like lost tourists."*).
2. **Check word count**: Keep the script between **130 and 620 words** (`35s` to `170s` at `~3.7 words/s`, strictly under 180 seconds / 3 minutes). Typical sweet spot is **150–220 words (~45–60 seconds)**.
3. Save the script to `src/project/script.txt` with `[hook]`, `[setting]`, `[action]`, `[snap]`, `[deadpan]`, `[explanation]`, `[consequence]`, `[twist]` headers.
4. Run `npm run timings` immediately to generate initial word timings (`src/project/words.json`, `src/project/words.md`) and `public/subtitles.srt`.
5. Show the clean voice-over script to the user and tell them:
   - *"Generate your Voice-Over from this script (ElevenLabs, OpenAI TTS, or your own recording) and save it as `public/vo.mp3` (or `public/vo.wav`), OR tell me to proceed right now with the built-in preview timing and swap `public/vo.mp3` in later."*

### Step 4: Word Timings & Hand-Fix Alignment
When the user provides `public/vo.mp3` (or `public/vo.wav`), or asks to proceed:
1. Optional (if user wants local Whisper speech-to-text): run `npm run whisper:install` once to install `whisper.cpp` + `ggml-base.en.bin`.
2. Run:
   ```bash
   npm run timings
   ```
3. **Hand-Fix Inspection**: Open `src/project/words.md` and `src/project/words.json`. Verify:
   - Every word `i` has `start < end` and `words[i].end <= words[i+1].start` (zero overlaps).
   - Section transitions (`[snap]`, `[deadpan]`, `[explanation]`, `[twist]`) have a natural `0.3s–0.45s` breath pause before the first word of the new section.
   - If any key punch word (like `"Crack!"`, `"Luckily,"`, `"Unluckily,"`) is slightly early/late against the voice-over waveform, hand-tune its `start`/`end` in `src/project/words.json`.
   - `public/subtitles.srt` is automatically updated with 1–2 word pop captions.

### Step 5: Shot Plan (`src/project/shots.ts`)
Read `src/project/words.md` to get the exact `w<N>` index of every word. Plan the shots in `src/project/shots.ts` following these rules:
- **Cut frequency**: Cut every **2.5 to 6.0 seconds** (typically 10–16 shots for a 50s video). Never let a single shot linger over 7.5 seconds.
- **Word-locked cuts**: Every shot's `from` field MUST be a word reference (`'w0'`, `'w12'`, `'w32'`, `'w69'`, etc.).
- **All 8 story beats**: Across `SHOTS`, the `beat` field must cover all 8 beats: `'hook'`, `'setting'`, `'action'`, `'snap'`, `'deadpan'`, `'explanation'`, `'consequence'`, `'twist'`.
- **Varied camera moves**: Never use the same `cam.move` twice in a row. Alternate between:
  - `'push'` (dolly in toward character/action)
  - `'pull'` (dolly out reveal, great for `[snap]`)
  - `'orbit'` (circle around subject to show 3D parallax)
  - `'truck'` (glide sideways alongside marching/walking characters)
  - `'crane'` / `'drop'` (vertical rise or descent)
  - `'low'` (heroic low angle looking up at architecture/characters)
  - `'close'` (tight emotional reaction shot)
  - `'follow'` (tracks a moving character)

### Step 6: 3D World Sets (`src/project/world.ts`)
Build 3 to 5 distinct sets in `src/project/world.ts` (`SETS`):
- **3-Layer Depth Rule**: Every set MUST have:
  1. **Foreground / Midground interactive stage** (`bridge`, `chainbridge`, `desk`, `road`, `river`, `sign`, `lamp`, `bench`, `barrel`, `crate`).
  2. **Background architecture & nature** (`house`, `shop`, `church`, `building`, `castle`, `tower`, `tree`, `pine`, `bush`, `flowers`, `rock` at `z = -2.5` to `-7.5`).
  3. **Atmosphere**: Saturated `sky` (`'morning'`, `'day'`, `'sunset'`, `'dusk'`, `'night'`, `'indoor'`), painted `ground` (`'grass'`, `'cobble'`, `'water'`, `'wood'`, `'carpet'`, `'tile'`), distance `fog` (`0.25–0.4`), and `backdrop` (`'hills'`, `'mountains'`, `'city'`, `'forest'`).
- **Environment Reactivity & "Show, Don't Just Shake" Physics Rule (`anim` + `fx`)**:
  - **NEVER rely on screen shake + surprised faces alone** when the narration describes a physical event (an explosion, rivets popping, a bridge snapping, liquid spilling, a wave surging). The 3D object itself MUST visibly transform/rupture:
    - Use `k: 'tank'` for industrial tanks/boilers (includes 4 steel bands, 48 visible 3D rivets that pop off during `do: 'shake'`, and 6 hull plates that blast apart during `do: 'explode'`).
    - Use `k: 'puddle'` for liquid spills/leaks (renders an organic 7-lobe glossy pool with surface ripples—never use a flat polygon cylinder for puddles).
    - Use `k: 'wave'` for floods/tsunamis (renders a curling multi-layered wave with foam rollers and airborne droplets).
    - Whenever the hook or snap mentions `"exploded"` / `"collapsed"`, trigger `do: 'explode'` or `'collapse'` on the 3D prop AND pair it with `{ k: 'explosion', pos: '<id>' }` + `{ k: 'splash' | 'debris' | 'rivets', pos: '<id>' }` in `shot.fx`.
  - `do: 'wobble'` or `'sway'` when characters march, jump, or swing.
  - Use `text: '...'` on `'sign'`, `'board'`, or `'shop'` items to add readable humor in the 3D scene.
- **Anti-Occlusion, Grounding & Visual Physics Rules for 3D Props**:
  - Place large backdrop structures (`tank`, `tower`, `building`, `castle`) at `z <= -3.0` with radius `<= 2.8` so their full silhouette and roof fit inside a 9:16 frame without becoming a flat wall.
  - Keep tabletop props (`k: 'bottle'`, `k: 'jar'`, etc.) at tabletop height (`y = 0.56`) to the left/right edges (`|x| >= 0.75`) so the center of the desk (`x = 0`) never blocks a speaking character's face behind the table.
  - Place characters in front of a desk at `z >= 0.65` (when desk is at `z = 0.1`) so their bodies never slice through the tabletop.
  - Keep moving tsunami/hazard meshes (`k: 'wave'`, boulders) behind the fleeing characters (`z <= -0.35`) while characters run in the foreground (`z = 0.6..0.95`) so the mesh never swallows characters whole.
  - **Show What the Narration Describes**:
    - If narration mentions characters being **glued, stuck, or trapped**, place `k: 'glue'` (`{ k: 'glue', at: [x, 0, z], s: 1.15, c: '#5C2E14' }`) at their feet so sticky 3D strands visibly hold them down.
    - If narration mentions **pouring, leaking, or scrubbing**, place `k: 'puddle'` with `do: 'flow'` and matching color (`#38B6FF` for saltwater/water + `fx: 'bubbles'`, `#D92632` for ketchup + `fx: 'pour'`, `#5C2E14` for syrup/mud).

### Step 7: 2D Characters & Active Choreography (`src/project/cast.ts` + `shots.ts`)
1. Define every recurring character in `src/project/cast.ts` with distinct silhouettes (`body` color, `pattern`, `hat`, `hair`, `extras`, `height`, `width`).
2. In `src/project/shots.ts`, choreograph `cast: [...]` for each shot following these **strict animation laws**:
   - **NO PASSIVE CHARACTERS**: Every character in every shot MUST have **at least 2 beats** (`beats: [beat1, beat2, ...]`). Even background listeners must shift between active states (`clap` -> `cheer`, `march` -> `stomp`, `salute` -> `nod`, `sit` -> `facepalm`).
   - **9:16 Portrait Framing Bounds**:
     - Keep all characters within `x` in `[-0.85, 0.85]` (ideally `[-0.65, 0.65]`) so secondary characters are never cropped at the left/right frame borders.
     - For `cam.move` (`'push'`, `'pull'`, `'truck'`, `'pan'`, `'close'`), keep `cam.amount` between `0.15` and `0.5` in 9:16 portrait so camera glides never push secondary characters off-screen.
     - Do not duplicate text in 2D `overlays` (`k: 'label'`) if a 3D `'board'` or `'sign'` in the background already displays the same title.
   - **Environment Height Alignment**:
     - Ground level is `y = 0` (`pos: [x, 0, z]` or `[x, z]`).
     - Elevated `chainbridge` / `bridge` deck is `y = 1.0` (`pos: [x, 1.0, z]`).
     - Waist-deep water in `riverBed` is `y = -0.32` (`pos: [x, -0.32, z]`).
     - Swing seat is `y = 0.55` (`pos: [0, 0.55, 0.1]`).
   - **Props & Emotes**: Give characters props in `hold` (`'sword'`, `'rifle'`, `'drum'`, `'sign'`, `'scroll'`, `'camera'`, `'map'`, `'umbrella'`, `'fish'`, `'cup'`, `'phone'`) and expressive pop-up `emote` symbols (`'!'`, `'?'`, `'!?'`, `'sweat'`, `'sparkle'`, `'music'`, `'anger'`, `'tears'`, `'dizzy'`, `'heart'`).
   - **Lip Sync**: Set `say: true` on the beat of the character who is speaking or narrating on-camera.

### Step 8: Post-Processing, Overlays & Captions (`src/project/shots.ts` + `config.ts`)
- Add punchy `overlays` on key beats (`k: 'label'` for place/year, `k: 'stamp'` for `'SNAP!'`, `'RESONANCE!'`, or official orders).
- Add 3D & screen `fx` on action beats (`'dust'`, `'sparks'`, `'splinters'`, `'splash'`, `'confetti'`, `'bubbles'`, `'stars'`, `'flash'`, `'speedlines'`, `'shake'`).
- Set `transition` between shots (`'cut'`, `'whip'`, `'wipe'`, `'flash'`, `'dissolve'`).

### Step 9: Synthesize SFX & Background Music (`npm run audio`)
- Every shot should include 1–3 timed `sfx` triggers (`'march'`, `'stomp'`, `'thud'`, `'creak'`, `'whoosh'`, `'ding'`, `'pop'`, `'boing'`, `'whistle'`, `'snap'`, `'crash'`, `'explosion'`, `'splash'`, `'bubbles'`, `'sad'`, `'stamp'`, `'clang'`).
- If the user provides custom audio files in `public/sfx-user/myfx.wav`, reference them with `name: 'user:myfx.wav'`.
- In `src/project/config.ts`, set `music.stops: [{ at: 'w<snap>', dur: 1.8 }]` so the background music cuts out right as the disaster hits.
- Run:
  ```bash
  npm run audio
  ```

### Step 10: Multi-Agent Self-Check & Full-Timeline Frame Audit (MANDATORY)
Before finishing, you MUST run both the automated validator and the visual frame audit across the entire video from start to finish:

1. **Run Structural & Liveness Gate**:
   ```bash
   npm run check
   ```
   Fix any TypeScript or liveness errors until `[check] PASSED` prints.

2. **Render Full-Timeline Audit Frames & Contact Sheets**:
   ```bash
   npm run audit
   ```
   This renders **Beat A (24%)** and **Beat B (76%)** of **every single shot from start to finish** into `out/audit/frames/` and stitches contact sheets `out/audit/sheet-1.jpg`, `out/audit/sheet-2.jpg`.

3. **Run Multi-Agent Visual QA Review**:
   - **If your host supports subagents** (e.g. Antigravity `invoke_subagent` or Claude Code `Task` tool), launch **2 parallel QA subagents** (or 1 comprehensive subagent + your own direct inspection) and inspect `out/audit/sheet-1.jpg` and `out/audit/sheet-2.jpg` with `read_file`:
     - **Agent 1 — Animation, Character Liveness & Environment Interaction Reviewer**:
       - Are the animations lively and engaging?
       - Are any characters passive/frozen between Beat A (`_A_`) and Beat B (`_B_`) of the same shot?
       - Are characters interacting accurately with the 3D environment (feet planted on the ground or bridge deck at `y=1.0`, sitting waist-deep in water, pushing the swing, holding props)?
       - Are there any weird limb poses, clipping, or off-screen characters?
     - **Agent 2 — Art Direction, Ink, Colour, Depth & Camera Reviewer**:
       - Are the black ink outlines crisp on both 2D characters and 3D props?
       - Is the colour palette vibrant with clear contrast between characters and background?
       - Is there strong 3D depth (foreground, midground, background, sky dome, distance fog, tilt-shift lens blur)?
       - Does the camera visibly glide between Beat A and Beat B of every shot, with clean framing where captions never cover characters' faces?
   - **If your host is single-agent** (Codex, ChatGPT, Cursor without subagents): Read `out/audit/sheet-1.jpg` and `out/audit/sheet-2.jpg` directly and perform both checklists yourself shot-by-shot.
   - **Fix & Re-Verify**: If any shot has clipping, poor framing, passive poses, or weak camera movement, edit `src/project/shots.ts` or `src/project/world.ts`, then re-run `npm run check && npm run audit` to confirm the fix.

### Step 11: Final Render & User GPU Render Instructions
Once the audit passes, provide the user with:
1. Summary of the completed project (`out/audit/sheet-1.jpg`, `public/subtitles.srt`, shot count, duration).
2. Clear **step-by-step manual GPU render commands** so the user can render at full speed on their own GPU (`NVIDIA / AMD / Apple Silicon`):

```bash
# 1. Enter the project folder
cd template

# 2. (Optional) Drop your generated Voice-Over file into public/vo.mp3, then re-sync timings & audio:
npm run timings
npm run audio

# 3. Preview interactively in Remotion Studio (live 3D scrub):
npm run studio

# 4. Fast draft render (half resolution, ~30-60s):
npm run render:draft

# 5. Final Full-HD / 2K GPU render (uses ANGLE hardware WebGL acceleration):
npx remotion render src/index.ts CartoonWorld out/video.mp4 --gl=angle --codec=h264 --CRF=18 --concurrency=4
```

**GPU Flag Notes for the User**:
- **Windows (NVIDIA / AMD)**: `--gl=angle` uses Direct3D 11 hardware acceleration automatically.
- **macOS (Apple Silicon M1/M2/M3/M4)**: `--gl=angle` uses Metal GPU acceleration automatically.
- **Linux with NVIDIA GPU**: Use `--gl=angle-egl` (or `--gl=angle`).
- **Extra speed**: Increase `--concurrency=4` (or `6` on 8GB+ VRAM GPUs).
