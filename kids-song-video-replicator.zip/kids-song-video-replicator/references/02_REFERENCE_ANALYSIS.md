# 02 — Reference video analysis

Goal: understand style + structure of the reference cheaply (contact sheets, not 4000 frames).

## Commands

```powershell
ffprobe -v error -show_entries stream=width,height,r_frame_rate,nb_frames -show_entries format=duration -of json ReferenceVideo.mp4

# 1) all frames (optional, heavy; gitignore reference_frames/)
mkdir reference_frames; ffmpeg -i ReferenceVideo.mp4 -q:v 3 reference_frames/frame_%05d.jpg
#    frame N  <->  time (N-1)/30 s

# 2) contact sheets: 1 tile = 2 s, 6x5 grid = 60 s per sheet   (READ THESE FIRST)
mkdir analysis/contact
ffmpeg -i ReferenceVideo.mp4 -vf "fps=0.5,scale=320:-1,drawtext=text='%{pts\:hms}':x=4:y=4:fontsize=18:fontcolor=white:box=1:boxcolor=black@0.6,tile=6x5" -q:v 3 analysis/contact/sheet_%02d.jpg

# 3) hard cuts list
ffmpeg -i ReferenceVideo.mp4 -vf "select='gt(scene,0.35)',showinfo" -f null - 2>&1 | Select-String "pts_time" > analysis/ref_cuts_raw.txt
#    keep only pts_time values -> analysis/ref_cuts.txt (most transitions in these videos are wipes, not hard cuts)
```

On Windows drawtext may need `fontfile=C\\:/Windows/Fonts/arial.ttf`. If drawtext fails, drop it.

## What to write in PRODUCTION_PLAN.md

§1 Style DNA (fill like this — real example from the original run):
- Look: flat 2D vector, no outlines, soft rounded shapes, 1 darker inner shade tone only. Noodle limbs, stick legs, mitten/3-finger hands.
- Faces: big white eyes + black pupils + highlight, huge open mouth with teeth row, blush. Blink + syllable lip-sync.
- Palette: maroon theatre curtains `#5A0F22 #7A1530`, wooden stage `#C47A3A #8A4A22`, night purple `#4B1E8C #6A2FC0`, saturated food colours.
- Recurring set: theatre stage, red curtains, scalloped gold valance, spotlight cone; Halloween props.
- Motion: on-beat squash & stretch, 2-pose side-hop dance every beat, arm waves, idle bob, ease-out-back entrances. Camera mostly static, occasional push-in/pan.
- Transitions: spin-tornado costume transform, themed wipes (ketchup stripes, frosting drip, candy stripe), iris/curtain.
- Branding bug corner.

§2 Structure table: one row per section, columns `# | Section | Reference (s) | Reference content | Ours (s / frames) | Our content`. Section id convention used everywhere in code:

```
A intro · B band intro · C1..C4 verse · T1..T4 transform (spin) · K1..K4 chorus · I1 interlude · F1..F3 finale · O outro
```

Map 1:1: same number of blocks as the reference; each verse = one solo hero (lyrics say "I'm"), finale = everyone ("We're all").

## Tips

- Look at one contact sheet per 60 s; describe each tile row in 1 line. That is enough to build §2.
- Note every transition type and on which beat it lands; copy that rhythm.
- Save findings before starting code (handoff).
