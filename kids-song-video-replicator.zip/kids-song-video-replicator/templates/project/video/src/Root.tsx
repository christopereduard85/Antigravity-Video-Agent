import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Composition,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { theme } from './theme';
import { getBeatState } from './rig/beat';
import { Bobo } from './characters/bobo/Bobo';
import { boboTokens } from './characters/bobo/tokens';
import { Lulu } from './characters/lulu/Lulu';
import { luluTokens } from './characters/lulu/tokens';
import { Ziggy } from './characters/ziggy/Ziggy';
import { ziggyTokens } from './characters/ziggy/tokens';
import { Grub } from './characters/grub/Grub';
import { grubTokens } from './characters/grub/tokens';
import {
  BonesDrummer,
  SpinnyBassist,
  BooSax,
} from './characters/band/BandCharacters';
import { makeBeatDancePose } from './rig/poses';
import { evalSpinTransform, TornadoSwirl } from './rig/actions';
import {
  CastleWindowSet,
  TheatreStageSet,
  FoodChorusSet,
  BandChorusCutawaySet,
  MoonlitFoodSkylineSet,
  TrickOrTreatStreetSet,
  MiniFoodDancer,
} from './sets/Sets';
import {
  CurtainWipe,
  DripWipe,
  StripeWipe,
  IrisWipe,
} from './transitions/Wipes';
import { CameraRig, CameraShot, lerp, easeInOutCubic } from './camera/CameraRig';
import { QABobo } from './characters/bobo/QA';
import { QACast } from './characters/QACast';
import { LogoBug } from './ui/LogoBug';
import { SingAlongOverlays } from './ui/SingAlongOverlays';

type HeroId = 1 | 2 | 3 | 4;

const HERO_TOKENS = {
  1: boboTokens,
  2: luluTokens,
  3: ziggyTokens,
  4: grubTokens,
} as const;

/**
 * Straddling Wipe Transitions across Chorus -> Next Section boundaries:
 * - Enters during the last 14 frames of Chorus (progress 0.0 -> 0.5, covering 100% at cutFrame)
 * - Exits during the first 14 frames of Next Section (progress 0.5 -> 1.0, revealing the new scene underneath!)
 */
const CHORUS_CUT_TRANSITIONS: Array<{
  cutFrame: number;
  kind: 'stripe' | 'drip';
  color?: string;
}> = [
  { cutFrame: 789, kind: 'stripe' }, // K1 -> I1
  { cutFrame: 1576, kind: 'drip', color: '#FF9EC4' }, // K2 -> C3
  { cutFrame: 2330, kind: 'drip', color: '#FF6FAE' }, // K3 -> C4
  { cutFrame: 3102, kind: 'stripe' }, // K4 -> F1
];

const StraddlingWipeOverlay: React.FC<{ frame: number }> = ({ frame }) => {
  const halfSpan = 14;
  for (const t of CHORUS_CUT_TRANSITIONS) {
    if (frame >= t.cutFrame - halfSpan && frame <= t.cutFrame + halfSpan) {
      const progress = (frame - (t.cutFrame - halfSpan)) / (halfSpan * 2);
      if (t.kind === 'stripe') {
        return <StripeWipe progress={progress} frame={frame} />;
      }
      return <DripWipe progress={progress} color={t.color} />;
    }
  }
  return null;
};

const RenderHeroById: React.FC<{
  id: HeroId;
  x: number;
  y: number;
  frame: number;
  fps: number;
  mode: 'sing' | 'dance';
  wearCostume: boolean;
  hasMic?: boolean;
  hatTipProgress?: number;
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId: string;
  overridePose?: ReturnType<typeof makeBeatDancePose>;
}> = ({
  id,
  x,
  y,
  frame,
  fps,
  mode,
  wearCostume,
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1.72,
  instanceId,
  overridePose,
}) => {
  const tokens = HERO_TOKENS[id];
  const pose =
    overridePose ?? makeBeatDancePose(tokens, frame, { x, y }, mode, fps);

  if (id === 1) {
    return (
      <Bobo
        pose={pose}
        frame={frame}
        fps={fps}
        costume={wearCostume ? 'burger' : 'none'}
        hasMic={hasMic}
        hatTipProgress={hatTipProgress}
        hasCandyBucket={hasCandyBucket}
        scale={scale}
        instanceId={instanceId}
      />
    );
  }
  if (id === 2) {
    return (
      <Lulu
        pose={pose}
        frame={frame}
        fps={fps}
        costume={wearCostume ? 'icecream' : 'none'}
        hasMic={hasMic}
        hatTipProgress={hatTipProgress}
        hasCandyBucket={hasCandyBucket}
        scale={scale * 0.92}
        instanceId={instanceId}
      />
    );
  }
  if (id === 3) {
    return (
      <Ziggy
        pose={pose}
        frame={frame}
        fps={fps}
        costume={wearCostume ? 'donut' : 'none'}
        hasMic={hasMic}
        hatTipProgress={hatTipProgress}
        hasCandyBucket={hasCandyBucket}
        scale={scale}
        instanceId={instanceId}
      />
    );
  }
  return (
    <Grub
      pose={pose}
      frame={frame}
      fps={fps}
      costume={wearCostume ? 'hotdog' : 'none'}
      hasMic={hasMic}
      hatTipProgress={hatTipProgress}
      hasCandyBucket={hasCandyBucket}
      scale={scale}
      instanceId={instanceId}
    />
  );
};

const SceneBodyAtFrame: React.FC<{
  frame: number;
  fps: number;
}> = ({ frame, fps }) => {
  const beat = getBeatState(frame, fps);
  const sec = beat.section;
  const localFrame = frame - sec.startFrame;
  const secDuration = Math.max(1, sec.endFrame - sec.startFrame);
  const secProgress = localFrame / secDuration;

  // ---------------------------------------------------------------------------
  // 1. Section A: Intro Castle Window with Pip (0..39)
  // ---------------------------------------------------------------------------
  if (sec.id === 'A') {
    const shot: CameraShot = {
      focusX: lerp(960, 840, easeInOutCubic(secProgress)),
      focusY: lerp(510, 440, easeInOutCubic(secProgress)),
      zoom: lerp(1.04, 1.24, easeInOutCubic(secProgress)),
      rotate: lerp(-1.0, 0.8, secProgress),
    };
    return (
      <CameraRig frame={frame} shot={shot}>
        <CastleWindowSet frame={frame} />
      </CameraRig>
    );
  }

  // ---------------------------------------------------------------------------
  // 2. Section B: Curtain Opens, Bobo Enters Stage with Halloween Band (39..63)
  // ---------------------------------------------------------------------------
  if (sec.id === 'B') {
    const walkX = lerp(720, 900, easeInOutCubic(secProgress));
    const shot: CameraShot = {
      focusX: 960,
      focusY: 565,
      zoom: lerp(1.16, 1.05, easeInOutCubic(secProgress)),
    };
    return (
      <>
        <CameraRig frame={frame} shot={shot}>
          <TheatreStageSet
            frame={frame}
            showBand
            showBooWithBand
            spotlights={[900]}
          />
          <RenderHeroById
            id={1}
            x={walkX}
            y={870}
            frame={frame}
            fps={fps}
            mode="sing"
            wearCostume={false}
            hasMic
            hatTipProgress={0}
            scale={1.72}
            instanceId="b-bobo"
          />
        </CameraRig>
        <CurtainWipe openProgress={secProgress} />
      </>
    );
  }

  // ---------------------------------------------------------------------------
  // 3. Verses (C1..C4), Tornado Transforms (T1..T4), & Choruses (K1..K4)
  // ---------------------------------------------------------------------------
  if (
    ['C1', 'T1', 'K1', 'C2', 'T2', 'K2', 'C3', 'T3', 'K3', 'C4', 'T4', 'K4'].includes(
      sec.id
    )
  ) {
    const heroNum = Number(sec.id[1]) as HeroId;
    const isVerse = sec.id.startsWith('C');
    const isTransform = sec.id.startsWith('T');
    const isChorus = sec.id.startsWith('K');

    const foodKind =
      heroNum === 1
        ? 'burger'
        : heroNum === 2
        ? 'icecream'
        : heroNum === 3
        ? 'donut'
        : 'hotdog';

    // --- A) VERSE (C1..C4): Single Lead Hero + Band + Locked Bowler Hat + 4 Calibrated Camera Cuts ---
    if (isVerse) {
      let shot: CameraShot;
      if (secProgress < 0.28) {
        const p = secProgress / 0.28;
        shot = {
          focusX: 960,
          focusY: 565,
          zoom: lerp(1.04, 1.14, easeInOutCubic(p)),
        };
      } else if (secProgress < 0.56) {
        const p = (secProgress - 0.28) / 0.28;
        shot = {
          focusX: 900,
          focusY: 565,
          zoom: lerp(1.28, 1.36, easeInOutCubic(p)),
          rotate: -0.8,
        };
      } else if (secProgress < 0.84) {
        const p = (secProgress - 0.56) / 0.28;
        shot = {
          focusX: lerp(1080, 880, easeInOutCubic(p)),
          focusY: 570,
          zoom: 1.18,
        };
      } else {
        const p = (secProgress - 0.84) / 0.16;
        shot = {
          focusX: 900,
          focusY: 555,
          zoom: lerp(1.34, 1.44, easeInOutCubic(p)),
          rotate: lerp(0, -1.8, p),
          beatPulse: 0.024,
        };
      }

      const hatTip =
        secProgress < 0.36
          ? Math.sin(Math.min(1, secProgress / 0.36) * Math.PI)
          : 0;

      return (
        <CameraRig frame={frame} shot={shot}>
          <TheatreStageSet
            frame={frame}
            showBand
            showBooWithBand
            spotlights={[900]}
          />
          <RenderHeroById
            id={heroNum}
            x={900}
            y={870}
            frame={frame}
            fps={fps}
            mode="sing"
            wearCostume={false}
            hasMic
            hatTipProgress={hatTip}
            scale={1.75}
            instanceId={`v-hero-${sec.id}`}
          />
        </CameraRig>
      );
    }

    // --- B) SPIN TORNADO TRANSFORM (T1..T4): Single Hero Transforms into Their Food Costume! ---
    if (isTransform) {
      const heroT = evalSpinTransform(
        HERO_TOKENS[heroNum],
        frame,
        localFrame,
        secDuration,
        { x: 900, y: 870 }
      );

      const punch = Math.sin(secProgress * Math.PI);
      const shot: CameraShot = {
        focusX: 900,
        focusY: 565,
        zoom: 1.16 + punch * 0.22,
        rotate: Math.sin(secProgress * Math.PI * 2) * 2.2,
        beatPulse: 0.028,
      };

      const swirlColors: readonly [string, string, string] =
        heroNum === 1
          ? ['#9BD43F', '#FFC71F', '#E8382B']
          : heroNum === 2
          ? ['#E7A3E0', '#88E8C2', '#FFF6E5']
          : heroNum === 3
          ? ['#4FB8F0', '#FF6FAE', '#FFE03D']
          : ['#F79A3E', '#FFD21F', '#C9412C'];

      return (
        <CameraRig frame={frame} shot={shot}>
          <TheatreStageSet
            frame={frame}
            showBand
            showBooWithBand
            spotlights={[900]}
          />
          <RenderHeroById
            id={heroNum}
            x={900}
            y={870}
            frame={frame}
            fps={fps}
            mode="dance"
            wearCostume={heroT.useCostume}
            scale={1.75}
            instanceId={`t-hero-${sec.id}`}
            overridePose={heroT.pose}
          />
          <TornadoSwirl
            x={900}
            y={850}
            progress={heroT.tornadoProgress}
            frame={frame}
            colors={swirlColors}
          />
        </CameraRig>
      );
    }

    // --- C) CHORUS (K1..K4): Dedicated to THAT Verse's Costumed Hero + 6 Mini Food Dancers! ---
    if (isChorus) {
      if (secProgress < 0.78) {
        let shot: CameraShot;
        if (secProgress < 0.26) {
          const p = secProgress / 0.26;
          shot = {
            focusX: 960,
            focusY: 565,
            zoom: lerp(1.28, 1.04, easeInOutCubic(p)),
            beatPulse: 0.022,
          };
        } else if (secProgress < 0.52) {
          const p = (secProgress - 0.26) / 0.26;
          shot = {
            focusX: 960,
            focusY: 560,
            zoom: lerp(1.3, 1.38, easeInOutCubic(p)),
            rotate: Math.sin(p * Math.PI * 2) * 1.4,
            beatPulse: 0.024,
          };
        } else {
          const p = (secProgress - 0.52) / 0.26;
          shot = {
            focusX: lerp(780, 1140, easeInOutCubic(p)),
            focusY: 570,
            zoom: 1.2,
            beatPulse: 0.022,
          };
        }

        return (
          <CameraRig frame={frame} shot={shot}>
            <FoodChorusSet food={foodKind} frame={frame} />
            <RenderHeroById
              id={heroNum}
              x={960}
              y={870}
              frame={frame}
              fps={fps}
              mode="dance"
              wearCostume
              scale={1.78}
              instanceId={`k-hero-${sec.id}`}
            />
          </CameraRig>
        );
      }

      // Sub-Scene 4 (78..100% = Bars 7–8): Clean Band Groove Cutaway
      const subP = (secProgress - 0.78) / 0.22;
      const shot: CameraShot = {
        focusX: lerp(900, 1020, easeInOutCubic(subP)),
        focusY: 575,
        zoom: lerp(1.12, 1.22, easeInOutCubic(subP)),
      };

      return (
        <CameraRig frame={frame} shot={shot}>
          <BandChorusCutawaySet food={foodKind} frame={frame} />
        </CameraRig>
      );
    }
  }

  // ---------------------------------------------------------------------------
  // 4. Section I1: Band Interlude Jam (821..868)
  // ---------------------------------------------------------------------------
  if (sec.id === 'I1') {
    const shot: CameraShot = {
      focusX: lerp(820, 1100, easeInOutCubic(secProgress)),
      focusY: 575,
      zoom: lerp(1.14, 1.24, Math.sin(secProgress * Math.PI)),
      rotate: lerp(-1.2, 1.2, secProgress),
      beatPulse: 0.022,
    };
    return (
      <CameraRig frame={frame} shot={shot}>
        <TheatreStageSet
          frame={frame}
          showBand={false}
          spotlights={[450, 960, 1470]}
        />
        <BonesDrummer x={450} y={845} frame={frame} scale={1.55} />
        <BooSax x={960} y={835} frame={frame} scale={1.58} />
        <SpinnyBassist x={1470} y={850} frame={frame} scale={1.55} />
      </CameraRig>
    );
  }

  // ---------------------------------------------------------------------------
  // 5. Section F1: Finale Reunion on Stage + Moonlit Giant Food Platforms (3142..3521)
  // ---------------------------------------------------------------------------
  if (sec.id === 'F1') {
    if (secProgress >= 0.55) {
      const shot: CameraShot = {
        focusX: 960,
        focusY: 540,
        zoom: 1.02,
        floatAmount: 0.35,
      };
      return (
        <CameraRig frame={frame} shot={shot}>
          <MoonlitFoodSkylineSet frame={frame} />
          <RenderHeroById
            id={1}
            x={280}
            y={740}
            frame={frame}
            fps={fps}
            mode="sing"
            wearCostume
            hasMic
            scale={1.42}
            instanceId="f1-sky-b"
          />
          <RenderHeroById
            id={2}
            x={730}
            y={740}
            frame={frame}
            fps={fps}
            mode="dance"
            wearCostume
            scale={1.36}
            instanceId="f1-sky-l"
          />
          <RenderHeroById
            id={3}
            x={1190}
            y={732}
            frame={frame}
            fps={fps}
            mode="dance"
            wearCostume
            scale={1.42}
            instanceId="f1-sky-z"
          />
          <RenderHeroById
            id={4}
            x={1640}
            y={760}
            frame={frame}
            fps={fps}
            mode="dance"
            wearCostume
            scale={1.42}
            instanceId="f1-sky-g"
          />
        </CameraRig>
      );
    }

    const shot: CameraShot =
      secProgress < 0.28
        ? {
            focusX: 960,
            focusY: 565,
            zoom: 1.04,
            beatPulse: 0.018,
          }
        : {
            focusX: lerp(620, 1300, easeInOutCubic((secProgress - 0.28) / 0.27)),
            focusY: 565,
            zoom: 1.22,
            beatPulse: 0.022,
          };

    return (
      <CameraRig frame={frame} shot={shot}>
        <TheatreStageSet
          frame={frame}
          showBand={false}
          spotlights={[340, 750, 1170, 1580]}
        />
        <RenderHeroById
          id={1}
          x={340}
          y={870}
          frame={frame}
          fps={fps}
          mode="sing"
          wearCostume
          hasMic
          scale={1.56}
          instanceId="f1-b"
        />
        <RenderHeroById
          id={2}
          x={750}
          y={870}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          scale={1.48}
          instanceId="f1-l"
        />
        <RenderHeroById
          id={3}
          x={1170}
          y={870}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          scale={1.56}
          instanceId="f1-z"
        />
        <RenderHeroById
          id={4}
          x={1580}
          y={870}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          scale={1.56}
          instanceId="f1-g"
        />
      </CameraRig>
    );
  }

  // ---------------------------------------------------------------------------
  // 6. Section F2: Progressive Split-Screen Color Grid (3521..3710)
  // ---------------------------------------------------------------------------
  if (sec.id === 'F2') {
    const stageCount =
      secProgress < 0.22
        ? 1
        : secProgress < 0.44
        ? 2
        : secProgress < 0.66
        ? 3
        : 4;
    const activeSlot = beat.beatIndex % 4;
    const zoom = (slot: number) => (activeSlot === slot ? 1.24 : 1.14);

    if (stageCount === 1) {
      return (
        <g>
          <rect x={0} y={0} width={1920} height={1080} fill={theme.gridPanels.burgerBg} />
          <MiniFoodDancer kind="burger" x={420} y={760} frame={frame} scale={1.55} phaseOffset={0.1} />
          <MiniFoodDancer kind="burger" x={1500} y={760} frame={frame} scale={1.55} phaseOffset={0.6} />
          <RenderHeroById
            id={1}
            x={960}
            y={810}
            frame={frame}
            fps={fps}
            mode="dance"
            wearCostume
            scale={1.85}
            instanceId="f2-1-b"
          />
        </g>
      );
    }

    return (
      <g>
        <rect x={0} y={0} width={960} height={540} fill={theme.gridPanels.burgerBg} />
        <MiniFoodDancer kind="burger" x={200} y={435} frame={frame} scale={0.95} phaseOffset={0.1} />
        <MiniFoodDancer kind="burger" x={760} y={435} frame={frame} scale={0.95} phaseOffset={0.5} />
        <RenderHeroById
          id={1}
          x={480}
          y={465}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          scale={zoom(0)}
          instanceId="f2-b"
        />

        <rect x={960} y={0} width={960} height={540} fill={theme.gridPanels.iceCreamBg} />
        <MiniFoodDancer kind="icecream" x={1160} y={435} frame={frame} scale={0.95} phaseOffset={0.2} />
        <MiniFoodDancer kind="icecream" x={1720} y={435} frame={frame} scale={0.95} phaseOffset={0.7} />
        <RenderHeroById
          id={2}
          x={1440}
          y={470}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          scale={zoom(1) * 0.92}
          instanceId="f2-l"
        />

        {stageCount === 3 ? (
          <>
            <rect x={0} y={540} width={1920} height={540} fill={theme.gridPanels.donutBg} />
            <MiniFoodDancer kind="donut" x={520} y={975} frame={frame} scale={1.1} phaseOffset={0.3} />
            <MiniFoodDancer kind="donut" x={1400} y={975} frame={frame} scale={1.1} phaseOffset={0.8} />
            <RenderHeroById
              id={3}
              x={960}
              y={1000}
              frame={frame}
              fps={fps}
              mode="dance"
              wearCostume
              scale={1.26}
              instanceId="f2-z3"
            />
          </>
        ) : (
          <>
            <rect x={0} y={540} width={960} height={540} fill={theme.gridPanels.donutBg} />
            <MiniFoodDancer kind="donut" x={200} y={975} frame={frame} scale={0.95} phaseOffset={0.3} />
            <MiniFoodDancer kind="donut" x={760} y={975} frame={frame} scale={0.95} phaseOffset={0.8} />
            <RenderHeroById
              id={3}
              x={480}
              y={1000}
              frame={frame}
              fps={fps}
              mode="dance"
              wearCostume
              scale={zoom(2)}
              instanceId="f2-z"
            />

            <rect x={960} y={540} width={960} height={540} fill={theme.gridPanels.hotDogBg} />
            <MiniFoodDancer kind="hotdog" x={1160} y={975} frame={frame} scale={0.95} phaseOffset={0.4} />
            <MiniFoodDancer kind="hotdog" x={1720} y={975} frame={frame} scale={0.95} phaseOffset={0.9} />
            <RenderHeroById
              id={4}
              x={1440}
              y={1000}
              frame={frame}
              fps={fps}
              mode="dance"
              wearCostume
              scale={zoom(3)}
              instanceId="f2-g"
            />
            <line x1={960} y1={540} x2={960} y2={1080} stroke="#FFFFFF" strokeWidth={12} />
          </>
        )}

        <line x1={960} y1={0} x2={960} y2={540} stroke="#FFFFFF" strokeWidth={12} />
        <line x1={0} y1={540} x2={1920} y2={540} stroke="#FFFFFF" strokeWidth={12} />
      </g>
    );
  }

  // ---------------------------------------------------------------------------
  // 7. Section F3: Trick-or-Treat Street Parade (3710..3900)
  // ---------------------------------------------------------------------------
  if (sec.id === 'F3') {
    const shot: CameraShot =
      secProgress < 0.42
        ? {
            focusX: lerp(720, 1180, easeInOutCubic(secProgress / 0.42)),
            focusY: 565,
            zoom: 1.24,
            beatPulse: 0.02,
          }
        : {
            focusX: 960,
            focusY: 555,
            zoom: lerp(1.18, 1.04, easeInOutCubic((secProgress - 0.42) / 0.58)),
            beatPulse: 0.018,
          };

    return (
      <CameraRig frame={frame} shot={shot}>
        <TrickOrTreatStreetSet frame={frame} />
        <RenderHeroById
          id={1}
          x={330}
          y={875}
          frame={frame}
          fps={fps}
          mode="sing"
          wearCostume
          hasMic
          hasCandyBucket
          scale={1.54}
          instanceId="f3-b"
        />
        <RenderHeroById
          id={2}
          x={745}
          y={875}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          hasCandyBucket
          scale={1.48}
          instanceId="f3-l"
        />
        <RenderHeroById
          id={3}
          x={1175}
          y={875}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          hasCandyBucket
          scale={1.54}
          instanceId="f3-z"
        />
        <RenderHeroById
          id={4}
          x={1590}
          y={875}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          hasCandyBucket
          scale={1.54}
          instanceId="f3-g"
        />
      </CameraRig>
    );
  }

  // ---------------------------------------------------------------------------
  // 8. Section O: Outro — Curtain Close & Boo Saxophone Spotlight Iris Close (3900..3997)
  // BooSax is rendered UNDERNEATH IrisWipe (no burger on face!) so when irisRadius -> 0,
  // the circular spotlight closes completely over Boo!
  // ---------------------------------------------------------------------------
  const curtainOpen = Math.max(0, 1 - secProgress / 0.34);
  const showSaxSolo = secProgress >= 0.36;
  const irisRadius =
    secProgress < 0.74
      ? 340
      : Math.max(0, 340 * (1 - (secProgress - 0.74) / 0.22));

  if (!showSaxSolo) {
    return (
      <g>
        <TrickOrTreatStreetSet frame={frame} />
        <RenderHeroById
          id={1}
          x={960}
          y={875}
          frame={frame}
          fps={fps}
          mode="dance"
          wearCostume
          hasCandyBucket
          scale={1.68}
          instanceId="o-bobo"
        />
        <CurtainWipe openProgress={curtainOpen} />
      </g>
    );
  }

  return (
    <g>
      <TheatreStageSet frame={frame} showBand={false} spotlights={[960]} />
      <CurtainWipe openProgress={0} />
      {/* BooSax rendered UNDERNEATH IrisWipe so the closing circle masks Boo cleanly! */}
      {irisRadius > 1 && <BooSax x={960} y={850} frame={frame} scale={1.75} />}
      <IrisWipe cx={960} cy={630} radius={irisRadius} />
    </g>
  );
};

export const RenderSceneAtFrame: React.FC<{
  frame: number;
  fps?: number;
}> = ({ frame, fps = 30 }) => {
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080">
      <SceneBodyAtFrame frame={frame} fps={fps} />
      <SingAlongOverlays frame={frame} fps={fps} />
      <StraddlingWipeOverlay frame={frame} />
      <LogoBug frame={frame} fps={fps} />
    </svg>
  );
};

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: '#260A17' }}>
      <Audio src={staticFile('HalloweenNight.wav')} />
      <RenderSceneAtFrame frame={frame} fps={fps} />
    </AbsoluteFill>
  );
};

/**
 * 20-Tile Full-Video QA Contact Sheet Composition (5 cols x 4 rows).
 */
const QA_SAMPLE_FRAMES: Array<{ f: number; label: string }> = [
  { f: 18, label: 'A: Window Intro' },
  { f: 45, label: 'B: Curtain Open' },
  { f: 95, label: 'C1: Bobo + Hat Tip' },
  { f: 405, label: 'T1: Bobo Tornado' },
  { f: 490, label: 'K1: Burger Chorus' },
  { f: 782, label: 'K1->I1 Wipe In' },
  { f: 796, label: 'K1->I1 Wipe Out' },
  { f: 960, label: 'C2: Lulu Verse' },
  { f: 1350, label: 'K2: Ice Cream Chorus' },
  { f: 1582, label: 'K2->C3 Drip Reveal' },
  { f: 1720, label: 'C3: Ziggy Verse' },
  { f: 2100, label: 'K3: Donut Chorus' },
  { f: 2450, label: 'C4: Grub Verse' },
  { f: 2900, label: 'K4: Hot Dog Chorus' },
  { f: 3106, label: 'K4->F1 Wipe Reveal' },
  { f: 3200, label: 'F1a: 4-Hero Stage' },
  { f: 3400, label: 'F1b: 4 Food Platforms' },
  { f: 3580, label: 'F2: 4-Color Grid' },
  { f: 3780, label: 'F3: Street Parade' },
  { f: 3955, label: 'O: Boo Sax Clean' },
];

export const QAAllSections: React.FC = () => {
  const cols = 5;
  const tileW = 1920 / cols; // 384
  const tileH = 1080 / 4; // 270
  const scale = tileW / 1920; // 0.2

  return (
    <AbsoluteFill style={{ backgroundColor: '#12061C' }}>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080">
        {QA_SAMPLE_FRAMES.map((item, idx) => {
          const c = idx % cols;
          const r = Math.floor(idx / cols);
          const tx = c * tileW;
          const ty = r * tileH;
          const clipId = `qa-tile-clip-${idx}`;
          return (
            <g key={idx} transform={`translate(${tx}, ${ty})`}>
              <defs>
                <clipPath id={clipId}>
                  <rect x={0} y={0} width={tileW} height={tileH} />
                </clipPath>
              </defs>
              <g clipPath={`url(#${clipId})`}>
                <g transform={`scale(${scale})`}>
                  <RenderSceneAtFrame frame={item.f} fps={30} />
                </g>
              </g>
              <rect
                x={0}
                y={0}
                width={tileW}
                height={tileH}
                fill="none"
                stroke="#FFFFFF"
                strokeWidth={2}
                opacity={0.35}
              />
              <rect
                x={6}
                y={tileH - 28}
                width={175}
                height={22}
                rx={4}
                fill="rgba(0,0,0,0.72)"
              />
              <text
                x={12}
                y={tileH - 12}
                fill="#FFE03D"
                fontSize={12}
                fontFamily="Arial, sans-serif"
                fontWeight="bold"
              >
                {`f${item.f} ${item.label}`}
              </text>
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="Main"
        component={MainVideo}
        durationInFrames={theme.durationInFrames}
        fps={theme.fps}
        width={theme.width}
        height={theme.height}
      />
      <Composition
        id="QA-AllSections"
        component={QAAllSections}
        durationInFrames={30}
        fps={theme.fps}
        width={theme.width}
        height={theme.height}
      />
      <Composition
        id="QA-Bobo"
        component={QABobo}
        durationInFrames={360}
        fps={theme.fps}
        width={theme.width}
        height={theme.height}
      />
      <Composition
        id="QA-Cast"
        component={QACast}
        durationInFrames={180}
        fps={theme.fps}
        width={theme.width}
        height={theme.height}
      />
    </>
  );
};
