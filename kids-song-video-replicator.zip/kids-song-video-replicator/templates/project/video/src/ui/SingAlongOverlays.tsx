import React from 'react';
import { getBeatState } from '../rig/beat';
import { getLyricAtFrame, LYRICS } from '../timeline';
import { clamp } from '../rig/geom';

export type StickerIconKind =
  | 'bobo'
  | 'lulu'
  | 'ziggy'
  | 'grub'
  | 'burger'
  | 'icecream'
  | 'donut'
  | 'hotdog'
  | 'pumpkin'
  | 'bat'
  | 'ghost'
  | 'question'
  | 'heart'
  | 'star';

/**
 * Illustrated Die-Cut Character & Theme Sticker (SVG).
 * No text boxes! Pure cute die-cut vector character faces, food costumes, and Halloween icons
 * with a thick white sticker border + drop shadow + spring pop-in animation.
 */
export const DieCutCharacterSticker: React.FC<{
  kind: StickerIconKind;
  x: number;
  y: number;
  scale?: number;
  rotate?: number;
  frame: number;
}> = ({ kind, x, y, scale = 1, rotate = 0, frame }) => {
  if (scale <= 0.02) return null;

  const renderArtwork = () => {
    switch (kind) {
      case 'bobo':
        return (
          <g>
            {/* White Die-Cut Sticker Backing */}
            <circle cx={0} cy={6} r={54} fill="#FFFFFF" />
            <circle cx={-22} cy={-48} r={14} fill="#FFFFFF" />
            <circle cx={22} cy={-48} r={14} fill="#FFFFFF" />
            <path
              d="M -14 -34 L -22 -48 M 14 -34 L 22 -48"
              stroke="#FFFFFF"
              strokeWidth={18}
              strokeLinecap="round"
            />
            {/* Antennae */}
            <path
              d="M -14 -34 L -22 -48 M 14 -34 L 22 -48"
              stroke="#6CA824"
              strokeWidth={6}
              strokeLinecap="round"
            />
            <circle cx={-22} cy={-48} r={7} fill="#9BD43F" stroke="#538518" strokeWidth={3} />
            <circle cx={22} cy={-48} r={7} fill="#9BD43F" stroke="#538518" strokeWidth={3} />
            {/* Pear Green Head */}
            <circle cx={0} cy={6} r={44} fill="#9BD43F" stroke="#538518" strokeWidth={4} />
            {/* Eyes */}
            <circle cx={-14} cy={0} r={11} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={14} cy={0} r={11} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={-12} cy={0} r={6} fill="#1E0E2F" />
            <circle cx={16} cy={0} r={6} fill="#1E0E2F" />
            <circle cx={-15} cy={-3} r={2.5} fill="#FFFFFF" />
            <circle cx={13} cy={-3} r={2.5} fill="#FFFFFF" />
            {/* Cheeks & Big Happy Smile */}
            <ellipse cx={-26} cy={12} rx={7} ry={4} fill="#FF85A2" opacity={0.8} />
            <ellipse cx={26} cy={12} rx={7} ry={4} fill="#FF85A2" opacity={0.8} />
            <path d="M -16 14 Q 0 32 16 14 Z" fill="#7A1C3A" stroke="#1E0E2F" strokeWidth={3} />
            <path d="M -10 21 Q 0 28 10 21" fill="#FF7096" />
          </g>
        );

      case 'lulu':
        return (
          <g>
            {/* White Die-Cut Backing */}
            <ellipse cx={0} cy={4} rx={48} ry={54} fill="#FFFFFF" />
            <circle cx={-34} cy={-26} r={16} fill="#FFFFFF" />
            <circle cx={34} cy={-26} r={16} fill="#FFFFFF" />
            {/* Cute Ears/Puffs */}
            <circle cx={-32} cy={-24} r={10} fill="#C970B8" />
            <circle cx={32} cy={-24} r={10} fill="#C970B8" />
            {/* Lavender Oval Head */}
            <ellipse cx={0} cy={4} rx={38} ry={44} fill="#E7A3E0" stroke="#A65499" strokeWidth={4} />
            {/* Eyes with Eyelashes */}
            <circle cx={-13} cy={-2} r={10} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={13} cy={-2} r={10} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={-13} cy={-2} r={5.5} fill="#1E0E2F" />
            <circle cx={13} cy={-2} r={5.5} fill="#1E0E2F" />
            <circle cx={-15} cy={-5} r={2.2} fill="#FFFFFF" />
            <circle cx={11} cy={-5} r={2.2} fill="#FFFFFF" />
            {/* Cheeks & Smile */}
            <ellipse cx={-23} cy={10} rx={6.5} ry={3.8} fill="#FF6FAE" opacity={0.85} />
            <ellipse cx={23} cy={10} rx={6.5} ry={3.8} fill="#FF6FAE" opacity={0.85} />
            <path d="M -14 14 Q 0 29 14 14 Z" fill="#7A1C3A" stroke="#1E0E2F" strokeWidth={3} />
          </g>
        );

      case 'ziggy':
        return (
          <g>
            {/* White Die-Cut Backing */}
            <circle cx={0} cy={4} r={54} fill="#FFFFFF" />
            <polygon points="-32,-32 -20,-54 -8,-36" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={10} strokeLinejoin="round" />
            <polygon points="32,-32 20,-54 8,-36" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={10} strokeLinejoin="round" />
            {/* Horns */}
            <polygon points="-30,-30 -20,-50 -10,-34" fill="#D9D2E9" stroke="#2B7EB3" strokeWidth={3} />
            <polygon points="30,-30 20,-50 10,-34" fill="#D9D2E9" stroke="#2B7EB3" strokeWidth={3} />
            {/* Blue Monster Head */}
            <circle cx={0} cy={4} r={44} fill="#4FB8F0" stroke="#2376A8" strokeWidth={4} />
            {/* 3 Iconic Eyes */}
            <circle cx={-19} cy={-2} r={9} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={2.8} />
            <circle cx={0} cy={-6} r={9.5} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={2.8} />
            <circle cx={19} cy={-2} r={9} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={2.8} />
            <circle cx={-19} cy={-2} r={4.8} fill="#1E0E2F" />
            <circle cx={0} cy={-6} r={5} fill="#1E0E2F" />
            <circle cx={19} cy={-2} r={4.8} fill="#1E0E2F" />
            <circle cx={-21} cy={-4} r={2} fill="#FFFFFF" />
            <circle cx={-2} cy={-8} r={2} fill="#FFFFFF" />
            <circle cx={17} cy={-4} r={2} fill="#FFFFFF" />
            {/* Smile */}
            <path d="M -16 14 Q 0 31 16 14 Z" fill="#7A1C3A" stroke="#1E0E2F" strokeWidth={3} />
          </g>
        );

      case 'grub':
        return (
          <g>
            {/* White Die-Cut Backing */}
            <ellipse cx={0} cy={8} rx={56} ry={46} fill="#FFFFFF" />
            <polygon points="-24,-28 -14,-54 -4,-28" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={10} strokeLinejoin="round" />
            <polygon points="24,-28 14,-54 4,-28" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={10} strokeLinejoin="round" />
            {/* Striped Horns */}
            <polygon points="-22,-26 -14,-50 -6,-26" fill="#E6E0F8" stroke="#B85D14" strokeWidth={3} />
            <polygon points="22,-26 14,-50 6,-26" fill="#E6E0F8" stroke="#B85D14" strokeWidth={3} />
            {/* Orange Dome Head */}
            <ellipse cx={0} cy={8} rx={46} ry={36} fill="#F79A3E" stroke="#C46316" strokeWidth={4} />
            {/* Eyes */}
            <circle cx={-15} cy={2} r={10} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={15} cy={2} r={10} fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
            <circle cx={-15} cy={2} r={5.5} fill="#1E0E2F" />
            <circle cx={15} cy={2} r={5.5} fill="#1E0E2F" />
            <circle cx={-17} cy={-1} r={2.2} fill="#FFFFFF" />
            <circle cx={13} cy={-1} r={2.2} fill="#FFFFFF" />
            {/* Smile */}
            <path d="M -16 16 Q 0 32 16 16 Z" fill="#FFFFFF" stroke="#1E0E2F" strokeWidth={3} />
          </g>
        );

      case 'burger':
        return (
          <g>
            {/* White Die-Cut Sticker Border */}
            <rect x={-58} y={-48} width={116} height={96} rx={44} fill="#FFFFFF" />
            {/* Bottom Bun */}
            <path d="M -44 18 Q 0 42 44 18 L 40 32 Q 0 44 -40 32 Z" fill="#E59235" stroke="#8C4A08" strokeWidth={3.5} />
            {/* Patty */}
            <rect x={-48} y={2} width={96} height={18} rx={9} fill="#5C2C16" stroke="#3A1808" strokeWidth={3.5} />
            {/* Melted Cheese */}
            <polygon points="-46,4 -20,4 -10,16 4,4 22,16 36,4 46,4 46,0 -46,0" fill="#FFD21F" stroke="#C88A00" strokeWidth={2.5} />
            {/* Lettuce Ruffle */}
            <path d="M -48 -4 Q -32 -12 -16 -3 Q 0 -12 16 -3 Q 32 -12 48 -4" fill="none" stroke="#68C938" strokeWidth={9} strokeLinecap="round" />
            {/* Top Sesame Bun */}
            <path d="M -46 -6 C -46 -42 46 -42 46 -6 Z" fill="#F29F3D" stroke="#8C4A08" strokeWidth={3.5} />
            {/* Sesame Seeds */}
            <ellipse cx={-16} cy={-24} rx={4.5} ry={2.5} fill="#FFF5D6" />
            <ellipse cx={0} cy={-28} rx={4.5} ry={2.5} fill="#FFF5D6" />
            <ellipse cx={16} cy={-23} rx={4.5} ry={2.5} fill="#FFF5D6" />
          </g>
        );

      case 'icecream':
        return (
          <g>
            {/* White Die-Cut Sticker Border */}
            <circle cx={0} cy={-16} r={46} fill="#FFFFFF" />
            <polygon points="-38,-6 38,-6 0,58" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={14} strokeLinejoin="round" />
            <circle cx={0} cy={-48} r={18} fill="#FFFFFF" />
            {/* Waffle Cone */}
            <polygon points="-30,-4 30,-4 0,50" fill="#E6A145" stroke="#9C5E14" strokeWidth={3.5} strokeLinejoin="round" />
            <line x1={-18} y1={4} x2={12} y2={32} stroke="#B87324" strokeWidth={2.5} />
            <line x1={18} y1={4} x2={-12} y2={32} stroke="#B87324" strokeWidth={2.5} />
            {/* Vanilla/Strawberry Scoop */}
            <path d="M -36 -4 C -38 -42 38 -42 36 -4 Q 20 6 0 -2 Q -20 6 -36 -4 Z" fill="#FFF3E0" stroke="#C87A98" strokeWidth={3.5} />
            {/* Sprinkles & Cherry */}
            <rect x={-16} cy={-22} width={8} height={3.5} rx={1.5} fill="#FF5A8A" transform="rotate(-20 -12 -22)" />
            <rect x={8} cy={-20} width={8} height={3.5} rx={1.5} fill="#39C2F7" transform="rotate(25 12 -20)" />
            <circle cx={0} cy={-44} r={10} fill="#E82042" stroke="#7A0C1E" strokeWidth={3} />
          </g>
        );

      case 'donut':
        return (
          <g>
            {/* White Die-Cut Sticker Border */}
            <circle cx={0} cy={0} r={56} fill="#FFFFFF" />
            {/* Golden Dough Torus */}
            <circle cx={0} cy={0} r={45} fill="#F2AA52" stroke="#9E5B16" strokeWidth={4} />
            {/* Pink Icing */}
            <circle cx={0} cy={0} r={38} fill="#FF6FAE" />
            {/* Donut Hole */}
            <circle cx={0} cy={0} r={15} fill="#FFFFFF" stroke="#9E5B16" strokeWidth={3.5} />
            {/* Rainbow Sprinkles */}
            <rect x={-26} y={-24} width={10} height={4} rx={2} fill="#FFE03D" transform="rotate(-30 -21 -22)" />
            <rect x={16} y={-24} width={10} height={4} rx={2} fill="#5CE1E6" transform="rotate(28 21 -22)" />
            <rect x={-28} y={16} width={10} height={4} rx={2} fill="#7ED957" transform="rotate(20 -23 18)" />
            <rect x={16} y={18} width={10} height={4} rx={2} fill="#FFFFFF" transform="rotate(-25 21 20)" />
          </g>
        );

      case 'hotdog':
        return (
          <g>
            {/* White Die-Cut Sticker Border */}
            <rect x={-64} y={-36} width={128} height={72} rx={36} fill="#FFFFFF" />
            {/* Top Bun */}
            <rect x={-48} y={-24} width={96} height={30} rx={15} fill="#EAA044" stroke="#8C4A08" strokeWidth={3.5} />
            {/* Red Sausage */}
            <rect x={-56} y={-10} width={112} height={24} rx={12} fill="#C93824" stroke="#70180C" strokeWidth={3.5} />
            {/* Wavy Mustard */}
            <path
              d="M -44 2 Q -30 -8 -16 2 T 12 2 T 40 2"
              fill="none"
              stroke="#FFE03D"
              strokeWidth={6}
              strokeLinecap="round"
            />
            {/* Bottom Bun */}
            <rect x={-46} y={8} width={92} height={20} rx={10} fill="#F2B05E" stroke="#8C4A08" strokeWidth={3.5} />
          </g>
        );

      case 'pumpkin':
        return (
          <g>
            <ellipse cx={0} cy={4} rx={52} ry={46} fill="#FFFFFF" />
            <rect x={-6} y={-44} width={12} height={18} rx={4} fill="#4E9A26" stroke="#26540E" strokeWidth={3} />
            <ellipse cx={0} cy={6} rx={42} ry={34} fill="#FF851B" stroke="#9E4100" strokeWidth={4} />
            <polygon points="-20,-2 -10,-14 -4,-2" fill="#FFE03D" stroke="#4A1800" strokeWidth={2.5} />
            <polygon points="20,-2 10,-14 4,-2" fill="#FFE03D" stroke="#4A1800" strokeWidth={2.5} />
            <path d="M -22 12 Q 0 28 22 12 L 14 20 L 0 15 L -14 20 Z" fill="#FFE03D" stroke="#4A1800" strokeWidth={2.5} />
          </g>
        );

      case 'bat':
        return (
          <g>
            <ellipse cx={0} cy={0} rx={62} ry={38} fill="#FFFFFF" />
            <path d="M -52 0 Q -32 -26 -14 -6 L 0 -22 L 14 -6 Q 32 -26 52 0 Q 32 10 18 18 L 0 12 L -18 18 Q -32 10 -52 0 Z" fill="#7E48B8" stroke="#36145C" strokeWidth={3.5} />
            <circle cx={-8} cy={-2} r={5} fill="#FFE03D" />
            <circle cx={8} cy={-2} r={5} fill="#FFE03D" />
          </g>
        );

      case 'ghost':
        return (
          <g>
            <path d="M -42 36 L -42 -10 C -42 -48 42 -48 42 -10 L 42 36 Q 28 24 14 36 Q 0 24 -14 36 Q -28 24 -42 36 Z" fill="#FFFFFF" stroke="#8C7AA8" strokeWidth={8} strokeLinejoin="round" />
            <path d="M -36 32 L -36 -8 C -36 -40 36 -40 36 -8 L 36 32 Q 24 22 12 32 Q 0 22 -12 32 Q -24 22 -36 32 Z" fill="#F8F6FF" stroke="#3B235E" strokeWidth={3.5} />
            <circle cx={-11} cy={-6} r={5.5} fill="#230A38" />
            <circle cx={11} cy={-6} r={5.5} fill="#230A38" />
            <ellipse cx={0} cy={8} rx={7} ry={9} fill="#FF6FAE" />
          </g>
        );

      case 'question':
        return (
          <g>
            <circle cx={0} cy={0} r={48} fill="#FFFFFF" />
            <circle cx={0} cy={0} r={39} fill="#8E24AA" stroke="#38084D" strokeWidth={4} />
            <text
              x={0}
              y={18}
              textAnchor="middle"
              fontFamily="'Arial Black', sans-serif"
              fontWeight={900}
              fontSize={54}
              fill="#FFE03D"
              stroke="#230A38"
              strokeWidth={5}
              paintOrder="stroke"
            >
              ?
            </text>
          </g>
        );

      case 'heart':
        return (
          <g>
            <circle cx={0} cy={0} r={46} fill="#FFFFFF" />
            <path
              d="M 0 28 C -38 4 -40 -26 -18 -30 C -6 -32 0 -20 0 -16 C 0 -20 6 -32 18 -30 C 40 -26 38 4 0 28 Z"
              fill="#FF4081"
              stroke="#7A0B32"
              strokeWidth={4}
            />
          </g>
        );

      case 'star':
      default:
        return (
          <g>
            <circle cx={0} cy={0} r={48} fill="#FFFFFF" />
            <polygon
              points="0,-38 11,-12 39,-9 18,10 24,37 0,23 -24,37 -18,10 -39,-9 -11,-12"
              fill="#FFE03D"
              stroke="#8C5400"
              strokeWidth={4}
              strokeLinejoin="round"
            />
            <circle cx={-9} cy={-2} r={4} fill="#230A38" />
            <circle cx={9} cy={-2} r={4} fill="#230A38" />
            <path d="M -8 8 Q 0 15 8 8" fill="none" stroke="#230A38" strokeWidth={3} strokeLinecap="round" />
          </g>
        );
    }
  };

  const bobY = Math.sin(frame * 0.14 + x * 0.01) * 6;

  return (
    <g
      transform={`translate(${x.toFixed(1)}, ${(y + bobY).toFixed(
        1
      )}) rotate(${rotate.toFixed(2)}) scale(${scale.toFixed(3)})`}
    >
      {/* Soft Sticker Cast Shadow */}
      <circle cx={4} cy={10} r={52} fill="rgba(14, 4, 24, 0.34)" />
      {renderArtwork()}
    </g>
  );
};

/**
 * Floating Musical Note / Sparkle Sticker (SVG) for upper safe corners.
 */
const FloatingNoteSticker: React.FC<{
  x: number;
  y: number;
  symbol: string;
  color: string;
  frame: number;
  phaseOffset?: number;
}> = ({ x, y, symbol, color, frame, phaseOffset = 0 }) => {
  const bob = Math.sin(frame * 0.14 + phaseOffset) * 10;
  const tilt = Math.cos(frame * 0.11 + phaseOffset) * 12;
  return (
    <g
      transform={`translate(${x.toFixed(1)}, ${(y + bob).toFixed(
        1
      )}) rotate(${tilt.toFixed(1)})`}
    >
      <text
        x={0}
        y={0}
        textAnchor="middle"
        fontFamily="'Arial Black', sans-serif"
        fontWeight={900}
        fontSize={42}
        fill={color}
        stroke="#FFFFFF"
        strokeWidth={8}
        paintOrder="stroke"
      >
        {symbol}
      </text>
    </g>
  );
};

/**
 * Bottom Karaoke Sing-Along Lyric Bar (SVG).
 * Sits in the bottom safe zone (y = 995..1065), below all characters' feet (y <= 890),
 * and highlights + bounces each word in real time as it is sung!
 */
export const KaraokeLyricBar: React.FC<{
  frame: number;
  fps?: number;
}> = ({ frame, fps = 30 }) => {
  const sec = frame / fps;
  // Karaoke lead-in: show line 0.4s BEFORE first word so viewer reads it in time; word highlight stays exact.
  const PRE = 0.4;
  const POST = 0.15;
  const line =
    LYRICS.find((l) => sec >= l.startSec - PRE && sec <= l.endSec + POST) ?? null;
  if (!line) return null;

  const enterP = clamp((sec - (line.startSec - PRE)) / 0.12, 0, 1);
  const exitP = clamp((line.endSec + POST - sec) / 0.12, 0, 1);
  const vis = Math.min(enterP, exitP);
  if (vis <= 0.02) return null;

  const words = line.words;
  const charWidth = 22;
  const wordGap = 22;
  const wordWidths = words.map((w) => Math.max(48, w.w.length * charWidth));
  const totalTextW =
    wordWidths.reduce((acc, w) => acc + w, 0) +
    Math.max(0, words.length - 1) * wordGap;

  const pillW = Math.min(1560, Math.max(520, totalTextW + 110));
  const pillH = 72;
  const centerY = 1022 + (1 - vis) * 40;

  let cursorX = 960 - totalTextW * 0.5;

  return (
    <g opacity={vis.toFixed(3)}>
      {/* Karaoke Pill Backdrop in Bottom Apron Safe Zone */}
      <rect
        x={960 - pillW * 0.5 + 4}
        y={centerY - pillH * 0.5 + 5}
        width={pillW}
        height={pillH}
        rx={36}
        fill="rgba(12, 4, 22, 0.55)"
      />
      <rect
        x={960 - pillW * 0.5}
        y={centerY - pillH * 0.5}
        width={pillW}
        height={pillH}
        rx={36}
        fill="rgba(36, 12, 58, 0.88)"
        stroke="#FFFFFF"
        strokeWidth={4.5}
      />

      {/* Individual Timed Words with Active Karaoke Bounce & Highlight */}
      {words.map((w, idx) => {
        const ww = wordWidths[idx];
        const wx = cursorX + ww * 0.5;
        cursorX += ww + wordGap;

        const isActive = sec >= w.startSec && sec <= w.endSec;
        const isPast = sec > w.endSec;
        const wDur = Math.max(0.08, w.endSec - w.startSec);
        const wPhase = isActive ? clamp((sec - w.startSec) / wDur, 0, 1) : 0;
        const bounceY = isActive ? -Math.sin(wPhase * Math.PI) * 15 - 4 : 0;
        const scale = isActive ? 1 + Math.sin(wPhase * Math.PI) * 0.18 : 1;

        const fillCol = isActive
          ? '#FFE03D'
          : isPast
          ? '#FFF3B0'
          : '#FFFFFF';

        return (
          <g
            key={idx}
            transform={`translate(${wx.toFixed(1)}, ${(
              centerY +
              11 +
              bounceY
            ).toFixed(1)}) scale(${scale.toFixed(3)})`}
          >
            {/* Bouncing Pink/Gold Beat Ball above active word */}
            {isActive && (
              <circle
                cx={0}
                cy={-38}
                r={7.5}
                fill="#FF6FAE"
                stroke="#FFFFFF"
                strokeWidth={2.5}
              />
            )}
            <text
              x={0}
              y={0}
              textAnchor="middle"
              fontFamily="'Arial Black', 'Fredoka', sans-serif"
              fontWeight={900}
              fontSize={34}
              fill={fillCol}
              stroke="#1E0836"
              strokeWidth={7}
              paintOrder="stroke"
              letterSpacing={0.6}
            >
              {w.w}
            </text>
          </g>
        );
      })}
    </g>
  );
};

/**
 * Context-Aware Illustrated Character & Costume Sticker Overlay Layer.
 * Pops in cute die-cut character portrait stickers, food costume stickers, and Halloween stickers
 * strictly at matching musical/lyric moments in safe side/upper margins!
 */
export const SingAlongOverlays: React.FC<{
  frame: number;
  fps?: number;
}> = ({ frame, fps = 30 }) => {
  const beat = getBeatState(frame, fps);
  const sec = beat.section;
  const localFrame = frame - sec.startFrame;
  const secDuration = Math.max(1, sec.endFrame - sec.startFrame);
  const secProgress = localFrame / secDuration;

  const beatPop = 1 + Math.max(0, -beat.hop) * 0.1;
  const swayTilt = beat.sway * 7;

  const renderSectionStickers = () => {
    // 1. Intro A & B: Cute Pumpkin & Bat Die-Cut Stickers in Upper Corners
    if (sec.id === 'A' || sec.id === 'B') {
      const pop = clamp(frame / 10, 0, 1);
      return (
        <>
          <DieCutCharacterSticker
            kind="pumpkin"
            x={160}
            y={120}
            scale={pop * beatPop * 0.95}
            rotate={-8 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind="bat"
            x={1760}
            y={120}
            scale={pop * beatPop * 0.95}
            rotate={8 - swayTilt}
            frame={frame}
          />
          <FloatingNoteSticker x={265} y={135} symbol="♪" color="#FFE03D" frame={frame} phaseOffset={0} />
          <FloatingNoteSticker x={1655} y={135} symbol="♫" color="#FF6FAE" frame={frame} phaseOffset={2} />
        </>
      );
    }

    // 2. Verses C1..C4: Character Face Sticker + Timed Mystery Question (?) -> Food Reveal Sticker!
    if (sec.id.startsWith('C')) {
      const heroNum = Number(sec.id[1]);
      const charKind: StickerIconKind =
        heroNum === 1 ? 'bobo' : heroNum === 2 ? 'lulu' : heroNum === 3 ? 'ziggy' : 'grub';
      const foodKind: StickerIconKind =
        heroNum === 1 ? 'burger' : heroNum === 2 ? 'icecream' : heroNum === 3 ? 'donut' : 'hotdog';

      const enterPop = clamp(localFrame / 8, 0, 1);
      // Right sticker pops in on Line 2 ("favorite bite" -> question mark) and flips to the Food Sticker on Line 4 ("juicy burger / ice cream / donut / hot dog")!
      const showMystery = secProgress >= 0.23 && secProgress < 0.72;
      const showFoodReveal = secProgress >= 0.72;
      const rightPop = showFoodReveal
        ? clamp((secProgress - 0.72) / 0.05, 0, 1) * 1.12
        : showMystery
        ? clamp((secProgress - 0.23) / 0.05, 0, 1)
        : 0;

      return (
        <>
          {/* Upper-Left Die-Cut Character Face Sticker */}
          <DieCutCharacterSticker
            kind={charKind}
            x={155}
            y={130}
            scale={enterPop * beatPop * 1.05}
            rotate={-7 + swayTilt}
            frame={frame}
          />
          {/* Upper-Right Timed Sticker: Mystery '?' then Food Costume Sticker when sung! */}
          {rightPop > 0.02 && (
            <DieCutCharacterSticker
              kind={showFoodReveal ? foodKind : 'question'}
              x={1765}
              y={130}
              scale={rightPop * beatPop * 1.05}
              rotate={7 - swayTilt}
              frame={frame}
            />
          )}
          <FloatingNoteSticker x={255} y={115} symbol="♪" color="#FFE03D" frame={frame} phaseOffset={1} />
        </>
      );
    }

    // 3. Tornado Transforms T1..T4: Starburst + Food Sticker Pop-In
    if (sec.id.startsWith('T')) {
      const heroNum = Number(sec.id[1]);
      const foodKind: StickerIconKind =
        heroNum === 1 ? 'burger' : heroNum === 2 ? 'icecream' : heroNum === 3 ? 'donut' : 'hotdog';
      const pop = Math.sin(secProgress * Math.PI);
      return (
        <>
          <DieCutCharacterSticker
            kind="star"
            x={165}
            y={135}
            scale={(0.8 + pop * 0.35) * beatPop}
            rotate={-10 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind={foodKind}
            x={1755}
            y={135}
            scale={(0.8 + pop * 0.35) * beatPop}
            rotate={10 - swayTilt}
            frame={frame}
          />
        </>
      );
    }

    // 4. Choruses K1..K4: Character Portrait Sticker + Food Sticker + Heart/Star on "yum yum yum / sweet / round / neat"
    if (sec.id.startsWith('K')) {
      const heroNum = Number(sec.id[1]);
      const charKind: StickerIconKind =
        heroNum === 1 ? 'bobo' : heroNum === 2 ? 'lulu' : heroNum === 3 ? 'ziggy' : 'grub';
      const foodKind: StickerIconKind =
        heroNum === 1 ? 'burger' : heroNum === 2 ? 'icecream' : heroNum === 3 ? 'donut' : 'hotdog';

      // Pop a cute Heart sticker on the second half of each 2-bar chorus chant ("yum yum yum!", "cold and sweet!", etc.)
      const barPhase = (beat.barIndex % 2) + beat.barPhase;
      const showHeart = barPhase >= 0.85 && secProgress < 0.76;

      return (
        <>
          {/* Left Margin: Character Face Die-Cut Sticker */}
          <DieCutCharacterSticker
            kind={charKind}
            x={150}
            y={135}
            scale={beatPop * 1.05}
            rotate={-6 + swayTilt}
            frame={frame}
          />
          {/* Right Margin: Food Costume Die-Cut Sticker */}
          <DieCutCharacterSticker
            kind={foodKind}
            x={1770}
            y={135}
            scale={beatPop * 1.08}
            rotate={6 - swayTilt}
            frame={frame}
          />
          {/* Timed Heart Sticker popping when they sing "yum yum yum!" / "cold and sweet!" */}
          {showHeart && (
            <DieCutCharacterSticker
              kind="heart"
              x={1645}
              y={155}
              scale={beatPop * 0.82}
              rotate={-12 + swayTilt}
              frame={frame}
            />
          )}
          <FloatingNoteSticker x={255} y={135} symbol="♫" color="#FFE03D" frame={frame} phaseOffset={0.5} />
          <FloatingNoteSticker x={1655} y={110} symbol="♪" color="#5CE1E6" frame={frame} phaseOffset={2.2} />
        </>
      );
    }

    // 5. Band Interlude I1: Ghost & Pumpkin Stickers
    if (sec.id === 'I1') {
      return (
        <>
          <DieCutCharacterSticker
            kind="ghost"
            x={155}
            y={130}
            scale={beatPop}
            rotate={-6 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind="pumpkin"
            x={1765}
            y={130}
            scale={beatPop}
            rotate={6 - swayTilt}
            frame={frame}
          />
        </>
      );
    }

    // 6. Finale F1: Character & Food Stickers popping in rhythm with the 4 friends!
    if (sec.id === 'F1') {
      const slot = beat.beatIndex % 4;
      const leftChar: StickerIconKind = slot === 0 ? 'bobo' : slot === 1 ? 'lulu' : slot === 2 ? 'ziggy' : 'grub';
      const rightFood: StickerIconKind = slot === 0 ? 'burger' : slot === 1 ? 'icecream' : slot === 2 ? 'donut' : 'hotdog';
      return (
        <>
          <DieCutCharacterSticker
            kind={leftChar}
            x={150}
            y={125}
            scale={beatPop * 1.02}
            rotate={-6 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind={rightFood}
            x={1770}
            y={125}
            scale={beatPop * 1.02}
            rotate={6 - swayTilt}
            frame={frame}
          />
        </>
      );
    }

    // 7. Finale F2: 4-Color Grid — Cute Die-Cut Character Face Sticker in the Corner of Each Quadrant!
    if (sec.id === 'F2') {
      const stageCount =
        secProgress < 0.22
          ? 1
          : secProgress < 0.44
          ? 2
          : secProgress < 0.66
          ? 3
          : 4;
      const activeSlot = beat.beatIndex % 4;
      const pop = (slot: number) => (activeSlot === slot ? 0.96 * beatPop : 0.78);

      if (stageCount === 1) {
        return (
          <DieCutCharacterSticker
            kind="bobo"
            x={155}
            y={130}
            scale={beatPop * 1.1}
            rotate={-6 + swayTilt}
            frame={frame}
          />
        );
      }

      return (
        <>
          <DieCutCharacterSticker
            kind="bobo"
            x={105}
            y={95}
            scale={pop(0)}
            rotate={-5}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind="lulu"
            x={1065}
            y={95}
            scale={pop(1)}
            rotate={5}
            frame={frame}
          />
          {stageCount >= 3 && (
            <DieCutCharacterSticker
              kind="ziggy"
              x={105}
              y={635}
              scale={pop(2)}
              rotate={-5}
              frame={frame}
            />
          )}
          {stageCount >= 4 && (
            <DieCutCharacterSticker
              kind="grub"
              x={1065}
              y={635}
              scale={pop(3)}
              rotate={5}
              frame={frame}
            />
          )}
        </>
      );
    }

    // 8. Finale F3: Trick-or-Treat Street Parade — Active Food Sticker Popping as Each Food Word is Sung!
    if (sec.id === 'F3') {
      const lyr = getLyricAtFrame(frame, fps);
      const w = lyr.word?.w.toLowerCase() ?? '';
      let activeFood: StickerIconKind = 'pumpkin';
      if (w.includes('burger')) activeFood = 'burger';
      else if (w.includes('ice') || w.includes('cream')) activeFood = 'icecream';
      else if (w.includes('donut')) activeFood = 'donut';
      else if (w.includes('hot') || w.includes('dog')) activeFood = 'hotdog';

      return (
        <>
          <DieCutCharacterSticker
            kind="pumpkin"
            x={150}
            y={125}
            scale={beatPop * 0.95}
            rotate={-6 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind={activeFood}
            x={1770}
            y={125}
            scale={beatPop * 1.1}
            rotate={6 - swayTilt}
            frame={frame}
          />
        </>
      );
    }

    // 9. Outro O: Cute Ghost & Star Sticker in Upper Corners before Iris Closes
    if (sec.id === 'O' && secProgress < 0.8) {
      return (
        <>
          <DieCutCharacterSticker
            kind="ghost"
            x={160}
            y={130}
            scale={beatPop * 0.95}
            rotate={-6 + swayTilt}
            frame={frame}
          />
          <DieCutCharacterSticker
            kind="star"
            x={1760}
            y={130}
            scale={beatPop * 0.95}
            rotate={6 - swayTilt}
            frame={frame}
          />
        </>
      );
    }

    return null;
  };

  return (
    <g pointerEvents="none">
      {renderSectionStickers()}
      <KaraokeLyricBar frame={frame} fps={fps} />
    </g>
  );
};
