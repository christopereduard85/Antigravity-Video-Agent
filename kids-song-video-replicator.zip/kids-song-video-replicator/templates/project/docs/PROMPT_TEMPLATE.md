# Model Sheet Prompt Template (use with `image-generator` subagent)

Fill `{…}` from the cast table in `CHARACTER_DESIGN_SYSTEM.md` §6. Save as `characters/design/{ID}_{name}_model_sheet.jpg` (copy from artifact dir if the subagent can't write).

```
16:9, high resolution. Professional preschool TV animation model sheet, flat 2D vector style like Super Simple Songs / Pinkfong. Soft rounded shapes, NO black outlines, one subtle darker shading tone + one soft highlight per shape (light from top-left), crisp edges, saturated friendly palette, big white eyes with black pupils and a small white catchlight, big open smiling mouth with teeth row and pink tongue, rosy blush, noodle limbs, 3-finger mitten hands, rounded feet. Off-white #F6F1EA background, small labels only. Original character, must match the attached/described cast style of BOBO (lime-green bean monster).

Character "{NAME}": {description, body color hex, shade hex, unique parts}.
Row 1: turnaround — front, 3/4, side, back (same height line).
Row 2: {NAME} wearing a {FOOD} costume — front, 3/4, action pose. Face stays visible. Costume sandwiches the body (back + front layers).   [band/mascot: replace with instrument poses]
Row 3: expressions (happy, singing mouth wide open, surprised, wink) + 3 mouth shapes (closed smile, half-open, wide open AH).
```

Done: `H1_bobo_model_sheet.jpg`, `cast_lineup.jpg`.
