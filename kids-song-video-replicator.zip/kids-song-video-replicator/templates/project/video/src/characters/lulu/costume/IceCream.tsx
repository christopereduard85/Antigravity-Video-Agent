import React from 'react';
import { CostumeLayerProps, CostumeSpec } from '../../../rig/types';
import { getSquashStretch } from '../../../rig/geom';
import { evalSpringSwings } from '../../../rig/spring';
import { BEATS } from '../../../timeline';
import { theme } from '../../../theme';

const ic = theme.foods.iceCream;

/**
 * Lulu's Ice Cream Cone Costume (matches characters/design/H2_lulu_model_sheet.jpg Row 2):
 * - Front: Tapered golden waffle cone with criss-cross lattice lines wrapping Lulu's lower torso
 *          + scalloped strawberry-pink scoop collar right under her mouth!
 * - Hat: Creamy vanilla scoop sitting atop her head with colorful sprinkles & a glossy red cherry + stem!
 */
const IceCreamFront: React.FC<CostumeLayerProps> = ({
  bodyW,
  bodyH,
  squash,
  arc,
  frame,
  fps,
}) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.72 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 12;

  const collarY = -hh * 0.02;
  const coneBotY = hh * 1.02;
  const coneTopW = hw * 0.88;
  const coneBotW = hw * 0.36;

  const spring = evalSpringSwings(frame, fps, BEATS.beatPeriodSec, 175, 11, 0.15, 7);
  const dripStretch = 1 + spring.stretch * 1.2;

  const conePath = `M ${(-coneTopW).toFixed(2)} ${collarY.toFixed(2)}
    L ${(-coneBotW).toFixed(2)} ${coneBotY.toFixed(2)}
    Q 0 ${(coneBotY + 14 * sy).toFixed(2)} ${coneBotW.toFixed(2)} ${coneBotY.toFixed(2)}
    L ${coneTopW.toFixed(2)} ${collarY.toFixed(2)} Z`;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, 0)`}>
      <defs>
        <clipPath id="lulu-cone-clip">
          <path d={conePath} />
        </clipPath>
      </defs>

      {/* Waffle Cone Base */}
      <path d={conePath} fill={ic.cone} />

      {/* Criss-Cross Waffle Lattice */}
      <g clipPath="url(#lulu-cone-clip)" stroke={ic.coneGrid} strokeWidth={3} opacity={0.65}>
        {[-90, -60, -30, 0, 30, 60, 90].map((off, i) => (
          <React.Fragment key={i}>
            <line
              x1={off - 55}
              y1={collarY - 10}
              x2={off + 55}
              y2={coneBotY + 20}
            />
            <line
              x1={off + 55}
              y1={collarY - 10}
              x2={off - 55}
              y2={coneBotY + 20}
            />
          </React.Fragment>
        ))}
        {/* Right-side inner cone shade */}
        <rect
          x={coneTopW * 0.25}
          y={collarY}
          width={coneTopW}
          height={coneBotY - collarY + 20}
          fill="rgba(120, 60, 10, 0.16)"
          stroke="none"
        />
      </g>

      {/* Waffle Cone Top Rim */}
      <ellipse
        cx={0}
        cy={collarY + 3 * sy}
        rx={coneTopW * 1.02}
        ry={10 * sy}
        fill={ic.coneGrid}
      />

      {/* Scalloped Strawberry Scoop Collar right below Lulu's face */}
      <path
        d={`M ${(-hw * 1.02).toFixed(2)} ${(collarY - 4 * sy).toFixed(2)}
            Q ${(-hw * 1.12).toFixed(2)} ${(collarY + 20 * sy * dripStretch).toFixed(2)} ${(-hw * 0.72).toFixed(2)} ${(collarY + 14 * sy).toFixed(2)}
            Q ${(-hw * 0.45).toFixed(2)} ${(collarY + 28 * sy * dripStretch).toFixed(2)} ${(-hw * 0.18).toFixed(2)} ${(collarY + 14 * sy).toFixed(2)}
            Q 0 ${(collarY + 26 * sy * dripStretch).toFixed(2)} ${(hw * 0.18).toFixed(2)} ${(collarY + 14 * sy).toFixed(2)}
            Q ${(hw * 0.45).toFixed(2)} ${(collarY + 28 * sy * dripStretch).toFixed(2)} ${(hw * 0.72).toFixed(2)} ${(collarY + 14 * sy).toFixed(2)}
            Q ${(hw * 1.12).toFixed(2)} ${(collarY + 20 * sy * dripStretch).toFixed(2)} ${(hw * 1.02).toFixed(2)} ${(collarY - 4 * sy).toFixed(2)}
            Q 0 ${(collarY - 14 * sy).toFixed(2)} ${(-hw * 1.02).toFixed(2)} ${(collarY - 4 * sy).toFixed(2)} Z`}
        fill={ic.strawberry}
      />
    </g>
  );
};

const IceCreamHat: React.FC<CostumeLayerProps> = ({
  bodyW,
  bodyH,
  squash,
  arc,
  frame,
  fps,
}) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.66 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 16;

  const spring = evalSpringSwings(frame, fps, BEATS.beatPeriodSec, 185, 11, 0.25, 7);
  const browY = -hh * 0.68 + spring.stretch * -14;

  const sprinkles = [
    { x: -0.45, y: -32, r: -28, col: '#FF5A7A' },
    { x: -0.18, y: -52, r: 18, col: '#48C8FF' },
    { x: 0.16, y: -56, r: -14, col: '#FFD23F' },
    { x: 0.44, y: -36, r: 32, col: '#7CE846' },
    { x: -0.25, y: -22, r: 12, col: '#B26BFF' },
    { x: 0.08, y: -28, r: -22, col: '#FF5A7A' },
    { x: 0.34, y: -18, r: 15, col: '#48C8FF' },
  ];

  return (
    <g
      transform={`translate(${shiftX.toFixed(2)}, ${browY.toFixed(2)}) rotate(${(
        spring.angleDeg * 0.28
      ).toFixed(2)})`}
    >
      {/* Creamy Vanilla Scoop Dome */}
      <path
        d={`M ${(-hw * 0.92).toFixed(2)} 6
            C ${(-hw * 0.98).toFixed(2)} ${(-86 * sy).toFixed(2)}, ${(
          hw * 0.98
        ).toFixed(2)} ${(-86 * sy).toFixed(2)}, ${(hw * 0.92).toFixed(2)} 6 Z`}
        fill={ic.vanilla}
      />

      {/* Scalloped Vanilla Scoop Bottom Rim */}
      <path
        d={`M ${(-hw * 0.96).toFixed(2)} 2
            Q ${(-hw * 1.06).toFixed(2)} 20 ${(-hw * 0.68).toFixed(2)} 14
            Q ${(-hw * 0.35).toFixed(2)} 24 0 12
            Q ${(hw * 0.35).toFixed(2)} 24 ${(hw * 0.68).toFixed(2)} 14
            Q ${(hw * 1.06).toFixed(2)} 20 ${(hw * 0.96).toFixed(2)} 2 Z`}
        fill={ic.vanilla}
      />

      {/* Subtle warm inner shade on right of vanilla scoop */}
      <path
        d={`M ${(hw * 0.25).toFixed(2)} ${(-64 * sy).toFixed(2)}
            C ${(hw * 0.82).toFixed(2)} ${(-56 * sy).toFixed(2)}, ${(
          hw * 0.92
        ).toFixed(2)} ${(-16 * sy).toFixed(2)}, ${(hw * 0.92).toFixed(2)} 6
            Q ${(hw * 0.4).toFixed(2)} 14 0 8
            Q ${(hw * 0.52).toFixed(2)} ${(-8 * sy).toFixed(2)} ${(
          hw * 0.25
        ).toFixed(2)} ${(-64 * sy).toFixed(2)} Z`}
        fill="#EADBC4"
        opacity={0.55}
      />

      {/* Colorful Sprinkles */}
      {sprinkles.map((s, idx) => (
        <rect
          key={idx}
          x={hw * s.x - 6}
          y={s.y * sy - 2.5}
          width={12}
          height={5}
          rx={2.5}
          fill={s.col}
          transform={`rotate(${s.r} ${hw * s.x} ${s.y * sy})`}
        />
      ))}

      {/* Glossy Red Cherry & Stem on Top */}
      <g
        transform={`translate(0, ${(-68 * sy).toFixed(2)}) rotate(${(
          spring.angleDeg * 0.45
        ).toFixed(2)})`}
      >
        <path
          d="M 2 -12 Q 12 -34 26 -38"
          fill="none"
          stroke="#6B2B1A"
          strokeWidth={4}
          strokeLinecap="round"
        />
        <circle cx={0} cy={0} r={16} fill={ic.cherry} />
        <circle cx={-5} cy={-5} r={4.5} fill="#FFFFFF" opacity={0.65} />
      </g>
    </g>
  );
};

export const iceCreamCostume: CostumeSpec = {
  Front: IceCreamFront,
  Hat: IceCreamHat,
  hideAppendages: true,
};
