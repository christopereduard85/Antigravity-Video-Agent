import os
import sys
import json
import difflib
import argparse

def transcribe_audio(audio_path, model_size="small", device="auto"):
    """
    Transkripsi audio menggunakan faster-whisper atau openai-whisper.
    Model otomatis diunduh dari huggingface.co pada run pertama:
    - base: ±75 MB
    - small: ±500 MB (default)
    - large-v3: ±3 GB (audio sulit)
    """
    try:
        from faster_whisper import WhisperModel
        import torch

        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        
        compute_type = "float16" if device == "cuda" else "int8"
        print(f"[INFO] Loading Whisper '{model_size}' on {device.upper()} ({compute_type})...")
        model = WhisperModel(model_size, device=device, compute_type=compute_type)
        
        segments, info = model.transcribe(audio_path, word_timestamps=True, beam_size=5)
        
        sentences = []
        words = []
        full_text = []

        seg_idx = 1
        for seg in segments:
            full_text.append(seg.text.strip())
            sentences.append({
                "id": seg_idx,
                "start": round(seg.start, 3),
                "end": round(seg.end, 3),
                "text": seg.text.strip()
            })
            seg_idx += 1
            if seg.words:
                for w in seg.words:
                    words.append({
                        "word": w.word.strip(),
                        "start": round(w.start, 3),
                        "end": round(w.end, 3),
                        "probability": round(w.probability, 3)
                    })

        return sentences, words, " ".join(full_text)

    except ImportError:
        print("[ERROR] faster-whisper belum terinstall. Install dengan: pip install faster-whisper torch")
        sys.exit(1)

def align_script_with_whisper(script_text, whisper_words):
    """
    Menyelaraskan teks script polos dengan timing kata Whisper menggunakan difflib.
    Kecocokan harus >= 90%.
    """
    script_words = script_text.strip().split()
    whisper_word_texts = [w["word"].lower().strip(".,!?;:\"'") for w in whisper_words]
    clean_script_words = [w.lower().strip(".,!?;:\"'") for w in script_words]

    matcher = difflib.SequenceMatcher(None, clean_script_words, whisper_word_texts)
    ratio = matcher.ratio()
    print(f"[ALIGNMENT] Kecocokan teks Script vs Audio: {ratio * 100:.2f}%")

    if ratio < 0.90:
        print(f"[WARNING] Kecocokan ({ratio*100:.1f}%) di bawah batas 90%! Script dan rekaman audio mungkin memiliki perbedaan kata.")

    aligned_words = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag in ('equal', 'replace'):
            w_start = whisper_words[j1]["start"] if j1 < len(whisper_words) else 0.0
            w_end = whisper_words[j2 - 1]["end"] if j2 <= len(whisper_words) else w_start + 0.5
            total_dur = max(0.1, w_end - w_start)
            sub_words = script_words[i1:i2]
            total_chars = sum(len(w) for w in sub_words)
            cur = w_start
            for sw in sub_words:
                dur = total_dur * (len(sw) / max(1, total_chars))
                aligned_words.append({
                    "word": sw,
                    "start": round(cur, 3),
                    "end": round(cur + dur, 3)
                })
                cur += dur
        elif tag == 'insert':
            pass
        elif tag == 'delete':
            # Kata di script yang tidak terucap di whisper
            last_t = aligned_words[-1]["end"] if aligned_words else 0.0
            for sw in script_words[i1:i2]:
                aligned_words.append({
                    "word": sw,
                    "start": round(last_t, 3),
                    "end": round(last_t + 0.2, 3)
                })
                last_t += 0.2

    return aligned_words, ratio

def main():
    parser = argparse.ArgumentParser(description="Transcribe & Align Audio with Whisper")
    parser.add_argument("--audio", required=True, help="Path ke voiceover")
    parser.add_argument("--script", default=None, help="Path ke script teks biasa (opsional)")
    parser.add_argument("--model", choices=["base", "small", "large-v3"], default="small")
    parser.add_argument("--device", choices=["cuda", "cpu", "auto"], default="auto")
    parser.add_argument("--outdir", required=True, help="Folder timeline output")

    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    sentences, words, full_text = transcribe_audio(args.audio, model_size=args.model, device=args.device)

    # Jika user memberikan script teks polos, selaraskan dengan difflib
    if args.script and os.path.exists(args.script):
        with open(args.script, "r", encoding="utf-8") as f:
            script_content = f.read()
        aligned_words, match_ratio = align_script_with_whisper(script_content, words)
        words = aligned_words

    # Tulis hasil ke timeline/
    with open(os.path.join(args.outdir, "sentences.json"), "w", encoding="utf-8") as f:
        json.dump(sentences, f, indent=2, ensure_ascii=False)

    with open(os.path.join(args.outdir, "words.json"), "w", encoding="utf-8") as f:
        json.dump(words, f, indent=2, ensure_ascii=False)

    with open(os.path.join(args.outdir, "transcript.txt"), "w", encoding="utf-8") as f:
        f.write(full_text)

    print(f"[SUCCESS] Transkripsi selesai: {len(sentences)} kalimat, {len(words)} kata disimpan di {args.outdir}")

if __name__ == "__main__":
    main()
