# Cartoon 3D Animated Shorts (Antigravity Skill)

Converted for **Antigravity** from `claude-animated-shorts` (originally proven on *"The Bridge That Fell for a Song"*).

This skill enables Antigravity to autonomously craft viral 55–70 s vertical animated story shorts: 2D characters in a colourful 3D world with ink outlines, painted town architecture, depth-of-field lens blur, gliding cameras, a march score, and sound effects. Everything is rendered locally with **Three.js** inside **Remotion** with no external AI video generator.

---

## Directory Structure

```text
cartoon-3d-short/
├── SKILL.md                 # Antigravity master skill instructions & pipeline
├── README.md                # Documentation & quick start guide
├── LICENSE                  # MIT License
├── scripts/                 # Stills, comparison sheets, and QA scripts
├── templates/
│   ├── bridge/              # Complete Three.js & Remotion source (Bridge short)
│   ├── audio/               # SFX, march music, DSP, timeline & mixing scripts
│   ├── scripts/             # Project-copyable helper scripts
│   ├── sandbox_index_example.tsx
│   └── SCRIPT_example.md
└── references/
    ├── STYLE_BIBLE.md       # Script & visual formulas measured from reference shorts
    ├── reports/             # 7 measured reports (motion, depth, textures, etc.)
    ├── frames/              # 38 full-size reference frames (540x960)
    └── sheets/              # 20 contact sheets (1,200 benchmark frames)
```

---

## Installation in Antigravity

This skill is installed in the Antigravity global skills directory:
- **Global Path:** `~/.gemini/config/skills/cartoon-3d-short/` (`C:\Users\chris\.gemini\config\skills\cartoon-3d-short\`)
- **Workspace Path:** (Optional) Copy into your project's `.agents/skills/cartoon-3d-short/`

---

## Prerequisites

1. **Node.js** (v18+) & **npm** or **pnpm**
2. **Remotion** with `@remotion/three`, `three`, `@react-three/fiber`, `@react-three/postprocessing`, `postprocessing`
3. **Python 3** with `numpy`, `scipy`, `pillow` (for sound synthesis and QA tools)
4. **ffmpeg** / **ffprobe** in system PATH

---

## Usage in Antigravity

In Antigravity chat, simply ask:
> *"Use the cartoon short skill and make a short about [topic]..."*
> or
> *"Make a short in the cartoon 3D style like the bridge video about [topic]..."*

Antigravity will automatically load `SKILL.md` via progressive disclosure and execute the 11-step pipeline:
1. **Topic and facts** (physical cause-and-effect + everyday analogy)
2. **Script** (~3.7 words/s, 55–70 s with the 8-part beat formula)
3. **Voice & timings** (`voice.wav` + `words.json`)
4. **Shot plan** (`story.ts` with camera choreography, cuts, kicks, and DOF)
5. **3D World** (`world.ts`, `lights.ts`, `build.ts`, `paint.ts`)
6. **2D Characters** (`toon.ts`, `cast.ts`, `cardshade.ts`)
7. **Post processing** (`Bridge.tsx`, `ink.ts`, `lensblur.ts`, `grade.ts`)
8. **Audio mix** (synthesized SFX, march score ducked under voice)
9. **Look checks** (test stills compared against `references/frames/` with Pro verifier subagent)
10. **Final render** (2K 1440x2560 vertical at 30 fps + automated frame QA)
11. **Deliver** (present final video with direct file link and playback stats)

---

## Notes & Performance

- **Temp Storage:** Remotion bundles copy assets into the system temp directory (~1.3 GB per bundle). On Windows/PowerShell, set:
  ```powershell
  $env:REMOTION_TMP="D:/remotion-tmp"; $env:TEMP="D:/remotion-tmp"; $env:TMP="D:/remotion-tmp"
  ```
- **Browser Executable:** `scripts/bridge-stills.mjs` automatically detects Google Chrome or uses `process.env.PUPPETEER_EXECUTABLE_PATH`.
- **License:** MIT License. Reference materials are for study and quality benchmarking only.
