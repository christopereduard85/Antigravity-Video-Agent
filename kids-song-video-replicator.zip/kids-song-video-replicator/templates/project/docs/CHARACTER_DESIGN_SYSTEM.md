# CHARACTER DESIGN SYSTEM — Studio-Quality Rigs in Remotion

> Read after `PRODUCTION_PLAN.md`. This doc defines HOW every character is designed, built, and animated.
> Goal: look like a studio-made 2D cartoon (Super Simple / Pinkfong), **never** like stiff SVG stickers pasted on a frame and moved around.

---

## 1. Pipeline overview

```mermaid
flowchart LR
  A["1 Concept art<br/>image-generator"] --> B["2 Model sheet approval<br/>(user)"]
  B --> C["3 Token file<br/>colors, proportions, attach points"]
  C --> D["4 Build with shared RIG ENGINE<br/>procedural paths, React/SVG"]
  D --> E["5 Pose + action library<br/>beat-driven"]
  E --> F["6 QA stills vs model sheet<br/>npx remotion still"]
  F --> G["7 Use in scenes"]
```

| Stage | Tool | Output |
|---|---|---|
| Concept | `image-generator` subagent | `characters/design/<ID>_model_sheet.jpg` (turnaround, costume, expressions, visemes) |
| Approval | User | ✅ in §8 table |
| Production asset | **Code-native procedural vector** in Remotion (React + SVG paths generated per frame) | `video/src/characters/<id>/` |
| Motion | Remotion `interpolate`, `spring`, `Easing` + own deterministic spring sim. GSAP only if a curve can't be expressed. | pose/action files |
| Polish | `@remotion/motion-blur` (spin/fast moves), full-frame grain overlay, contact shadows | — |
| Review | `npx remotion still <comp> --frame=N` side-by-side with `reference_frames/frame_N.jpg` | `analysis/qa/` |

**Why not trace concept art into static SVG?** Static SVG parts only translate/rotate/scale → seams at joints, rigid bodies, "paper puppet" feel. Instead, every shape is a **function of pose params** that regenerates its path each frame. Concept art is the visual target only. It is never imported as an asset.

Skills: `design-dna` (tokens), `motion-director` + `motion-design` (acting/timing), `remotion-video` (build/render), `motion-background` (sets).

---

## 2. The 12 anti-"pasted SVG" rules (mandatory)

1. **One silhouette.** Limbs are stroked bezier "noodles" whose root sits *inside* the body edge and is drawn *behind* the body. No visible joints, no seams.
2. **Bodies deform, they don't scale.** Body path comes from a param generator (superellipse/bezier blob). Squash & stretch preserve volume: `sx * sy = 1`, anchored at the feet.
3. **Shading deforms with the body.** Shadow and highlight shapes are derived from the *same* deformed body path (offset or inset), clipped by the body `clipPath`. Never use a separate static shadow image.
4. **Limbs bend with IK.** Arms and legs are 2-bone IK (shoulder to hand target) rendered as one smooth quadratic/cubic curve with tapered width. Hands and feet orient along the curve's end tangent.
5. **Follow-through via springs.** Antennae, ears, tails, hair, lettuce, and cheese drips are spring chains that lag behind body motion. Springs must be deterministic: simulate from frame 0 to the current frame (memoized) or use an analytic damped oscillation per beat impulse.
6. **Eyes are alive.** Blink with an eyelid shape that closes over the eye (not `scaleY` on the eye). Pupils track a look-at target. Eyes squash with the body. Add saccades (small pupil jumps every 1–3 s).
7. **Mouth morphs.** Visemes (`closed`, `mid`, `open`, `O`, `E`) share the same point count and interpolate point-by-point. Teeth and tongue are clipped inside the mouth shape.
8. **Line of action.** Each pose has a `lean` + `arc`, so the whole body curves (C or S curve), not just rotates.
9. **Ground contact.** A soft ellipse shadow under the feet shrinks and fades with jump height. Feet never slide while planted.
10. **Anticipation → action → overshoot → settle** on every big move (entrances, jumps, transforms). Use ease-out-back or spring with damping around 12.
11. **Overlap, no twins.** Left and right limbs offset 1–3 frames. Never mirror-perfect symmetry while moving.
12. **Unified finish.** Same light direction (top-left) for all characters. 1 shade tone + 1 highlight per material. Subtle full-frame grain (opacity ≈ 0.04). Motion blur on spins.

---

## 3. Rig engine architecture (shared by ALL characters)

```
video/src/rig/
  types.ts          Pose, CharacterTokens, Viseme, LimbSpec types
  geom.ts           vec math, bezier helpers, superellipse/blob path, offsetPath, taper stroke
  ik.ts             2-bone IK solver (lengths, target, bend direction) -> joint point
  spring.ts         deterministic spring sim (memo by frame), analytic beat impulse
  beat.ts           useBeat(): {beatIndex, phase 0-1, barPhase} from analysis/beats.json
  Body.tsx          blob body path from tokens + pose.squash/lean/arc; exposes clip id + anchor map
  Shading.tsx       shade/highlight from body path, clipped
  Limb.tsx          noodle limb: root anchor -> IK -> tapered path + hand/foot glyph
  Eyes.tsx          eye whites, pupils (look-at), eyelids (blink), squash
  Mouth.tsx         viseme morph + teeth + tongue clip
  Appendage.tsx     spring chain (antenna, ear, tail, hair)
  ContactShadow.tsx ground ellipse
  Character.tsx     generic assembler: tokens + pose + costume -> layered SVG <g>
  poses.ts          shared base poses (idle, sing, danceA, danceB, wave, jump, spinPrep)
  actions.ts        beat-locked pose sequences: danceLoop(beat), walkIn, spinTransform
```

### Core types (contract — keep stable)

```ts
type Vec = { x: number; y: number };

interface Pose {
  root: Vec;            // feet anchor on stage (px, 1920x1080 space)
  squash: number;       // -1 stretch .. 0 neutral .. 1 squash (volume preserved)
  lean: number;         // degrees, line of action
  arc: number;          // -1..1 body curve (C-curve)
  headTilt: number;     // degrees (if separate head)
  handL: Vec; handR: Vec;   // IK targets, relative to body center
  footL: Vec; footR: Vec;
  look: Vec;            // pupil look-at, -1..1
  blink: number;        // 0 open .. 1 closed
  viseme: Viseme; mouthOpen: number; // 0..1
  expression: 'happy' | 'surprised' | 'wink' | 'sing';
}

interface CharacterTokens {
  id: string;
  height: number;                     // px at scale 1
  body: { shape: 'blob' | 'bean' | 'tall' | 'long'; w: number; h: number; squareness: number };
  colors: { base: string; shade: string; highlight: string; limb: string; feet: string; blush: string; mouth: string; tongue: string };
  anchors: { shoulderL: Vec; shoulderR: Vec; hipL: Vec; hipR: Vec; eyes: Vec[]; mouth: Vec; appendages: Vec[] }; // normalized -1..1 in body box
  limbs: { armLen: [number, number]; legLen: [number, number]; width: [number, number] }; // upper/lower, root/tip
  eyes: { r: number; pupilR: number; count: 2 | 3 };
  appendages: AppendageSpec[];        // antenna/ear/tail spring chains
  costumes: Record<string, React.FC<CostumeProps>>;
}
```

A character = **token file + optional unique part components**. All motion code is shared. That makes new characters cheap and keeps them consistent.

### Layer order (back to front)
`ContactShadow` → back appendages → `costume.back` → far limbs (L arm, L leg) → `Body` + `Shading` → spots/markings → `Eyes` → `Mouth` → `costume.front` → near limbs (R arm, R leg) → front appendages → props (mic).

### Costume rule
A costume is two components, `back` and `front`, that sandwich the body. Each gets the same deformed body frame (`squash/lean/arc`), so it squashes *with* the character. Soft parts (lettuce, cheese drip, sprinkles, mustard) use `Appendage` springs. The face must stay visible.

---

## 4. Character file template

```
video/src/characters/<id>/
  tokens.ts          CharacterTokens (from model sheet)
  <Name>.tsx         export const <Name> = (p) => <Character tokens={tokens} {...p} />
  parts/             unique parts only (e.g. Bobo antennae balls, Ziggy 3rd eye)
  costume/<Food>.tsx { back, front }
  QA.tsx             composition: turnaround + all visemes + dance loop for stills
```

Register `QA.tsx` as composition `QA-<Name>` in `Root.tsx`.

---

## 5. Animation language (from reference)

- Tempo-locked: **every** idle, dance, and hop uses `useBeat()`. Hop down-squash on the beat, up-stretch on the off-beat.
- Dance = 2 alternating key poses per beat (A on beats 1 and 3, B on beats 2 and 4) + arm wave on the bar.
- Singing = `viseme` from `analysis/lyrics_timed.json` syllables + amplitude envelope for `mouthOpen`.
- Transform (`spinTransform`): anticipation crouch (6f) → spin up into color swirl tornado (12f, motion blur) → costume pops in with overshoot (8f) → settle (6f). Reused 4×.
- Entrances: walk-in or bounce-in with overshoot. Exits: anticipation then fast out (8f).
- Blink every 2–4 s (deterministic random by `frame + id` seed). Blink takes 6 frames: close 2, hold 1, open 3.

---

## 6. Cast tokens (starting values — refine from model sheets)

| ID | Name | Shape | Base / shade | Limbs / feet | Unique parts | Costume |
|---|---|---|---|---|---|---|
| H1 | **Bobo** | round bean, h 260 | #8CD43A / #6BB02A | #6BB02A / #F28C28 | 2 antennae + ball tips (spring), back spots | Burger |
| H2 | **Lulu** | tall noodle, h 380 | #E7A3E0 / #C97EC2 | #C97EC2 / #8E4FA8 | long floppy bunny ears (spring), hair curl | Ice cream cone |
| H3 | **Ziggy** | short wide, h 220 | #4FB8F0 / #2E93CC | #2E93CC / #FFD23F | 3 eyes, tiny horns | Sprinkled donut |
| H4 | **Grub** | long low, 4 legs, h 200 | #F79A3E / #D9771F | #D9771F / #7A3E12 | floppy ears + wag tail (spring) | Hot dog |
| B1 | **Bones** | skeleton drummer | #F4EFE6 / #CFC6B6 | bone limbs | jaw bounce on kick | — |
| B2 | **Spinny** | round spider, 6 legs | #7B4FD0 / #5A33A8 | #5A33A8 | 6 IK legs, plays bass | — |
| B3 | **Boo** | ghost | #FFFFFF / #DCD6F0 | — | wavy tail (spring chain) | — |
| M1 | **Pip** | small bat | #4A2B6E / #33194F | wings | wing flap cycle | — |

Global: eye white #FFFFFF, pupil #1B1B2A, mouth #5A1A2A, tongue #FF7A8A, blush #FF9AA8 @ 0.6, teeth #FFFFFF.

---

## 7. QA gate (each character must pass before use)

- [ ] Stills match the model sheet silhouette and colors (turnaround frames).
- [ ] No seams at shoulders or hips at extreme poses (arm up, arm down, crouch).
- [ ] Squash 1.0 and stretch -1.0 look good; volume visually preserved.
- [ ] Shading follows deformation, nothing slides off the body.
- [ ] Blink, look-at, and all 5 visemes render cleanly (teeth stay clipped).
- [ ] Springs settle without jitter. Re-rendering the same frame gives an identical result (determinism).
- [ ] Dance loop locked to beat over 8 bars, no foot sliding.
- [ ] Costume deforms with body; face visible; soft parts lag naturally.
- [ ] Side-by-side with ref frame (e.g. `reference_frames/frame_00241.jpg`) feels the same family.

## 8. Status

| ID | Concept sheet | Approved | tokens.ts | Rig built | QA pass |
|---|---|---|---|---|---|
| H1 Bobo | `characters/design/H1_bobo_model_sheet.jpg` ✅ generated | ✅ user 2026-11-07 | ✅ `video/src/characters/bobo/tokens.ts` | ✅ `video/src/characters/bobo/Bobo.tsx` + `costume/Burger.tsx` | ✅ `analysis/qa/bobo_sheet.png` |
| H2 Lulu | `characters/design/H2_lulu_model_sheet.jpg` ✅ generated | ✅ | ✅ `video/src/characters/lulu/tokens.ts` | ✅ `video/src/characters/lulu/Lulu.tsx` + `costume/IceCream.tsx` | ✅ `analysis/qa/cast_qa_sheet.png` |
| H3 Ziggy | `characters/design/cast_lineup.jpg` + `QACast.tsx` ✅ | ✅ | ✅ `video/src/characters/ziggy/tokens.ts` | ✅ `video/src/characters/ziggy/Ziggy.tsx` + `costume/Donut.tsx` | ✅ `analysis/qa/cast_qa_sheet.png` |
| H4 Grub | `characters/design/cast_lineup.jpg` + D5 revision in `QACast.tsx` ✅ | ✅ | ✅ `video/src/characters/grub/tokens.ts` | ✅ `video/src/characters/grub/Grub.tsx` + `costume/HotDog.tsx` | ✅ `analysis/qa/cast_qa_sheet.png` |
| B1–B3, M1 | `characters/design/cast_lineup.jpg` + `QACast.tsx` ✅ | ✅ | ✅ `video/src/characters/band/BandCharacters.tsx` | ✅ `BonesDrummer`, `SpinnyBassist`, `BooSax`, `PipBat` | ✅ `analysis/qa/cast_qa_sheet.png` |

**Build order:** rig engine + Bobo (reference implementation) → QA → then copy the pattern for the others.

