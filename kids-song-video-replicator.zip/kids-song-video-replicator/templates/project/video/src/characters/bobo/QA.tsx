import React from 'react';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';
import { Bobo } from './Bobo';
import { boboTokens } from './tokens';
import { makeBeatDancePose, makeNeutralPose } from '../../rig/poses';
import { evalSpinTransform, TornadoSwirl } from '../../rig/actions';
import { Expression, Viseme } from '../../rig/types';
import { theme } from '../../theme';

export const QABobo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Segment 1 (0..89): Full Studio Sheet view (clean spacing, zero overlap with headers!)
  if (frame < 90) {
    const baseFront = makeNeutralPose(boboTokens, { x: 260, y: 455 });
    const baseSing = {
      ...makeBeatDancePose(boboTokens, frame, { x: 640, y: 455 }, 'sing', fps),
      jumpY: 0,
    };
    const burgerFront = {
      ...makeNeutralPose(boboTokens, { x: 1080, y: 455 }),
      handL: { x: -115, y: 65 },
      handR: { x: 115, y: 65 },
    };
    const burgerJump = makeBeatDancePose(
      boboTokens,
      frame,
      { x: 1540, y: 455 },
      'jump',
      fps
    );

    const exprs: Array<{
      label: string;
      expr: Expression;
      vis: Viseme;
      open: number;
      x: number;
    }> = [
      { label: 'Happy (Half-open)', expr: 'happy', vis: 'mid', open: 0.45, x: 240 },
      { label: 'Singing (Eyes Arc)', expr: 'sing', vis: 'open', open: 0.85, x: 580 },
      { label: 'Surprised (O)', expr: 'surprised', vis: 'O', open: 0.8, x: 920 },
      { label: 'Winking (Smile)', expr: 'wink', vis: 'closed', open: 0, x: 1260 },
      { label: 'Wide AH Dome', expr: 'happy', vis: 'open', open: 0.95, x: 1620 },
    ];

    return (
      <AbsoluteFill style={{ backgroundColor: theme.sheetBg }}>
        <svg width={1920} height={1080} viewBox="0 0 1920 1080">
          <text
            x={80}
            y={72}
            fontFamily="Arial Black, sans-serif"
            fontSize={46}
            fill="#69A11E"
          >
            BOBO — STUDIO RIG QA SHEET
          </text>
          <text
            x={80}
            y={108}
            fontFamily="sans-serif"
            fontSize={21}
            fontWeight="bold"
            fill="#4A4A5A"
          >
            Row 1: Base Monster &amp; Burger Costume Rigs (Deformable Bean + 2-Bone IK + Spring Antennae/Cheese)
          </text>

          <Bobo
            pose={baseFront}
            frame={frame}
            costume="none"
            scale={0.92}
            instanceId="r1-1"
          />
          <text x={260} y={505} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
            Base Front
          </text>

          <Bobo
            pose={baseSing}
            frame={frame}
            costume="none"
            hasMic
            scale={0.92}
            instanceId="r1-2"
          />
          <text x={640} y={505} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
            Singing + Mic (IK)
          </text>

          <Bobo
            pose={burgerFront}
            frame={frame}
            costume="burger"
            scale={0.92}
            instanceId="r1-3"
          />
          <text x={1080} y={505} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
            Burger Costume Front
          </text>

          <Bobo
            pose={burgerJump}
            frame={frame}
            costume="burger"
            scale={0.92}
            instanceId="r1-4"
          />
          <text x={1540} y={505} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
            Burger Jumping Pose
          </text>

          {/* Row 2: Expressions & All 5 Visemes */}
          <text
            x={80}
            y={585}
            fontFamily="sans-serif"
            fontSize={21}
            fontWeight="bold"
            fill="#4A4A5A"
          >
            Row 2: Facial Expressions &amp; 5 Interpolated Mouth Visemes (Teeth + Tongue Clipped)
          </text>

          {exprs.map((item, idx) => {
            const p = {
              ...makeNeutralPose(boboTokens, { x: item.x, y: 955 }),
              expression: item.expr,
              viseme: item.vis,
              mouthOpen: item.open,
            };
            return (
              <g key={idx}>
                <Bobo
                  pose={p}
                  frame={frame}
                  costume="none"
                  scale={0.88}
                  instanceId={`r2-${idx}`}
                />
                <text
                  x={item.x}
                  y={1008}
                  textAnchor="middle"
                  fontFamily="sans-serif"
                  fontSize={20}
                  fontWeight="bold"
                  fill="#2B2D38"
                >
                  {item.label}
                </text>
              </g>
            );
          })}
        </svg>
      </AbsoluteFill>
    );
  }

  // Segment 2 (90..359): Stage Action Preview
  const localStageFrame = frame - 90;
  const isTransform = localStageFrame >= 60 && localStageFrame < 107;
  const isAfterTransform = localStageFrame >= 107;

  const transformState = isTransform
    ? evalSpinTransform(boboTokens, frame, localStageFrame - 60, 47, {
        x: 960,
        y: 860,
      })
    : null;

  const activePose = transformState
    ? transformState.pose
    : makeBeatDancePose(
        boboTokens,
        frame,
        { x: 960, y: 860 },
        isAfterTransform ? 'dance' : 'sing',
        fps
      );

  const activeCostume = transformState
    ? transformState.useCostume
      ? 'burger'
      : 'none'
    : isAfterTransform
    ? 'burger'
    : 'none';

  return (
    <AbsoluteFill style={{ backgroundColor: theme.stage.wallBg }}>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080">
        <rect x={0} y={0} width={1920} height={780} fill={theme.stage.curtainDark} />
        {Array.from({ length: 16 }).map((_, i) => (
          <rect
            key={i}
            x={i * 120}
            y={0}
            width={64}
            height={780}
            fill={theme.stage.curtainMain}
            opacity={0.55}
          />
        ))}
        <polygon
          points="760,0 1160,0 1380,920 540,920"
          fill={theme.stage.spotlight}
        />
        <rect x={0} y={770} width={1920} height={310} fill={theme.stage.woodBase} />
        <rect x={0} y={770} width={1920} height={14} fill={theme.stage.woodEdge} />

        <Bobo
          pose={activePose}
          frame={frame}
          fps={fps}
          costume={activeCostume}
          hasMic={!isTransform && !isAfterTransform}
          scale={1.35}
          instanceId="stage-bobo"
        />

        {transformState && (
          <TornadoSwirl
            x={960}
            y={840}
            progress={transformState.tornadoProgress}
            frame={frame}
          />
        )}

        {Array.from({ length: 12 }).map((_, i) => (
          <circle
            key={i}
            cx={i * 170 + 85}
            cy={10}
            r={95}
            fill={theme.stage.curtainMain}
            stroke={theme.stage.curtainTrim}
            strokeWidth={6}
          />
        ))}
      </svg>
    </AbsoluteFill>
  );
};
