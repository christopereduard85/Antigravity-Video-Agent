# 09 — Feedback history (replay order of the original session)

Use this as the expected sequence of iterations. A weaker model can pre-empt these requests by doing each item proactively.

| Step | User request (orig. Indonesian, translated) | Result delivered |
|---|---|---|
| 1 | Replicate reference video with my song + lyrics | Plan: frames, contact sheets, cut list, style DNA, 19-section structure table (PRODUCTION_PLAN.md) |
| 2 | Choose characters | Agent-designed cast of 8 (Bobo, Lulu, Ziggy, Grub, Bones, Spinny, Boo, Pip); concept sheets via image generator; user: "nice design mantap" |
| 3 | Grub revision | add monster traits (2 horns, toothy grin, darker spots), keep dachshund body |
| 4 | Build | audio timing (152 BPM, 19 sections, 40 lines), Remotion scaffold, rig engine, Bobo + Burger + QA sheet |
| 5 | Continue | all rigs + costumes, sets, wipes, all sections A..O, 28 s preview |
| 6 | More camera / scene density | CameraRig, 4 camera cuts per verse, chorus sub-scenes, band cutaways |
| 7 | Audit fixes | logo text EDUFAM, hat/bucket locked to rig, overscan bleed, strict solo heroes, removed confusing gags, giant food platforms finale, better lip-sync |
| 8 | Transitions + band clean-up | straddling wipes, clean Boo/iris outro |
| 9 | "add kids-song texts like lyrics, and sticker/labels that liven it up, matching theme, not disturbing characters" | karaoke lyric bar + overlays |
| 10 | "lyrics good but not on rhythm; labels = character stickers popping on cue, not top text" | word-level timing templates; die-cut character/food stickers |
| 11 | "lyrics late" / "from verse 2 onward still late" | Whisper re-anchoring of all 40 lines |
| 12 | "hot dog verse/chorus lyric speed" | K4 re-timed after spin break |
| 13 | "chorus 4 + finale slightly late, fix fast" | −0.40 s / −0.45 s |
| 14 | "at 01:17 one frame suddenly appears after pink transition" (screenshot) | section gap fix, contiguous sections |
| 15 | "watermark: small 'edufam' sticker, pops randomly except centre, disappears, ~10 s later elsewhere" | LogoBug pop-out sticker |
| 16 | "give me cmd to render full with GPU; stop local preview" | `--gl=angle` render command + npm script |
| 17 | (user rendered) "output is good" | done |

## Style of collaboration the user liked
- Terse replies (user enforces "caveman mode": short, factual, no filler; reply in user's language — Indonesian).
- Show proof (still images, numbers: seconds/frames).
- Fix fast and narrowly; don't redesign what was approved.
