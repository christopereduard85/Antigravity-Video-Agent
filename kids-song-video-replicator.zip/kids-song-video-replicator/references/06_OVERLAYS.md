# 06 — Sing-along overlays: karaoke bar, die-cut stickers, watermark

All in `video/src/ui/`. Rendered inside the main `<svg>` after the scene, before the wipe.

## Safe zones (1920x1080) — never violate

| Zone | Use |
|---|---|
| y 995–1065, x 505–1415 | karaoke bar (bottom centre apron, below characters' feet ~870) |
| top-left (x 60–300, y 50–260), top-right (x 1620–1860, y 50–260) | section stickers |
| side margins x<260 / x>1660, y 300–1000 | watermark pop-outs |
| centre x 500–1420, y 150–950 | **forbidden** for overlays (characters live here) |

## Karaoke lyric bar (`KaraokeLyricBar` in SingAlongOverlays.tsx)

- Dark rounded pill (`#1E0836`-ish) with white border, centred at bottom.
- Shows current lyric line from `LYRICS`; line appears **0.4 s before** its first word (lead-in) and stays until next line.
- Words laid out by measured width; the active word (startSec ≤ t ≤ endSec) turns yellow `#FFE03D`, scales up and bounces (sin), past words stay highlighted/white, future words white.
- A small pink bouncing ball dot above the active word.
- Font: `'Arial Black', 'Fredoka', sans-serif`, heavy stroke (`paintOrder="stroke"`).
- Timing truth comes only from `lyrics_timed.json`; never offset in component.

## Die-cut stickers (`DieCutCharacterSticker`, `FloatingNoteSticker`)

User definition of "label": illustrated **stickers of the characters/food from the animation**, popping on cue to make it lively — NOT text banners.
- Kinds: `bobo lulu ziggy grub burger icecream donut hotdog pumpkin bat ghost question heart star`.
- Look: thick white die-cut backing shape (circles/ellipses bigger than the art) + soft drop shadow + flat vector art inside; scale with spring pop-in and beat pulse (`beatPop`), gentle sway tilt.
- Per section (`renderSectionStickers`):
  - A/B: pumpkin + bat, music notes.
  - Verse C*: question-mark sticker while "what will I be?" then hero face + food reveal near the reveal line.
  - Chorus K*: hero face top-left (150,135), food top-right (1770,135), heart pops on the "yum yum yum / cold and sweet" half of each 2-bar chant (`barPhase ≥ 0.85`), floating ♫ ♪ notes.
  - I1: ghost + pumpkin. F1: hero/food cycling per beat. F2: hero face in each quadrant corner, active one pops. F3: food sticker switches to the food word currently sung (reads `getLyricAtFrame().word`). O: ghost + star until 80%.

## Watermark (`LogoBug.tsx`) — "edufam"

Spec given by user: small sticker with text "edufam", pops out randomly anywhere except centre / never blocking animation, pops then disappears, ~10 s later pops again at a different place.

Implementation (approved):
```
activeSpan = 2.4 s (72 f) visible, cycleDuration = 12 s (360 f)
cycle = floor(frame / 360); localF = frame % 360; hidden if localF >= 72
pop-in first 11 f: scale = sin(p·π/2) + sin(p·π)·0.2   (overshoot ~1.16)
exit last 10 f: scale = (72-localF)/10 · 1.1
position = SAFE_STICKER_POSITIONS[(cycle*3 + 1) % 10]   (coprime step → never same spot twice in a row)
micro hover: y += sin(frame·0.2)·2.5, rotate += cos(frame·0.16)·1.4
pill 120x36, rx 18, white die-cut border +4.5 px, drop shadow, gloss highlight, ★ icon, text 16 px Arial Black white with dark stroke
```
10 safe positions: corners and side margins (x≈130–145 or 1770–1790; y 340, 560, 780, 910/930, 990/1010). No top positions at y<300 (they collide with section stickers).
Mounted inside `RenderSceneAtFrame` as `<LogoBug frame={frame} fps={fps} />` (SVG `<g>`), not as an HTML div.

Change the text/colours for another brand; keep timing & safe positions.
