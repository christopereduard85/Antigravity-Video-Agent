import React from 'react';
import { CostumeLayerProps, CostumeSpec } from '../../../rig/types';
import { getSquashStretch } from '../../../rig/geom';
import { theme } from '../../../theme';

const hd = theme.foods.hotDog;

/**
 * Grub's Hot Dog Costume:
 * Horizontal toasted golden bun + juicy red-brown sausage ends extending left & right + wavy yellow mustard zigzag!
 */
const HotDogBack: React.FC<CostumeLayerProps> = ({ bodyW, bodyH, squash, arc }) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.78 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 12;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, ${(hh * 0.35).toFixed(2)})`}>
      {/* Upper rear bun cushion */}
      <rect
        x={-hw * 0.92}
        y={-22 * sy}
        width={hw * 1.84}
        height={56 * sy}
        rx={28 * sy}
        fill={hd.bunShade}
      />
      {/* Juicy Sausage Ends extending left and right */}
      <rect
        x={-hw * 1.16}
        y={-8 * sy}
        width={hw * 2.32}
        height={44 * sy}
        rx={22 * sy}
        fill={hd.sausage}
      />
      {/* Sausage bottom shade */}
      <path
        d={`M ${(-hw * 1.12).toFixed(2)} ${(20 * sy).toFixed(2)}
            L ${(hw * 1.12).toFixed(2)} ${(20 * sy).toFixed(2)}
            Q ${(hw * 1.15).toFixed(2)} ${(36 * sy).toFixed(2)} ${(hw * 0.95).toFixed(2)} ${(36 * sy).toFixed(2)}
            L ${(-hw * 0.95).toFixed(2)} ${(36 * sy).toFixed(2)}
            Q ${(-hw * 1.15).toFixed(2)} ${(36 * sy).toFixed(2)} ${(-hw * 1.12).toFixed(2)} ${(20 * sy).toFixed(2)} Z`}
        fill={hd.sausageShade}
      />
    </g>
  );
};

const HotDogFront: React.FC<CostumeLayerProps> = ({ bodyW, bodyH, squash, arc }) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.78 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 14;
  const topY = hh * 0.34;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, ${topY.toFixed(2)})`}>
      {/* Sausage center band across chest */}
      <rect
        x={-hw * 1.02}
        y={-6 * sy}
        width={hw * 2.04}
        height={36 * sy}
        rx={18 * sy}
        fill={hd.sausage}
      />

      {/* Wavy Yellow Mustard Zigzag across sausage */}
      <path
        d={`M ${(-hw * 0.92).toFixed(2)} ${(8 * sy).toFixed(2)}
            Q ${(-hw * 0.72).toFixed(2)} ${(-6 * sy).toFixed(2)} ${(-hw * 0.54).toFixed(2)} ${(8 * sy).toFixed(2)}
            Q ${(-hw * 0.36).toFixed(2)} ${(22 * sy).toFixed(2)} ${(-hw * 0.18).toFixed(2)} ${(8 * sy).toFixed(2)}
            Q 0 ${(-6 * sy).toFixed(2)} ${(hw * 0.18).toFixed(2)} ${(8 * sy).toFixed(2)}
            Q ${(hw * 0.36).toFixed(2)} ${(22 * sy).toFixed(2)} ${(hw * 0.54).toFixed(2)} ${(8 * sy).toFixed(2)}
            Q ${(hw * 0.72).toFixed(2)} ${(-6 * sy).toFixed(2)} ${(hw * 0.92).toFixed(2)} ${(8 * sy).toFixed(2)}`}
        fill="none"
        stroke={hd.mustard}
        strokeWidth={10}
        strokeLinecap="round"
      />

      {/* Warm Toasted Front Bun Cushion */}
      <rect
        x={-hw * 0.95}
        y={16 * sy}
        width={hw * 1.9}
        height={48 * sy}
        rx={24 * sy}
        fill={hd.bun}
      />
      {/* Front bun lower shade */}
      <path
        d={`M ${(-hw * 0.88).toFixed(2)} ${(44 * sy).toFixed(2)}
            Q 0 ${(66 * sy).toFixed(2)} ${(hw * 0.88).toFixed(2)} ${(44 * sy).toFixed(2)}
            Q 0 ${(56 * sy).toFixed(2)} ${(-hw * 0.88).toFixed(2)} ${(44 * sy).toFixed(2)} Z`}
        fill={hd.bunShade}
      />
      {/* Front bun glossy top highlight */}
      <ellipse
        cx={-hw * 0.35}
        cy={26 * sy}
        rx={hw * 0.32}
        ry={5 * sy}
        fill="#FFE3B3"
        opacity={0.55}
      />
    </g>
  );
};

export const hotDogCostume: CostumeSpec = {
  Back: HotDogBack,
  Front: HotDogFront,
  hideAppendages: false, // Keep Grub's cute floppy ears, horns, and wagging tail visible!
};
