param(
  [string]$Ref = 'ReferenceVideo.mp4',
  [switch]$AllFrames
)
# Reference analysis: probe, contact sheets (1 tile = 2 s, 6x5 = 60 s), scene cuts.
New-Item -ItemType Directory -Force -Path 'analysis/contact' | Out-Null
ffprobe -v error -show_entries stream=width,height,r_frame_rate,nb_frames -show_entries format=duration -of json $Ref
ffmpeg -y -i $Ref -vf "fps=0.5,scale=320:-1,tile=6x5" -q:v 3 analysis/contact/sheet_%02d.jpg
ffmpeg -i $Ref -vf "select='gt(scene,0.35)',showinfo" -f null - 2>&1 |
  Select-String -Pattern 'pts_time:([0-9.]+)' -AllMatches |
  ForEach-Object { $_.Matches | ForEach-Object { [math]::Round([double]$_.Groups[1].Value, 2) } } |
  Out-File -Encoding utf8 analysis/ref_cuts.txt
if ($AllFrames) {
  New-Item -ItemType Directory -Force -Path 'reference_frames' | Out-Null
  ffmpeg -y -i $Ref -q:v 3 reference_frames/frame_%05d.jpg   # frame N = time (N-1)/30
}
Write-Host "Read analysis/contact/sheet_*.jpg first. Cuts in analysis/ref_cuts.txt"
