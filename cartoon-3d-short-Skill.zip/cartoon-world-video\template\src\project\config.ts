import type { ProjectConfig } from '../engine/types';

export const CONFIG: ProjectConfig = {
  title: 'The Great Molasses Flood (Boston, 1919)',
  format: 'portrait', // 'portrait' (9:16) | 'landscape' (16:9)
  resolution: '1080', // '1080' (Full HD) | '1440' (2K QHD)
  voiceFile: 'audio/vo.wav',
  music: {
    mood: 'whimsical',
    volume: 0.16,
    // Cut music right on "BOOM!" (w101) for dramatic punch
    stops: [{ at: 'w101', dur: 2.4 }],
    bpm: 114,
  },
  captions: true,
  tail: 1.2,
};
