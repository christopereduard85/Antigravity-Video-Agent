import React from 'react';
import { getBeatState } from '../rig/beat';

export interface CameraShot {
  /** Center X focal point in 1920x1080 stage coordinates (default 960) */
  focusX?: number;
  /** Center Y focal point in 1920x1080 stage coordinates (default 540) */
  focusY?: number;
  /** Camera zoom factor (1 = full 1920x1080 frame, 1.35 = Medium Close-Up) */
  zoom?: number;
  /** Dutch tilt angle in degrees */
  rotate?: number;
  /** Subtle beat-synced zoom pulse intensity (default 0.014) */
  beatPulse?: number;
  /** Smooth musical camera float intensity (default 0.6) */
  floatAmount?: number;
  /** Show warm foreground vignette for multi-plane depth */
  showVignette?: boolean;
}

export function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * clamp01(t);
}

export function easeOutCubic(t: number): number {
  const p = clamp01(t);
  return 1 - Math.pow(1 - p, 3);
}

export function easeInOutCubic(t: number): number {
  const p = clamp01(t);
  return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
}

/**
 * Studio 2.5D Multi-Plane Camera Rig.
 * Clamps focal offsets safely within overscanned set bounds so background edges are never exposed,
 * and keeps characters centered with generous headroom.
 */
export const CameraRig: React.FC<{
  frame: number;
  shot: CameraShot;
  children: React.ReactNode;
}> = ({ frame, shot, children }) => {
  const b = getBeatState(frame);

  const focusX = shot.focusX ?? 960;
  const focusY = shot.focusY ?? 540;
  const baseZoom = Math.max(1.0, shot.zoom ?? 1);
  const pulseAmp = shot.beatPulse ?? 0.014;
  const floatAmt = shot.floatAmount ?? 0.6;

  // Musical beat pulse on downbeats/beats + gentle figure-8 camera float
  const pulse = Math.max(0, -b.hop) * pulseAmp;
  const z = baseZoom * (1 + pulse);

  const floatX = Math.sin(frame * 0.045) * 5 * floatAmt;
  const floatY = Math.cos(frame * 0.07) * 3.5 * floatAmt;
  const rot = (shot.rotate ?? 0) + Math.sin(frame * 0.035) * 0.25 * floatAmt;

  const fx = focusX + floatX;
  const fy = focusY + floatY;

  // Transform around (fx, fy) and map to screen center (960, 540)
  const tx = 960 - fx * z;
  const ty = 540 - fy * z;

  return (
    <g>
      <g
        transform={`translate(960, 540) rotate(${rot.toFixed(
          3
        )}) translate(-960, -540) translate(${tx.toFixed(2)}, ${ty.toFixed(
          2
        )}) scale(${z.toFixed(4)})`}
      >
        {children}
      </g>

      {/* Subtle Warm Studio Lighting Vignette */}
      {(shot.showVignette ?? true) && (
        <g pointerEvents="none">
          <circle cx={120} cy={80} r={220} fill="rgba(255, 190, 90, 0.04)" />
          <circle cx={1800} cy={80} r={220} fill="rgba(255, 190, 90, 0.04)" />
        </g>
      )}
    </g>
  );
};
