import { CharacterTokens } from '../../rig/types';

/**
 * Grub (H4) — Orange dachshund-monster with D5 revision:
 * 2 tiny cream monster horns, darker orange monster spots, floppy ears, wagging tail, 4 short legs!
 */
export const grubTokens: CharacterTokens = {
  id: 'grub',
  name: 'Grub',
  height: 230,
  body: {
    shape: 'long',
    w: 196,
    h: 142,
    squareness: 0.34,
    topTaper: 0.88,
  },
  colors: {
    base: '#F79A3E',
    shade: '#D9771F',
    highlight: '#FFC885',
    belly: '#FFBE73',
    limb: '#E08328',
    feet: '#7A3E12',
    spots: '#C96512',
    blush: '#FF708A',
    mouth: '#5E1824',
    tongue: '#FF7A8A',
    teeth: '#FFFFFF',
    eyeWhite: '#FFFFFF',
    pupil: '#1B1B2A',
  },
  anchors: {
    shoulderL: { x: -0.88, y: 0.12 },
    shoulderR: { x: 0.88, y: 0.12 },
    hipL: { x: -0.32, y: 0.9 },
    hipR: { x: 0.32, y: 0.9 },
    eyes: [
      { x: -0.28, y: -0.24 },
      { x: 0.28, y: -0.24 },
    ],
    blush: [
      { x: -0.56, y: 0.02 },
      { x: 0.56, y: 0.02 },
    ],
    mouth: { x: 0, y: 0.14 },
    appendages: [
      { x: -0.68, y: -0.45 }, // floppy ear L
      { x: 0.68, y: -0.45 }, // floppy ear R
      { x: -0.32, y: -0.92 }, // tiny horn L (D5 revision)
      { x: 0.32, y: -0.92 }, // tiny horn R (D5 revision)
      { x: 0.82, y: 0.35 }, // wagging tail
    ],
  },
  spots: [
    { x: -0.62, y: 0.38, rx: 12, ry: 9, rot: -15 },
    { x: -0.42, y: 0.58, rx: 8, ry: 6, rot: 10 },
    { x: 0.62, y: 0.38, rx: 11, ry: 8, rot: 18 },
  ],
  extraLegPairs: [
    {
      hipL: { x: -0.64, y: 0.86 },
      hipR: { x: 0.64, y: 0.86 },
      footOffsetX: 34,
      footOffsetY: -2,
    },
  ],
  limbs: {
    armLen: [32, 30],
    legLen: [18, 16],
    width: [12, 10],
    hand: 'mitten3',
    foot: 'bean',
  },
  eyes: {
    count: 2,
    r: 18,
    pupilR: 10.5,
    catchlight: 3.8,
  },
  mouth: {
    w: 58,
    h: 34,
    hasFangs: true,
  },
  appendages: [
    {
      kind: 'ear',
      anchor: 0,
      segments: 2,
      length: 56,
      width: 30,
      tipR: 0,
      stiffness: 160,
      damping: 11,
      splay: -115,
      color: '#C96512',
      tipColor: '#9E4B08',
      layer: 'back',
    },
    {
      kind: 'ear',
      anchor: 1,
      segments: 2,
      length: 56,
      width: 30,
      tipR: 0,
      stiffness: 160,
      damping: 11,
      splay: 115,
      color: '#C96512',
      tipColor: '#9E4B08',
      layer: 'back',
    },
    {
      kind: 'horn',
      anchor: 2,
      segments: 1,
      length: 38,
      width: 22,
      tipR: 0,
      stiffness: 220,
      damping: 14,
      splay: -22,
      color: '#D8CEF0',
      tipColor: '#FFD23F',
      layer: 'back',
    },
    {
      kind: 'horn',
      anchor: 3,
      segments: 1,
      length: 38,
      width: 22,
      tipR: 0,
      stiffness: 220,
      damping: 14,
      splay: 22,
      color: '#D8CEF0',
      tipColor: '#FFD23F',
      layer: 'back',
    },
    {
      kind: 'tail',
      anchor: 4,
      segments: 2,
      length: 48,
      width: 10,
      tipR: 0,
      stiffness: 190,
      damping: 10,
      splay: 55,
      color: '#D9771F',
      layer: 'back',
    },
  ],
};
