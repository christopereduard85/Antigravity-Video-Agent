import React from 'react';
import { THEME } from '../../constants/theme';
import { getActiveCue, NarrationCue } from '../../../timing';

interface SubtitleDisplayProps {
  frame?: number;
  customText?: string;
  customHighlightIndex?: number;
}

export const SubtitleDisplay: React.FC<SubtitleDisplayProps> = ({
  frame,
  customText,
  customHighlightIndex,
}) => {
  let text = customText || '';
  let highlightWordIndex = customHighlightIndex ?? 0;

  if (frame !== undefined) {
    const cue: NarrationCue | undefined = getActiveCue(frame);
    if (!cue) {
      // Tidak ada narasi yang aktif di frame ini
      return null;
    }
    text = cue.text;
    const words = text.split(' ');
    const durationFrames = Math.max(1, cue.endFrame - cue.startFrame);
    const progress = Math.max(0, Math.min(1, (frame - cue.startFrame) / durationFrames));
    highlightWordIndex = Math.min(words.length - 1, Math.floor(progress * words.length));
  }

  if (!text) return null;

  const words = text.split(' ');

  return (
    <div
      style={{
        position: 'absolute',
        bottom: '80px',
        left: '120px',
        right: '120px',
        textAlign: 'center',
        zIndex: 60,
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          display: 'inline-block',
          fontFamily: THEME.typography.fontFamily,
          fontSize: '44px',
          fontWeight: 900,
          textTransform: 'uppercase',
          letterSpacing: '1.5px',
          lineHeight: 1.3,
          textShadow: '0 4px 12px rgba(0,0,0,0.9), 0 2px 4px rgba(0,0,0,0.8)',
          WebkitTextStroke: `3px ${THEME.colors.textStroke}`,
        }}
      >
        {words.map((word, idx) => {
          const isHighlighted = idx === highlightWordIndex;
          return (
            <span
              key={idx}
              style={{
                color: isHighlighted ? THEME.colors.textHighlight : THEME.colors.textWhite,
                marginRight: '14px',
                display: 'inline-block',
                transform: isHighlighted ? 'scale(1.08)' : 'scale(1)',
                transition: 'transform 0.08s ease',
              }}
            >
              {word}
            </span>
          );
        })}
      </div>
    </div>
  );
};
