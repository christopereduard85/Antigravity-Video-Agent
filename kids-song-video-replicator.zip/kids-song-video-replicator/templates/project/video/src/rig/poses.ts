import { CharacterTokens, Pose, Vec } from './types';
import { evalAutoBlink } from './spring';
import { getBeatState } from './beat';

/**
 * Neutral studio model-sheet pose (matches Row 1 Front View of H1_bobo_model_sheet.jpg:
 * arms arch gently out and down to lower hip level, fingers pointing down-outward).
 */
export function makeNeutralPose(
  tokens: CharacterTokens,
  root: Vec = { x: 960, y: 840 }
): Pose {
  const hw = tokens.body.w * 0.5;
  const hh = tokens.body.h * 0.5;
  return {
    root,
    jumpY: 0,
    squash: 0,
    lean: 0,
    arc: 0,
    handL: { x: -hw - 26, y: hh * 0.72 },
    handR: { x: hw + 26, y: hh * 0.72 },
    footL: { x: -hw * 0.34, y: 0 },
    footR: { x: hw * 0.34, y: 0 },
    look: { x: 0, y: 0 },
    blink: 0,
    viseme: 'mid',
    mouthOpen: 0.48,
    expression: 'happy',
  };
}

/**
 * Beat-locked dancing & singing pose (Rule 5, 8, 10, 11).
 */
export function makeBeatDancePose(
  tokens: CharacterTokens,
  frame: number,
  root: Vec = { x: 960, y: 840 },
  mode: 'idle' | 'sing' | 'dance' | 'jump' = 'dance',
  fps = 30
): Pose {
  const b = getBeatState(frame, fps);
  const hw = tokens.body.w * 0.5;
  const hh = tokens.body.h * 0.5;
  const blink = evalAutoBlink(frame, tokens.id);
  const bLag = getBeatState(Math.max(0, frame - 2), fps);

  if (mode === 'idle') {
    const squash = -b.hop * 0.14;
    return {
      root,
      jumpY: 0,
      squash,
      lean: b.sway * 2.5,
      arc: b.sway * 0.18,
      handL: { x: -hw - 26, y: hh * 0.68 + b.hop * 6 },
      handR: { x: hw + 26, y: hh * 0.68 + bLag.hop * 6 },
      footL: { x: -hw * 0.34, y: 0 },
      footR: { x: hw * 0.34, y: 0 },
      look: { x: b.sway * 0.15, y: 0 },
      blink,
      viseme: b.mouthOpen > 0.15 ? b.viseme : 'closed',
      mouthOpen: b.mouthOpen,
      expression: 'happy',
    };
  }

  if (mode === 'sing') {
    const squash = -b.hop * 0.22;
    const waveL = Math.sin(b.beatFloat * Math.PI) * 24;
    return {
      root: { x: root.x + b.sway * 10, y: root.y },
      jumpY: Math.max(0, b.hop * 8),
      squash,
      lean: b.sway * 5,
      arc: b.sway * 0.32,
      // Left hand waves gracefully at side, right hand holds mic near mouth (below eyes!)
      handL: { x: -hw - 36, y: hh * 0.35 - waveL },
      handR: { x: hw * 0.62, y: hh * 0.42 },
      footL: { x: -hw * 0.35, y: Math.max(0, b.sway * -8) },
      footR: { x: hw * 0.35, y: Math.max(0, b.sway * 8) },
      look: { x: b.sway * 0.22, y: -0.05 },
      blink,
      viseme: b.mouthOpen > 0.15 ? b.viseme : 'closed',
      mouthOpen: b.mouthOpen,
      expression: 'happy',
    };
  }

  if (mode === 'jump') {
    const jumpPhase = (Math.sin(b.beatFloat * Math.PI) + 1) * 0.5;
    const jumpY = 26 + jumpPhase * 32;
    const squash = -0.22;
    return {
      root,
      jumpY,
      squash,
      lean: -8,
      arc: 0.28,
      handL: { x: -hw - 52, y: -hh * 0.32 },
      handR: { x: hw + 52, y: -hh * 0.42 },
      footL: { x: -hw * 0.42, y: -10 },
      footR: { x: hw * 0.45, y: -16 },
      look: { x: 0.08, y: -0.08 },
      blink,
      viseme: 'mid',
      mouthOpen: 0.65,
      expression: 'happy',
    };
  }

  // Energetic Chorus Dance ('dance') — also sings along accurately with the lyrics!
  const squash = -b.hop * 0.28;
  const jumpY = Math.max(0, b.hop * 20);
  const armUpL = Math.sin(b.beatFloat * Math.PI) * 36;
  const armUpR = -Math.sin(bLag.beatFloat * Math.PI) * 36;

  return {
    root: { x: root.x + b.sway * 16, y: root.y },
    jumpY,
    squash,
    lean: b.sway * 6.5,
    arc: b.sway * 0.4,
    handL: { x: -hw - 44, y: hh * 0.22 - armUpL },
    handR: { x: hw + 44, y: hh * 0.22 - armUpR },
    footL: { x: -hw * 0.36, y: Math.max(0, -b.sway * 14) },
    footR: { x: hw * 0.36, y: Math.max(0, b.sway * 14) },
    look: { x: b.sway * 0.25, y: 0 },
    blink,
    viseme: b.mouthOpen > 0.15 ? b.viseme : 'closed',
    mouthOpen: b.mouthOpen,
    expression: 'happy',
  };
}
