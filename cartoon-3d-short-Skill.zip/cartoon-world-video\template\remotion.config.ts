// Remotion CLI config. Do not edit per video.
import fs from 'node:fs';
import { Config } from '@remotion/cli/config';

const CHROME_PATHS = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
];
for (const p of CHROME_PATHS) {
  if (fs.existsSync(p)) {
    Config.setBrowserExecutable(p);
    break;
  }
}

Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setOverwriteOutput(true);
// GPU WebGL through ANGLE. Works on Windows (D3D11), macOS (Metal) and Linux with a GPU.
// If you get a black video or "WebGL not supported", run with --gl=swangle (slow, CPU).
Config.setChromiumOpenGlRenderer('angle');
Config.setConcurrency(2);
Config.setDelayRenderTimeoutInMilliseconds(120000);
