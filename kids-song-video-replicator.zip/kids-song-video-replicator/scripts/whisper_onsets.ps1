param(
  [Parameter(Mandatory = $true)][string]$Song,
  [string]$Model = 'analysis/models/ggml-base.en.bin'
)
# Vocal onset transcription with ffmpeg's native whisper filter (ffmpeg >= 8).
# Model: https://huggingface.co/ggerganov/whisper.cpp/tree/main  (ggml-base.en.bin or ggml-small.en.bin)
if (-not (Test-Path $Model)) { Write-Error "Missing $Model. Download it first."; exit 1 }
$m = $Model.Replace('\', '/')
ffmpeg -y -i $Song -vn -af "whisper=model=${m}:language=en:queue=3:destination=analysis/whisper.srt:format=srt" -f null -
ffmpeg -y -i $Song -vn -af "whisper=model=${m}:language=en:queue=12:destination=analysis/whisper12.srt:format=srt" -f null -
Write-Host "Wrote analysis/whisper.srt and analysis/whisper12.srt. Use earliest believable start per lyric line -> STARTS in build_timing.py"
Write-Host "Slice audio to double-check: ffmpeg -y -ss <sec> -t 12 -i `"$Song`" analysis/audio_check/slice_<sec>s.mp3"
