import fs from 'fs';
import path from 'path';

/**
 * Universal Procedural Audio Synthesizer for Remotion Storytelling Videos
 * Generates CD-Quality 44.1kHz, 16-bit Stereo PCM WAV files with ZERO external audio dependencies.
 */

const SAMPLE_RATE = 44100;

function createWavBuffer(samples, sampleRate = SAMPLE_RATE, numChannels = 2) {
  const byteRate = sampleRate * numChannels * 2;
  const blockAlign = numChannels * 2;
  const dataSize = samples.length * 2;
  const buffer = Buffer.alloc(44 + dataSize);

  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);

  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20); // PCM
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(16, 34); // 16-bit

  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    buffer.writeInt16LE(Math.floor(s < 0 ? s * 0x8000 : s * 0x7fff), offset);
    offset += 2;
  }

  return buffer;
}

// 1. REALISTIC ACOUSTIC SHOE FOOTSTEPS (Tuk... Tuk... Tuk... - NO WHITE NOISE)
export function generateFootsteps(duration = 6.3, stepCadence = 0.58) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  const stepTimes = [];
  for (let t = 0.2; t < duration - 0.3; t += stepCadence) {
    stepTimes.push(t);
  }

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let valL = 0;
    let valR = 0;

    for (let sIdx = 0; sIdx < stepTimes.length; sIdx++) {
      const st = stepTimes[sIdx];
      if (t >= st && t <= st + 0.22) {
        const dt = t - st;
        // Heel strike (140 Hz dropping to 55 Hz)
        const heelPhase = 2 * Math.PI * (55 * dt - (85 / 45) * Math.exp(-dt * 45));
        const heel = Math.sin(heelPhase) * Math.exp(-dt * 32) * 0.75;
        // Sole tap (340 Hz & 520 Hz)
        const tap = (Math.sin(2 * Math.PI * 340 * dt) * 0.6 + Math.sin(2 * Math.PI * 520 * dt) * 0.25) * Math.exp(-dt * 55);
        // Floor body cavity resonance (110 Hz)
        const floorRes = Math.sin(2 * Math.PI * 110 * dt) * Math.exp(-dt * 20) * 0.3;

        const step = (heel + tap + floorRes) * 0.7;
        const isLeft = sIdx % 2 === 0;
        valL += step * (isLeft ? 0.95 : 0.65);
        valR += step * (isLeft ? 0.65 : 0.95);
      }
    }

    stereo[i * 2] = Math.tanh(valL);
    stereo[i * 2 + 1] = Math.tanh(valR);
  }
  return stereo;
}

// 2. HEAVY WOODEN LOCKED DOOR RATTLE (NO METAL PIPE RINGING)
export function generateLockedDoorRattle(duration = 2.8) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  const events = [
    { t: 0.10, p: 0.75 }, { t: 0.18, p: 0.55 },
    { t: 0.50, p: 0.95 }, { t: 0.59, p: 0.70 },
    { t: 1.10, p: 1.00 }, { t: 1.21, p: 0.85 }, { t: 1.32, p: 0.90 },
    { t: 1.45, p: 0.75 }, { t: 1.60, p: 0.85 },
    { t: 2.05, p: 0.70 }, { t: 2.18, p: 0.45 }
  ];

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let val = 0;

    for (const ev of events) {
      if (t >= ev.t && t <= ev.t + 0.25) {
        const dt = t - ev.t;
        // Heavy wood panel thump (50 - 110 Hz)
        const woodPhase = 2 * Math.PI * (50 * dt - (60 / 30) * Math.exp(-dt * 30));
        const woodThump = Math.sin(woodPhase) * Math.exp(-dt * 24) * 0.85;
        // Body resonance (135 Hz & 210 Hz)
        const bodyRes = (Math.sin(2 * Math.PI * 135 * dt) * 0.5 + Math.sin(2 * Math.PI * 210 * dt) * 0.3) * Math.exp(-dt * 38);
        // Deadbolt strain click (360 Hz)
        const latchClick = Math.sin(2 * Math.PI * 360 * dt) * Math.exp(-dt * 70) * 0.4;
        val += (woodThump + bodyRes + latchClick) * ev.p;
      }
    }

    val = Math.tanh(val * 1.1);
    stereo[i * 2] = val * 0.9;
    stereo[i * 2 + 1] = val * 1.0;
  }
  return stereo;
}

// 3. DUAL HAPTIC PHONE VIBRATION
export function generatePhoneVibrate(duration = 2.0) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let env = 0;
    if (t >= 0.1 && t <= 0.5) env = Math.sin(((t - 0.1) / 0.4) * Math.PI);
    else if (t >= 0.75 && t <= 1.2) env = Math.sin(((t - 0.75) / 0.45) * Math.PI);

    if (env > 0) {
      const motor = Math.sin(2 * Math.PI * 165 * t) * 0.7 + Math.sin(2 * Math.PI * 82 * t) * 0.3;
      const rattle = (Math.random() * 2 - 1) * 0.25 * (Math.sin(2 * Math.PI * 35 * t) > 0 ? 1 : 0);
      const val = (motor + rattle) * env * 0.85;
      stereo[i * 2] = val;
      stereo[i * 2 + 1] = val;
    }
  }
  return stereo;
}

// 4. CHAT MESSAGE POP CHIME
export function generateMessagePop() {
  const duration = 0.8;
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let val = 0;
    if (t < 0.05) {
      const freq = 600 + (t / 0.05) * 800;
      val += Math.sin(2 * Math.PI * freq * t) * 0.4 * (1 - t / 0.05);
    }
    const decay = Math.exp(-t * 9);
    val += (Math.sin(2 * Math.PI * 920 * t) + Math.sin(2 * Math.PI * 1840 * t) * 0.45) * decay * 0.7;
    stereo[i * 2] = val;
    stereo[i * 2 + 1] = val;
  }
  return stereo;
}

// 5. HEARTBEAT THUMP
export function generateHeartbeat(duration = 3.2) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);
  const thumps = [0.15, 0.42, 1.35, 1.62];

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let val = 0;
    for (const start of thumps) {
      if (t >= start && t <= start + 0.28) {
        const dt = t - start;
        const env = Math.sin((dt / 0.28) * Math.PI) * Math.exp(-dt * 8);
        val += Math.sin(2 * Math.PI * (52 - dt * 25) * dt) * env * 0.9;
      }
    }
    val = Math.tanh(val * 1.3);
    stereo[i * 2] = val;
    stereo[i * 2 + 1] = val;
  }
  return stereo;
}

// 6. DANGER / TENSION STING
export function generateDangerSting(duration = 3.5) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    const impactEnv = t < 0.08 ? t / 0.08 : Math.exp(-(t - 0.08) * 1.8);
    const subFreq = Math.max(35, 75 - t * 15);
    const sub = Math.sin(2 * Math.PI * subFreq * t);
    const cluster = (Math.sin(2 * Math.PI * 220 * t) + Math.sin(2 * Math.PI * 233.08 * t) + Math.sin(2 * Math.PI * 311.13 * t)) / 3;
    const val = Math.tanh((sub * 0.65 + cluster * 0.45) * impactEnv * 1.4);
    stereo[i * 2] = val;
    stereo[i * 2 + 1] = val * 0.95;
  }
  return stereo;
}

// 7. CINEMATIC DARK AMBIENT BGM WITH VOCAL EQ SCOOP
export function generateDarkBGM(duration = 104.0) {
  const totalSamples = Math.floor(duration * SAMPLE_RATE);
  const stereo = new Float32Array(totalSamples * 2);

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let masterEnv = 1.0;
    if (t < 4.0) masterEnv = t / 4.0;
    else if (t > duration - 6.0) masterEnv = Math.max(0, (duration - t) / 6.0);

    const sub = Math.sin(2 * Math.PI * 36.71 * t) * 0.45 + Math.sin(2 * Math.PI * 73.42 * t) * 0.35;
    const pad = (Math.sin(2 * Math.PI * 73.42 * t) * 0.3 + Math.sin(2 * Math.PI * 110.0 * t) * 0.25) * 0.7;
    const diss = t > 18 ? Math.sin(2 * Math.PI * 155.56 * t) * 0.15 : 0;

    const left = (sub * 0.5 + pad * 0.55 + diss * 0.4) * masterEnv;
    const right = (sub * 0.5 + pad * 0.55 + diss * 0.45) * masterEnv;
    stereo[i * 2] = Math.tanh(left * 0.7);
    stereo[i * 2 + 1] = Math.tanh(right * 0.7);
  }
  return stereo;
}

// CLI runner if invoked directly: node audio_synthesizer.mjs <targetDir>
if (process.argv[1] && process.argv[1].endsWith('audio_synthesizer.mjs')) {
  const targetDir = process.argv[2] || path.resolve('public', 'sfx');
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

  const tasks = [
    { name: 'footsteps.wav', fn: () => generateFootsteps() },
    { name: 'door_rattle.wav', fn: () => generateLockedDoorRattle() },
    { name: 'phone_vibrate.wav', fn: () => generatePhoneVibrate() },
    { name: 'message_pop.wav', fn: () => generateMessagePop() },
    { name: 'heartbeat.wav', fn: () => generateHeartbeat() },
    { name: 'danger_sting.wav', fn: () => generateDangerSting() },
    { name: 'bgm_ambient.wav', fn: () => generateDarkBGM(104) },
  ];

  for (const t of tasks) {
    const buf = createWavBuffer(t.fn());
    fs.writeFileSync(path.join(targetDir, t.name), buf);
    console.log(`Generated: ${t.name} (${(buf.length / 1024).toFixed(1)} KB)`);
  }
}
