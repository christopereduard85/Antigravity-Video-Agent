import React from 'react';
import { THEME } from '../../constants/theme';

interface SmartphoneProps {
  vibrate?: boolean;
  msg1Progress?: number; // 0 to 1 spring progress
  msg2Progress?: number; // 0 to 1 spring progress
  alertRed?: boolean;    // Ketika pesan kedua masuk (alarm darurat)
}

export const Smartphone: React.FC<SmartphoneProps> = ({
  vibrate = false,
  msg1Progress = 1,
  msg2Progress = 0,
  alertRed = false,
}) => {
  // Getaran halus alami smartphone
  const vibX = vibrate ? (Math.random() - 0.5) * 6 : 0;
  const vibY = vibrate ? (Math.random() - 0.5) * 6 : 0;

  return (
    <div
      style={{
        position: 'relative',
        width: '380px',
        height: '720px',
        backgroundColor: '#090D1A',
        borderRadius: '46px',
        border: '6px solid #1E293B',
        boxShadow: alertRed
          ? '0 30px 100px rgba(0,0,0,0.95), 0 0 60px rgba(239, 68, 68, 0.45)'
          : '0 30px 100px rgba(0,0,0,0.95), 0 0 60px rgba(59, 130, 246, 0.35)',
        transform: `translate(${vibX}px, ${vibY}px)`,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        transition: 'box-shadow 0.3s ease',
      }}
    >
      {/* Dynamic Island / Notch & Speaker */}
      <div
        style={{
          position: 'absolute',
          top: '14px',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '110px',
          height: '24px',
          backgroundColor: '#000000',
          borderRadius: '16px',
          zIndex: 25,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '10px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.8)',
        }}
      >
        <div style={{ width: '48px', height: '4px', backgroundColor: '#1E293B', borderRadius: '2px' }} />
        <div style={{ width: '8px', height: '8px', backgroundColor: '#0F172A', borderRadius: '50%', border: '1px solid #1E293B' }} />
      </div>

      {/* Layar OLED Lengkap */}
      <div
        style={{
          position: 'absolute',
          inset: '8px',
          backgroundColor: '#050811',
          borderRadius: '38px',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          padding: '48px 22px 24px 22px',
        }}
      >
        {/* Kilau Kaca Pantulan Sinematik */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: '-60%',
            width: '120%',
            height: '100%',
            background: 'linear-gradient(115deg, rgba(255,255,255,0.06) 0%, transparent 60%)',
            pointerEvents: 'none',
            zIndex: 20,
          }}
        />

        {/* Ambient Glow di Layar */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: alertRed
              ? 'radial-gradient(circle at 50% 30%, rgba(220, 38, 38, 0.22) 0%, transparent 80%)'
              : 'radial-gradient(circle at 50% 25%, rgba(59, 130, 246, 0.18) 0%, transparent 80%)',
            pointerEvents: 'none',
            transition: 'background 0.5s ease',
          }}
        />

        {/* Status Bar Atas */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            fontSize: '12px',
            color: '#94A3B8',
            fontFamily: THEME.typography.fontFamily,
            fontWeight: 700,
            marginBottom: '26px',
            zIndex: 10,
          }}
        >
          <span>23:41</span>
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            <span style={{ fontSize: '10px' }}>5G</span>
            <div
              style={{
                width: '20px',
                height: '10px',
                border: '1.5px solid #94A3B8',
                borderRadius: '3px',
                padding: '1px',
              }}
            >
              <div style={{ width: '85%', height: '100%', backgroundColor: '#22C55E', borderRadius: '1px' }} />
            </div>
          </div>
        </div>

        {/* Header Kontak "Mom" */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '14px',
            backgroundColor: 'rgba(15, 23, 42, 0.65)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '20px',
            padding: '12px 16px',
            marginBottom: '28px',
            zIndex: 10,
            boxShadow: '0 8px 25px rgba(0,0,0,0.5)',
          }}
        >
          {/* Avatar Mom */}
          <div
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              backgroundColor: '#7C3AED',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 900,
              fontSize: '20px',
              color: '#FFF',
              fontFamily: THEME.typography.fontFamily,
              boxShadow: '0 0 16px rgba(124, 58, 237, 0.65)',
            }}
          >
            M
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ color: '#F8FAFC', fontWeight: 800, fontSize: '17px', fontFamily: THEME.typography.fontFamily }}>
              Mom
            </div>
            <div style={{ color: '#4ADE80', fontSize: '11px', fontWeight: 600, fontFamily: THEME.typography.fontFamily }}>
              iMessage • Online
            </div>
          </div>
        </div>

        {/* Kontainer Balon Chat */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', zIndex: 10 }}>
          {/* PESAN 1: "Don't go inside." */}
          {msg1Progress > 0 && (
            <div
              style={{
                alignSelf: 'flex-start',
                maxWidth: '88%',
                backgroundColor: 'rgba(30, 41, 59, 0.95)',
                borderRadius: '20px 20px 20px 6px',
                padding: '16px 20px',
                border: '1.5px solid #475569',
                boxShadow: '0 10px 25px rgba(0,0,0,0.6)',
                transform: `translateY(${(1 - msg1Progress) * 35}px) scale(${0.88 + msg1Progress * 0.12})`,
                opacity: msg1Progress,
              }}
            >
              <div
                style={{
                  color: '#FCA5A5',
                  fontWeight: 900,
                  fontSize: '20px',
                  fontFamily: THEME.typography.fontFamily,
                  letterSpacing: '0.4px',
                }}
              >
                Don't go inside.
              </div>
              <div style={{ color: '#64748B', fontSize: '11px', textAlign: 'right', marginTop: '6px' }}>
                23:41
              </div>
            </div>
          )}

          {/* PESAN 2: "He's already in your apartment." */}
          {msg2Progress > 0 && (
            <div
              style={{
                alignSelf: 'flex-start',
                maxWidth: '92%',
                backgroundColor: 'rgba(69, 10, 10, 0.95)',
                borderRadius: '20px 20px 20px 6px',
                padding: '16px 20px',
                border: '2px solid #EF4444',
                boxShadow: '0 12px 35px rgba(220, 38, 38, 0.55), 0 0 20px rgba(239, 68, 68, 0.4)',
                transform: `translateY(${(1 - msg2Progress) * 45}px) scale(${0.85 + msg2Progress * 0.15})`,
                opacity: msg2Progress,
              }}
            >
              <div
                style={{
                  color: '#FEF2F2',
                  fontWeight: 900,
                  fontSize: '21px',
                  fontFamily: THEME.typography.fontFamily,
                  letterSpacing: '0.4px',
                  lineHeight: 1.3,
                  textShadow: '0 0 14px rgba(239, 68, 68, 0.8)',
                }}
              >
                He's already in your apartment.
              </div>
              <div style={{ color: '#FCA5A5', fontSize: '11px', textAlign: 'right', marginTop: '6px' }}>
                23:42
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
