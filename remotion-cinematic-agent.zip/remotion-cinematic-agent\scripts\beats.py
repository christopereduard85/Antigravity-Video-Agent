import os
import json
import argparse

def split_into_beats(sentences, target_dur=3.0, min_dur=1.2, max_dur=6.5):
    """
    Memecah kalimat menjadi 'beat' (frasa yang mendapat satu gambar/shot visual).
    Target: 3.0 detik, Maksimum: 6.5 detik, Minimum: 1.2 detik.
    """
    beats = []
    beat_id = 1

    for s in sentences:
        s_dur = s["end"] - s["start"]
        text = s["text"]

        if s_dur <= max_dur:
            # Kalimat pas dalam 1 beat
            beats.append({
                "id": beat_id,
                "sentence_id": s.get("id", beat_id),
                "start": s["start"],
                "end": s["end"],
                "duration": round(s_dur, 2),
                "text": text
            })
            beat_id += 1
        else:
            # Kalimat terlalu panjang, pecah berdasarkan tanda baca koma, titik koma, atau kata penghubung
            clauses = [c.strip() for c in text.replace(';', ',').replace(' - ', ',').split(',') if c.strip()]
            if len(clauses) <= 1:
                # Pecah berdasarkan jumlah kata jika tidak ada tanda baca
                words = text.split()
                mid = len(words) // 2
                clauses = [" ".join(words[:mid]), " ".join(words[mid:])]

            total_chars = sum(len(c) for c in clauses)
            cur_start = s["start"]

            for c in clauses:
                share = len(c) / max(1, total_chars)
                c_dur = s_dur * share
                beats.append({
                    "id": beat_id,
                    "sentence_id": s.get("id", beat_id),
                    "start": round(cur_start, 3),
                    "end": round(cur_start + c_dur, 3),
                    "duration": round(c_dur, 2),
                    "text": c
                })
                cur_start += c_dur
                beat_id += 1

    return beats

def generate_draft_shots(beats):
    """
    Menghasilkan draf awal story/shots.json dari beats dengan scene: 'TODO'.
    Potong 0.1 - 0.2 detik sebelum frasa dimulai.
    """
    shots = []
    for b in beats:
        # Pre-cut 0.15s sebelum frasa agar transisi visual tidak telat
        adjusted_start = max(0.0, round(b["start"] - 0.15, 2))
        shots.append({
            "id": f"shot_{b['id']:03d}",
            "beat_id": b["id"],
            "startSec": adjusted_start,
            "endSec": b["end"],
            "durationSec": round(b["end"] - adjusted_start, 2),
            "text": b["text"],
            "scene": "TODO",
            "camera": "static",
            "transition": "cut",
            "sfx": [],
            "ambience": None
        })

    # Pastikan shots berurutan tanpa celah
    for i in range(len(shots) - 1):
        shots[i]["endSec"] = shots[i + 1]["startSec"]
        shots[i]["durationSec"] = round(shots[i]["endSec"] - shots[i]["startSec"], 2)

    return shots

def main():
    parser = argparse.ArgumentParser(description="Split sentences into cinematic visual beats")
    parser.add_argument("--sentences", required=True, help="Path ke timeline/sentences.json")
    parser.add_argument("--outdir_timeline", required=True, help="Folder timeline output")
    parser.add_argument("--outdir_story", required=True, help="Folder story output")

    args = parser.parse_args()
    os.makedirs(args.outdir_timeline, exist_ok=True)
    os.makedirs(args.outdir_story, exist_ok=True)

    with open(args.sentences, "r", encoding="utf-8") as f:
        sentences = json.load(f)

    beats = split_into_beats(sentences)
    draft_shots = generate_draft_shots(beats)

    beats_path = os.path.join(args.outdir_timeline, "beats.json")
    with open(beats_path, "w", encoding="utf-8") as f:
        json.dump(beats, f, indent=2, ensure_ascii=False)

    shots_path = os.path.join(args.outdir_story, "shots.json")
    with open(shots_path, "w", encoding="utf-8") as f:
        json.dump(draft_shots, f, indent=2, ensure_ascii=False)

    print(f"[SUCCESS] Generated {len(beats)} beats in {beats_path}")
    print(f"[SUCCESS] Generated draft shots in {shots_path} with scene: 'TODO'")

if __name__ == "__main__":
    main()
