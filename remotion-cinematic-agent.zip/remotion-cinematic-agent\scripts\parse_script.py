import os
import re
import json
import argparse

def parse_time_str(t_str):
    """Konversi waktu SRT (00:01:23,456) atau VTT (00:01:23.456) atau [mm:ss] ke detik."""
    t_str = t_str.strip()
    # Format [mm:ss] atau [m:ss.xx]
    m_short = re.match(r'\[?(\d+):(\d+(?:\.\d+)?)\]?', t_str)
    if m_short:
        mins = float(m_short.group(1))
        secs = float(m_short.group(2))
        return mins * 60.0 + secs

    # Format HH:MM:SS,mmm atau HH:MM:SS.mmm
    parts = re.split(r'[:,\.]', t_str)
    if len(parts) >= 3:
        h = float(parts[0])
        m = float(parts[1])
        s = float(parts[2])
        ms = float(parts[3]) if len(parts) > 3 else 0.0
        if ms > 0:
            if len(parts[3]) == 3: ms = ms / 1000.0
            elif len(parts[3]) == 2: ms = ms / 100.0
        return h * 3600.0 + m * 60.0 + s + ms
    return 0.0

def distribute_words_proportionally(sentence_text, start_sec, end_sec):
    """Membagi waktu per kata proporsional berdasarkan panjang karakter kata."""
    words = sentence_text.strip().split()
    if not words:
        return []
    total_chars = sum(len(w) for w in words)
    duration = max(0.1, end_sec - start_sec)
    
    word_items = []
    current_time = start_sec
    for w in words:
        share = len(w) / max(1, total_chars)
        w_dur = duration * share
        word_items.append({
            "word": w,
            "start": round(current_time, 3),
            "end": round(current_time + w_dur, 3)
        })
        current_time += w_dur
    return word_items

def main():
    parser = argparse.ArgumentParser(description="Parse Timestamped Script (SRT/VTT/JSON/TXT)")
    parser.add_argument("--input", required=True, help="Path ke script bertimestamp")
    parser.add_argument("--outdir", required=True, help="Folder timeline output")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    ext = os.path.splitext(args.input)[1].lower()

    sentences = []
    
    with open(args.input, "r", encoding="utf-8") as f:
        content = f.read()

    if ext == ".json":
        data = json.loads(content)
        if isinstance(data, list):
            sentences = data
        elif "sentences" in data:
            sentences = data["sentences"]
    elif ext in [".srt", ".vtt"]:
        # Regex SRT / VTT cue parser
        cue_pattern = re.compile(
            r'(?:(\d+)\s+)?(\d{1,2}:\d{2}:\d{2}[,\.]\d{2,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,\.]\d{2,3})\s*\n(.*?)(?=\n\s*(?:\d+\s+)?\d{1,2}:\d{2}:\d{2}|$)',
            re.DOTALL
        )
        matches = cue_pattern.findall(content)
        for idx, m in enumerate(matches):
            s_start = parse_time_str(m[1])
            s_end = parse_time_str(m[2])
            text = " ".join(line.strip() for line in m[3].strip().splitlines())
            if text:
                sentences.append({
                    "id": idx + 1,
                    "start": round(s_start, 3),
                    "end": round(s_end, 3),
                    "text": text
                })
    else:
        # TXT dengan format [mm:ss] atau [hh:mm:ss] per baris
        lines = content.splitlines()
        for idx, line in enumerate(lines):
            m = re.match(r'\[?(\d+:\d+(?::\d+)?(?:[,\.]\d+)?)\]?\s*(.*)', line.strip())
            if m:
                s_start = parse_time_str(m.group(1))
                text = m.group(2).strip()
                sentences.append({
                    "id": idx + 1,
                    "start": round(s_start, 3),
                    "end": round(s_start + 3.0, 3), # default jika tanpa end
                    "text": text
                })
        # Sesuaikan end waktu baris n dengan start baris n+1
        for i in range(len(sentences) - 1):
            sentences[i]["end"] = sentences[i + 1]["start"]

    # Generate words.json dengan distribusi proporsional
    all_words = []
    full_transcript_text = []
    for s in sentences:
        full_transcript_text.append(s["text"])
        words = distribute_words_proportionally(s["text"], s["start"], s["end"])
        all_words.extend(words)

    # Simpan sentences.json
    with open(os.path.join(args.outdir, "sentences.json"), "w", encoding="utf-8") as f:
        json.dump(sentences, f, indent=2, ensure_ascii=False)

    # Simpan words.json
    with open(os.path.join(args.outdir, "words.json"), "w", encoding="utf-8") as f:
        json.dump(all_words, f, indent=2, ensure_ascii=False)

    # Simpan transcript.txt
    with open(os.path.join(args.outdir, "transcript.txt"), "w", encoding="utf-8") as f:
        f.write("\n\n".join(full_transcript_text))

    print(f"[SUCCESS] Parsed {len(sentences)} sentences and {len(all_words)} words into {args.outdir}")

if __name__ == "__main__":
    main()
