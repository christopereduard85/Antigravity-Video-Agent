# Character gag loops (the "cat presses the button" recipe)

Short character gags (6-10 s, one character, one prop, one consequence), in whatever style the reference sets.
This is the workflow behind the wall-button cat: hesitate, try, BOOM, crumble to dust.

## 1. Reference first, never a description

Ask for (or find) one image of the look: a still, a GIF or a screenshot. Describe to yourself what makes it
work before drawing: number of colours, whether there are outlines, how heads and bodies merge, eye style.
"A cute cat" with no reference produces a generic, childish drawing. One reference fixes it.

## 2. Lock one style and follow it strictly

There is no universally right style (outlines or none, flat or shaded, chibi or realistic). What breaks an
animation is drifting between styles, or adding detail the style doesn't have. Before any code:

- Write a **style sheet** from the reference: palette (exact hex values), line treatment (outlines yes/no,
  weight), shading (flat, cel, gradient), proportions (head-to-body ratio), how eyes and faces are drawn,
  level of detail.
- Put it in the file header next to the beat sheet, and check every new shape against it.
- When the person says something "looks off" or "childish", compare the frame against the reference and the
  style sheet first; the fix is usually removing what isn't in the reference, not adding more.

## 3. Beats of a gag loop (8.9 s example at 30 fps)

| Beat | Time | What sells it |
|---|---|---|
| LOOK | 0.6-1.6 s | eyes glance at the prop, head follows 3 frames later |
| REACH | 1.6-2.6 s | slow ease-in reach, paw trembles near the target |
| DOUBT | 2.6-3.4 s | fast retreat (3-4x faster than the reach), brows worried |
| COMMIT | 3.4-3.85 s | brows go flat, short anticipation, a 3-frame jab |
| PAUSE | 3.85-4.8 s | relief: nothing happens. Silence. Hold ~1 s |
| BOOM | 4.8 s | 2 flash frames, shock shape, then the result: charred, smoking, blinking |
| CRUMBLE | 6.75 s | the body falls to dust under gravity into a pile; the eyes stay on top |
| LOOP | end | iris out / back to frame 0 |

Timing is the acting: **slow when he doubts, fast when he commits, silence right before the boom.**
The pause before the payoff is the joke. Never jump from press to explosion.

## 4. Build notes

- Draw each frame as SVG from a pure function `frame(t)`; pose = keyed params (reach, lean, brows, eyes).
- Dust: render the charred silhouette once to a canvas, sample its filled pixels every 3 px, and give each
  grain a delay that grows from the top down, then gravity + a little drift, landing on a pile shape.
- Sound (optional): a click on the press, a beat of silence, a boom, then a soft sand hiss for the crumble.

## 5. Self-review

Render one still per beat (LOOK, REACH, DOUBT, COMMIT, PAUSE, BOOM, CRUMBLE) in a contact sheet. Check: every frame
matches the style sheet, the PAUSE frame is still calm (not already exploding), the first frame of each beat isn't
empty, eyes aren't frozen mid-blink on a hold.
