# 04 — Characters: design → tokens → rigs → costumes

Full spec: `templates/project/docs/CHARACTER_DESIGN_SYSTEM.md` (12 anti-"pasted SVG" rules, rig architecture, Pose/Tokens contract, layer order, costume sandwich rule, animation language, QA gate). Read it fully before touching characters.

## Step A — roster (ask user)

Rule from lyrics: verse lines say "I'm gonna be…" → **one solo hero per verse**; finale says "We're all…" → everyone together. Original roster (8):

| ID | Name | Role | Costume |
|---|---|---|---|
| H1 | Bobo – lime bean monster, 2 spring antennae | verse 1 | Burger |
| H2 | Lulu – tall lavender noodle, floppy ears | verse 2 | Ice cream cone |
| H3 | Ziggy – short wide blue, 3 eyes, horns | verse 3 | Sprinkled donut |
| H4 | Grub – long low orange dachshund-monster, 4 legs, horns, toothy grin | verse 4 | Hot dog |
| B1 | Bones – skeleton drummer | band | — |
| B2 | Spinny – purple spider bassist | band | — |
| B3 | Boo – ghost saxophonist | band + outro | — |
| M1 | Pip – bat, intro mascot | intro | — |

Ask the user: use these / give own designs / agent designs new ones. Lock the answer in `NEXT_STEPS.md` "LOCKED DECISIONS".

## Step B — concept model sheets (optional but recommended)

Use an image-generation tool/subagent with `templates/project/docs/PROMPT_TEMPLATE.md`. Output `characters/design/<ID>_<name>_model_sheet.jpg` (turnaround row, costume row, expressions + 3 mouth shapes row). Show user, get approval. Concept art is ONLY a visual target — never import it as an asset.

Approved examples are in `examples/` (H1 Bobo sheet, H2 Lulu sheet, cast lineup).

## Step C — build (template already contains all of this)

1. Rig engine `video/src/rig/` is generic — reuse untouched.
2. Each hero = `characters/<id>/tokens.ts` (shape, colours, anchors, limb lengths, appendage springs) + `<Name>.tsx` (wraps `<Character tokens=…/>`) + `costume/<Food>.tsx` exporting back/front layers.
3. Band/mascot = `characters/band/BandCharacters.tsx` (`BonesDrummer`, `SpinnyBassist`, `BooSax`, `PipBat`), simpler bespoke rigs that still follow beat.
4. `Root.tsx` → `HERO_TOKENS` map + `RenderHeroById` picks the right component by id 1..4, props: `x,y,frame,fps,mode('sing'|'dance'),wearCostume,hasMic,hatTipProgress,hasCandyBucket,scale,instanceId,overridePose`.
5. Props attached inside `Character.tsx`: bowler hat at `deformBodyPoint(0,-0.96,…)` (moves with head squash), candy bucket at `pose.handL`, mic at hand. Never place props as separate absolute layers (they drift).

### New character recipe (for a weaker model)
1. Copy `characters/bobo/` → `characters/<new>/`, rename exports.
2. Edit `tokens.ts` colours + body w/h + appendages. Keep anchors normalised −1..1.
3. Copy the closest costume, change paths/colours. Keep the face visible (costume opening around eyes/mouth).
4. Add to `HERO_TOKENS` + `RenderHeroById` in `Root.tsx`, and to `QACast.tsx`.
5. Render `QA-Cast` still; compare to model sheet.

## Step D — QA stills

```powershell
./video/node_modules/.bin/remotion still video/src/index.ts QA-Bobo analysis/qa/bobo_sheet.png --frame=15 --public-dir=video/public --browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe"
./video/node_modules/.bin/remotion still video/src/index.ts QA-Cast analysis/qa/cast_qa_sheet.png --frame=30 --public-dir=video/public --browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe"
```
Show both to the user before building scenes.

## Motion language (must keep)

- Everything tempo-locked through `getBeatState(frame,fps)` (`rig/beat.ts`): beatIndex, beatPhase, barIndex, barPhase, section.
- Dance: 2 key poses alternating per beat + arm wave per bar (`makeBeatDancePose`).
- Spin transform (`evalSpinTransform` + `TornadoSwirl`): crouch → spin into 3-colour swirl → costume pops with overshoot → settle. Swirl colours = hero base + food colours.
- Blink every 2–4 s deterministic by seed; springs deterministic (same frame → same pixels).
