# Beat sheets

Write this before any code and paste it as the header comment of the file. Frames at 30 fps. "Story frames"
ignore hit-stops; the real frame keeps counting while the story clock is frozen.

```
CONCEPT   one sentence that governs every choice
FORMAT    1080x1920 · 30 fps · 6 s (180 frames) · tool
PALETTE   3-5 colours, one accent reserved for the focal action
BEATS     f0-f20    ...             (anticipation → action → reaction → settle)
          f20-f38   ...
          f64       CONTACT · hit-stop 5f (2 impact frames)
          ...
          f150-180  ending: payoff / twist / loop back to f0
AVOID     linear tweens → eased keys per segment
          straight paths → gravity arcs
          ... (5-9 items, each with an "instead")
REVIEW    stills at: f0, f30, f40, ... (one per beat) · per-frame checks: hands, speed, face
```

Pick the template closest to the request and adapt it. Durations are starting points; when there is music, snap
beats to it (at 120 BPM a beat is 15 frames).

## 1. Character action / VFX (spell, punch, throw, duel)

| Beat | Frames | What happens |
|---|---|---|
| Establish | 0-20 | Idle with life: breathing, hover, a glance or squint toward the target |
| Anticipation | 20-38 | Lean and sink away from the action, power gathers (orb swells, fist cocks), eyes narrow |
| Hold | 38-42 | Trembling hold at the extreme pose |
| Strike | 42-46 | Accelerate into release or contact, smear on the fastest frames |
| Travel | 46-64 | Projectile on a gravity arc, stretched along velocity, trail from past positions; camera leads it |
| Telegraph | 54-64 | Target sees it: eyes widen, flinch and brace before contact |
| Contact | 64 | 2 inverted impact frames + 3-5 frames hit-stop, victim shudders |
| Aftermath | 64-100 | Flash, ring, sparks on arcs, decaying shake, knock-back on a spring, a mark that stays |
| Reaction | 100-140 | Characters respond (shake-off, cheer with a squash-and-hop) |
| Twist | 140-180 | Ending beat that changes the situation (the target powers up, the hero panics) |

## 2. Logo sting / reveal (3-5 s)

| Beat | Frames | What happens |
|---|---|---|
| Setup | 0-15 | One element enters on an arc (a drop, a dot, a line), never a fade |
| Anticipation | 15-24 | It compresses, pauses or winds up |
| Transformation | 24-60 | It becomes the logo through a physical idea: pours, folds, grows, bounces into letters. Parts land staggered (2-4 frames apart), each with a squash |
| Lock-up | 60-75 | Settle with a tiny overshoot; secondary details (shine, tagline) follow 6-10 frames later |
| Hold | 75-120 | Hold to read. Optional idle loop (breathing shine) |

Rule: the transformation must come from what the brand is (a drink pours, a fruit grows on a tree, dots bounce).
Never morph through mush.

## 3. Explainer / kinetic type (15-60 s)

| Beat | Frames | What happens |
|---|---|---|
| Hook | 0-45 | A bold claim or question; words land on beats with a dip-and-spring |
| Problem | 45-180 | One hero shape carries the idea; it morphs between scenes instead of cutting |
| Turn | ~180 | A hit: hit-stop, colour change, camera punch |
| Proof | 180-n | Numbers fly in on arcs, count up, bars race and land with a squash |
| Payoff | last 2 s | The hero shape resolves into the ending (logo, CTA); hold to read |

Rules: one focal thing per beat, text holds at least 1 frame per 2 characters, numbers never fly straight.

## 4. Product / UI demo

| Beat | Frames | What happens |
|---|---|---|
| Context | 0-30 | Device or window arrives on an arc and settles |
| Action | 30-n | Cursor moves on curves with ease-out arrivals; clicks squash the button and send a ring |
| Result | | The result grows out of the clicked element (connected motion), not a crossfade |
| Highlight | | Camera punches in on the important part, then eases back |

## 5. Satisfying loop (2-4 s)

Design the last frame first: it must equal frame 0 so the loop is invisible. Use cycles whose periods divide the
loop length, keep one continuous motion path, and put the most satisfying contact exactly on a beat.

## 6. Music-synced

Write the beat grid first (`frames per beat = 1800 / BPM` at 30 fps). Contacts land on the beat frame, wind-ups
start 4-10 frames before it, and nothing contacts between beats unless it's a deliberate syncopation.

## Worked example (the good-vs-bad mage)

```
CONCEPT   a smug violet mage hurls a fireball, and the teal mage it hits gets angry
FORMAT    1080x1920 · 30 fps · 6 s + 5 frames of hit-stop
BEATS     f0-20    idle hover, A glances at B and squints
          f20-38   A sinks and leans back, the orb swells in a hand swung low behind
          f38-42   trembling hold
          f42-46   underhand whip with a smear; release at f46
          f46-64   ball on a gravity arc, tail from its past positions; camera leads
          f54-64   B sees it coming: eyes widen, braces
          f64      CONTACT: 2 impact frames + 3 hit-stop, B shudders
          f64-100  flash, ring, sparks on arcs, decaying shake, B knocked back on a spring, scorch stays
          f104-130 A squashes and hops in celebration
          f140-180 B's hat flame flares, eyebrows down; A's eyes go wide and it leans away
AVOID     linear tweens → eased keys · straight path → gravity arc · tail before release → tail from past
          positions · fade on hit → impact frames + hit-stop · stop dead → damped settle · random flicker →
          seeded noise · hand across the face → arm beside or behind the head
```

Templates 1-6 each have a directed starter scene in `assets/stage.html` (character action, logo sting, text
hook, app demo, loop, beat bounce). Copy the closest one and change its keys; keep the structure.
