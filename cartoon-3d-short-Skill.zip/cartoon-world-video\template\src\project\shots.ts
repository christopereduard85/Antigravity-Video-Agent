import type { Shot } from '../engine/types';

export const SHOTS: Shot[] = [
  // 1. HOOK - Part A: 1919 giant steel tank explodes (w0 = 0.06s -> w9 = 3.86s)
  {
    id: 's01-hook-tank',
    from: 'w0',
    beat: 'hook',
    note: 'In 1919, a giant steel tank in downtown Boston trembles and explodes!',
    set: 'bostonTank',
    cam: { move: 'push', on: 'manager', dist: 5.8, angle: -8, height: 0.95, amount: 0.18, shake: 0.3 },
    cast: [
      {
        who: 'manager',
        pos: [-0.42, 0, 0.35],
        look: 'right',
        beats: [
          { at: 'w0', do: 'talk', face: 'proud', hold: 'clipboard', say: true },
          { at: 'w5', do: 'recoil', face: 'shocked', to: [-0.55, 0, 0.35], emote: '!?' },
        ],
      },
      {
        who: 'worker',
        pos: [0.42, 0, 0.3],
        look: 'left',
        beats: [
          { at: 'w0', do: 'hammer', face: 'determined', hold: 'wrench' },
          { at: 'w6', do: 'panic', face: 'scared', to: [0.55, 0, 0.3], emote: '!' },
        ],
      },
    ],
    fx: [
      { at: 'w5', k: 'rivets', pos: 'tank', size: 1.1 },
      { at: 'w6', k: 'explosion', pos: 'tank', size: 1.3 },
      { at: 'w6', k: 'splash', pos: 'tank', size: 1.25, color: '#633215' },
      { at: 'w6', k: 'shake', size: 1.1, dur: 0.7 },
    ],
    overlays: [{ at: 'w0', to: 'w6', k: 'label', text: 'BOSTON · JANUARY 1919', pos: 'top' }],
    sfx: [
      { at: 'w5', name: 'creak', vol: 0.6 },
      { at: 'w7', name: 'explosion', vol: 0.75 },
    ],
  },

  // 2. HOOK - Part B: Flooded downtown Boston with warm pancake syrup (w9 = 3.86s -> w19 = 8.95s)
  {
    id: 's02-hook-syrup',
    from: 'w9',
    beat: 'hook',
    note: 'Downtown Boston floods with a tsunami of warm pancake syrup!',
    set: 'floodedStreet',
    transition: 'whip',
    cam: { move: 'truck', on: 'fireman', dist: 5.4, angle: 8, height: 0.85, amount: 0.45 },
    cast: [
      {
        who: 'fireman',
        pos: [-0.45, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w9', do: 'run', face: 'shocked', to: [-0.25, 0, 0.4], hold: 'broom', emote: '!' },
          { at: 'w14', do: 'flail', face: 'scared', to: [-0.15, 0, 0.4], say: true, emote: 'sweat' },
        ],
      },
      {
        who: 'kid1',
        pos: [0.52, 0, 0.45],
        look: 'left',
        beats: [
          { at: 'w9', do: 'jump', face: 'happy', hold: 'bucket', emote: 'sparkle' },
          { at: 'w15', do: 'eat', face: 'grin', hold: 'bucket', emote: 'heart' },
        ],
      },
    ],
    fx: [{ at: 'w14', k: 'splash', pos: 'fireman', size: 0.9 }],
    sfx: [
      { at: 'w9', name: 'whoosh', vol: 0.55 },
      { at: 'w14', name: 'splash', vol: 0.7 },
    ],
  },

  // 3. SETTING - Part A: Boston's North End 1919 & Rum Company (w19 = 8.95s -> w30 = 14.08s)
  {
    id: 's03-setting-company',
    from: 'w19',
    beat: 'setting',
    note: 'Boston North End, 1919. The rum company manager proudly shows off the new tank project.',
    set: 'bostonTank',
    transition: 'wipe',
    cam: { move: 'orbit', on: 'manager', dist: 5.5, angle: -14, height: 0.85, amount: 18 },
    cast: [
      {
        who: 'manager',
        pos: [-0.42, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w19', do: 'talk', face: 'proud', hold: 'money', say: true, emote: 'sparkle' },
          { at: 'w24', do: 'point', face: 'smug', to: [-0.2, 0, 0.4], hold: 'money' },
        ],
      },
      {
        who: 'worker',
        pos: [0.48, 0, 0.35],
        look: 'left',
        beats: [
          { at: 'w19', do: 'nod', face: 'neutral', hold: 'wrench' },
          { at: 'w25', do: 'shrug', face: 'worried', emote: '?' },
        ],
      },
    ],
    overlays: [{ at: 'w19', to: 'w23e', k: 'label', text: 'NORTH END · BOSTON 1919', pos: 'top' }],
    sfx: [
      { at: 'w19', name: 'whoosh', vol: 0.45 },
      { at: 'w26', name: 'ding', vol: 0.55 },
    ],
  },

  // 4. SETTING - Part B: 50-foot steel tank holding 2M gallons next to busy street (w30 = 14.08s -> w46 = 19.99s)
  {
    id: 's04-setting-tank',
    from: 'w30',
    beat: 'setting',
    note: 'Low-angle hero shot of the 50-foot steel tank holding 2 million gallons right next to a busy street.',
    set: 'bostonTank',
    cam: { move: 'low', on: 'manager', dist: 5.6, angle: 14, height: 0.4, amount: 0.28 },
    cast: [
      {
        who: 'manager',
        pos: [-0.6, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w30', do: 'cheer', face: 'grin', hold: 'clipboard', say: true },
          { at: 'w40', do: 'wave', face: 'proud', to: [-0.3, 0, 0.4], emote: '!' },
        ],
      },
      {
        who: 'kid1',
        pos: [0.65, 0, 0.45],
        look: 'left',
        beats: [
          { at: 'w30', do: 'walk', face: 'happy', to: [0.25, 0, 0.45], hold: 'bucket' },
          { at: 'w40', do: 'lookaround', face: 'shocked', emote: '!' },
        ],
      },
    ],
    sfx: [
      { at: 'w32', name: 'thud', vol: 0.65 },
      { at: 'w39', name: 'creak', vol: 0.55 },
    ],
  },

  // 5. ACTION 1 - Kids collect leaking molasses in buckets (w46 = 19.99s -> w64 = 25.95s)
  {
    id: 's05-action-kids',
    from: 'w46',
    beat: 'action',
    note: 'From day one, the seams leaked so badly that kids showed up with buckets to collect free candy.',
    set: 'bostonTank',
    cam: { move: 'push', on: 'kid1', dist: 5.0, angle: -10, height: 0.65, amount: 0.3 },
    cast: [
      {
        who: 'kid1',
        pos: [-0.45, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w46', do: 'run', face: 'happy', to: [0.05, 0, 0.4], hold: 'bucket', emote: '!' },
          { at: 'w55', do: 'reach', face: 'grin', hold: 'bucket', say: true, emote: 'sparkle' },
          { at: 'w61', do: 'cheer', face: 'laugh', hold: 'bucket', emote: 'heart' },
        ],
      },
      {
        who: 'kid2',
        pos: [0.75, 0, 0.4],
        look: 'left',
        beats: [
          { at: 'w46', do: 'hop', face: 'happy', hold: 'mug' },
          { at: 'w56', do: 'drink', face: 'love', to: [0.45, 0, 0.4], hold: 'mug', emote: 'heart' },
        ],
      },
    ],
    fx: [{ at: 'w51', k: 'bubbles', pos: 'kid1', size: 0.85 }],
    sfx: [
      { at: 'w51', name: 'bubbles', vol: 0.6 },
      { at: 'w61', name: 'pop', vol: 0.55 },
    ],
  },

  // 6. ACTION 2 - Manager paints the whole tank brown (w64 = 25.95s -> w83 = 31.71s)
  {
    id: 's06-action-paint',
    from: 'w64',
    beat: 'action',
    note: 'Instead of fixing the steel, the manager paints the whole tank brown so nobody can see the leaks!',
    set: 'bostonTank',
    transition: 'whip',
    cam: { move: 'orbit', on: 'manager', dist: 5.5, angle: 12, height: 0.75, amount: 18 },
    cast: [
      {
        who: 'manager',
        pos: [-0.15, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w64', do: 'shake', face: 'smug', hold: 'broom', say: true },
          { at: 'w71', do: 'hammer', face: 'evil', to: [0.22, 0, 0.4], hold: 'broom', emote: 'idea' },
          { at: 'w78', do: 'wave', face: 'wink', hold: 'bucket', emote: 'sparkle' },
        ],
      },
      {
        who: 'worker',
        pos: [-0.62, 0, 0.35],
        look: 'right',
        beats: [
          { at: 'w64', do: 'point', face: 'worried', hold: 'wrench', emote: '?' },
          { at: 'w72', do: 'facepalm', face: 'disgust', emote: 'sweat' },
        ],
      },
    ],
    overlays: [{ at: 'w72', to: 'w82e', k: 'stamp', text: 'PAINT IT BROWN!', pos: 'top', color: '#6E3B1E' }],
    sfx: [
      { at: 'w64', name: 'whoosh', vol: 0.45 },
      { at: 'w72', name: 'boing', vol: 0.6 },
      { at: 'w78', name: 'ding', vol: 0.5 },
    ],
  },

  // 7. ACTION 3 - Warm January afternoon heats syrup & rivets pop like gunshots (w83 = 31.71s -> w101 = 39.49s)
  {
    id: 's07-action-rivets',
    from: 'w83',
    beat: 'action',
    note: 'A warm January afternoon heats the fermenting syrup inside, and the rivets pop like gunshots!',
    set: 'bostonTank',
    cam: { move: 'close', on: 'worker', dist: 5.3, angle: -8, height: 0.65, amount: 0.16, shake: 0.55 },
    cast: [
      {
        who: 'worker',
        pos: [-0.25, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w83', do: 'lookaround', face: 'worried', hold: 'wrench', emote: 'sweat' },
          { at: 'w90', do: 'recoil', face: 'shocked', to: [-0.42, 0, 0.4], emote: '!' },
          { at: 'w95', do: 'cower', face: 'scared', to: [-0.48, 0, 0.4], emote: '!?' },
        ],
      },
      {
        who: 'manager',
        pos: [0.38, 0, 0.4],
        look: 'left',
        beats: [
          { at: 'w83', do: 'drink', face: 'happy', hold: 'cup' },
          { at: 'w93', do: 'panic', face: 'scared', to: [0.48, 0, 0.4], hold: 'none', say: true, emote: '!' },
        ],
      },
    ],
    fx: [
      { at: 'w88', k: 'steam', pos: 'tank', size: 1.0 },
      { at: 'w91', k: 'rivets', pos: 'tank', size: 1.15 },
      { at: 'w95', k: 'rivets', pos: 'tank', size: 1.25 },
      { at: 'w98', k: 'rivets', pos: 'tank', size: 1.35 },
      { at: 'w98', k: 'shake', size: 1.2, dur: 0.9 },
    ],
    sfx: [
      { at: 'w88', name: 'creak', vol: 0.7 },
      { at: 'w95', name: 'snap', vol: 0.75 },
      { at: 'w98', name: 'snap', vol: 0.85 },
      { at: 'w100', name: 'snap', vol: 0.9 },
    ],
  },

  // 8A. SNAP - BOOM! Steel wall rips wide open (w101 = 39.49s -> w108 = 42.76s)
  {
    id: 's08a-snap-boom',
    from: 'w101',
    beat: 'snap',
    note: 'BOOM! The steel wall rips wide open!',
    set: 'bostonTank',
    transition: 'flash',
    cam: { move: 'pull', on: 'manager', dist: 5.5, angle: 6, height: 1.0, amount: 0.28, shake: 0.85 },
    cast: [
      {
        who: 'manager',
        pos: [0.3, 0, 0.5],
        look: 'left',
        beats: [
          { at: 'w101', do: 'recoil', face: 'shocked', emote: '!?' },
          { at: 'w104', do: 'panic', face: 'scared', to: [0.52, 0, 0.7], emote: '!' },
        ],
      },
      {
        who: 'worker',
        pos: [-0.35, 0, 0.5],
        look: 'right',
        beats: [
          { at: 'w101', do: 'jump', face: 'scared', emote: '!' },
          { at: 'w104', do: 'recoil', face: 'shocked', to: [-0.55, 0, 0.7], say: true },
        ],
      },
    ],
    fx: [
      { at: 'w101', k: 'flash', dur: 0.3 },
      { at: 'w101', k: 'explosion', pos: 'tank', size: 1.3 },
      { at: 'w101', k: 'speedlines', dur: 0.9 },
      { at: 'w105', k: 'debris', pos: 'tank', size: 1.2 },
      { at: 'w101', k: 'shake', size: 1.6, dur: 1.2 },
    ],
    overlays: [{ at: 'w101', to: 'w107e', k: 'stamp', text: 'BOOM!', pos: 'top', color: '#D92B3A' }],
    sfx: [
      { at: 'w101', name: 'explosion', vol: 0.95 },
      { at: 'w105', name: 'crash', vol: 0.85 },
    ],
  },

  // 8B. SNAP - Launching a 25-foot wave of molasses at 35 mph (w108 = 42.76s -> w119 = 47.82s)
  {
    id: 's08b-snap-wave',
    from: 'w108',
    beat: 'snap',
    note: 'A 25-foot wave of molasses launches across the street at 35 miles an hour!',
    set: 'bostonTank',
    cam: { move: 'truck', on: 'worker', dist: 5.6, angle: -8, height: 0.9, amount: 0.45, shake: 0.65 },
    cast: [
      {
        who: 'worker',
        pos: [-0.35, 0, 0.65],
        look: 'right',
        beats: [
          { at: 'w108', do: 'run', face: 'scared', to: [-0.5, 0, 0.85], emote: '!' },
          { at: 'w113', do: 'tumble', face: 'dizzy', to: [-0.55, 0.15, 0.95], say: true },
        ],
      },
      {
        who: 'manager',
        pos: [0.35, 0, 0.65],
        look: 'right',
        beats: [
          { at: 'w108', do: 'tumble', face: 'scared', to: [0.48, 0.25, 0.85], emote: '!?' },
          { at: 'w114', do: 'fall', face: 'pain', to: [0.55, 0, 0.95] },
        ],
      },
    ],
    fx: [
      { at: 'w108', k: 'splash', pos: 'manager', size: 1.1 },
      { at: 'w111', k: 'speedlines', dur: 0.8 },
    ],
    overlays: [{ at: 'w110', to: 'w118e', k: 'stamp', text: '25 FT WAVE · 35 MPH!', pos: 'top', color: '#633215' }],
    sfx: [
      { at: 'w108', name: 'whoosh', vol: 0.75 },
      { at: 'w111', name: 'splash', vol: 0.85 },
    ],
  },

  // 9. DEADPAN - Part A: Luckily, the neighborhood smelled like fresh waffles (w119 = 47.82s -> w127 = 51.37s)
  {
    id: 's09-deadpan-luckily',
    from: 'w119',
    beat: 'deadpan',
    note: 'Deadpan 1: Luckily, the entire neighborhood smelled like fresh waffles.',
    set: 'floodedStreet',
    transition: 'cut',
    cam: { move: 'push', on: 'kid1', dist: 5.2, angle: -6, height: 0.65, amount: 0.18 },
    cast: [
      {
        who: 'kid1',
        pos: [-0.28, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w119', do: 'idle', face: 'deadpan', hold: 'bucket', say: true },
          { at: 'w123', do: 'cheer', face: 'love', hold: 'bucket', emote: 'heart' },
        ],
      },
      {
        who: 'kid2',
        pos: [0.35, 0, 0.4],
        look: 'left',
        beats: [
          { at: 'w119', do: 'eat', face: 'happy', hold: 'mug', emote: 'music' },
          { at: 'w124', do: 'clap', face: 'grin', emote: 'sparkle' },
        ],
      },
    ],
    overlays: [{ at: 'w119', to: 'w126e', k: 'label', text: 'LUCKILY: FRESH WAFFLE SMELL', pos: 'top' }],
    sfx: [
      { at: 'w119', name: 'ding', vol: 0.55 },
      { at: 'w125', name: 'pop', vol: 0.5 },
    ],
  },

  // 10. DEADPAN - Part B: Unluckily, crushed train tracks & glued firemen to cobblestones (w127 = 51.37s -> w144 = 59.02s)
  {
    id: 's10-deadpan-unluckily',
    from: 'w127',
    beat: 'deadpan',
    note: 'Deadpan 2: Unluckily, the syrup crushed elevated train tracks and glued horses, trucks, and firemen straight to the cobblestones.',
    set: 'floodedStreet',
    cam: { move: 'crane', on: 'fireman', dist: 5.5, angle: 14, height: 0.6, amount: 1.2 },
    cast: [
      {
        who: 'fireman',
        pos: [0.0, -0.15, 0.45],
        look: 'front',
        beats: [
          { at: 'w127', do: 'pull', face: 'deadpan', hold: 'broom', say: true, emote: 'sweat' },
          { at: 'w135', do: 'flail', face: 'pain', hold: 'broom', emote: '!' },
          { at: 'w140', do: 'sit', face: 'sad', hold: 'broom', emote: 'tears' },
        ],
      },
      {
        who: 'manager',
        pos: [-0.65, -0.18, 0.3],
        look: 'right',
        beats: [
          { at: 'w127', do: 'sit', face: 'dizzy', emote: 'dizzy' },
          { at: 'w136', do: 'facepalm', face: 'cry', emote: 'tears' },
        ],
      },
      {
        who: 'worker',
        pos: [0.65, -0.15, 0.3],
        look: 'left',
        beats: [
          { at: 'w127', do: 'pull', face: 'worried', hold: 'wrench' },
          { at: 'w138', do: 'shrug', face: 'deadpan', emote: '?' },
        ],
      },
    ],
    props: [
      { k: 'glue', at: [0, 0, 0.45], s: 1.15, c: '#5C2E14' },
      { k: 'glue', at: [-0.65, 0, 0.3], s: 0.95, c: '#5C2E14' },
      { k: 'glue', at: [0.65, 0, 0.3], s: 0.95, c: '#5C2E14' },
    ],
    fx: [{ at: 'w135', k: 'bubbles', pos: 'fireman', size: 0.9 }],
    overlays: [{ at: 'w127', to: 'w135', k: 'stamp', text: 'UNLUCKILY: GLUED!', pos: 'top', color: '#D92B3A' }],
    sfx: [
      { at: 'w127', name: 'sad', vol: 0.7 },
      { at: 'w130', name: 'crash', vol: 0.65 },
      { at: 'w135', name: 'bubbles', vol: 0.6 },
    ],
  },

  // 11. EXPLANATION - Part A: Shear-thinning fluid like ketchup in a bottle (w144 = 59.02s -> w164 = 66.35s)
  {
    id: 's11-explain-ketchup',
    from: 'w144',
    beat: 'explanation',
    note: 'Molasses is a shear-thinning fluid, like ketchup in a bottle: when it blasts forward it flows fast like a wave.',
    set: 'ketchupLab',
    transition: 'wipe',
    cam: { move: 'orbit', on: 'chef', dist: 5.5, angle: -10, height: 0.65, amount: 16 },
    cast: [
      {
        who: 'chef',
        pos: [-0.15, 0, -0.75],
        look: 'front',
        beats: [
          { at: 'w144', do: 'talk', face: 'happy', hold: 'bottle', say: true, emote: 'idea' },
          { at: 'w154', do: 'shake', face: 'determined', hold: 'bottle', emote: '!' },
          { at: 'w159', do: 'point', face: 'grin', hold: 'bottle', emote: 'sparkle' },
        ],
      },
      {
        who: 'kid1',
        pos: [0.55, 0, 0.15],
        look: 'left',
        beats: [
          { at: 'w144', do: 'lookaround', face: 'confused', emote: '?' },
          { at: 'w156', do: 'recoil', face: 'shocked', emote: '!' },
        ],
      },
    ],
    props: [
      {
        k: 'puddle',
        at: [-0.52, 0.57, -0.32],
        s: [0.52, 0.05, 0.38],
        c: '#D92632',
        c2: '#FF5A64',
        anim: [{ at: 'w154', to: 'w163e', do: 'flow', amt: 1.4 }],
      },
    ],
    fx: [
      { at: 'w154', k: 'pour', pos: 'ketchupBottle', size: 0.9, color: '#D92632' },
      { at: 'w156', k: 'splash', pos: 'ketchupBottle', size: 0.85, color: '#D92632' },
    ],
    sfx: [
      { at: 'w144', name: 'whoosh', vol: 0.45 },
      { at: 'w150', name: 'pop', vol: 0.55 },
      { at: 'w156', name: 'splash', vol: 0.65 },
    ],
  },

  // 12. EXPLANATION - Part B: Cools in winter air and turns into thick glue (w164 = 66.35s -> w185 = 73.27s)
  {
    id: 's12-explain-glue',
    from: 'w164',
    beat: 'explanation',
    note: 'The second it stops and cools in the winter air, it turns into thick glue that traps anything inside it.',
    set: 'ketchupLab',
    cam: { move: 'push', on: 'chef', dist: 5.4, angle: 8, height: 0.65, amount: 0.18 },
    cast: [
      {
        who: 'chef',
        pos: [-0.15, 0, -0.75],
        look: 'front',
        beats: [
          { at: 'w164', do: 'shiver', face: 'cold', say: true, emote: 'shiver' },
          { at: 'w175', do: 'pull', face: 'shocked', hold: 'plank', emote: '!' },
        ],
      },
      {
        who: 'kid1',
        pos: [0.55, 0, 0.15],
        look: 'left',
        beats: [
          { at: 'w164', do: 'shiver', face: 'cold' },
          { at: 'w178', do: 'pull', face: 'worried', hold: 'bucket', emote: 'sweat' },
        ],
      },
    ],
    props: [
      { k: 'glue', at: [-0.15, 0, -0.58], s: 1.15, c: '#5C2E14' },
      { k: 'glue', at: [0.55, 0, 0.18], s: 1.25, c: '#5C2E14' },
      { k: 'glue', at: [0.42, 0.57, -0.32], s: 0.75, c: '#5C2E14' },
    ],
    sfx: [
      { at: 'w170', name: 'boing', vol: 0.55 },
      { at: 'w179', name: 'thud', vol: 0.7 },
    ],
  },

  // 13a. CONSEQUENCE - Scrubbing harbor with saltwater for 6 months (w185 = 73.27s -> w194 = 77.52s)
  {
    id: 's13a-consequence-scrub',
    from: 'w185',
    beat: 'consequence',
    note: 'After 6 months of scrubbing the harbor with saltwater...',
    set: 'floodedStreet',
    transition: 'whip',
    cam: { move: 'truck', on: 'fireman', dist: 5.2, angle: -12, height: 0.65, amount: 0.45 },
    cast: [
      {
        who: 'fireman',
        pos: [-0.25, 0, 0.45],
        look: 'right',
        beats: [
          { at: 'w185', do: 'push', face: 'worried', to: [0.15, 0, 0.45], hold: 'broom', say: true, emote: 'sweat' },
          { at: 'w189', do: 'pull', face: 'determined', to: [0.35, 0, 0.45], hold: 'broom', emote: '!' },
        ],
      },
      {
        who: 'worker',
        pos: [0.85, 0, 0.45],
        look: 'left',
        beats: [
          { at: 'w185', do: 'carry', face: 'worried', hold: 'bucket', emote: 'sweat' },
          { at: 'w190', do: 'throw', face: 'determined', hold: 'bucket', emote: 'sparkle' },
        ],
      },
    ],
    props: [
      {
        k: 'puddle',
        at: [0.22, 0.04, 0.52],
        s: [1.75, 0.06, 1.05],
        c: '#38B6FF',
        c2: '#BCEBFF',
        anim: [{ at: 'w185', to: 'w193e', do: 'flow', amt: 1.3 }],
      },
    ],
    fx: [
      { at: 'w186', k: 'splash', pos: 'fireman', size: 0.95, color: '#38B6FF' },
      { at: 'w188', k: 'bubbles', pos: 'fireman', size: 1.15, color: '#FFFFFF' },
      { at: 'w190', k: 'splash', pos: 'worker', size: 0.95, color: '#38B6FF' },
    ],
    overlays: [{ at: 'w186', to: 'w193e', k: 'label', text: '6 MONTHS OF SCRUBBING', pos: 'top' }],
    sfx: [
      { at: 'w185', name: 'whoosh', vol: 0.45 },
      { at: 'w190', name: 'splash', vol: 0.65 },
    ],
  },

  // 13b. CONSEQUENCE - Boston passes strict engineering law (w194 = 77.52s -> w213 = 83.79s)
  {
    id: 's13b-consequence-law',
    from: 'w194',
    beat: 'consequence',
    note: 'Boston passes a strict law: every tank and building must be stamped safe by a licensed engineer.',
    set: 'cityHall',
    transition: 'whip',
    cam: { move: 'push', on: 'inspector', dist: 5.6, angle: 4, height: 0.6, amount: 0.16 },
    cast: [
      {
        who: 'inspector',
        pos: [0.0, 0.15, -0.35],
        look: 'front',
        beats: [
          { at: 'w194', do: 'point', face: 'angry', hold: 'sign', holdText: 'ENGINEER\nSTAMP!', say: true, emote: '!' },
          { at: 'w202', do: 'talk', face: 'determined', hold: 'scroll', say: true },
          { at: 'w208', do: 'hammer', face: 'proud', hold: 'sign', holdText: 'APPROVED', emote: 'sparkle' },
        ],
      },
      {
        who: 'fireman',
        pos: [-0.65, 0, 0.68],
        look: 'right',
        beats: [
          { at: 'w194', do: 'salute', face: 'proud', hold: 'broom', emote: '!' },
          { at: 'w205', do: 'nod', face: 'happy', hold: 'broom' },
        ],
      },
      {
        who: 'worker',
        pos: [0.65, 0, 0.68],
        look: 'left',
        beats: [
          { at: 'w194', do: 'nod', face: 'determined', hold: 'clipboard' },
          { at: 'w206', do: 'cheer', face: 'happy', hold: 'clipboard', emote: 'sparkle' },
        ],
      },
    ],
    fx: [{ at: 'w208', k: 'stars', pos: 'inspector', size: 0.85 }],
    overlays: [{ at: 'w197', to: 'w212e', k: 'stamp', text: 'LAW: ENGINEER STAMP', pos: 'bottom', color: '#1F325C' }],
    sfx: [
      { at: 'w194', name: 'whoosh', vol: 0.45 },
      { at: 'w199', name: 'stamp', vol: 0.8 },
      { at: 'w208', name: 'stamp', vol: 0.85 },
    ],
  },

  // 14a. TWIST - Part A: Modern engineering safety laws exist today... (w213 = 83.79s -> w221 = 87.21s)
  {
    id: 's14a-twist-laws',
    from: 'w213',
    beat: 'twist',
    note: 'Twist Part A: Which means modern engineering safety laws exist today...',
    set: 'cityHall',
    cam: { move: 'orbit', on: 'inspector', dist: 5.3, angle: -8, height: 0.65, amount: 14 },
    cast: [
      {
        who: 'inspector',
        pos: [-0.2, 0.15, -0.35],
        look: 'right',
        beats: [
          { at: 'w213', do: 'talk', face: 'proud', hold: 'scroll', say: true, emote: 'sparkle' },
          { at: 'w217', do: 'point', face: 'determined', hold: 'sign', holdText: 'SAFETY\nLAW', emote: '!' },
        ],
      },
      {
        who: 'worker',
        pos: [0.48, 0, 0.68],
        look: 'left',
        beats: [
          { at: 'w213', do: 'read', face: 'happy', hold: 'scroll' },
          { at: 'w218', do: 'salute', face: 'proud', hold: 'scroll', emote: 'sparkle' },
        ],
      },
    ],
    sfx: [
      { at: 'w214', name: 'ding', vol: 0.6 },
      { at: 'w218', name: 'pop', vol: 0.55 },
    ],
  },

  // 14b. TWIST - Part B: ...because a manager tried to fix a leaking syrup bomb with brown paint! (w221 = 87.21s -> end)
  {
    id: 's14b-twist-paint',
    from: 'w221',
    beat: 'twist',
    note: 'Callback twist: ...because one guy tried to fix a leaking syrup bomb with brown paint!',
    set: 'bostonTank',
    transition: 'wipe',
    cam: { move: 'follow', on: 'manager', dist: 5.2, angle: -10, height: 0.8, amount: 0.25 },
    cast: [
      {
        who: 'manager',
        pos: [-0.35, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w221', do: 'tiptoe', face: 'smug', to: [0.15, 0, 0.4], hold: 'bucket', say: true, emote: 'sweat' },
          { at: 'w227', do: 'shrug', face: 'nervous', to: [0.35, 0, 0.4], hold: 'broom', emote: '!' },
          { at: 'w230', do: 'cower', face: 'shocked', hold: 'bucket', emote: '!?' },
        ],
      },
      {
        who: 'inspector',
        pos: [-0.85, 0, 0.4],
        look: 'right',
        beats: [
          { at: 'w221', do: 'walk', face: 'angry', to: [-0.55, 0, 0.4], hold: 'scroll', emote: 'anger' },
          { at: 'w227', do: 'point', face: 'determined', to: [-0.45, 0, 0.4], hold: 'sign', holdText: 'NO BROWN\nPAINT!', emote: '!' },
        ],
      },
      {
        who: 'kid1',
        pos: [0.85, 0, 0.45],
        look: 'left',
        beats: [
          { at: 'w221', do: 'eat', face: 'happy', hold: 'bucket' },
          { at: 'w228', do: 'laugh', face: 'laugh', hold: 'bucket', emote: 'heart' },
        ],
      },
    ],
    fx: [{ at: 'w231', k: 'confetti', pos: 'inspector', size: 0.8 }],
    sfx: [
      { at: 'w222', name: 'boing', vol: 0.55 },
      { at: 'w229', name: 'pop', vol: 0.6 },
      { at: 'w231', name: 'ding', vol: 0.7 },
    ],
  },
];
