// Time resolution: word refs -> seconds -> frames.
import wordsJson from '../project/words.json';
import type { T } from './types';

export type Word = { i: number; w: string; start: number; end: number };
export type WordsFile = { words: Word[]; sections?: { name: string; from: number }[]; estimated?: boolean };

export const WORDS: Word[] = (wordsJson as unknown as WordsFile).words;
export const FPS = 30;

const RE = /^w(\d+)(e)?(?:([+-])(\d+(?:\.\d+)?))?$/;

export function timeOf(t: T): number {
  if (typeof t === 'number') return t;
  const m = RE.exec(t);
  if (!m) throw new Error(`Bad time ref "${t}". Use 'w12', 'w12e', 'w12+0.3' or a number of seconds.`);
  const idx = Number(m[1]);
  const word = WORDS[idx];
  if (!word) throw new Error(`Time ref "${t}": word #${idx} does not exist (last word is #${WORDS.length - 1}).`);
  let s = m[2] ? word.end : word.start;
  if (m[3]) s += (m[3] === '+' ? 1 : -1) * Number(m[4]);
  return Math.max(0, s);
}

export const frameOf = (t: T) => Math.round(timeOf(t) * FPS);

/** Index of the word being spoken at time s (or -1). */
export function wordAt(s: number): number {
  for (let k = 0; k < WORDS.length; k++) {
    if (s >= WORDS[k].start && s < WORDS[k].end) return k;
  }
  return -1;
}

export function isSpeaking(s: number): boolean {
  return wordAt(s) >= 0;
}

export function lastWordEnd(): number {
  return WORDS.length ? WORDS[WORDS.length - 1].end : 5;
}
