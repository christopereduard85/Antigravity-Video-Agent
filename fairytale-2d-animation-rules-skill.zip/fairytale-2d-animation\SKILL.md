---
name: fairytale-2d-animation
description: >
  Automated 2D storybook & fairy-tale animation studio using Remotion + Three.js
  (@remotion/three) and motion-director choreography. Produces broadcast-ready
  1920x1080 30fps full-length children's fairy-tale and world legend episodes (up to
  8 minutes) in 100% English. Features the signature Chubby Giant Panda (`PANDA_MAIN`)
  as the recurring Main Character or Storyteller Narrator alongside custom story-specific
  characters (zero top-left corner watermark), source-backed folklore research,
  multi-character English Voice-Over scripts for manual user recording, multi-angle
  2-bone articulated limbs (walk, run, crouch, sit, jump on gravity arcs, climb, knock,
  blow, throw), interactive set pieces, wind-alive environments, Three.js 3D magic FX,
  and automatic 30fps lip-sync. Compatible with both Antigravity and Claude Code.
---

# Fairytale 2D Animation Studio (Remotion + Three.js + Motion-Director)

This skill turns **Antigravity** or **Claude Code** into an end-to-end 2D storybook animation studio powered by **Remotion 4 + Three.js (`@remotion/three`) + `motion-director` kinematics**, engineered to match the rich visual staging, expressive full-body motion, and editorial pacing of the reference episodes (`REFERENCE1.mp4`, `REFERENCE2.mp4`, `REFERENCE3.mp4`).

---

## Core Non-Negotiable Rules

1. **100% English Output (Even for Indonesian or Global Folklore)**:
   - Whether a researched legend comes from Indonesia (*Timun Mas*, *Lake Toba*, *Malin Kundang*, *Si Kancil*, *Bawang Merah & Bawang Putih*), Asia, Africa, or Europe, **all topic pitches, research notes, character descriptions, Voice-Over scripts (`VO-SCRIPT.md`), spoken dialogue lines, and on-screen subtitles MUST be written in natural, expressive English**.
2. **Full-Length Unshortened Episodes (Up to ~8 Minutes)**:
   - Do **NOT** compress stories into 30–60 second summaries. Unless the user explicitly asks for a short test preview, write the **complete, unshortened narrative** (typically **35–75 shots**, **65–140 dialogue lines**, **5 to 8 minutes** total duration depending on the story), preserving all 3 acts, rule-of-three obstacles, character banter, suspense, and emotional resolution.
3. **Signature Main Character / Narrator = Giant Panda (`PANDA_MAIN`) + Custom Story Cast (Zero Corner Logo)**:
   - **Always include the signature Chubby Giant Panda** (`createMainPanda()` / `PANDA_MAIN` from `src/kit/character/types.ts`, `species: "panda"`, `build: "chubby"`) in every episode as either:
     - **The Storyteller / On-Stage Narrator (`id: "narrator"`)** who guides the audience through human legends/folktales, reacts on stage, and opens/closes the bumpers, **OR**
     - **The Main Protagonist (`id: "panda"`)** in animal fables and original adventures.
   - **Do NOT alter the Panda's iconic look** (pear-shaped creamy-white head with full chubby cheeks, compact round charcoal-black ears, angled teardrop black eye patches, warm golden-amber eyes with white sclera, black shoulder/chest band over a round creamy-white belly, sturdy black arms & legs with tan paw pads & 4 toe tips per foot).
   - **All other story characters are unlocked & custom-built** per legend (never use old characters like "Rubi"), and **never render a top-left face watermark/logo** on the video frame.
4. **Reference-Accurate Animation, Physical Weight & Adaptive Camera (Zero Foot-Sliding)**:
   - Characters must **never** just stand still or run in place with feet sliding across the floor (never 10 steps in place while barely moving).
   - **Exact Zero-Foot-Sliding Formula (`src/kit/character/Character.tsx` & `Stage.tsx`)**: Stride cycle is mathematically distance-locked to ground displacement: `stridePhase = (rigTravel / strideCyc) * 2π` where `strideCyc = 4 * legLen * sin(A°)`. During the stance phase, the planted foot remains mathematically static on the ground (`worldFootX = const`) regardless of acceleration or easing curve!
   - **4-Pose Weight Cushioning & Hand-Animated Physics**: Every step cycles through `Contact -> Down/Cushion (knee flexion) -> Passing -> High-Point/Airborne` with articulated ankle rotation, anticipation squats before take-off, damped landing settles, secondary pendulum prop swing, dynamic tension-curved fishing rods with taut line, and world-anchored footstep dust specks and water ripples (`<FootstepWorldFX/>`).
   - **Adaptive Camera & Multi-Plane Parallax**: Wide outdoor travel/chase scenes (`mountainPath`, `meadow`, `flowerField`, `forest`, `village`, `river`) use `scrollX: [0, ...]` driving multi-plane parallax (`0.18x` peaks, `0.42x` hills, `0.68x` mid trees, `1.0x` ground, `1.28x` foreground) and zero-slip cart wheel rotation (`(travelDist / 24) * (180 / π)`), while tight/indoor spaces (`livingRoom`, `bedroom`, `kitchen`, `palace`) anchor the room (`scrollX = 0`) while characters walk naturally across the floor.
   - **Reactive Foliage Interaction**: Bushes and flower clusters detect character proximity (`dx < 145px, dy < 135px`) and physically skew/rotate away by `15°–18°` as characters brush past, springing back smoothly.
   - **Pose-to-Pose Phrase Acting (`src/kit/acting.ts`)**: Speaking characters snap into distinct silhouette key poses (`explain`, `armsWide`, `pointOut`, `handChest`, `handsCheeks`, etc.) 4 frames ahead of each spoken VO phrase with 5-frame head-turn blinks, `armsFront` layering, and listener eye-gaze tracking (`lookX`).
   - **Editorial Multi-Camera Coverage (`Stage.tsx`)**: Hard-cuts cleanly on line/phrase boundaries between Establishing Wide (`1.1x`), Tight Two-Shot (`1.42x`), Medium Close-Up (`1.66x`), and Emotional Bust Close-Up (`1.88x`), keeping wide action in view.
    - **River / Lake Staging Coordinates**: In `backdrop: "river"` and `"lake"`, the sparkling blue water channel spans `y = 596..775` and the foreground dry grassy bank spans `y = 792..1080`. Place land characters on the dry bank (`y = 855..870`) and swimming fish / `waterSplash` inside the water channel (`y = 715..740`).
5. **Zero-White-Screen Architectural Law (WebGL-Free Pure Vector Overlays & Localized VFX)**:
   - **Never Use Heavy WebGL Overlays for 2D Shows**: In Chromium / Remotion preview and headless rendering, WebGL `<ThreeCanvas>` frequently spawns solid opaque white canvases (`#FFFFFF`) that completely blanket the underlying SVG stage. **All atmospheric overlays (sparkles, petals, wind, fireflies, confetti, storm rain) MUST be pure, frame-deterministic, 100% transparent vector SVG layers**.
   - **Zero Full-Canvas Bloom Rectangles**: Never render `<rect width={W} height={H} fill="white" />` or full-screen radial bloom gradients. Transformation and aura VFX must be strictly **bounded to the character silhouette** (`rx, ry` tied to character scale), using warm, soft golden/amber tones (`#FEF08A`, `#FDE047`, `#F59E0B`) with subtle opacity (maximum `0.45–0.65`).
   - **Transient VFX Duration (Max 45–60 Frames)**: Transformation and magical burst effects must only live during the transition moment (`if (frame > duration) return null;`, default 45–60 frames ≈ 1.5–2s). They must NEVER span an entire shot, leaving characters and scenery 100% visible and crisp during spoken dialogue.
6. **Action Props & Mechanical Kinematics (Physics Synchronization Law)**:
   - **Separation of Prop Mesh vs World Action Rig**: `Character.tsx` only renders the physical held prop mesh. External mechanics (fishing lines, parabolic flight arcs, splash ripples, tension struggle) are managed exclusively by dedicated Scene Rigs (`<FishingSceneRig/>`, `<ProjectileView/>`) at the world SVG root.
   - **Analytical Tip Derivation**: Tool tips (bamboo rod tips, staff ends) must be derived dynamically from character arm FK/IK joint vectors, body lean, and prop dimensions—never guessed with static coordinates.
   - **Phase Inactivity Discipline**: Never render detached action lines, floating bobbers, or strings in midair before the action begins (`if (frame < actionStart) return null;`).
   - **Clean Prop Release**: When a character drops a prop (e.g. `prop: "none"` or gasping in amazement with `handsCheeks`), tension lines and struggle effects terminate immediately.
7. **Character Anatomical Joint Consistency (Clean Silhouette Law)**:
   - **Calf-to-Ankle Separation**: In 2-bone limbs with stroke caps, terminate the calf stroke cleanly above the sole (`ankY = Ft[1] - limbW * 0.35` with `strokeLinecap="butt"` for animal paws) and smoothly flare paw width to match calf width (`0.48 * limbW`), preventing unsightly bell-bottom double-cuff bulbing.
   - **Ground-Plane Stability**: Feet must never sink below ground plane (`y = 0`). During contact, ankle pitch dynamically adjusts (`pitchDeg = -thighDeg * 0.65`) so soles sit completely flat.
8. **Narrative Staging, Continuous Travel & Environmental Purity**:
   - **Geographical Integrity**: Respect the geography of the folklore: Danau (lake) vs Sungai (river).
   - **The "Hanya Padang Hijau" Purity Principle**: When a scene calls for an open meadow or field celebration, use the dedicated `backdrop: "greenPasture"` preset (rolling emerald hills, crisp sky, clouds, swaying grass tufts; no trees or foreground floral occluders).
   - **Continuous Travel vs Edge-Freezing**: For travel, errands, and chases (e.g. delivering lunch to the fields), cut to a centered tracking shot with continuous multi-plane background displacement (`scrollX: [0, -850]`), rather than letting the character run to the screen edge and freeze.
   - **Parameterized Outro Bumpers**: YouTube search cards in `SeriesOutro` must dynamically type the configured `brandName` (e.g., `"EduFam"` -> `"Search EduFam."`).

---

## Mandatory References to Read First

Before designing characters or writing an episode, read:
- `references/animation-rules-and-heuristics.md` — master codification of the Zero-White-Screen law, analytical prop kinematics, anatomical joint separation, transient VFX lifecycles, and environmental purity.
- `references/visual-style-bible.md` — flat-vector zero-outline rules, multi-angle staging, interactive set pieces, emotion cards, and typography.
- `references/story-research-guide.md` — mandatory folklore research protocol, 100% English adaptation rules, full-length 5–8 minute 3-act structure, and the 2-phase Voice-Over workflow.
- `references/motion-director/CHEATSHEET.md` & `references/motion-director/dynamics.md` (or the installed `motion-director` skill) — easing rules (`ease.in` into contact, `ease.out` out of contact, `ease.sine` gestures), parabolic gravity `arc()`, `damp()` spring settle, `hitStop()`, and secondary follow-through.

---

## End-to-End Workflow (2 Phases)

### Phase 1: Research, English Topic Pitches, Full Cast Design & English VO Script

1. **Research & Propose 3 Legends / Fairy Tales in English (Never Improvise)**:
   - Use `search_web` (if available) or documented folklore indices (ATU Index, Balai Pustaka / Indonesian regional folklore archives, Grimm KHM, Aesop, Asian/Middle Eastern folklore) to verify real origins, plot beats, and morals.
   - Present **3 researched story options in English** (e.g., 1 Indonesian Archipelago Legend, 1 Asian Folktale, 1 World Classic Fairy Tale), listing the verified origin, full 3-act plot arc, estimated duration (5–8 min), and proposed speaking character roles.
2. **Scaffold the Episode Project**:
   ```bash
   node "<skillDir>/scripts/init-project.mjs" "<targetProjectDir>"
   ```
   Install dependencies (`npm install`) and ensure the headless browser is cached (`npx remotion browser ensure`).
3. **Design Story Characters in `src/story/characters.ts` (`CAST`)**:
   - Include the signature Giant Panda via `createMainPanda({ id: "narrator", name: "Bobo the Panda" })` (as on-stage Narrator/Companion or Main Character), and build bespoke `CharacterSpec` definitions for all other characters in the story's cast.
   - Supported `species` (19 presets): `"panda" | "human" | "pig" | "fox" | "cat" | "wolf" | "dog" | "bear" | "rabbit" | "mouse" | "goat" | "sheep" | "tiger" | "monkey" | "deer" | "mousedeer" | "bird" | "frog" | "dragon"`.
   - Supported `build` (6 builds): `"chibi"`, `"kid"`, `"chubby"`, `"adult"`, `"elder"`, `"big"`.
   - Use `customHeadSvg` / `customTorsoSvg` whenever a character needs unique horns, jewelry, armor, wings, or markings beyond standard presets.
4. **Direct the Full Shot-by-Shot Episode in `src/story/script.ts` (`EPISODE`)**:
   - Write all dialogue lines, VO acting prompts, and subtitles in **English**.
   - Structure a full-length episode (40–75 shots for a 5–8 minute story) with rich choreography:
     - Use `beats: ActorBeat[]` inside `actors` so characters change pose, level (`crouch`, `sit`, `jumpArcHeight`), and angle (`view: "front" | "threeQuarter" | "side" | "back"`) across the shot.
     - Place foreground over-the-shoulder characters (`layer: "front"`, `view: "back"`) to create cinematic depth like the reference videos.
     - Place interactive `setPieces` (`strawHouse`, `woodHouse`, `brickHouse`, `cottage`, `pendopo` with `doorOpen` / `shake` / `collapseAtFrame`, `sofa`, `bed`, `diningTable`, `cartStraw`, `cartWood`, `cartBrick`, `bushCover`, `rockPile`, `cauldron`, `waterSplash`, `treeTrunkFg`, `doorFrameFg`).
     - Add parabolic `projectiles` (`brick`, `stone`, `apple`, `strawBundle`, `woodLog`, `magicOrb`, `waterBall`) and `hitStops` (`[[atFrame, holdFrames]]`) for action beats.
5. **Export the English VO Recording Sheet & Pause for User Audio**:
   ```bash
   node "<skillDir>/scripts/build-timeline.mjs" "<targetProjectDir>"
   ```
   Present `VO-SCRIPT.md` to the user so they can generate/record the English `.mp3` or `.wav` files and return them.

---

### Phase 2: VO Audio Ingestion, 30fps Lip-Sync, Visual QA Loop & Final Render

When the user provides `.mp3` or `.wav` files:

1. **Place VO Files in `<targetProjectDir>/public/vo/`**:
   - Files match by full line ID (`01_mbok_morning.mp3`) or numeric prefix (`01.mp3` / `01.wav`).
   - If the user provides one combined audio file per character or a single master file, split it on silence into per-line files in `public/vo/` using `ffmpeg`.
2. **Build the Audio-Driven Timeline & 30fps Lip-Sync Envelope**:
   ```bash
   node "<skillDir>/scripts/build-timeline.mjs" "<targetProjectDir>"
   ```
3. **Visual QA Loop (`motion-director` Contact-Sheet Inspection — Mandatory)**:
   - Render `CharacterSheet` and action contact stills across key beats (anticipation crouch, airborne apex, impact hit-stop, over-the-shoulder framing):
     ```bash
     npx remotion still CharacterSheet out/char-sheet.png --frame=15 --gl=angle
     npx remotion still Episode out/qa-shot1.png --frame=420 --gl=angle
     npx remotion still Episode out/qa-shot2.png --frame=625 --gl=angle
     ```
   - Inspect every rendered PNG with `read_file` (or `View` in Claude Code) to verify:
     - Smooth warm-espresso linework (`#2B1B12`), cel-shaded volumetric gradients, and clean fingered hands emerging from sleeves
     - Dynamic full-body poses (bent knees on crouch/run/jump, sitting on furniture, over-the-shoulder `back` views, flying debris/projectiles)
     - Clean English subtitles and zero top-left watermark logo
4. **Render the Full MP4 Episode**:
   ```bash
   npx remotion render Episode out/episode.mp4 --gl=angle
   ```

---

## Kit Architecture Inside `template/`

| Path | Purpose |
| --- | --- |
| `src/kit/anim.ts` | `motion-director` animation core: `ease` curves, multi-keyframe `keys()`, `evalAnim()`, `arc()` gravity parabola, `damp()` spring settle, `hitStop()`, `hitShudder()`, `volScale()` squash & stretch |
| `src/kit/acting.ts` | Reference-engineered pose-to-pose phrase acting (`GESTURES`, `speakerActing`, `listenerActing`, `emphasisActing`, head-turn blinks) & single-line spoken-phrase subtitle splitter (`activeSubtitlePhrase`) |
| `src/kit/character/types.ts` | `CharacterSpec`, `PANDA_MAIN` / `createMainPanda` (with signature red neckerchief `scarf`), 20 `Species` (including dedicated `fish`), 6 `Build`s, 4 `ViewAngle`s (`front`, `threeQuarter`, `side`, `back`), 38 `Pose`s, 17 `Expression`s, 24 `Prop`s (`microphone`, `bamboo`, `stick`, etc.), `RigOverride` (`armsFront`, `blinkBoost`), custom SVG hooks |
| `src/kit/character/Character.tsx` | Smooth cel-shaded illustrated character rig with warm espresso linework (`#2B1B12`), volumetric gradients, sculpted cartoon hands & finger grips, 2-bone articulated arm & leg rig (`hip -> knee -> foot`, `shoulder -> elbow -> hand`), dynamic Batik sarong/kebaya/vest costuming, and `<FishCharacter/>` delegation |
| `src/kit/backgrounds/Backdrops.tsx` | 14 wind-alive parallax environment presets (foreground corner flower bushes, scalloped forest silhouettes, separated river/lake water channel `y=596..775` & foreground grass bank `y=792..1080`, rich interior wainscoting/bookshelf/curtains) + `<SetPieceView/>` interactive architecture & furniture |
| `src/kit/fx/Overlays.tsx` | Rounded 5-point golden star `MagicWipe`, `ThoughtCloudFrame`, `WindGust`, `ImpactBurst`, `ProjectileView` (parabolic thrown props), single-line `SubtitleBar` |
| `src/kit/fx/Bumpers.tsx` | Story-driven `SeriesIntro`, `StorybookTitleCard`, and `SeriesOutro` (English defaults, uses the episode's own cast, zero corner logo) |
| `src/kit/three/ThreeStage.tsx` | Deterministic `@remotion/three` 3D particle & extruded 3D magic-star burst layer |
| `src/kit/Stage.tsx` | Editorial multi-camera coverage (`Wide -> Two-Shot -> Medium/Bust Close-Up`), listener eye-gaze tracking, pose-to-pose acting hookup, multi-beat `ActorBeat` evaluator, parabolic jump arcs, `hitStop` clock, depth-sorted layers (`back`, `mid`, `front`), 30fps lip-sync, and audio sequencer |
