param(
  [Parameter(Mandatory = $true)][string]$Song,
  [string]$Workspace = (Get-Location).Path,
  [switch]$SkipNpm
)
# Scaffold a new kids-song video project from the skill template.
$ErrorActionPreference = 'Stop'
$Skill = Split-Path -Parent $PSScriptRoot
$Tpl = Join-Path $Skill 'templates\project'
Set-Location $Workspace

Write-Host "[1/6] copy template video/ analysis/ docs"
if (-not (Test-Path 'video')) { Copy-Item -Recurse (Join-Path $Tpl 'video') 'video' } else { Write-Host '  video/ exists, skipped' }
New-Item -ItemType Directory -Force -Path 'analysis','analysis\qa','analysis\contact','analysis\audio_check','analysis\models','characters\design','out' | Out-Null
Get-ChildItem (Join-Path $Tpl 'analysis') -File | ForEach-Object {
  $dst = Join-Path 'analysis' $_.Name
  if (-not (Test-Path $dst)) { Copy-Item $_.FullName $dst }
}
foreach ($d in 'AGENTS.md','NEXT_STEPS.md','PRODUCTION_PLAN.md','CHARACTER_DESIGN_SYSTEM.md') {
  if (-not (Test-Path $d)) { Copy-Item (Join-Path $Tpl "docs\$d") $d }
}
if (-not (Test-Path 'characters\design\PROMPT_TEMPLATE.md')) { Copy-Item (Join-Path $Tpl 'docs\PROMPT_TEMPLATE.md') 'characters\design\PROMPT_TEMPLATE.md' }
if (-not (Test-Path '.gitignore')) { "reference_frames/`nvideo/node_modules/`nvideo/out/`nout/" | Set-Content -Encoding utf8 '.gitignore' }

Write-Host "[2/6] copy song -> video/public/HalloweenNight.wav (name used by Root.tsx)"
New-Item -ItemType Directory -Force -Path 'video\public' | Out-Null
Copy-Item -Force $Song 'video\public\HalloweenNight.wav'

Write-Host "[3/6] song duration"
$dur = [double](& ffprobe -v error -show_entries format=duration -of csv=p=0 $Song)
$frames = [int][math]::Round($dur * 30)
Write-Host ("  duration {0:N3}s -> {1} frames @30fps" -f $dur, $frames)
Write-Host "  -> set theme.ts durationInFrames = $frames and replace 3997 in analysis/build_timing.py"

Write-Host "[4/6] point analysis scripts at the song"
$songName = Split-Path -Leaf $Song
foreach ($py in 'audio_beats.py','build_timing.py') {
  $p = Join-Path 'analysis' $py
  if (Test-Path $p) {
    $txt = [IO.File]::ReadAllText((Resolve-Path $p), [Text.Encoding]::UTF8)
    $txt = $txt.Replace("'Halloween Night.wav'", "'$songName'")
    [IO.File]::WriteAllText((Resolve-Path $p), $txt, (New-Object Text.UTF8Encoding($false)))
  }
}

if (-not $SkipNpm) {
  Write-Host "[5/6] npm install (needs network)"
  Push-Location video; npm install; Pop-Location
} else { Write-Host "[5/6] npm install skipped" }

Write-Host "[6/6] next:"
Write-Host "  python analysis/audio_beats.py"
Write-Host "  Copy-Item analysis/beats_raw.json analysis/beats.json   # first time only"
Write-Host "  (edit section_defs / STARTS in analysis/build_timing.py)"
Write-Host "  python analysis/build_timing.py"
Write-Host "  ./video/node_modules/.bin/tsc -p video/tsconfig.json --noEmit"
Write-Host "  powershell -File $PSScriptRoot\render_qa_stills.ps1 -Frames 15,380"
