# Characters and limbs

Viewers read eyes first, then hands. Bad hands (snapping between poses, crossing the face, resting on the chin)
make an otherwise good animation look broken. These rules hold for any rigged character: people, mascots,
creatures, stick figures.

## Rig recipe

- Build every character from parts with their own pivots: hips or base, body, head, each arm as upper arm +
  forearm + hand, props attached to the hand.
- Keep a **body space**: positions relative to the base, before lean and squash. Check limb rules there.
- Arms are two angles: the upper arm angle at the shoulder and a bend at the elbow. Hand =
  shoulder + L1·dir(a1) + L2·dir(a1 + bend).
- Put shoulders at the sides of the body, below the head, so a raised arm can pass *beside* the head.
- Squash and stretch the body around its base and keep the volume (`sx = 1 / sqrt(sy)`).
- Attached parts lag: a hat tip, ear, tail or cloth angle = minus a gain × the body's recent change in lean
  (`lean(s) - lean(s - 3)`), plus a damped spring after stops.
- Eyes: blink (2-3 frames closed), glance before acting, squint for intent, widen for surprise, brows for anger.

## Limb rules

1. **One-way elbows.** The forearm bends one way from straight (0° to about −150°). No hyperextension, no folding
   shut.
2. **The face is sacred.** No arm, hand or held prop crosses the face, unless the act is declared up front (a
   facepalm, a shield). Raise arms beside or behind the head. Plan throws so the arc misses the head (an underhand
   or sidearm throw is often easier to read in 2D than an overhand one).
3. **Reach.** A hand never folds back into its own shoulder (keep at least 35% of the arm length away).
4. **Rest low.** Resting hands sit at chest height or lower, or out to the side. No hand-on-chin unless acted.
5. **Ground.** Hands and props never go below the ground line.
6. **Smooth hands.** In body space a hand moves at most ~40 px per frame (at 1080 px wide) and changes speed by at
   most ~22 px per frame, except in declared fast spans (a whip, a punch, an impact). Gestures use a sine ease
   (peak speed 1.6× average), not a cubic in-out (3×). Big arcs get more frames.

Plan a pose before keying it: where does the hand land relative to the face and silhouette? Key it, then run the
per-frame check. The stage's **Check** button does rules 2, 5 and 6 for tracked hands; add more for your rig.

## Acting

- Every character acts on every beat, even when it is not the focus: breathing, blinking, reacting.
- Reactions lead the event slightly (a flinch before contact) and follow it (a shake-off after).
- Contrast sells: a slow, heavy anticipation makes a fast strike feel faster.
- One clear silhouette per key pose. If you can't read the pose as a black shape, change it.
