import { Vec } from './types';

export const add = (a: Vec, b: Vec): Vec => ({ x: a.x + b.x, y: a.y + b.y });
export const sub = (a: Vec, b: Vec): Vec => ({ x: a.x - b.x, y: a.y - b.y });
export const scale = (a: Vec, s: number): Vec => ({ x: a.x * s, y: a.y * s });
export const len = (a: Vec): number => Math.hypot(a.x, a.y);
export const norm = (a: Vec): Vec => {
  const l = len(a);
  return l > 1e-6 ? { x: a.x / l, y: a.y / l } : { x: 0, y: -1 };
};
export const perp = (a: Vec): Vec => ({ x: -a.y, y: a.x });
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const lerpVec = (a: Vec, b: Vec, t: number): Vec => ({
  x: lerp(a.x, b.x, t),
  y: lerp(a.y, b.y, t),
});
export const clamp = (v: number, lo: number, hi: number): number =>
  Math.max(lo, Math.min(hi, v));

/**
 * Volume-preserving squash & stretch factors.
 * squash > 0 => wider & shorter; squash < 0 => narrower & taller.
 */
export function getSquashStretch(squash: number): { sx: number; sy: number } {
  const k = clamp(squash, -0.65, 0.65);
  const sy = Math.pow(2, -k * 0.52);
  const sx = 1 / sy;
  return { sx, sy };
}

/**
 * Deform a normalized body coordinate (-1..1, -1..1) into pixel space relative to body center,
 * applying topTaper, volume-preserving squash/stretch, and C-curve arc bend.
 */
export function deformBodyPoint(
  nx: number,
  ny: number,
  w: number,
  h: number,
  topTaper: number,
  squash: number,
  arc: number
): Vec {
  const { sx, sy } = getSquashStretch(squash);
  // Smooth taper from top (ny = -1 => topTaper) to bottom (ny = +0.5 => 1.04, ny = +1 => 0.92)
  const t = (ny + 1) * 0.5; // 0 at top, 1 at bottom
  const widthFactor = lerp(topTaper, 1.06, Math.sin(t * Math.PI * 0.78));
  const halfW = (w * 0.5) * widthFactor * sx;
  const halfH = (h * 0.5) * sy;

  // C-curve horizontal shift peaks at top/bottom and bends middle
  const bendX = arc * 22 * (1 - ny * ny);
  const bendTilt = -arc * 0.14 * ny * halfW;

  return {
    x: nx * halfW + bendX,
    y: ny * halfH + bendTilt,
  };
}

/**
 * Generate a smooth closed cubic-bezier SVG path through a ring of points (Catmull-Rom to Bezier).
 */
export function closedSmoothPath(pts: Vec[], tension = 0.22): string {
  const n = pts.length;
  if (n < 3) return '';
  const f = (v: number) => v.toFixed(2);
  let d = `M ${f(pts[0].x)} ${f(pts[0].y)}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n];
    const p1 = pts[i];
    const p2 = pts[(i + 1) % n];
    const p3 = pts[(i + 2) % n];
    const c1 = {
      x: p1.x + (p2.x - p0.x) * tension,
      y: p1.y + (p2.y - p0.y) * tension,
    };
    const c2 = {
      x: p2.x - (p3.x - p1.x) * tension,
      y: p2.y - (p3.y - p1.y) * tension,
    };
    d += ` C ${f(c1.x)} ${f(c1.y)}, ${f(c2.x)} ${f(c2.y)}, ${f(p2.x)} ${f(p2.y)}`;
  }
  return d + ' Z';
}

/**
 * Sample N points around the deformed bean/blob silhouette for procedural body + shading generation.
 */
export function sampleBodyRing(
  w: number,
  h: number,
  topTaper: number,
  squareness: number,
  squash: number,
  arc: number,
  offsetX = 0,
  offsetY = 0,
  scaleMult = 1,
  samples = 24
): Vec[] {
  const pts: Vec[] = [];
  const pExp = lerp(1.0, 0.72, clamp(squareness, 0, 1));
  for (let i = 0; i < samples; i++) {
    const theta = (i / samples) * Math.PI * 2 - Math.PI * 0.5;
    const cx = Math.cos(theta);
    const cy = Math.sin(theta);
    const nx = Math.sign(cx) * Math.pow(Math.abs(cx), pExp) * scaleMult;
    const ny = Math.sign(cy) * Math.pow(Math.abs(cy), pExp) * scaleMult;
    const p = deformBodyPoint(nx, ny, w, h, topTaper, squash, arc);
    pts.push({ x: p.x + offsetX, y: p.y + offsetY });
  }
  return pts;
}

/**
 * Build a tapered noodle limb filled path from root -> joint -> tip with given rootWidth and tipWidth.
 * Returns { d, tipPos, tangentAngleDeg }.
 */
export function buildTaperedLimbPath(
  root: Vec,
  joint: Vec,
  tip: Vec,
  rootWidth: number,
  tipWidth: number
): { d: string; tipPos: Vec; tangentAngleDeg: number } {
  const steps = 12;
  const leftPts: Vec[] = [];
  const rightPts: Vec[] = [];

  // Quadratic bezier evaluation with pulled control point so the curve passes near `joint`
  const ctrl = {
    x: joint.x * 1.35 - (root.x + tip.x) * 0.175,
    y: joint.y * 1.35 - (root.y + tip.y) * 0.175,
  };

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const mt = 1 - t;
    const pos = {
      x: mt * mt * root.x + 2 * mt * t * ctrl.x + t * t * tip.x,
      y: mt * mt * root.y + 2 * mt * t * ctrl.y + t * t * tip.y,
    };
    const tan = norm({
      x: 2 * mt * (ctrl.x - root.x) + 2 * t * (tip.x - ctrl.x),
      y: 2 * mt * (ctrl.y - root.y) + 2 * t * (tip.y - ctrl.y),
    });
    const n = perp(tan);
    const r = lerp(rootWidth * 0.5, tipWidth * 0.5, t);
    leftPts.push(add(pos, scale(n, r)));
    rightPts.push(add(pos, scale(n, -r)));
  }

  const endTan = norm(sub(tip, ctrl));
  const tangentAngleDeg = (Math.atan2(endTan.y, endTan.x) * 180) / Math.PI;
  const f = (v: number) => v.toFixed(2);

  let d = `M ${f(leftPts[0].x)} ${f(leftPts[0].y)}`;
  for (let i = 1; i <= steps; i++) {
    d += ` L ${f(leftPts[i].x)} ${f(leftPts[i].y)}`;
  }
  // Rounded cap at tip
  d += ` A ${(tipWidth * 0.5).toFixed(2)} ${(tipWidth * 0.5).toFixed(2)} 0 0 1 ${f(
    rightPts[steps].x
  )} ${f(rightPts[steps].y)}`;
  for (let i = steps - 1; i >= 0; i--) {
    d += ` L ${f(rightPts[i].x)} ${f(rightPts[i].y)}`;
  }
  d += ' Z';

  return { d, tipPos: tip, tangentAngleDeg };
}
