import React from 'react';

export type Vec = { x: number; y: number };

export type Viseme = 'closed' | 'mid' | 'open' | 'O' | 'E';

export type Expression = 'happy' | 'surprised' | 'wink' | 'sing';

export interface Pose {
  root: Vec; // feet anchor on stage (px, 1920x1080 space)
  jumpY: number; // height above root (0 = on ground, >0 = in air)
  squash: number; // -1 stretch .. 0 neutral .. 1 squash (volume preserved)
  lean: number; // degrees, whole-body tilt
  arc: number; // -1..1 body C-curve bend
  handL: Vec; // IK targets relative to body center (in px)
  handR: Vec;
  footL: Vec; // relative to root (in px)
  footR: Vec;
  look: Vec; // pupil offset -1..1
  blink: number; // 0 open .. 1 closed
  viseme: Viseme;
  mouthOpen: number; // 0..1
  expression: Expression;
  spinAngle?: number; // 0..360 for spin-tornado
}

export interface AppendageSpec {
  kind: 'antenna' | 'ear' | 'tail' | 'curl' | 'horn';
  anchor: number; // index into anchors.appendages
  segments: number;
  length: number;
  width: number;
  tipR: number;
  stiffness: number;
  damping: number;
  splay: number; // degrees base angle from vertical up (-18 = left, +18 = right)
  color?: string;
  tipColor?: string;
  layer?: 'back' | 'front';
}

export interface CostumeLayerProps {
  bodyW: number;
  bodyH: number;
  squash: number;
  lean: number;
  arc: number;
  frame: number;
  fps: number;
  velX: number;
  velY: number;
}

export interface CostumeSpec {
  Back?: React.FC<CostumeLayerProps>;
  Front?: React.FC<CostumeLayerProps>;
  Hat?: React.FC<CostumeLayerProps>;
  hideAppendages?: boolean;
}

export interface SpotSpec {
  x: number; // normalized -1..1
  y: number;
  rx: number;
  ry: number;
  rot?: number;
}

export interface CharacterTokens {
  id: string;
  name: string;
  height: number;
  body: {
    shape: 'bean' | 'blob' | 'tall' | 'long';
    w: number;
    h: number;
    squareness: number;
    topTaper: number;
  };
  colors: {
    base: string;
    shade: string;
    highlight: string;
    belly?: string;
    limb: string;
    feet: string;
    spots?: string;
    blush: string;
    mouth: string;
    tongue: string;
    teeth: string;
    eyeWhite: string;
    pupil: string;
  };
  anchors: {
    shoulderL: Vec;
    shoulderR: Vec;
    hipL: Vec;
    hipR: Vec;
    eyes: Vec[];
    blush: Vec[];
    mouth: Vec;
    appendages: Vec[];
  };
  spots?: SpotSpec[];
  extraLegPairs?: Array<{
    hipL: Vec;
    hipR: Vec;
    footOffsetX: number;
    footOffsetY: number;
  }>;
  limbs: {
    armLen: readonly [number, number];
    legLen: readonly [number, number];
    width: readonly [number, number];
    hand: 'mitten3';
    foot: 'bean';
  };
  eyes: {
    count: 2 | 3;
    r: number;
    pupilR: number;
    catchlight: number;
    hasLashes?: boolean;
  };
  mouth: {
    w: number;
    h: number;
    hasFangs?: boolean;
  };
  appendages: readonly AppendageSpec[];
}
