import React from 'react';

/**
 * Curated list of safe periphery/margin locations.
 * Placed strictly in outer margins, away from the central character stage,
 * top curtain decorations, and bottom karaoke lyric bar!
 */
const SAFE_STICKER_POSITIONS = [
  { x: 1780, y: 1010, rotate: -4, bg: '#7B1FA2', star: '#FFE03D' }, // 0: Bottom-Right corner
  { x: 140,  y: 990,  rotate: 5,  bg: '#FF8F00', star: '#FFFFFF' }, // 1: Bottom-Left safe corner
  { x: 1790, y: 560,  rotate: -7, bg: '#3949AB', star: '#FF80AB' }, // 2: Right middle edge
  { x: 130,  y: 560,  rotate: 6,  bg: '#00897B', star: '#FFE03D' }, // 3: Left middle edge
  { x: 1785, y: 340,  rotate: 8,  bg: '#E91E63', star: '#FFFFFF' }, // 4: Upper-Right safe margin
  { x: 135,  y: 340,  rotate: -6, bg: '#00ACC1', star: '#FFE03D' }, // 5: Upper-Left safe margin
  { x: 1780, y: 780,  rotate: 5,  bg: '#F4511E', star: '#FFE03D' }, // 6: Lower-Right margin
  { x: 140,  y: 780,  rotate: -5, bg: '#43A047', star: '#FFFFFF' }, // 7: Lower-Left margin
  { x: 1770, y: 930,  rotate: -3, bg: '#5E35B1', star: '#80D8FF' }, // 8: Lower-Right inner corner
  { x: 145,  y: 910,  rotate: 4,  bg: '#C2185B', star: '#FFE03D' }, // 9: Lower-Left inner corner
];

/**
 * Playful Die-Cut "edufam" Watermark Sticker (SVG).
 * - Small and cute with thick white die-cut sticker outline and drop shadow.
 * - Pops out with a bouncy spring animation in safe periphery margins (never center/blocking).
 * - Stays visible for ~2.4s, then pops away.
 * - Reappears ~10 seconds later in a completely different safe location!
 */
export const LogoBug: React.FC<{
  frame?: number;
  fps?: number;
}> = ({ frame = 0, fps = 30 }) => {
  // Visible active window = ~2.4 seconds (72 frames)
  const activeSpan = Math.round(fps * 2.4);
  // Dormant window = ~9.6 seconds (288 frames)
  // Total cycle = 12 seconds (360 frames)
  const cycleDuration = Math.round(fps * 12);

  const cycle = Math.floor(frame / cycleDuration);
  const localF = frame % cycleDuration;

  // Hidden during dormant period (~9.6 seconds)
  if (localF >= activeSpan) return null;

  // Spring pop-in (first 11 frames = ~0.37s) with cute bouncy overshoot
  let scale = 1;
  if (localF < 11) {
    const p = localF / 11;
    // Overshoot curve: starts at 0, bounces up to 1.16, settles to 1.0
    scale = Math.sin(p * Math.PI * 0.5) + Math.sin(p * Math.PI) * 0.2;
  } else if (localF > activeSpan - 10) {
    // Snappy shrink exit (last 10 frames = ~0.33s)
    const p = (activeSpan - localF) / 10;
    scale = Math.max(0, p * 1.1);
  }

  if (scale <= 0.02) return null;

  // Select pseudo-random safe position per cycle (coprime jump ensures no repeating consecutive spots)
  const posIndex = (cycle * 3 + 1) % SAFE_STICKER_POSITIONS.length;
  const pos = SAFE_STICKER_POSITIONS[posIndex];

  // Gentle micro-hover while visible
  const hoverY = Math.sin(frame * 0.2) * 2.5;
  const hoverRotate = Math.cos(frame * 0.16) * 1.4;

  const w = 120;
  const h = 36;
  const rx = h * 0.5;

  return (
    <g
      transform={`translate(${pos.x.toFixed(1)}, ${(pos.y + hoverY).toFixed(
        1
      )}) rotate(${(pos.rotate + hoverRotate).toFixed(2)}) scale(${scale.toFixed(
        3
      )})`}
      pointerEvents="none"
    >
      {/* Sticker Drop Shadow */}
      <rect
        x={-w * 0.5 + 2.5}
        y={-h * 0.5 + 4}
        width={w}
        height={h}
        rx={rx}
        fill="rgba(14, 4, 24, 0.42)"
      />
      {/* Thick White Die-Cut Sticker Outline */}
      <rect
        x={-w * 0.5 - 4.5}
        y={-h * 0.5 - 4.5}
        width={w + 9}
        height={h + 9}
        rx={rx + 4.5}
        fill="#FFFFFF"
      />
      {/* Colored Sticker Body */}
      <rect
        x={-w * 0.5}
        y={-h * 0.5}
        width={w}
        height={h}
        rx={rx}
        fill={pos.bg}
        stroke="rgba(255, 255, 255, 0.55)"
        strokeWidth={1.8}
      />
      {/* Gloss Highlight */}
      <rect
        x={-w * 0.42}
        y={-h * 0.38}
        width={w * 0.84}
        height={h * 0.32}
        rx={h * 0.16}
        fill="rgba(255, 255, 255, 0.28)"
      />

      {/* Mini Star Sparkle Icon */}
      <text
        x={-w * 0.5 + 16}
        y={4}
        textAnchor="middle"
        fontFamily="'Arial Black', sans-serif"
        fontSize={12}
        fill={pos.star}
        stroke="#1E0836"
        strokeWidth={2.2}
        paintOrder="stroke"
      >
        ★
      </text>

      {/* "edufam" Sticker Wordmark */}
      <text
        x={8}
        y={6}
        textAnchor="middle"
        fontFamily="'Arial Black', 'Fredoka', 'Quicksand', sans-serif"
        fontWeight={900}
        fontSize={16}
        fill="#FFFFFF"
        stroke="#1E0836"
        strokeWidth={4}
        paintOrder="stroke"
        letterSpacing={1.1}
      >
        edufam
      </text>
    </g>
  );
};
