// ============================================================================
// 2D CHARACTER BILLBOARD IN 3D WORLD.
// Evaluates ShotChar beats at current global time `t`, draws onto an offscreen
// Canvas 2D via drawCharacter(), uploads as a CanvasTexture, and billboards
// horizontally toward the active camera while standing upright on the ground.
// ============================================================================
import React, { useMemo, useRef } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { CAST } from '../project/cast';
import {
  BASE_POSE,
  CANVAS_UNITS,
  FOOT_FROM_BOTTOM,
  drawCharacter,
  type DrawState,
  type Pose,
} from './drawCharacter';
import { timeOf, wordAt, WORDS } from './timing';
import type { Act, Beat, Emote, Face, Item, Look, Pos, ShotChar, Vec3 } from './types';
import { clamp, easeInOut, hashStr, lerp, noise1, spring } from './util';

export function toVec3(p: Pos): Vec3 {
  return p.length === 2 ? [p[0], 0, p[1]] : [p[0], p[1], p[2]];
}

export type EvaluatedChar = {
  pos: Vec3;
  vel: Vec3;
  act: Act;
  face: Face;
  look: Look;
  item: Item;
  itemText?: string;
  emote: Emote;
  emoteT: number;
  say: boolean;
  beatElapsed: number;
  beatProgress: number;
};

/** Resolve character world position and active beat state at global time `t` (seconds). */
export function evaluateShotChar(sc: ShotChar, t: number, shotEndT: number): EvaluatedChar {
  const beats = sc.beats;
  let curPos: Vec3 = toVec3(sc.pos);
  let vel: Vec3 = [0, 0, 0];
  let act: Act = 'idle';
  let face: Face = 'neutral';
  let look: Look = sc.look ?? 'auto';
  let item: Item = 'none';
  let itemText: string | undefined;
  let emote: Emote = 'none';
  let emoteT = -1;
  let say = false;
  let beatElapsed = 0;
  let beatProgress = 0;

  const times = beats.map((b) => timeOf(b.at));

  for (let i = 0; i < beats.length; i++) {
    const b: Beat = beats[i];
    const t0 = times[i];
    const t1 = i + 1 < beats.length ? Math.max(t0 + 0.05, times[i + 1]) : Math.max(t0 + 0.2, shotEndT);
    if (t < t0 && i > 0) break;

    if (b.do) act = b.do;
    if (b.face) face = b.face;
    if (b.look) look = b.look;
    if (b.hold !== undefined) item = b.hold;
    if (b.holdText !== undefined) itemText = b.holdText;
    if (b.say !== undefined) say = b.say;
    if (b.emote && b.emote !== 'none' && t >= t0) {
      emote = b.emote;
      emoteT = t - t0;
    }

    const startPos: Vec3 = [...curPos];
    if (b.to) {
      const target = toVec3(b.to);
      const u = clamp((t - t0) / Math.max(0.05, t1 - t0));
      const e = act === 'run' || act === 'walk' || act === 'march' ? lerp(u, easeInOut(u), 0.35) : easeInOut(u);
      curPos = [
        lerp(startPos[0], target[0], e),
        lerp(startPos[1], target[1], e),
        lerp(startPos[2], target[2], e),
      ];
      if (t >= t0 && t <= t1 && u > 0.01 && u < 0.99) {
        const dt = Math.max(0.05, t1 - t0);
        vel = [(target[0] - startPos[0]) / dt, (target[1] - startPos[1]) / dt, (target[2] - startPos[2]) / dt];
      }
      if (t >= t1) curPos = target;
    }

    if (t >= t0 && (t < t1 || i === beats.length - 1)) {
      beatElapsed = Math.max(0, t - t0);
      beatProgress = clamp((t - t0) / Math.max(0.05, t1 - t0));
    }
  }

  return { pos: curPos, vel, act, face, look, item, itemText, emote, emoteT, say, beatElapsed, beatProgress };
}

/** Synthesize procedural Pose from action `act`, global time `t`, and beatElapsed. */
export function computePose(act: Act, t: number, beatElapsed: number, seed: number, say: boolean): Pose {
  const p: Pose = {
    ...BASE_POSE,
    aF: [...BASE_POSE.aF],
    aB: [...BASE_POSE.aB],
    lF: [...BASE_POSE.lF],
    lB: [...BASE_POSE.lB],
  };

  const phase = (seed % 97) * 0.13;
  const breath = Math.sin(t * 2.6 + phase);
  p.squash = 1 + breath * 0.015;
  p.head = Math.sin(t * 1.7 + phase) * 0.03;
  p.aF = [0.18 + Math.sin(t * 2.2 + phase) * 0.04, 0.16];
  p.aB = [-0.12 + Math.cos(t * 2.2 + phase) * 0.04, 0.14];

  switch (act) {
    case 'idle':
      break;
    case 'talk': {
      const g = Math.sin(t * 6.5 + phase);
      p.aF = [0.55 + g * 0.25, -0.55 - g * 0.15];
      p.aB = [0.22 - g * 0.12, -0.25];
      p.head = Math.sin(t * 4.2 + phase) * 0.06;
      p.headY = Math.abs(Math.sin(t * 6.5 + phase)) * 0.012;
      p.squash = 1 + Math.sin(t * 6.5 + phase) * 0.025;
      break;
    }
    case 'walk': {
      const w = t * 9.5 + phase;
      const s = Math.sin(w);
      const c = Math.abs(Math.cos(w));
      p.y = c * 0.038;
      p.squash = 1 + Math.cos(w * 2) * 0.03;
      p.lean = 0.08;
      p.lF = [s * 0.55, Math.max(0, -s) * 0.45];
      p.lB = [-s * 0.55, Math.max(0, s) * 0.45];
      p.aF = [-s * 0.45, -0.25];
      p.aB = [s * 0.45, -0.25];
      p.head = Math.sin(w) * 0.04;
      break;
    }
    case 'run': {
      const w = t * 15 + phase;
      const s = Math.sin(w);
      p.y = Math.abs(Math.cos(w)) * 0.075;
      p.squash = 1 + Math.cos(w * 2) * 0.05;
      p.lean = 0.24;
      p.lF = [s * 0.85, Math.max(0, -s) * 0.75 + 0.15];
      p.lB = [-s * 0.85, Math.max(0, s) * 0.75 + 0.15];
      p.aF = [-s * 0.75 + 0.2, -0.85];
      p.aB = [s * 0.75 + 0.2, -0.85];
      p.head = -0.08 + Math.sin(w) * 0.05;
      break;
    }
    case 'march': {
      // Rhythmic high-knee soldier step (2 Hz = 4 steps/sec)
      const w = t * Math.PI * 4;
      const s = Math.sin(w);
      const stepImpact = Math.pow(Math.max(0, Math.cos(w)), 3);
      p.y = Math.abs(s) * 0.055;
      p.squash = 1 - stepImpact * 0.055;
      p.lean = 0.04;
      const liftF = Math.max(0, s);
      const liftB = Math.max(0, -s);
      p.lF = [liftF * 0.95 - (1 - liftF) * 0.25, liftF * 0.85];
      p.lB = [liftB * 0.95 - (1 - liftB) * 0.25, liftB * 0.85];
      p.aF = [-s * 0.65, -0.35];
      p.aB = [s * 0.65, -0.35];
      p.headY = stepImpact * 0.018;
      break;
    }
    case 'sneak':
    case 'tiptoe': {
      const w = t * 6.5 + phase;
      const s = Math.sin(w);
      p.lean = 0.22;
      p.y = Math.max(0, Math.sin(w * 2)) * 0.04;
      p.squash = 0.94 + Math.sin(w * 2) * 0.04;
      p.lF = [s * 0.45, 0.35 + Math.max(0, -s) * 0.35];
      p.lB = [-s * 0.45, 0.35 + Math.max(0, s) * 0.35];
      p.aF = [0.65 + s * 0.15, -0.85];
      p.aB = [0.45 - s * 0.15, -0.75];
      p.head = -0.12;
      break;
    }
    case 'jump':
    case 'hop': {
      const cyc = act === 'hop' ? (t * 2.6 + phase) % 1 : clamp(beatElapsed / 0.75);
      const arc = Math.sin(cyc * Math.PI);
      p.y = arc * (act === 'hop' ? 0.18 : 0.32);
      p.squash = cyc < 0.15 ? 0.82 : cyc > 0.85 ? 0.86 : 1.12;
      p.aF = [2.4 * arc + 0.3, -0.2];
      p.aB = [2.2 * arc + 0.2, -0.2];
      p.lF = [-0.35 * arc, 0.55 * arc];
      p.lB = [0.25 * arc, 0.55 * arc];
      break;
    }
    case 'fall': {
      const u = clamp(beatElapsed / 0.55);
      p.rot = easeInOut(u) * (Math.PI * 0.48);
      p.y = Math.sin(u * Math.PI) * 0.12;
      p.aF = [2.2 + Math.sin(t * 18) * 0.3, -0.2];
      p.aB = [2.0 + Math.cos(t * 18) * 0.3, -0.2];
      p.lF = [Math.sin(t * 16) * 0.4, 0.3];
      p.lB = [-Math.sin(t * 16) * 0.4, 0.3];
      break;
    }
    case 'tumble': {
      p.rot = beatElapsed * 7.5;
      p.y = 0.18 + Math.abs(Math.sin(beatElapsed * 6)) * 0.18;
      p.aF = [2.3, -0.4];
      p.aB = [-2.1, 0.4];
      p.lF = [0.6, 0.5];
      p.lB = [-0.6, 0.5];
      break;
    }
    case 'sit': {
      p.sit = 1;
      p.aF = [0.35 + Math.sin(t * 2 + phase) * 0.05, -0.45];
      p.aB = [0.25, -0.35];
      break;
    }
    case 'lie': {
      p.rot = -Math.PI * 0.48;
      p.y = -0.18;
      p.aF = [0.2, 0.1];
      p.aB = [-0.1, 0.1];
      break;
    }
    case 'point':
    case 'present': {
      const pop = spring(beatElapsed, 2.5, 6);
      p.lean = 0.08 * pop;
      p.aF = [1.52 * pop, -0.05];
      p.aB = [-0.2, 0.25];
      p.head = -0.05;
      break;
    }
    case 'wave': {
      p.aF = [2.45 + Math.sin(t * 12) * 0.32, -0.25 + Math.cos(t * 12) * 0.2];
      p.aB = [0.2, 0.15];
      p.head = Math.sin(t * 6) * 0.06;
      break;
    }
    case 'cheer': {
      const b = Math.abs(Math.sin(t * 9 + phase));
      p.y = b * 0.08;
      p.squash = 0.94 + b * 0.12;
      p.aF = [2.65 + Math.sin(t * 9) * 0.2, -0.15];
      p.aB = [2.55 - Math.sin(t * 9) * 0.2, -0.15];
      p.head = Math.sin(t * 9) * 0.07;
      break;
    }
    case 'clap': {
      const c = Math.abs(Math.sin(t * 11));
      p.aF = [1.1 + c * 0.25, -0.95 - c * 0.2];
      p.aB = [1.0 + c * 0.25, -0.9 - c * 0.2];
      p.squash = 0.98 + c * 0.04;
      break;
    }
    case 'shrug': {
      const u = spring(beatElapsed, 2, 5);
      p.aF = [0.75 * u, -1.15 * u];
      p.aB = [-0.75 * u, 1.15 * u];
      p.head = 0.14 * u;
      p.headY = 0.025 * u;
      break;
    }
    case 'think': {
      p.aF = [0.95, -1.75];
      p.aB = [-0.25, 0.65];
      p.head = 0.1 + Math.sin(t * 2) * 0.03;
      break;
    }
    case 'nod': {
      p.headY = Math.abs(Math.sin(t * 9)) * 0.035;
      p.head = Math.sin(t * 9) * 0.12;
      break;
    }
    case 'shake': {
      p.head = Math.sin(t * 14) * 0.14;
      p.x = Math.sin(t * 14) * 0.015;
      break;
    }
    case 'panic':
    case 'flail': {
      const w = t * 18;
      p.y = Math.abs(Math.sin(w)) * 0.06;
      p.x = Math.sin(w * 0.7) * 0.03;
      p.squash = 1 + Math.sin(w * 2) * 0.06;
      p.aF = [2.4 + Math.sin(w) * 0.55, Math.cos(w) * 0.4];
      p.aB = [2.3 - Math.sin(w) * 0.55, -Math.cos(w) * 0.4];
      p.lF = [Math.sin(w) * 0.45, 0.35];
      p.lB = [-Math.sin(w) * 0.45, 0.35];
      p.shiver = 0.7;
      break;
    }
    case 'cower': {
      p.squash = 0.84;
      p.lean = 0.25;
      p.headY = 0.04;
      p.aF = [1.85, -1.35];
      p.aB = [1.75, -1.35];
      p.lF = [0.25, 0.45];
      p.lB = [-0.15, 0.45];
      p.shiver = 0.85;
      break;
    }
    case 'recoil': {
      const u = spring(beatElapsed, 3, 5);
      p.lean = -0.28 * u;
      p.x = -0.06 * u;
      p.y = Math.max(0, Math.sin(Math.min(1, beatElapsed * 3) * Math.PI)) * 0.08;
      p.aF = [1.9 * u, -0.5];
      p.aB = [1.4 * u, -0.5];
      break;
    }
    case 'push':
    case 'wipe':
    case 'dig':
    case 'sweep': {
      p.lean = 0.32 + Math.sin(t * 6) * 0.04;
      p.aF = [1.45 + Math.sin(t * 8) * 0.22, -0.15];
      p.aB = [1.35 - Math.sin(t * 8) * 0.22, -0.2];
      p.lF = [0.45, 0.4];
      p.lB = [-0.55, 0.1];
      break;
    }
    case 'pull': {
      p.lean = -0.3 + Math.sin(t * 5) * 0.04;
      p.aF = [1.25, -0.45];
      p.aB = [1.15, -0.5];
      p.lF = [0.45, 0.1];
      p.lB = [-0.45, 0.4];
      break;
    }
    case 'carry':
    case 'lift': {
      const up = act === 'lift' ? Math.min(1, beatElapsed * 2) : 0.4;
      p.squash = 0.94;
      p.aF = [1.2 + up * 1.1, -0.6];
      p.aB = [1.1 + up * 1.1, -0.6];
      p.lF = [0.15 + Math.sin(t * 7) * 0.25, 0.2];
      p.lB = [-0.15 - Math.sin(t * 7) * 0.25, 0.2];
      break;
    }
    case 'throw':
    case 'punch': {
      const u = clamp(beatElapsed / 0.35);
      const swing = u < 0.35 ? -0.8 * (u / 0.35) : 1.65 * easeInOut((u - 0.35) / 0.65);
      p.lean = swing * 0.18;
      p.aF = [0.6 + swing, -0.15];
      p.aB = [-0.4, 0.3];
      break;
    }
    case 'hammer': {
      const s = Math.sin(t * 12);
      p.lean = s * 0.12 + 0.1;
      p.aF = [1.45 + s * 0.75, -0.25];
      p.aB = [0.25, 0.2];
      p.squash = 1 - Math.max(0, -s) * 0.05;
      break;
    }
    case 'type': {
      p.aF = [0.95 + Math.sin(t * 22) * 0.12, -0.85];
      p.aB = [0.85 + Math.cos(t * 22) * 0.12, -0.85];
      p.head = 0.1;
      break;
    }
    case 'phone':
    case 'read':
    case 'write': {
      p.aF = [0.95, -0.95];
      p.aB = act === 'write' ? [0.85 + Math.sin(t * 14) * 0.1, -0.9] : [0.25, 0.2];
      p.head = 0.16;
      break;
    }
    case 'drink':
    case 'eat': {
      const sip = 0.5 + 0.5 * Math.sin(t * 4);
      p.aF = [1.15 + sip * 0.55, -1.35 - sip * 0.3];
      p.head = -0.12 * sip;
      break;
    }
    case 'dance': {
      const w = t * 9;
      p.x = Math.sin(w * 0.5) * 0.04;
      p.y = Math.abs(Math.sin(w)) * 0.06;
      p.squash = 0.94 + Math.abs(Math.cos(w)) * 0.12;
      p.lean = Math.sin(w * 0.5) * 0.15;
      p.aF = [1.8 + Math.sin(w) * 0.65, -0.4];
      p.aB = [1.8 - Math.sin(w) * 0.65, -0.4];
      p.lF = [Math.sin(w) * 0.4, 0.3];
      p.lB = [-Math.sin(w) * 0.4, 0.3];
      break;
    }
    case 'bow': {
      const u = Math.sin(clamp(beatElapsed / 1.1) * Math.PI);
      p.lean = 0.55 * u;
      p.head = 0.2 * u;
      p.aF = [0.1, 0.1];
      p.aB = [-0.2, 0.1];
      break;
    }
    case 'salute': {
      const u = spring(beatElapsed, 2.5, 6);
      p.aF = [1.85 * u, -2.05 * u];
      p.aB = [0.05, 0.05];
      p.squash = 1.03;
      break;
    }
    case 'facepalm': {
      p.aF = [1.55, -1.95];
      p.head = 0.18;
      p.headY = 0.025;
      break;
    }
    case 'lookaround': {
      p.head = Math.sin(t * 4.5) * 0.16;
      p.aF = [0.35, -0.25];
      break;
    }
    case 'stomp': {
      const w = t * 8;
      const lift = Math.max(0, Math.sin(w));
      p.lF = [lift * 0.85, lift * 0.75];
      p.squash = 1 - Math.max(0, -Math.sin(w)) * 0.06;
      p.aF = [0.45, -0.45];
      p.aB = [-0.35, 0.35];
      break;
    }
    case 'climb': {
      const w = t * 7;
      p.aF = [2.3 + Math.sin(w) * 0.45, -0.4];
      p.aB = [2.3 - Math.sin(w) * 0.45, -0.4];
      p.lF = [Math.cos(w) * 0.45, 0.55];
      p.lB = [-Math.cos(w) * 0.45, 0.55];
      break;
    }
    case 'swim':
    case 'fly': {
      p.rot = 1.15;
      const w = t * 7;
      p.y = Math.sin(w * 0.5) * 0.06 + (act === 'fly' ? 0.35 : 0);
      p.aF = [2.1 + Math.sin(w) * 0.5, -0.3];
      p.aB = [1.9 - Math.sin(w) * 0.5, -0.3];
      p.lF = [Math.sin(w * 1.5) * 0.3, 0.2];
      p.lB = [-Math.sin(w * 1.5) * 0.3, 0.2];
      break;
    }
    case 'spin': {
      p.rot = beatElapsed * 9;
      p.aF = [1.5, 0];
      p.aB = [-1.5, 0];
      break;
    }
    case 'reach': {
      p.lean = 0.2;
      p.aF = [1.65 + Math.sin(t * 4) * 0.08, -0.05];
      p.aB = [1.45, -0.1];
      break;
    }
    case 'shiver': {
      p.shiver = 1;
      p.squash = 0.95;
      p.aF = [0.65, -1.25];
      p.aB = [0.55, -1.25];
      break;
    }
    case 'laugh': {
      const b = Math.abs(Math.sin(t * 11));
      p.squash = 0.95 + b * 0.08;
      p.lean = -0.1 + b * 0.08;
      p.head = -0.12;
      p.aF = [0.55, -1.1];
      p.aB = [0.45, -1.0];
      break;
    }
  }

  // Lip-sync mouth flap when speaking
  if (say || act === 'talk') {
    const wi = wordAt(t);
    if (wi >= 0) {
      const w = WORDS[wi];
      const u = (t - w.start) / Math.max(0.06, w.end - w.start);
      p.mouth = clamp(Math.sin(u * Math.PI) * (0.65 + 0.35 * Math.abs(Math.sin(t * 26))));
    } else if (act === 'talk') {
      p.mouth = Math.max(0, Math.sin(t * 14)) * 0.45;
    }
  }

  return p;
}

const TEX_SIZE = 512;

export const CharacterCard: React.FC<{
  sc: ShotChar;
  t: number;
  shotEndT: number;
}> = ({ sc, t, shotEndT }) => {
  const design = CAST[sc.who];
  if (!design) {
    throw new Error(`Unknown character "${sc.who}" in shot. Available CAST keys: ${Object.keys(CAST).join(', ')}`);
  }

  const { camera } = useThree();
  const seed = useMemo(() => hashStr(sc.who), [sc.who]);

  const { canvas, ctx, texture } = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = TEX_SIZE;
    c.height = TEX_SIZE;
    const context = c.getContext('2d')!;
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = false;
    return { canvas: c, ctx: context, texture: tex };
  }, []);

  const ev = evaluateShotChar(sc, t, shotEndT);
  const pose = computePose(ev.act, t, ev.beatElapsed, seed, ev.say);

  // Determine facing relative to camera right vector when 'auto'
  let facing: 1 | -1 | 0 | 2 = 1;
  if (ev.look === 'right') facing = 1;
  else if (ev.look === 'left') facing = -1;
  else if (ev.look === 'front') facing = 0;
  else if (ev.look === 'back') facing = 2;
  else {
    const speedSq = ev.vel[0] * ev.vel[0] + ev.vel[2] * ev.vel[2];
    if (speedSq > 0.01) {
      // Project velocity onto camera right vector on XZ plane
      const forward = new THREE.Vector3();
      camera.getWorldDirection(forward);
      const rightX = -forward.z;
      const rightZ = forward.x;
      const dotR = ev.vel[0] * rightX + ev.vel[2] * rightZ;
      facing = dotR >= -0.02 ? 1 : -1;
    } else {
      facing = (seed & 1) === 0 ? 1 : -1;
    }
  }

  // Deterministic blink every ~3.4 seconds for 0.13 seconds
  const blinkCyc = (t + (seed % 31) * 0.17) % 3.4;
  const blink = blinkCyc > 3.27;

  const drawState: DrawState = {
    pose,
    face: ev.face,
    facing,
    blink,
    item: ev.item,
    itemText: ev.itemText,
    emote: ev.emote,
    emoteT: ev.emoteT,
    t,
  };

  drawCharacter(ctx, canvas.width, design, drawState);
  texture.needsUpdate = true;

  // Billboard yaw toward camera on XZ plane
  const dx = camera.position.x - ev.pos[0];
  const dz = camera.position.z - ev.pos[2];
  const yaw = Math.atan2(dx, dz);

  const scale = (sc.scale ?? 1) * (design.height ?? 1);
  const planeSize = CANVAS_UNITS * scale;
  // Feet are drawn at FOOT_FROM_BOTTOM above bottom of canvas -> lift plane center so feet sit at y=0
  const planeCenterY = (CANVAS_UNITS / 2 - FOOT_FROM_BOTTOM) * scale;

  return (
    <group position={ev.pos} rotation={[0, yaw, 0]}>
      {/* Ground contact shadow */}
      <mesh position={[0, 0.015, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.36 * scale * (design.width ?? 1), 24]} />
        <meshBasicMaterial color="#0f0b18" transparent opacity={0.34} depthWrite={false} />
      </mesh>
      {/* 2D character card */}
      <mesh position={[0, planeCenterY, 0]} renderOrder={2}>
        <planeGeometry args={[planeSize, planeSize]} />
        <meshBasicMaterial
          map={texture}
          transparent
          alphaTest={0.08}
          side={THREE.DoubleSide}
          toneMapped={false}
        />
      </mesh>
    </group>
  );
};
