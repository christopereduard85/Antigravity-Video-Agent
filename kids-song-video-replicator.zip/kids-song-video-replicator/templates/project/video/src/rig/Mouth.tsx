import React from 'react';
import { CharacterTokens, Pose } from './types';
import { clamp, deformBodyPoint, lerp } from './geom';

/**
 * Rule 7: Point-interpolated viseme morph with clipped upper teeth row and curved pink tongue.
 * Always shows appealing studio teeth + tongue articulation when open, and a warm smile when closed.
 */
export const Mouth: React.FC<{
  tokens: CharacterTokens;
  pose: Pose;
  idPrefix: string;
}> = ({ tokens, pose, idPrefix }) => {
  const { w: bw, h: bh, topTaper } = tokens.body;
  const center = deformBodyPoint(
    tokens.anchors.mouth.x,
    tokens.anchors.mouth.y,
    bw,
    bh,
    topTaper,
    pose.squash,
    pose.arc
  );

  const mw = tokens.mouth.w;
  const mh = tokens.mouth.h;
  const openAmt = clamp(pose.mouthOpen, 0, 1);

  // 1. Closed smile arc when not singing / between words
  if (
    (pose.viseme === 'closed' || openAmt < 0.15) &&
    pose.expression !== 'surprised'
  ) {
    const hw = mw * 0.45;
    const dip = mh * 0.44;
    return (
      <g transform={`translate(${center.x.toFixed(2)}, ${center.y.toFixed(2)})`}>
        <path
          d={`M ${(-hw).toFixed(2)} -2 Q 0 ${dip.toFixed(2)} ${hw.toFixed(2)} -2`}
          fill="none"
          stroke={tokens.colors.mouth}
          strokeWidth={4.5}
          strokeLinecap="round"
        />
        <path
          d={`M ${(-hw - 3).toFixed(2)} -5 Q ${(-hw + 1).toFixed(2)} -1 ${(-hw + 2).toFixed(2)} 3`}
          fill="none"
          stroke={tokens.colors.mouth}
          strokeWidth={3.5}
          strokeLinecap="round"
        />
        <path
          d={`M ${(hw + 3).toFixed(2)} -5 Q ${(hw - 1).toFixed(2)} -1 ${(hw - 2).toFixed(2)} 3`}
          fill="none"
          stroke={tokens.colors.mouth}
          strokeWidth={3.5}
          strokeLinecap="round"
        />
      </g>
    );
  }

  const clipId = `${idPrefix}-mouth-clip`;

  // 2. Surprised or 'O' viseme = rounded oval mouth with teeth & tongue
  if (pose.expression === 'surprised' || pose.viseme === 'O') {
    const rx = mw * lerp(0.22, 0.3, openAmt);
    const ry = mh * lerp(0.36, 0.64, openAmt);
    return (
      <g
        transform={`translate(${center.x.toFixed(2)}, ${(center.y + 6).toFixed(
          2
        )})`}
      >
        <defs>
          <clipPath id={clipId}>
            <ellipse cx={0} cy={0} rx={rx} ry={ry} />
          </clipPath>
        </defs>
        <g clipPath={`url(#${clipId})`}>
          <ellipse cx={0} cy={0} rx={rx} ry={ry} fill={tokens.colors.mouth} />
          <rect
            x={-rx * 0.75}
            y={-ry * 1.05}
            width={rx * 1.5}
            height={ry * 0.45}
            rx={3}
            fill={tokens.colors.teeth}
          />
          <ellipse
            cx={0}
            cy={ry * 0.68}
            rx={rx * 0.85}
            ry={ry * 0.52}
            fill={tokens.colors.tongue}
          />
        </g>
      </g>
    );
  }

  // 3. Expressive Singing / Speaking D-Mouth ('mid', 'open', 'E')
  // Smoothly modulates width and jaw drop depth on every syllable!
  const isE = pose.viseme === 'E';
  const isOpen = pose.viseme === 'open';
  const hw = mw * (isE ? 0.53 : isOpen ? lerp(0.46, 0.52, openAmt) : lerp(0.42, 0.48, openAmt));
  const topDip = mh * 0.04;
  const botDepth =
    mh *
    (isOpen
      ? lerp(0.55, 1.04, openAmt)
      : isE
      ? lerp(0.42, 0.76, openAmt)
      : lerp(0.38, 0.84, openAmt));

  const mouthPath = `M ${(-hw).toFixed(2)} -3 Q 0 ${topDip.toFixed(
    2
  )} ${hw.toFixed(2)} -3 C ${(hw * 0.96).toFixed(2)} ${(
    botDepth * 0.75
  ).toFixed(2)}, ${(hw * 0.45).toFixed(2)} ${botDepth.toFixed(
    2
  )}, 0 ${botDepth.toFixed(2)} C ${(-hw * 0.45).toFixed(
    2
  )} ${botDepth.toFixed(2)}, ${(-hw * 0.96).toFixed(2)} ${(
    botDepth * 0.75
  ).toFixed(2)}, ${(-hw).toFixed(2)} -3 Z`;

  const teethDepth = mh * (isE ? 0.28 : 0.23);

  return (
    <g transform={`translate(${center.x.toFixed(2)}, ${center.y.toFixed(2)})`}>
      <defs>
        <clipPath id={clipId}>
          <path d={mouthPath} />
        </clipPath>
      </defs>

      <g clipPath={`url(#${clipId})`}>
        <path d={mouthPath} fill={tokens.colors.mouth} />
        <path
          d={`M ${(-hw * 0.88).toFixed(2)} -8 L ${(hw * 0.88).toFixed(
            2
          )} -8 L ${(hw * 0.82).toFixed(2)} ${teethDepth.toFixed(2)} Q 0 ${(
            teethDepth + 4
          ).toFixed(2)} ${(-hw * 0.82).toFixed(2)} ${teethDepth.toFixed(2)} Z`}
          fill={tokens.colors.teeth}
        />
        <ellipse
          cx={0}
          cy={botDepth * 0.9}
          rx={hw * 0.68}
          ry={botDepth * 0.48}
          fill={tokens.colors.tongue}
        />
      </g>
    </g>
  );
};
