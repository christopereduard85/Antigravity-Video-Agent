// ============================================================================
// CINEMATIC POST-PROCESSING, TRANSITIONS, OVERLAYS & SCREEN FX.
// Pure deterministic layer on top of ThreeCanvas:
//  - Depth-of-field lens softness & warm storybook color grade
//  - Vignette & subtle sunlit bloom
//  - Shot transitions (cut, whip, dissolve, flash, zoom, wipe)
//  - Action speedlines & impact flashes
//  - Diegetic / graphic overlays (title, stamp, label, counter)
// ============================================================================
import React from 'react';
import { INK } from './drawCharacter';
import { timeOf } from './timing';
import type { Overlay, Shot } from './types';
import { clamp, easeInOut, spring } from './util';

export const PostLayer: React.FC<{
  shot: Shot;
  t: number;
  shotStartT: number;
  shotEndT: number;
}> = ({ shot, t, shotStartT, shotEndT }) => {
  const blurStrength = shot.cam.blur ?? 1;
  const elapsed = Math.max(0, t - shotStartT);
  const remain = Math.max(0, shotEndT - t);

  // Active flash FX
  let flashAlpha = 0;
  let hasSpeedlines = false;
  for (const fx of shot.fx ?? []) {
    const t0 = timeOf(fx.at);
    const dur = fx.dur ?? (fx.k === 'flash' ? 0.28 : 0.65);
    if (t >= t0 && t <= t0 + dur) {
      const u = (t - t0) / dur;
      if (fx.k === 'flash' || fx.k === 'explosion') {
        flashAlpha = Math.max(flashAlpha, (1 - u) * (fx.k === 'flash' ? 0.85 : 0.45));
      }
      if (fx.k === 'speedlines') {
        hasSpeedlines = true;
      }
    }
  }

  // Shot entrance transition
  const tr = shot.transition ?? 'cut';
  const trDur = tr === 'cut' ? 0 : 0.24;
  const trU = trDur > 0 ? clamp(elapsed / trDur) : 1;

  if (tr === 'flash' && trU < 1) {
    flashAlpha = Math.max(flashAlpha, (1 - trU) * 0.85);
  }

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      {/* Top & bottom tilt-shift depth-of-field lens softness */}
      {blurStrength > 0.05 && (
        <>
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '18%',
              backdropFilter: `blur(${(2.4 * blurStrength).toFixed(1)}px)`,
              WebkitMaskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.85), rgba(0,0,0,0))',
              maskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.85), rgba(0,0,0,0))',
            }}
          />
          <div
            style={{
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              height: '14%',
              backdropFilter: `blur(${(1.8 * blurStrength).toFixed(1)}px)`,
              WebkitMaskImage: 'linear-gradient(to top, rgba(0,0,0,0.75), rgba(0,0,0,0))',
              maskImage: 'linear-gradient(to top, rgba(0,0,0,0.75), rgba(0,0,0,0))',
            }}
          />
        </>
      )}

      {/* Warm storybook sunlight grade + soft vignette */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(circle at 50% 42%, rgba(255,248,225,0.06) 0%, rgba(20,14,32,0.0) 58%, rgba(16,12,26,0.34) 100%)',
        }}
      />

      {/* Comic action speedlines */}
      {hasSpeedlines && <SpeedLinesOverlay t={t} />}

      {/* Graphic overlays (titles, stamps, labels, counters) */}
      {(shot.overlays ?? []).map((ov, i) => (
        <OverlayItem key={i} ov={ov} t={t} shotEndT={shotEndT} />
      ))}

      {/* Impact / transition flash */}
      {flashAlpha > 0.01 && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backgroundColor: `rgba(255, 252, 235, ${flashAlpha.toFixed(3)})`,
          }}
        />
      )}

      {/* Wipe / whip / dissolve transition overlays */}
      {tr === 'dissolve' && trU < 1 && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backgroundColor: `rgba(27, 22, 34, ${(1 - easeInOut(trU)) * 0.55})`,
          }}
        />
      )}
      {tr === 'wipe' && trU < 1 && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            bottom: 0,
            left: `${easeInOut(trU) * 100}%`,
            width: '100%',
            backgroundColor: INK,
          }}
        />
      )}
      {tr === 'whip' && trU < 1 && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backdropFilter: `blur(${((1 - trU) * 14).toFixed(1)}px)`,
          }}
        />
      )}
      {remain < 0.01 && null}
    </div>
  );
};

const SpeedLinesOverlay: React.FC<{ t: number }> = ({ t }) => {
  const step = Math.floor(t * 24);
  return (
    <svg
      viewBox="0 0 1000 1000"
      preserveAspectRatio="none"
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.55 }}
    >
      {Array.from({ length: 28 }).map((_, i) => {
        const a = (i / 28) * Math.PI * 2 + (step % 3) * 0.04;
        const rIn = 340 + ((i * 19 + step * 13) % 90);
        const rOut = 760;
        const x1 = 500 + Math.cos(a) * rIn;
        const y1 = 500 + Math.sin(a) * rIn;
        const x2 = 500 + Math.cos(a + 0.018) * rOut;
        const y2 = 500 + Math.sin(a + 0.018) * rOut;
        const x3 = 500 + Math.cos(a - 0.018) * rOut;
        const y3 = 500 + Math.sin(a - 0.018) * rOut;
        return <polygon key={i} points={`${x1},${y1} ${x2},${y2} ${x3},${y3}`} fill="#FFFFFF" stroke={INK} strokeWidth={3} />;
      })}
    </svg>
  );
};

const OverlayItem: React.FC<{ ov: Overlay; t: number; shotEndT: number }> = ({ ov, t, shotEndT }) => {
  const t0 = timeOf(ov.at);
  const t1 = ov.to !== undefined ? timeOf(ov.to) : shotEndT;
  if (t < t0 || t > t1) return null;

  const pop = spring(t - t0, 3, 5.5);
  const top = ov.pos === 'top' ? '13%' : ov.pos === 'bottom' ? '66%' : '24%';

  if (ov.k === 'stamp') {
    return (
      <div
        style={{
          position: 'absolute',
          top,
          left: '50%',
          transform: `translate(-50%, -50%) scale(${pop.toFixed(3)}) rotate(-6deg)`,
          border: `6px solid ${ov.color ?? '#D92B3A'}`,
          backgroundColor: 'rgba(255,250,238,0.94)',
          color: ov.color ?? '#D92B3A',
          padding: '10px 26px',
          borderRadius: 12,
          fontFamily: 'Montserrat, Arial Black, sans-serif',
          fontWeight: 900,
          fontSize: 42,
          letterSpacing: 2,
          textTransform: 'uppercase',
          boxShadow: `0 6px 0 ${INK}`,
          whiteSpace: 'pre-line',
          textAlign: 'center',
        }}
      >
        {ov.text}
      </div>
    );
  }

  return (
    <div
      style={{
        position: 'absolute',
        top,
        left: '50%',
        transform: `translate(-50%, -50%) scale(${pop.toFixed(3)})`,
        backgroundColor: ov.color ?? '#FFF6DC',
        color: INK,
        border: `5px solid ${INK}`,
        padding: ov.k === 'title' ? '14px 32px' : '8px 20px',
        borderRadius: 14,
        fontFamily: 'Montserrat, Arial Black, sans-serif',
        fontWeight: 900,
        fontSize: ov.k === 'title' ? 38 : 28,
        boxShadow: `0 6px 0 ${INK}`,
        whiteSpace: 'pre-line',
        textAlign: 'center',
      }}
    >
      {ov.text}
    </div>
  );
};
