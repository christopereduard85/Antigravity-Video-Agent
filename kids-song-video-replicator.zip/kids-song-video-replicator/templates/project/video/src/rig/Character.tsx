import React from 'react';
import { CharacterTokens, CostumeSpec, Pose } from './types';
import { deformBodyPoint } from './geom';
import { ContactShadow } from './ContactShadow';
import { Body } from './Body';
import { Limb } from './Limb';
import { Eyes } from './Eyes';
import { Mouth } from './Mouth';
import { Appendage } from './Appendage';
import { BEATS } from '../timeline';

export interface CharacterProps {
  tokens: CharacterTokens;
  pose: Pose;
  frame: number;
  fps?: number;
  costume?: CostumeSpec | null;
  hasMic?: boolean;
  /** Optional bowler hat attached directly to the deformed head crown (0 = on head, 1 = tipped in greeting) */
  hatTipProgress?: number;
  /** Optional trick-or-treat pumpkin candy bucket held in left hand */
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId?: string;
}

export const Character: React.FC<CharacterProps> = ({
  tokens,
  pose,
  frame,
  fps = 30,
  costume = null,
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1,
  instanceId = 'char',
}) => {
  const { w, h, topTaper } = tokens.body;
  const legHeight = tokens.limbs.legLen[0] + tokens.limbs.legLen[1];
  const bodyCenterY = -(legHeight + h * 0.44) - pose.jumpY;

  const shoulderL = deformBodyPoint(
    tokens.anchors.shoulderL.x,
    tokens.anchors.shoulderL.y,
    w,
    h,
    topTaper,
    pose.squash,
    pose.arc
  );
  const shoulderR = deformBodyPoint(
    tokens.anchors.shoulderR.x,
    tokens.anchors.shoulderR.y,
    w,
    h,
    topTaper,
    pose.squash,
    pose.arc
  );
  const hipL = deformBodyPoint(
    tokens.anchors.hipL.x,
    tokens.anchors.hipL.y,
    w,
    h,
    topTaper,
    pose.squash,
    pose.arc
  );
  const hipR = deformBodyPoint(
    tokens.anchors.hipR.x,
    tokens.anchors.hipR.y,
    w,
    h,
    topTaper,
    pose.squash,
    pose.arc
  );
  const crown = deformBodyPoint(
    0,
    -0.96,
    w,
    h,
    topTaper,
    pose.squash,
    pose.arc
  );

  const footTargetL = {
    x: pose.footL.x,
    y: pose.footL.y - bodyCenterY - pose.jumpY * 0.28,
  };
  const footTargetR = {
    x: pose.footR.x,
    y: pose.footR.y - bodyCenterY - pose.jumpY * 0.28,
  };

  const costumeProps = {
    bodyW: w,
    bodyH: h,
    squash: pose.squash,
    lean: pose.lean,
    arc: pose.arc,
    frame,
    fps,
    velX: 0,
    velY: 0,
  };

  const idPrefix = `${tokens.id}-${instanceId}`;
  const bodyClipId = `${idPrefix}-body-clip`;

  const spinCos =
    pose.spinAngle !== undefined ? Math.cos((pose.spinAngle * Math.PI) / 180) : 1;
  const spinScaleX =
    pose.spinAngle !== undefined
      ? Math.sign(spinCos || 1) * Math.max(0.25, Math.abs(spinCos))
      : 1;

  return (
    <g
      transform={`translate(${pose.root.x.toFixed(2)}, ${pose.root.y.toFixed(
        2
      )}) scale(${scale})`}
    >
      {/* 1. Ground contact shadow */}
      <ContactShadow width={w} jumpY={pose.jumpY} squash={pose.squash} />

      {/* Main character group anchored at body center */}
      <g
        transform={`translate(0, ${bodyCenterY.toFixed(2)}) rotate(${pose.lean.toFixed(
          2
        )}) scale(${spinScaleX.toFixed(3)}, 1)`}
      >
        {/* 2. Back appendages */}
        {!costume?.hideAppendages &&
          tokens.appendages
            .filter((a) => a.layer !== 'front')
            .map((a, idx) => (
              <Appendage
                key={`app-b-${idx}`}
                spec={a}
                tokens={tokens}
                pose={pose}
                frame={frame}
                fps={fps}
                beatPeriodSec={BEATS.beatPeriodSec}
              />
            ))}

        {/* 3. Costume Back layer */}
        {costume?.Back && <costume.Back {...costumeProps} />}

        {/* 4. Extra back leg pairs (e.g. Grub 4 legs) */}
        {tokens.extraLegPairs?.map((pair, idx) => {
          const eHipL = deformBodyPoint(
            pair.hipL.x,
            pair.hipL.y,
            w,
            h,
            topTaper,
            pose.squash,
            pose.arc
          );
          const eHipR = deformBodyPoint(
            pair.hipR.x,
            pair.hipR.y,
            w,
            h,
            topTaper,
            pose.squash,
            pose.arc
          );
          return (
            <g key={`extra-legs-${idx}`}>
              <Limb
                kind="leg"
                side="L"
                root={eHipL}
                target={{
                  x: footTargetL.x - pair.footOffsetX,
                  y: footTargetL.y + pair.footOffsetY,
                }}
                lengths={tokens.limbs.legLen}
                widths={tokens.limbs.width}
                limbColor={tokens.colors.limb}
                shadeColor={tokens.colors.shade}
                footColor={tokens.colors.feet}
              />
              <Limb
                kind="leg"
                side="R"
                root={eHipR}
                target={{
                  x: footTargetR.x + pair.footOffsetX,
                  y: footTargetR.y + pair.footOffsetY,
                }}
                lengths={tokens.limbs.legLen}
                widths={tokens.limbs.width}
                limbColor={tokens.colors.limb}
                shadeColor={tokens.colors.shade}
                footColor={tokens.colors.feet}
              />
            </g>
          );
        })}

        {/* 5. Primary Legs */}
        <Limb
          kind="leg"
          side="L"
          root={hipL}
          target={footTargetL}
          lengths={tokens.limbs.legLen}
          widths={tokens.limbs.width}
          limbColor={tokens.colors.limb}
          shadeColor={tokens.colors.shade}
          footColor={tokens.colors.feet}
        />
        <Limb
          kind="leg"
          side="R"
          root={hipR}
          target={footTargetR}
          lengths={tokens.limbs.legLen}
          widths={tokens.limbs.width}
          limbColor={tokens.colors.limb}
          shadeColor={tokens.colors.shade}
          footColor={tokens.colors.feet}
        />

        {/* 6. Far arm (Left arm) */}
        <Limb
          kind="arm"
          side="L"
          root={shoulderL}
          target={pose.handL}
          lengths={tokens.limbs.armLen}
          widths={tokens.limbs.width}
          limbColor={tokens.colors.limb}
          shadeColor={tokens.colors.shade}
          footColor={tokens.colors.feet}
        />

        {/* Optional Trick-or-Treat Candy Bucket held in Left Hand */}
        {hasCandyBucket && (
          <g
            transform={`translate(${pose.handL.x.toFixed(1)}, ${(
              pose.handL.y + 18
            ).toFixed(1)}) rotate(${(pose.lean * -0.8).toFixed(1)}) scale(0.75)`}
          >
            <path
              d="M -30 -8 A 30 28 0 0 1 30 -8"
              fill="none"
              stroke="#2B142C"
              strokeWidth={6}
            />
            <ellipse cx={0} cy={14} rx={34} ry={25} fill="#FF7B1C" />
            <ellipse cx={0} cy={14} rx={22} ry={25} fill="#FF9436" />
            <rect x={-25} y={-10} width={50} height={7} rx={3.5} fill="#D95B08" />
            <polygon points="-14,8 -8,-1 -2,8" fill="#2B142C" />
            <polygon points="2,8 8,-1 14,8" fill="#2B142C" />
            <path
              d="M -15 17 Q 0 27 15 17"
              fill="none"
              stroke="#2B142C"
              strokeWidth={4}
              strokeLinecap="round"
            />
          </g>
        )}

        {/* 7. Deformable Body + Clipped Shading + Belly + Spots */}
        <Body tokens={tokens} pose={pose} clipId={bodyClipId} />

        {/* 8. Eyes + Blush */}
        <Eyes tokens={tokens} pose={pose} frame={frame} idPrefix={idPrefix} />

        {/* 9. Viseme Mouth */}
        <Mouth tokens={tokens} pose={pose} idPrefix={idPrefix} />

        {/* 10. Costume Front & Hat layers */}
        {costume?.Front && <costume.Front {...costumeProps} />}
        {costume?.Hat && <costume.Hat {...costumeProps} />}

        {/* Optional Dapper Bowler Hat Anchored Directly to Deformed Head Crown! */}
        {!costume && hatTipProgress !== undefined && (
          <g
            transform={`translate(${(
              crown.x -
              14 +
              hatTipProgress * 18
            ).toFixed(1)}, ${(crown.y + 4 - hatTipProgress * 26).toFixed(
              1
            )}) rotate(${(-8 + hatTipProgress * 24).toFixed(1)}) scale(0.68)`}
          >
            <ellipse cx={0} cy={8} rx={68} ry={14} fill="#1E1826" />
            <path d="M -46 6 C -46 -46, 46 -46, 46 6 Z" fill="#2B2336" />
            <path
              d="M -44 2 Q 0 10 44 2"
              fill="none"
              stroke="#E8382B"
              strokeWidth={9}
            />
          </g>
        )}

        {/* 11. Near arm (Right arm) + optional stage Microphone */}
        <Limb
          kind="arm"
          side="R"
          root={shoulderR}
          target={pose.handR}
          lengths={tokens.limbs.armLen}
          widths={tokens.limbs.width}
          limbColor={tokens.colors.limb}
          shadeColor={tokens.colors.shade}
          footColor={tokens.colors.feet}
        />

        {hasMic && (
          <g
            transform={`translate(${pose.handR.x.toFixed(2)}, ${pose.handR.y.toFixed(
              2
            )}) rotate(-28)`}
          >
            <rect x={-4} y={-26} width={8} height={28} rx={3} fill="#2B2D38" />
            <circle cx={0} cy={-30} r={10} fill="#9CA4B8" />
            <path d="M -9 -30 L 9 -30" stroke="#5A6275" strokeWidth={2} />
          </g>
        )}

        {/* 12. Front appendages */}
        {!costume?.hideAppendages &&
          tokens.appendages
            .filter((a) => a.layer === 'front')
            .map((a, idx) => (
              <Appendage
                key={`app-f-${idx}`}
                spec={a}
                tokens={tokens}
                pose={pose}
                frame={frame}
                fps={fps}
                beatPeriodSec={BEATS.beatPeriodSec}
              />
            ))}
      </g>
    </g>
  );
};
