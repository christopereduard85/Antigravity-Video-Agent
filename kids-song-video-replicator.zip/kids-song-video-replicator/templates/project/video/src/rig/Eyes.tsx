import React from 'react';
import { CharacterTokens, Pose } from './types';
import { clamp, deformBodyPoint, getSquashStretch } from './geom';
import { evalSaccade } from './spring';

export const Eyes: React.FC<{
  tokens: CharacterTokens;
  pose: Pose;
  frame: number;
  idPrefix: string;
}> = ({ tokens, pose, frame, idPrefix }) => {
  const { w, h, topTaper } = tokens.body;
  const { sx, sy } = getSquashStretch(pose.squash * 0.45);
  const sac = evalSaccade(frame, tokens.id);
  const lookX = clamp(pose.look.x + sac.x, -1, 1);
  const lookY = clamp(pose.look.y + sac.y, -1, 1);

  return (
    <g>
      {/* Rosy blush cheeks */}
      {tokens.anchors.blush.map((b, idx) => {
        const pt = deformBodyPoint(
          b.x,
          b.y,
          w,
          h,
          topTaper,
          pose.squash,
          pose.arc
        );
        return (
          <ellipse
            key={`blush-${idx}`}
            cx={pt.x}
            cy={pt.y}
            rx={tokens.eyes.r * 0.68 * sx}
            ry={tokens.eyes.r * 0.38 * sy}
            fill={tokens.colors.blush}
            opacity={0.72}
          />
        );
      })}

      {/* Eyes */}
      {tokens.anchors.eyes.map((ea, idx) => {
        const pt = deformBodyPoint(
          ea.x,
          ea.y,
          w,
          h,
          topTaper,
          pose.squash,
          pose.arc
        );
        const r = tokens.eyes.r;
        const pr = tokens.eyes.pupilR;
        const rx = r * sx;
        const ry = r * sy;
        const clipId = `${idPrefix}-eye-${idx}`;
        const sideSign = ea.x < -0.05 ? -1 : ea.x > 0.05 ? 1 : 0;

        // Happy singing eyes = joyful upward curved arcs
        if (pose.expression === 'sing') {
          return (
            <path
              key={idx}
              d={`M ${(pt.x - rx * 0.85).toFixed(2)} ${(pt.y + ry * 0.15).toFixed(
                2
              )} Q ${pt.x.toFixed(2)} ${(pt.y - ry * 0.95).toFixed(2)} ${(
                pt.x +
                rx * 0.85
              ).toFixed(2)} ${(pt.y + ry * 0.15).toFixed(2)}`}
              fill="none"
              stroke={tokens.colors.pupil}
              strokeWidth={5.2}
              strokeLinecap="round"
            />
          );
        }

        // Wink expression closes rightmost eye
        if (pose.expression === 'wink' && idx === tokens.anchors.eyes.length - 1) {
          return (
            <g key={idx}>
              <path
                d={`M ${(pt.x - rx * 0.8).toFixed(2)} ${(
                  pt.y -
                  ry * 0.35
                ).toFixed(2)} L ${(pt.x + rx * 0.55).toFixed(2)} ${pt.y.toFixed(
                  2
                )} L ${(pt.x - rx * 0.8).toFixed(2)} ${(
                  pt.y +
                  ry * 0.35
                ).toFixed(2)}`}
                fill="none"
                stroke={tokens.colors.pupil}
                strokeWidth={5}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </g>
          );
        }

        const maxShift = (r - pr) * 0.58;
        const px = pt.x + lookX * maxShift;
        const py = pt.y + lookY * maxShift;
        const pupilScale = pose.expression === 'surprised' ? 0.82 : 1.0;
        const lidDrop = clamp(pose.blink, 0, 1) * (ry * 2.15);

        return (
          <g key={idx}>
            <defs>
              <clipPath id={clipId}>
                <ellipse cx={pt.x} cy={pt.y} rx={rx} ry={ry} />
              </clipPath>
            </defs>

            {/* Optional outer eyelashes (e.g. Lulu) */}
            {tokens.eyes.hasLashes && sideSign !== 0 && (
              <g stroke={tokens.colors.pupil} strokeWidth={3.2} strokeLinecap="round">
                <line
                  x1={pt.x + sideSign * rx * 0.78}
                  y1={pt.y - ry * 0.45}
                  x2={pt.x + sideSign * rx * 1.18}
                  y2={pt.y - ry * 0.72}
                />
                <line
                  x1={pt.x + sideSign * rx * 0.92}
                  y1={pt.y - ry * 0.12}
                  x2={pt.x + sideSign * rx * 1.28}
                  y2={pt.y - ry * 0.28}
                />
              </g>
            )}

            <g clipPath={`url(#${clipId})`}>
              <ellipse
                cx={pt.x}
                cy={pt.y}
                rx={rx}
                ry={ry}
                fill={tokens.colors.eyeWhite}
              />
              <ellipse
                cx={pt.x}
                cy={pt.y - ry * 0.85}
                rx={rx * 1.1}
                ry={ry * 0.4}
                fill="rgba(0,0,0,0.08)"
              />

              <circle
                cx={px}
                cy={py}
                r={pr * pupilScale}
                fill={tokens.colors.pupil}
              />

              <circle
                cx={px - pr * 0.34}
                cy={py - pr * 0.34}
                r={tokens.eyes.catchlight}
                fill="#FFFFFF"
              />
              <circle
                cx={px + pr * 0.32}
                cy={py + pr * 0.32}
                r={tokens.eyes.catchlight * 0.45}
                fill="#FFFFFF"
                opacity={0.85}
              />

              {lidDrop > 0.02 && (
                <g>
                  <rect
                    x={pt.x - rx * 1.2}
                    y={pt.y - ry * 1.2}
                    width={rx * 2.4}
                    height={lidDrop}
                    fill={tokens.colors.base}
                  />
                  <line
                    x1={pt.x - rx}
                    y1={pt.y - ry + lidDrop}
                    x2={pt.x + rx}
                    y2={pt.y - ry + lidDrop}
                    stroke={tokens.colors.shade}
                    strokeWidth={3}
                  />
                </g>
              )}
            </g>
          </g>
        );
      })}
    </g>
  );
};
