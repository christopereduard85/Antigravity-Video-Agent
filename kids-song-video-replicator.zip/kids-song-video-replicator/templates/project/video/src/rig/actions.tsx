import React from 'react';
import { CharacterTokens, Pose, Vec } from './types';
import { clamp, lerp } from './geom';
import { makeBeatDancePose } from './poses';

/**
 * Spin Tornado Transform sequence (CHARACTER_DESIGN_SYSTEM.md §5):
 * Given localFrame (0..durationFrames, typically 47 frames = 1 bar @ 152 BPM):
 * - 0..9   (anticipation crouch): deep squash down, arms tucked in
 * - 10..31 (spin tornado): rapid spin, stretch up, colorful tornado rings cover body; costume swaps at mid-spin (frame 21)
 * - 32..40 (overshoot pop): costume pops out in high jump stretch with arms raised
 * - 41..47 (settle): lands with soft squash -> ready to dance
 */
export function evalSpinTransform(
  tokens: CharacterTokens,
  globalFrame: number,
  localFrame: number,
  totalFrames = 47,
  root: Vec = { x: 960, y: 840 }
): {
  pose: Pose;
  useCostume: boolean;
  tornadoProgress: number; // 0 = hidden, 0..1 = active swirl
} {
  const base = makeBeatDancePose(tokens, globalFrame, root, 'dance');
  const hw = tokens.body.w * 0.5;
  const hh = tokens.body.h * 0.5;

  if (localFrame < 10) {
    // Anticipation crouch
    const t = localFrame / 10;
    const ease = Math.sin((t * Math.PI) / 2);
    return {
      pose: {
        ...base,
        jumpY: 0,
        squash: lerp(0, 0.52, ease),
        lean: lerp(0, -6, ease),
        handL: { x: -hw - 12, y: hh * 0.3 },
        handR: { x: hw + 12, y: hh * 0.3 },
        viseme: 'O',
        mouthOpen: 0.5,
        expression: 'surprised',
      },
      useCostume: false,
      tornadoProgress: 0,
    };
  }

  if (localFrame < 32) {
    // Tornado spin!
    const t = (localFrame - 10) / 22;
    const spinAngle = t * 1080; // 3 full turns
    const jumpY = Math.sin(t * Math.PI) * 58;
    return {
      pose: {
        ...base,
        jumpY,
        squash: -0.35,
        lean: Math.sin(t * Math.PI * 4) * 10,
        spinAngle,
        handL: { x: -hw - 36, y: -hh * 0.4 },
        handR: { x: hw + 36, y: -hh * 0.4 },
        viseme: 'open',
        mouthOpen: 0.85,
        expression: 'happy',
      },
      useCostume: t >= 0.5,
      tornadoProgress: Math.sin(t * Math.PI),
    };
  }

  // Overshoot pop & settle (32..totalFrames)
  const t = clamp((localFrame - 32) / Math.max(1, totalFrames - 32), 0, 1);
  const popJump = Math.max(0, Math.sin(t * Math.PI) * 40 * (1 - t * 0.5));
  const settleSquash = Math.sin(t * Math.PI * 2) * -0.32 * (1 - t * 0.4);

  return {
    pose: {
      ...base,
      jumpY: popJump,
      squash: settleSquash,
      lean: (1 - t) * -8,
      handL: { x: -hw - 40, y: lerp(-hh * 0.65, -hh * 0.15, t) },
      handR: { x: hw + 40, y: lerp(-hh * 0.65, -hh * 0.15, t) },
      viseme: 'open',
      mouthOpen: 0.8,
      expression: 'happy',
    },
    useCostume: true,
    tornadoProgress: 0,
  };
}

/**
 * Colorful cartoon Tornado Swirl SVG overlay matching reference video spin transforms (sheet_01 row 4, sheet_02 row 4).
 */
export const TornadoSwirl: React.FC<{
  x: number;
  y: number;
  progress: number; // 0..1
  frame: number;
  colors?: readonly [string, string, string];
}> = ({
  x,
  y,
  progress,
  frame,
  colors = ['#9BD43F', '#FFC71F', '#E8382B'],
}) => {
  if (progress <= 0.01) return null;
  const bands = 7;
  return (
    <g
      transform={`translate(${x.toFixed(2)}, ${y.toFixed(2)})`}
      opacity={Math.min(1, progress * 1.35)}
    >
      {Array.from({ length: bands }).map((_, i) => {
        const frac = i / (bands - 1); // 0 bottom .. 1 top
        const cy = -40 - frac * 250;
        const wobble = Math.sin(frame * 0.65 + i * 1.3) * 18;
        const rx = (48 + frac * 95) * (0.65 + progress * 0.45);
        const ry = 20 + frac * 12;
        const col = colors[i % colors.length];
        return (
          <g key={i} transform={`translate(${wobble.toFixed(2)}, ${cy.toFixed(2)}) rotate(${(Math.sin(frame * 0.5 + i) * 6).toFixed(2)})`}>
            <ellipse cx={0} cy={0} rx={rx} ry={ry} fill={col} />
            <ellipse
              cx={-rx * 0.2}
              cy={-ry * 0.2}
              rx={rx * 0.65}
              ry={ry * 0.45}
              fill="rgba(255,255,255,0.28)"
            />
          </g>
        );
      })}
    </g>
  );
};
