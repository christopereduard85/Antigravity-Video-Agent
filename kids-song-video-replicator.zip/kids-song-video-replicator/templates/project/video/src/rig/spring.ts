/**
 * Deterministic damped spring & secondary-motion helpers for Remotion.
 * Every function is pure in `frame` so any frame rendered out-of-order produces the exact same result.
 */

export function evalSpringSwings(
  frame: number,
  fps: number,
  beatPeriodSec: number,
  stiffness = 180,
  damping = 12,
  phaseOffset = 0,
  impulseAmp = 14
): { angleDeg: number; stretch: number } {
  const t = frame / fps;
  const omega = Math.sqrt(stiffness);
  const zeta = damping / (2 * omega);
  const omegaD = omega * Math.sqrt(Math.max(0.05, 1 - zeta * zeta));

  // Sum damped responses from recent beats + continuous harmonic sway
  const beatFloat = t / beatPeriodSec + phaseOffset;
  const frac = beatFloat - Math.floor(beatFloat);
  const dt = frac * beatPeriodSec;
  const dir = Math.floor(beatFloat) % 2 === 0 ? 1 : -1;

  const impulse =
    dir *
    impulseAmp *
    Math.exp(-zeta * omega * dt * 0.35) *
    Math.sin(omegaD * dt * 0.45);

  const harmonic = Math.sin(beatFloat * Math.PI) * (impulseAmp * 0.42);
  const stretch =
    Math.exp(-zeta * omega * dt * 0.4) * Math.cos(omegaD * dt * 0.5) * 0.08;

  return {
    angleDeg: impulse + harmonic,
    stretch,
  };
}

/**
 * Deterministic blink generator seeded by character id and frame.
 * Blinks every ~2.8 - 3.6 seconds; blink lasts 6 frames (close 2, hold 1, open 3).
 */
export function evalAutoBlink(frame: number, seedStr: string): number {
  let hash = 2166136261;
  for (let i = 0; i < seedStr.length; i++) {
    hash ^= seedStr.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const period = 88 + (Math.abs(hash) % 24); // ~3.0 - 3.7s @ 30fps
  const offset = Math.abs(hash >> 8) % period;
  const local = (frame + offset) % period;
  const curve = [0.35, 0.9, 1.0, 0.85, 0.4, 0.1];
  if (local >= 0 && local < curve.length) {
    return curve[local];
  }
  return 0;
}

/**
 * Deterministic subtle eye saccade (pupil micro-look) every ~1.8 seconds.
 */
export function evalSaccade(frame: number, seedStr: string): { x: number; y: number } {
  const bucket = Math.floor(frame / 54);
  const s = bucket * 131 + seedStr.charCodeAt(0) * 17;
  const x = Math.sin(s * 1.7) * 0.18;
  const y = Math.cos(s * 2.3) * 0.1;
  return { x, y };
}
