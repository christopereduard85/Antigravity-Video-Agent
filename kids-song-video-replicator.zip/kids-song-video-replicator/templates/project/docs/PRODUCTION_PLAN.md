# PRODUCTION PLAN — "Halloween Night" (Costume Party Food Song)

> Handoff doc. Any model/agent continuing this project: read this file first, then `AGENTS.md`.
> **Next agent: open `NEXT_STEPS.md` first (locked decisions + task queue).**
> Status tracker at bottom. Update it after every step + run `graphify update`.

---

## 0. Inputs

| Asset | Path | Notes |
|---|---|---|
| Reference video | `ReferenceVideo.mp4` | 1920x1080, 30 fps, 156.83 s, 4705 frames. Super Simple Songs style. |
| Reference frames | `reference_frames/frame_00001.jpg … frame_04705.jpg` | frame N = time (N-1)/30 s |
| Contact sheets | `analysis/contact/sheet_01..03.jpg` | 1 tile = 2 s, 6x5 grid, 60 s per sheet. Use these first (cheap tokens). |
| Hard cuts (ref) | `analysis/ref_cuts.txt` | 11.3 25.4 33.27 52.67 55.9 60.67 79.9 83.03 104.03 112.9 113.03 133.6 134.83 137.53 143.13 (most transitions are wipes/morphs, not hard cuts) |
| Our song | `Halloween Night.wav` | **133.207 s** → **3997 frames @ 30 fps** |
| Our lyrics | `PROJECTlyric.txt` | 4 verses + 4 choruses + finale |

---

## 1. Style DNA (from reference)

- **Look**: flat 2D vector, no outlines, soft rounded shapes, tiny inner shading only (1 darker tone). Thick limbs = simple noodle lines (2–3 px @1080 scaled ~8 px), stick legs, mitten/3-finger hands.
- **Faces**: big white eyes with black pupils + small highlight, huge open mouths (teeth row), blush. Eyes blink, mouth lip-syncs open/close on syllables.
- **Palette**: deep maroon/burgundy theatre (#5A0F22, #7A1530 curtains), wooden stage orange-brown (#C47A3A / #8A4A22), night purple (#4B1E8C, #6A2FC0), saturated food colors (tomato red, cheese yellow, frosting pink #F7B6D2), mint, lime.
- **Recurring set**: theatre stage with red curtains + scalloped valance + spotlight cone; Halloween props (jack-o'-lanterns, candles, moon, bats, cobweb).
- **Motion**: bouncy, on-beat squash & stretch, 2-pose dance loops (side-to-side hop every beat), arm wave cycles, constant subtle idle bob. Snappy ease-out-back on entrances. Camera mostly static; occasional push-in / pan.
- **Transitions**: spin-tornado transform (character spins into colored swirl → reveals costume), themed wipes (wavy ketchup stripes, frosting drip, candy-cane stripe), food-object fills screen then pulls back, iris/curtain open-close.
- **Branding bug**: bottom-right logo (replace with our own logo, ~120 px).

## 2. Reference structure → Our song (1:1 mapping, same 4-block + finale form)

Reference time is ±1 s (from contact sheets). Our times are **exact 152.0 BPM downbeat-snapped times** from `analysis/beats.json` (30 fps, 3997 frames total).

| # | Section | Reference (s) | Reference content | Ours (s / frames) | Our content |
|---|---|---|---|---|---|
| A | Intro | 0–2 | Bat at moonlit castle window, candles | 0.00–1.31 (0–39) | Pip (bat) at moonlit castle window |
| B | Band intro | 2–10 | Curtains open; cat drummer, snake bassist, bat on bass; singer enters with mic | 1.31–2.10 (39–63) | Curtain open, band (Bones, Spinny, Boo) jams, Bobo walks in |
| C1 | Verse 1 | 4–12 | Red monster sings on stage | 2.10–13.16 (63–395) | Bobo sings "At the costume party tonight…" |
| T1 | Transform 1 | 12–16 | Spin → pizza costume (pizza-shop stage with slice dancers) | 13.16–14.73 (395–442) | Spin → **Burger** costume (on snare build) |
| K1 | Chorus 1 | 16–30 | Pizza dances with slice minions, pizza falls, pizza box opens, face in box | 14.73–27.37 (442–821) | "Burger burger yum yum yum": Bobo burger + mini burger dancers, giant bun stack, burger-box gag |
| I1 | Interlude | 30–34 | Snake + rat band eat pizza | 27.37–28.95 (821–868) | Band members munch burgers |
| C2 | Verse 2 | 34–42 | Two monsters (teal tall + blue) sing on stage | 28.95–40.00 (868–1200) | Lulu on stage |
| T2 | Transform 2 | 42–44 | Tornado spin | 40.00–41.58 (1200–1247) | Spin → **Ice cream cone** |
| K2 | Chorus 2 | 44–60 | Fries spotlight, fries rollercoaster, fries pile, red/yellow wave wipe | 41.58–54.21 (1247–1626) | "Ice cream cold and sweet": scoop spotlight, cone pattern, sprinkles rain, melting-drip wipe |
| C3 | Verse 3 | 60–68 | Orange + purple monsters, costume rack, closet | 54.21–65.26 (1626–1958) | Ziggy on stage, costume rack |
| T3 | Transform 3 | 68–70 | Closet / reveal | 65.26–66.84 (1958–2005) | Spin → **Sprinkled donut** |
| K3 | Chorus 3 | 70–86 | Cupcakes spotlight, cupcake wallpaper pattern, cupcake pile, pink frosting drip wipe | 66.84–79.47 (2005–2384) | "Donut round and round": donut rolling, donut-ring pattern spinning, donut tower, glaze drip wipe |
| C4 | Verse 4 | 86–96 | Big green monster + mint goblin, milkshakes | 79.47–90.53 (2384–2716) | Grub on stage |
| T4 | Transform 4 | 96–98 | Tornado spin | 90.53–92.10 (2716–2763) | Spin → **Hot dog** |
| K4 | Chorus 4 | 98–112 | Sundae + milkshake in diner, cherry mini character, candy-stripe wipe, cherry slides on straw | 92.10–104.73 (2763–3142) | "Hot dog warm and neat": hot-dog stand/diner, mustard zigzag wipe, mini ketchup/mustard bottle sidekicks |
| F1 | Finale lineup | 112–124 | All costumed heroes in spotlight row on stage | 104.73–117.37 (3142–3521) | "We're all gonna be our favorite bite!" lineup, spotlights |
| F2 | Finale montage | 124–138 | Pizza mic close-up, flying food collage, split-screen color grid of each hero | 117.37–123.68 (3521–3710) | "Burgers, ice cream, donuts, and hot dogs!" — 4-panel color grid, one per hero, beat-synced pops |
| F3 | Finale night | 138–148 | Moonlit hill with giant foods; trick-or-treat street with pumpkin buckets | 123.68–130.00 (3710–3900) | Trick-or-treat street, all heroes with pumpkin buckets |
| O | Outro | 148–157 | Curtain closes, rat plays saxophone made of pizza, iris | 130.00–133.21 (3900–3997) | Curtain close + Boo sax sting, logo |

## 3. Character analysis

Reference cast: 7 monster singers (1 solo + 3 duos) + 5 band/cameo (cat drummer, snake bassist, bat, rat sax, cherry mini).
Our lyrics use **"I'm"** per verse (solo) and **"We're all"** in finale → solo hero per verse is the clean fit.

### Recommended roster (8)

| ID | Role | Base form (monster) | Costume | Screen time |
|---|---|---|---|---|
| H1 | Hero, verse 1 | TBD by user | Burger | high |
| H2 | Hero, verse 2 | TBD | Ice cream cone | high |
| H3 | Hero, verse 3 | TBD | Sprinkled donut | high |
| H4 | Hero, verse 4 | TBD | Hot dog | high |
| B1 | Band – drummer | TBD (ref: cat) | — | medium |
| B2 | Band – bassist | TBD (ref: snake) | — | medium |
| B3 | Band – sax/outro | TBD (ref: rat) | — | low |
| M1 | Intro mascot | TBD (ref: bat) | — | low |

Minimum viable: **4 heroes + 2 band (6)**. Mini food extras (mini burgers, scoops, sprinkles, ketchup/mustard bottles) are props, not full rigs.

Each hero needs **2 rigs**: base monster + costumed version (same face/limbs reused inside costume = cheap).

### Character rig spec (for build)
- SVG React component, layered parts: `body`, `eyes`(blink), `mouth`(3 visemes: closed / mid / open), `armL`, `armR`, `legL`, `legR`, `costume` (optional), `prop` (mic).
- Props: `pose` (idle | dance | wave | sing | spin), `beat` (0–1 phase), `mouthOpen` (0–1), `blink` (bool), `costume` (none | burger | icecream | donut | hotdog).

## 4. Tech pipeline

- **Engine**: Remotion (React) — skill `remotion-video`. Motion direction: `motion-director` + `motion-design`. Style tokens: `design-dna`. Backgrounds: `motion-background`. GSAP optional for complex easing curves (use Remotion `interpolate`/`spring` first).
- **Format**: 1920x1080, 30 fps, 3997 frames, audio = `Halloween Night.wav`.
- **Planned layout**:
```
video/                      Remotion project
  src/Root.tsx              composition (3997f)
  src/timeline.ts           SINGLE SOURCE OF TRUTH: section/shot frame ranges + beat grid
  src/theme.ts              palette + tokens from §1
  src/characters/           H1..H4, B1..B3, M1 (+ costume variants)
  src/props/                food props, mic, pumpkins, instruments
  src/sets/                 Stage, PurpleSpot, Diner, Street, MoonHill, ColorGrid
  src/transitions/          SpinTornado, DripWipe, StripeWipe, Iris, Curtain
  src/scenes/               A, B, C1, T1, K1 … O  (one file per section)
  public/Halloween Night.wav
analysis/
  beats.json                beat grid + section boundaries (Step 2 output)
  lyrics_timed.json         line-level lyric timestamps (Step 2 output)
characters/design/          approved character sheets (PNG/SVG)
```

## 5. Work order (do in sequence)

1. [x] Extract ref frames, contact sheets, cut list, this plan.
2. [x] **Audio timing**: 152.0 BPM, 85 downbeats, 19 sections (`analysis/beats.json`) + 40 timed lyric lines (`analysis/lyrics_timed.json`). Table §2 updated.
3. [x] **Character design** (Bobo + cast approved; remaining sheets = NEXT_STEPS T4): user supplies designs OR agent designs per §3 (image-generator for concept sheets → then redraw as clean SVG). Get user approval.
4. [x] **Scaffold Remotion** project at `video/`, `theme.ts`, `timeline.ts` from `beats.json`, audio wired.
5. [x] **Build rigs**: Bobo end-to-end (`video/src/rig/*` + `Bobo.tsx` + `Burger.tsx` + `QA.tsx`) incl. blink, 5-viseme mouth, 2-bone IK limbs, spring antennae/cheese, dance loop on 152 BPM beat. Rendered `analysis/qa/bobo_sheet.png`.
6. [x] **Build sets & transitions**: `CastleWindowSet`, `TheatreStageSet`, `FoodChorusSet` (with dancing mini food sidekicks), `TrickOrTreatStreetSet`, `ColorGrid`, `CurtainWipe`, `DripWipe`, `StripeWipe`, `IrisWipe`.
7. [x] **Block sections A→O** (all 19 sections across 3997 frames wired in `video/src/Root.tsx`).
8. [x] **Build all 8 rigs & 4 costumes**: Bobo (Burger), Lulu (Ice Cream), Ziggy (Donut), Grub (Hot Dog, D5 revision), Bones (Drums), Spinny (Spider Bass), Boo (Ghost Sax), Pip (Bat). Rendered `analysis/qa/cast_qa_sheet.png`.
9. [x] **Block K2, K3, K4, finale, outro**: Complete in `video/src/Root.tsx`.
10. [x] **Lip-sync pass**: `viseme` from `lyrics_timed.json` + 30fps vocal amplitude envelope in `beats.json`.
11. [ ] **Preview / Final render**: Preview `out/preview_verse1.mp4` (`frames 0-840`, 28.03s) + `analysis/qa/preview_verse1_sheet.jpg` rendered. Full `out/HalloweenNight.mp4` next on user approval.

## 6. Status

| Date | Step | By | Note |
|---|---|---|---|
| 2026-11-07 | 1 | Opus | Plan + analysis done. Waiting user: character designs (§3). |
| 2026-11-07 | 3 | Opus | User chose agent-designed cast. Cast = Bobo, Lulu, Ziggy, Grub, Bones, Spinny, Boo, Pip. Rules + rig architecture in `CHARACTER_DESIGN_SYSTEM.md`. Concept sheets in `characters/design/`. |
| 2026-11-07 | 3 | Opus | User approved Bobo + cast. Decisions locked in `NEXT_STEPS.md`. Next: T1 audio timing. |
| 2026-11-07 | 2,4,5 | Argon | Completed T1 (`beats.json` 152 BPM + `lyrics_timed.json`), T2 (Remotion scaffold at `video/`), and T3 (shared procedural rig engine `video/src/rig/` + Bobo & Burger costume + QA sheet render `analysis/qa/bobo_sheet.png`). Next: T4–T5 remaining characters after user OK on Bobo QA sheet. |
| 2026-11-07 | 6–10 | Argon | Completed T4 (`H2_lulu_model_sheet.jpg`), T5 (all 8 character rigs + 4 food costumes + `analysis/qa/cast_qa_sheet.png`), T6 (`Sets.tsx` + `Wipes.tsx`), and T7–T9 (all 19 sections A..O wired into `Main` in `video/src/Root.tsx`). Ready for T10 preview/full render. |
| 2026-11-07 | 11 | Argon | Rendered 28s preview `out/preview_verse1.mp4` (frames 0–840) and contact sheet `analysis/qa/preview_verse1_sheet.jpg`. Ready for user review before full render. |
| 2026-11-07 | 11b | Argon | Upgraded camera play & scene density (`CameraRig.tsx`, upgraded `Sets.tsx` & `Root.tsx` with 4 camera cuts per verse, 4 sub-scenes per chorus including Burger Box / Ice Cream Parlor / Donut Kaleidoscope / Hot Dog Ribbon gags + Band Eating cutaways, studio-scale characters + stage duos, verified in `analysis/qa/stage_upgrade_f90.png`). Launched Remotion Studio local web server for instant browser preview. |
| 2026-11-07 | 11c | Argon | Comprehensive 20-section audit & fix (`analysis/qa/all_sections_qa_sheet.png`): changed badge to `EDUFAM`, locked bowler hat & candy bucket inside `Character.tsx`, added 3840x2280 overscan bleed to all sets (zero checkerboard), enforced strict solo character progression per verse, removed overlapping/confusing gag frames, rebuilt 4 giant food platforms (`MoonlitFoodSkylineSet`), and upgraded syllable lip-sync (`timeline.ts`, `Mouth.tsx`). |
| 2026-11-07 | 11d | Argon | Fixed straddling wipe transitions (`StraddlingWipeOverlay` in `Root.tsx` & `Wipes.tsx`), cleaned Boo Saxophonist face & iris closure in `O`, and added Kids Karaoke Sing-Along Lyric Bar + Die-Cut Sticker Badges (`SingAlongOverlays.tsx`), verified across all 20 tiles in `analysis/qa/all_sections_qa_sheet.png`. |
| 2026-11-07 | 11e | Argon | Synced all 40 lyric lines & word timings (`analysis/build_timing.py` -> `video/src/data/lyrics_timed.json`) to exact vocal rhythm in `Halloween Night.wav`, and replaced top text banners with illustrated die-cut character & food costume stickers (`DieCutCharacterSticker` in `video/src/ui/SingAlongOverlays.tsx`). |
| 2026-11-07 | 11f | Argon | Re-anchored all 40 lyric lines directly from Whisper speech recognition output (`analysis/whisper.srt` + `whisper12.srt`), removing the phantom 1.5s interlude delay so Verse 2 starts at 27.05s, Verse 3 at 52.70s, Verse 4 at 77.40s, Finale at 103.30s. Rebuilt `beats.json`, `lyrics_timed.json`, and wipe transitions in `Root.tsx`. Verified with `analysis/qa/all_sections_qa_sheet_v3.png`. |
| 2026-11-07 | 11g | Flash | Fixed Verse 4 and Chorus 4 timing in `build_timing.py`: Chorus 4 previously started at 89.8s (1.8s too early before trumpet/spin break). Re-timed Chorus 4 to exact vocal onset at 91.60s (lines 28-31 at 91.60s, 94.75s, 97.85s, 100.95s), Verse 4 at 77.65s (lines 24-27 at 77.65s, 80.75s, 83.85s, 86.95s), K4 wipe cut at frame 3114. Verified with `analysis/qa/all_sections_qa_sheet_v4.png`. |
| 2026-11-07 | 11h | Flash | Advanced Chorus 4 (Hot Dog) by 0.40s (lines 28-31 at 91.20s, 94.35s, 97.45s, 100.55s) and Finale 1 by 0.45s (lines 32-35 at 103.55s, 106.70s, 109.80s, 112.90s) per user request ("telat sedikit"). Rebuilt `beats.json`, `lyrics_timed.json`, and updated K4->F1 wipe cut to frame 3102 in `Root.tsx`. |
| 2026-11-07 | 11i | Flash | Fixed glitch frame at 01:17.18 (frame 2328): resolved 12-frame gap between K3 (2318) and C4 (2330) by extending K3 to 2330 with seamless startFrame continuity in `build_timing.py`, synced `cutFrame: 2330` in `Root.tsx`, and patched fallback in `timeline.ts` to prevent defaulting to Outro Section O. Verified with `test_f2328.png` and `test_f2334.png`. |
| 2026-11-08 | 11j | Argon | Implemented dynamic die-cut "edufam" watermark sticker in `LogoBug.tsx` and wired into `Root.tsx`. Small pill sticker with white die-cut border, spring overshoot pop-in, micro-hover, and snappy exit. Cycles through 10 safe periphery positions every ~10s without obstructing characters, animations, or karaoke. Verified on still frames 20 and 380. |
| 2026-11-08 | 11k | Argon | Stopped local studio daemon, added `render:gpu` script (`--gl=angle`) in `video/package.json`, verified full GPU render `out/HalloweenNight.mp4` (`1920x1080`, `30 fps`, `3997 frames`, `133.23 s`, `137.67 MB`), moved QA stills to `analysis/qa/`, and ran full Graphify AST + semantic + community-labeling update. |
