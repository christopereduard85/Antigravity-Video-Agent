import React from 'react';
import { CostumeLayerProps, CostumeSpec } from '../../../rig/types';
import { getSquashStretch } from '../../../rig/geom';
import { evalSpringSwings } from '../../../rig/spring';
import { BEATS } from '../../../timeline';
import { theme } from '../../../theme';

const c = theme.foods.burger;

/**
 * Bobo's Burger Costume (matches characters/design/H1_bobo_model_sheet.jpg Row 2).
 * Envelops Bobo's entire lower body from right under his mouth down to his hips,
 * leaving a cute face window between the wavy green lettuce frill above his eyes and the tomato/cheese below his smile!
 */
const BurgerBack: React.FC<CostumeLayerProps> = ({ bodyW, bodyH, squash, arc }) => {
  const { sx, sy } = getSquashStretch(squash);
  const w = bodyW * 1.48 * sx;
  const shiftX = arc * 12;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, 0)`}>
      {/* Back shadow rim of burger enveloping lower torso */}
      <ellipse
        cx={0}
        cy={bodyH * 0.26 * sy}
        rx={w * 0.54}
        ry={bodyH * 0.32 * sy}
        fill={c.pattyShade}
      />
      <ellipse
        cx={0}
        cy={bodyH * 0.42 * sy}
        rx={w * 0.5}
        ry={bodyH * 0.22 * sy}
        fill={c.bunShade}
      />
    </g>
  );
};

const BurgerFront: React.FC<CostumeLayerProps> = ({
  bodyW,
  bodyH,
  squash,
  arc,
  frame,
  fps,
}) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.72 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 14;

  const springL = evalSpringSwings(frame, fps, BEATS.beatPeriodSec, 170, 11, 0.1, 8);
  const springR = evalSpringSwings(frame, fps, BEATS.beatPeriodSec, 170, 11, 0.35, 8);
  const dripStretchL = 1 + springL.stretch * 1.35;
  const dripStretchR = 1 + springR.stretch * 1.35;

  // Starts right below Bobo's smile (y = hh * 0.32) and covers all the way to the bottom of his body (hh * 1.05)
  const topY = hh * 0.32;
  const pattyY = hh * 0.56;
  const bunY = hh * 0.84;

  return (
    <g transform={`translate(${shiftX.toFixed(2)}, 0)`}>
      {/* 1. Thick Rounded Bottom Bun */}
      <path
        d={`M ${(-hw * 0.92).toFixed(2)} ${pattyY.toFixed(2)}
            C ${(-hw * 0.98).toFixed(2)} ${(bunY + 26 * sy).toFixed(2)}, ${(
          hw * 0.98
        ).toFixed(2)} ${(bunY + 26 * sy).toFixed(2)}, ${(hw * 0.92).toFixed(
          2
        )} ${pattyY.toFixed(2)} Z`}
        fill={c.bunTop}
      />
      {/* Bottom bun lower shade */}
      <path
        d={`M ${(-hw * 0.86).toFixed(2)} ${(bunY - 2 * sy).toFixed(2)}
            Q 0 ${(bunY + 26 * sy).toFixed(2)} ${(hw * 0.86).toFixed(2)} ${(
          bunY -
          2 * sy
        ).toFixed(2)}
            Q 0 ${(bunY + 12 * sy).toFixed(2)} ${(-hw * 0.86).toFixed(2)} ${(
          bunY -
          2 * sy
        ).toFixed(2)} Z`}
        fill={c.bunShade}
      />
      {/* Bottom bun warm upper rim */}
      <ellipse
        cx={0}
        cy={pattyY + 6 * sy}
        rx={hw * 0.91}
        ry={13 * sy}
        fill={c.bunHighlight}
      />

      {/* 2. Thick Juicy Grilled Beef Patty */}
      <rect
        x={-hw * 0.98}
        y={topY + 10 * sy}
        width={hw * 1.96}
        height={38 * sy}
        rx={19 * sy}
        fill={c.patty}
      />
      <path
        d={`M ${(-hw * 0.94).toFixed(2)} ${(topY + 32 * sy).toFixed(2)}
            Q 0 ${(topY + 52 * sy).toFixed(2)} ${(hw * 0.94).toFixed(2)} ${(
          topY +
          32 * sy
        ).toFixed(2)}
            L ${(hw * 0.96).toFixed(2)} ${(topY + 20 * sy).toFixed(2)}
            Q 0 ${(topY + 40 * sy).toFixed(2)} ${(-hw * 0.94).toFixed(2)} ${(
          topY +
          32 * sy
        ).toFixed(2)} Z`}
        fill={c.pattyShade}
      />

      {/* 3. Melted Yellow Cheddar Cheese with 2 spring-animated drips */}
      <path
        d={`M ${(-hw * 0.99).toFixed(2)} ${(topY + 8 * sy).toFixed(2)}
            Q ${(-hw * 0.68).toFixed(2)} ${(topY + 18 * sy).toFixed(2)} ${(
          -hw * 0.54
        ).toFixed(2)} ${(topY + 34 * sy * dripStretchL).toFixed(2)}
            Q ${(-hw * 0.45).toFixed(2)} ${(
          topY +
          38 * sy * dripStretchL
        ).toFixed(2)} ${(-hw * 0.36).toFixed(2)} ${(topY + 18 * sy).toFixed(2)}
            Q 0 ${(topY + 26 * sy).toFixed(2)} ${(hw * 0.34).toFixed(2)} ${(
          topY +
          20 * sy
        ).toFixed(2)}
            Q ${(hw * 0.44).toFixed(2)} ${(
          topY +
          46 * sy * dripStretchR
        ).toFixed(2)} ${(hw * 0.54).toFixed(2)} ${(
          topY +
          46 * sy * dripStretchR
        ).toFixed(2)}
            Q ${(hw * 0.64).toFixed(2)} ${(
          topY +
          44 * sy * dripStretchR
        ).toFixed(2)} ${(hw * 0.68).toFixed(2)} ${(topY + 18 * sy).toFixed(2)}
            L ${(hw * 0.99).toFixed(2)} ${(topY + 8 * sy).toFixed(2)}
            Q 0 ${(topY - 2 * sy).toFixed(2)} ${(-hw * 0.99).toFixed(2)} ${(
          topY +
          8 * sy
        ).toFixed(2)} Z`}
        fill={c.cheese}
      />

      {/* 4. Lush Red Tomato Slices tucked right under Bobo's chin */}
      <path
        d={`M ${(-hw * 0.94).toFixed(2)} ${(topY + 4 * sy).toFixed(2)}
            Q ${(-hw * 0.52).toFixed(2)} ${(topY + 16 * sy).toFixed(2)} 0 ${(
          topY +
          8 * sy
        ).toFixed(2)}
            Q ${(hw * 0.52).toFixed(2)} ${(topY + 16 * sy).toFixed(2)} ${(
          hw * 0.94
        ).toFixed(2)} ${(topY + 4 * sy).toFixed(2)}
            Q ${(hw * 0.7).toFixed(2)} ${(topY - 8 * sy).toFixed(2)} ${(
          hw * 0.35
        ).toFixed(2)} ${(topY + 2 * sy).toFixed(2)}
            Q 0 ${(topY + 6 * sy).toFixed(2)} ${(-hw * 0.35).toFixed(2)} ${(
          topY +
          2 * sy
        ).toFixed(2)}
            Q ${(-hw * 0.7).toFixed(2)} ${(topY - 8 * sy).toFixed(2)} ${(
          -hw * 0.94
        ).toFixed(2)} ${(topY + 4 * sy).toFixed(2)} Z`}
        fill={c.tomato}
      />
      {/* Subtle tomato highlight */}
      <ellipse
        cx={-hw * 0.52}
        cy={topY + 4 * sy}
        rx={hw * 0.24}
        ry={4 * sy}
        fill={c.tomatoShade}
        opacity={0.55}
      />
      <ellipse
        cx={hw * 0.52}
        cy={topY + 4 * sy}
        rx={hw * 0.24}
        ry={4 * sy}
        fill={c.tomatoShade}
        opacity={0.55}
      />
    </g>
  );
};

const BurgerHat: React.FC<CostumeLayerProps> = ({
  bodyW,
  bodyH,
  squash,
  arc,
  frame,
  fps,
}) => {
  const { sx, sy } = getSquashStretch(squash);
  const hw = bodyW * 0.74 * sx;
  const hh = bodyH * 0.5 * sy;
  const shiftX = arc * 16;

  const spring = evalSpringSwings(frame, fps, BEATS.beatPeriodSec, 190, 12, 0.2, 5);
  const hatBobY = spring.stretch * -14;
  const browY = -hh * 0.52 + hatBobY;

  return (
    <g
      transform={`translate(${shiftX.toFixed(2)}, ${browY.toFixed(2)}) rotate(${(
        spring.angleDeg * 0.22
      ).toFixed(2)})`}
    >
      {/* Wavy Green Lettuce Frill wrapping top & sides of Bobo's face */}
      <path
        d={`M ${(-hw * 1.04).toFixed(2)} 6
            Q ${(-hw * 1.18).toFixed(2)} 28 ${(-hw * 0.88).toFixed(2)} 26
            Q ${(-hw * 0.68).toFixed(2)} 36 ${(-hw * 0.44).toFixed(2)} 16
            Q ${(-hw * 0.18).toFixed(2)} 28 0 14
            Q ${(hw * 0.18).toFixed(2)} 28 ${(hw * 0.44).toFixed(2)} 16
            Q ${(hw * 0.68).toFixed(2)} 36 ${(hw * 0.88).toFixed(2)} 26
            Q ${(hw * 1.18).toFixed(2)} 28 ${(hw * 1.04).toFixed(2)} 6 Z`}
        fill={c.lettuce}
      />
      <path
        d={`M ${(-hw * 0.96).toFixed(2)} 6
            Q ${(-hw * 0.5).toFixed(2)} 18 0 10
            Q ${(hw * 0.5).toFixed(2)} 18 ${(hw * 0.96).toFixed(2)} 6
            L ${(hw * 0.94).toFixed(2)} 0 L ${(-hw * 0.94).toFixed(2)} 0 Z`}
        fill={c.lettuceShade}
      />

      {/* Domed Golden Top Bun */}
      <path
        d={`M ${(-hw * 0.98).toFixed(2)} 4
            C ${(-hw * 1.02).toFixed(2)} ${(-74 * sy).toFixed(2)}, ${(
          hw * 1.02
        ).toFixed(2)} ${(-74 * sy).toFixed(2)}, ${(hw * 0.98).toFixed(2)} 4
            Q 0 14 ${(-hw * 0.98).toFixed(2)} 4 Z`}
        fill={c.bunTop}
      />

      {/* Top bun right-side inner shade */}
      <path
        d={`M ${(hw * 0.25).toFixed(2)} ${(-54 * sy).toFixed(2)}
            C ${(hw * 0.85).toFixed(2)} ${(-48 * sy).toFixed(2)}, ${(
          hw * 0.98
        ).toFixed(2)} ${(-12 * sy).toFixed(2)}, ${(hw * 0.98).toFixed(2)} 4
            Q ${(hw * 0.35).toFixed(2)} 12 ${(-hw * 0.3).toFixed(2)} 8
            Q ${(hw * 0.55).toFixed(2)} ${(-4 * sy).toFixed(2)} ${(
          hw * 0.25
        ).toFixed(2)} ${(-54 * sy).toFixed(2)} Z`}
        fill={c.bunShade}
        opacity={0.55}
      />

      {/* Top-left glossy bun highlight */}
      <ellipse
        cx={-hw * 0.38}
        cy={-32 * sy}
        rx={hw * 0.28}
        ry={12 * sy}
        fill={c.bunHighlight}
        opacity={0.5}
        transform={`rotate(-18 ${-hw * 0.38} ${-32 * sy})`}
      />

      {/* Sesame Seeds */}
      {[
        { x: -0.52, y: -24, r: -24 },
        { x: -0.22, y: -42, r: -10 },
        { x: 0.08, y: -46, r: 8 },
        { x: 0.38, y: -36, r: 22 },
        { x: 0.6, y: -20, r: 30 },
        { x: -0.32, y: -15, r: -14 },
        { x: 0.02, y: -20, r: 4 },
        { x: 0.32, y: -15, r: 16 },
      ].map((s, i) => (
        <ellipse
          key={i}
          cx={hw * s.x}
          cy={s.y * sy}
          rx={5.5}
          ry={3}
          fill={c.sesame}
          transform={`rotate(${s.r} ${hw * s.x} ${s.y * sy})`}
        />
      ))}
    </g>
  );
};

export const burgerCostume: CostumeSpec = {
  Back: BurgerBack,
  Front: BurgerFront,
  Hat: BurgerHat,
  hideAppendages: true,
};
