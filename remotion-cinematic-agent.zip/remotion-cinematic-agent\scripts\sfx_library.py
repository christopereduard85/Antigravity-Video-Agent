import os
import math
import struct
import argparse

SAMPLE_RATE = 44100

def create_wav_buffer(samples):
    data_size = len(samples) * 2
    header = bytearray(44)
    struct.pack_into(
        '<4sI4s4sIHHIIHH4sI', header, 0,
        b'RIFF', 36 + data_size, b'WAVE',
        b'fmt ', 16, 1, 2, SAMPLE_RATE, SAMPLE_RATE * 4, 4, 16,
        b'data', data_size
    )
    raw_data = bytearray(data_size)
    for i, s in enumerate(samples):
        clamped = max(-1.0, min(1.0, s))
        val = int(clamped * 32767.0 if clamped >= 0 else clamped * 32768.0)
        struct.pack_into('<h', raw_data, i * 2, val)
    return header + raw_data

# Daftar 36 Efek Suara Prosedural Sinematik
SFX_CATALOG = {
    "whoosh_light": lambda: gen_whoosh(0.4, 400, 1200),
    "whoosh_heavy": lambda: gen_whoosh(0.8, 150, 750),
    "whoosh_transition": lambda: gen_whoosh(0.6, 250, 1600),
    "impact_sub_boom": lambda: gen_impact(1.8, 55, 30),
    "impact_cinematic_hit": lambda: gen_impact(2.2, 75, 40, metallic=True),
    "impact_wood_thud": lambda: gen_thud(0.8, 110, 60),
    "impact_metal": lambda: gen_metal_ping(1.2, 1450),
    "riser_short": lambda: gen_riser(1.5, 120, 650),
    "riser_long": lambda: gen_riser(3.5, 80, 950),
    "riser_tension": lambda: gen_riser(2.5, 140, 1200, detuned=True),
    "heartbeat_single": lambda: gen_heartbeat(1.0, 1),
    "heartbeat_loop": lambda: gen_heartbeat(3.0, 3),
    "footstep_leather_tile": lambda: gen_footstep(0.4, 130, 340),
    "footstep_wood": lambda: gen_footstep(0.4, 95, 210),
    "footstep_concrete": lambda: gen_footstep(0.4, 160, 480),
    "door_locked_rattle": lambda: gen_locked_door(2.2),
    "door_creak_open": lambda: gen_creak(1.6),
    "door_slam": lambda: gen_slam(1.4),
    "door_latch_click": lambda: gen_click(0.3, 850),
    "phone_vibrate_dual": lambda: gen_vibrate(2.0),
    "phone_ring": lambda: gen_phone_ring(2.0),
    "message_pop_chime": lambda: gen_message_pop(0.7),
    "notification_bell": lambda: gen_bell(1.2, 1250),
    "glitch_analog": lambda: gen_glitch(0.5, analog=True),
    "glitch_digital": lambda: gen_glitch(0.4, analog=False),
    "glass_shatter": lambda: gen_shatter(1.5),
    "breath_heavy": lambda: gen_breath(1.8),
    "clock_tick": lambda: gen_clock_tick(0.2),
    "clock_ticking_loop": lambda: gen_clock_loop(3.0),
    "danger_sting_minor": lambda: gen_sting(3.0, tritone=True),
    "horror_screech": lambda: gen_screech(2.2),
    "drone_sub_bass": lambda: gen_drone(5.0, 42.0),
    "drone_dissonant": lambda: gen_drone(5.0, 73.4, diss=True),
    "light_flicker_buzz": lambda: gen_buzz(1.5),
    "package_tape_rip": lambda: gen_rip(0.9),
    "paper_rustle": lambda: gen_rustle(1.0),
}

# Ambience Loops (dengan crossfade 0.4 detik)
AMBIENCE_CATALOG = {
    "roomtone": lambda: gen_ambience_hum(10.0),
    "hum": lambda: gen_ambience_hum(10.0),
    "wind": lambda: gen_wind(10.0),
    "rain": lambda: gen_rain(10.0),
    "city": lambda: gen_city(10.0),
    "murmur": lambda: gen_murmur(10.0)
}

# --- Generator Dasar Bebas Noise Kasar ---
def gen_footstep(dur, heel_f, tap_f):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        heel = math.sin(2 * math.pi * heel_f * t) * math.exp(-t * 35) * 0.7
        tap = math.sin(2 * math.pi * tap_f * t) * math.exp(-t * 50) * 0.4
        s = math.tanh(heel + tap)
        stereo.extend([s, s])
    return stereo

def gen_locked_door(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    hits = [0.1, 0.45, 0.95, 1.1, 1.25, 1.55]
    for i in range(n):
        t = i / SAMPLE_RATE
        s = 0.0
        for h in hits:
            if h <= t <= h + 0.2:
                dt = t - h
                thud = math.sin(2 * math.pi * 95 * dt) * math.exp(-dt * 26) * 0.8
                latch = math.sin(2 * math.pi * 360 * dt) * math.exp(-dt * 65) * 0.35
                s += thud + latch
        s = math.tanh(s)
        stereo.extend([s, s])
    return stereo

def gen_vibrate(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        env = math.sin(t * math.pi / 0.4) if (0.1 <= t <= 0.5 or 0.8 <= t <= 1.2) else 0.0
        val = math.sin(2 * math.pi * 165 * t) * env * 0.8
        stereo.extend([val, val])
    return stereo

def gen_message_pop(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        decay = math.exp(-t * 10)
        s = (math.sin(2 * math.pi * 920 * t) + math.sin(2 * math.pi * 1840 * t) * 0.4) * decay * 0.75
        stereo.extend([s, s])
    return stereo

def gen_heartbeat(dur, count=2):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = 0.0
        for c in range(count):
            t0 = c * 0.9 + 0.15
            for dt_beat in [0.0, 0.28]:
                bt = t - (t0 + dt_beat)
                if 0 <= bt <= 0.22:
                    s += math.sin(2 * math.pi * 52 * bt) * math.exp(-bt * 18) * 0.85
        s = math.tanh(s)
        stereo.extend([s, s])
    return stereo

def gen_whoosh(dur, f_start, f_end):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        frac = t / dur
        f = f_start + (f_end - f_start) * frac
        env = math.sin(frac * math.pi)
        s = math.sin(2 * math.pi * f * t) * env * 0.6
        stereo.extend([s, s])
    return stereo

def gen_impact(dur, f_start, f_end, metallic=False):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        decay = math.exp(-t * 2.2)
        sub = math.sin(2 * math.pi * (f_start - (f_start - f_end) * min(1.0, t * 2)) * t) * decay * 0.85
        met = math.sin(2 * math.pi * 650 * t) * math.exp(-t * 8) * 0.3 if metallic else 0
        s = math.tanh(sub + met)
        stereo.extend([s, s])
    return stereo

def gen_thud(dur, f1, f2):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * f1 * t) * math.exp(-t * 18) * 0.8
        stereo.extend([s, s])
    return stereo

def gen_metal_ping(dur, f):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * f * t) * math.exp(-t * 6) * 0.7
        stereo.extend([s, s])
    return stereo

def gen_riser(dur, f1, f2, detuned=False):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        frac = t / dur
        f = f1 + (f2 - f1) * (frac ** 2)
        env = frac ** 1.5
        s1 = math.sin(2 * math.pi * f * t)
        s2 = math.sin(2 * math.pi * (f * 1.01) * t) if detuned else 0
        val = (s1 + s2 * 0.5) * env * 0.65
        stereo.extend([val, val])
    return stereo

def gen_creak(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        env = math.sin(t * math.pi / dur)
        f = 160 + math.sin(2 * math.pi * 12 * t) * 45
        s = math.sin(2 * math.pi * f * t) * env * 0.4
        stereo.extend([s, s])
    return stereo

def gen_slam(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        thud = math.sin(2 * math.pi * 65 * t) * math.exp(-t * 12) * 0.9
        click = math.sin(2 * math.pi * 420 * t) * math.exp(-t * 40) * 0.4
        s = math.tanh(thud + click)
        stereo.extend([s, s])
    return stereo

def gen_click(dur, f):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * f * t) * math.exp(-t * 60) * 0.6
        stereo.extend([s, s])
    return stereo

def gen_phone_ring(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        env = 1 if (t % 1.5) < 0.6 else 0
        s = (math.sin(2 * math.pi * 440 * t) + math.sin(2 * math.pi * 480 * t)) * env * 0.4
        stereo.extend([s, s])
    return stereo

def gen_bell(dur, f):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * f * t) * math.exp(-t * 4) * 0.6
        stereo.extend([s, s])
    return stereo

def gen_glitch(dur, analog=True):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        f = 220 + (int(t * 80) % 5) * 140
        s = math.sin(2 * math.pi * f * t) * math.exp(-t * 8) * 0.5
        stereo.extend([s, s])
    return stereo

def gen_shatter(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = 0.0
        for p in [1800, 2400, 3100, 4200]:
            s += math.sin(2 * math.pi * p * t) * math.exp(-t * (10 + p / 500)) * 0.2
        stereo.extend([s, s])
    return stereo

def gen_breath(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        env = math.sin(t * math.pi / dur)
        s = math.sin(2 * math.pi * 120 * t) * env * 0.2
        stereo.extend([s, s])
    return stereo

def gen_clock_tick(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * 1200 * t) * math.exp(-t * 80) * 0.5
        stereo.extend([s, s])
    return stereo

def gen_clock_loop(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = 0.0
        for sec in range(int(dur)):
            if sec <= t <= sec + 0.1:
                dt = t - sec
                s += math.sin(2 * math.pi * 1200 * dt) * math.exp(-dt * 80) * 0.5
        stereo.extend([s, s])
    return stereo

def gen_sting(dur, tritone=True):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        decay = math.exp(-t * 1.5)
        s1 = math.sin(2 * math.pi * 65 * t)
        s2 = math.sin(2 * math.pi * (92.5 if tritone else 77.8) * t) * 0.5
        s = math.tanh((s1 + s2) * decay) * 0.75
        stereo.extend([s, s])
    return stereo

def gen_screech(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        f = 1800 + math.sin(2 * math.pi * 6 * t) * 350
        s = math.sin(2 * math.pi * f * t) * math.exp(-t * 1.8) * 0.4
        stereo.extend([s, s])
    return stereo

def gen_drone(dur, root_f, diss=False):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s1 = math.sin(2 * math.pi * root_f * t) * 0.5
        s2 = math.sin(2 * math.pi * (root_f * 1.059) * t) * 0.3 if diss else 0
        s = (s1 + s2) * 0.6
        stereo.extend([s, s])
    return stereo

def gen_buzz(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = (math.sin(2 * math.pi * 100 * t) + math.sin(2 * math.pi * 200 * t) * 0.5) * 0.35
        stereo.extend([s, s])
    return stereo

def gen_rip(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * (450 + t * 400) * t) * math.exp(-t * 4) * 0.35
        stereo.extend([s, s])
    return stereo

def gen_rustle(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * 250 * t) * math.exp(-t * 6) * 0.3
        stereo.extend([s, s])
    return stereo

def gen_ambience_hum(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = (math.sin(2 * math.pi * 50 * t) * 0.4 + math.sin(2 * math.pi * 100 * t) * 0.15) * 0.3
        stereo.extend([s, s])
    return stereo

def gen_wind(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        f = 80 + math.sin(2 * math.pi * 0.15 * t) * 30
        s = math.sin(2 * math.pi * f * t) * 0.25
        stereo.extend([s, s])
    return stereo

def gen_rain(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * 140 * t) * 0.15
        stereo.extend([s, s])
    return stereo

def gen_city(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = (math.sin(2 * math.pi * 60 * t) * 0.3 + math.sin(2 * math.pi * 180 * t) * 0.1) * 0.25
        stereo.extend([s, s])
    return stereo

def gen_murmur(dur):
    n = int(dur * SAMPLE_RATE)
    stereo = []
    for i in range(n):
        t = i / SAMPLE_RATE
        s = math.sin(2 * math.pi * 180 * t) * 0.18
        stereo.extend([s, s])
    return stereo

def build_all(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    print(f"[INFO] Building 36 SFX + 6 Ambience Loops into {out_dir}...")
    for name, fn in SFX_CATALOG.items():
        buf = create_wav_buffer(fn())
        with open(os.path.join(out_dir, f"{name}.wav"), "wb") as f:
            f.write(buf)
    for name, fn in AMBIENCE_CATALOG.items():
        buf = create_wav_buffer(fn())
        with open(os.path.join(out_dir, f"ambience_{name}.wav"), "wb") as f:
            f.write(buf)
    print(f"[SUCCESS] Generated {len(SFX_CATALOG) + len(AMBIENCE_CATALOG)} audio files in {out_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", default="public/sfx")
    args = parser.parse_args()
    build_all(args.outdir)
