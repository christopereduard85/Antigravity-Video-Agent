import React from 'react';
import { Vec } from './types';
import { buildTaperedLimbPath } from './geom';
import { solve2BoneIK } from './ik';

export const Limb: React.FC<{
  kind: 'arm' | 'leg';
  side: 'L' | 'R';
  root: Vec;
  target: Vec;
  lengths: readonly [number, number];
  widths: readonly [number, number];
  limbColor: string;
  shadeColor: string;
  footColor: string;
}> = ({
  kind,
  side,
  root,
  target,
  lengths,
  widths,
  limbColor,
  shadeColor,
  footColor,
}) => {
  // For arms: bow elbows outward/upward (L = +1, R = -1) so hanging arms form a smooth downward arch.
  // For legs: bow knees slightly outward (L = +1, R = -1).
  const bendSign: 1 | -1 = side === 'L' ? 1 : -1;
  const { joint, end } = solve2BoneIK(
    root,
    target,
    lengths[0],
    lengths[1],
    bendSign
  );
  const { d, tipPos, tangentAngleDeg } = buildTaperedLimbPath(
    root,
    joint,
    end,
    widths[0],
    widths[1]
  );

  const flip = side === 'L' ? -1 : 1;

  return (
    <g>
      {/* Subtle underside shade on limb */}
      <path
        d={d}
        fill={shadeColor}
        transform="translate(1.5, 2)"
        opacity={0.4}
      />
      {/* Seamless tapered noodle limb */}
      <path d={d} fill={limbColor} />

      {kind === 'arm' ? (
        /* 3-finger rounded cartoon hand oriented along limb end tangent */
        <g
          transform={`translate(${tipPos.x.toFixed(2)}, ${tipPos.y.toFixed(
            2
          )}) rotate(${(tangentAngleDeg - 90).toFixed(2)})`}
        >
          <ellipse cx={0} cy={3} rx={8.5} ry={7} fill={limbColor} />
          {/* 3 splayed fingers pointing along tangent (+Y in local frame) */}
          <ellipse
            cx={-6.5}
            cy={9.5}
            rx={3.3}
            ry={6.2}
            fill={limbColor}
            transform="rotate(25 -6.5 9.5)"
          />
          <ellipse cx={0} cy={11.5} rx={3.4} ry={6.8} fill={limbColor} />
          <ellipse
            cx={6.5}
            cy={9.5}
            rx={3.3}
            ry={6.2}
            fill={limbColor}
            transform="rotate(-25 6.5 9.5)"
          />
        </g>
      ) : (
        /* Rounded orange bean shoe/foot matching Bobo model sheet */
        <g
          transform={`translate(${tipPos.x.toFixed(2)}, ${(
            tipPos.y + 3
          ).toFixed(2)})`}
        >
          <ellipse
            cx={flip * 3.5}
            cy={3.5}
            rx={16.5}
            ry={9.5}
            fill={footColor}
          />
          <path
            d={`M ${-13 + flip * 3.5} 5 Q ${flip * 3.5} 13 ${
              13 + flip * 3.5
            } 5 Q ${flip * 3.5} 9 ${-13 + flip * 3.5} 5 Z`}
            fill="rgba(0,0,0,0.18)"
          />
          <ellipse
            cx={flip * 2 - 3}
            cy={-0.5}
            rx={6.5}
            ry={3.2}
            fill="rgba(255,255,255,0.28)"
          />
        </g>
      )}
    </g>
  );
};
