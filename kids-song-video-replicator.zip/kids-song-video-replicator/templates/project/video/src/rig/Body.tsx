import React from 'react';
import { CharacterTokens, Pose } from './types';
import { closedSmoothPath, deformBodyPoint, getSquashStretch, sampleBodyRing } from './geom';
import { Shading } from './Shading';

export const Body: React.FC<{
  tokens: CharacterTokens;
  pose: Pose;
  clipId: string;
}> = ({ tokens, pose, clipId }) => {
  const { w, h, topTaper, squareness } = tokens.body;
  const ring = sampleBodyRing(w, h, topTaper, squareness, pose.squash, pose.arc);
  const bodyD = closedSmoothPath(ring, 0.21);
  const { sx, sy } = getSquashStretch(pose.squash);
  const bellyCenter = deformBodyPoint(0, 0.36, w, h, topTaper, pose.squash, pose.arc);

  return (
    <g>
      <defs>
        <clipPath id={clipId}>
          <path d={bodyD} />
        </clipPath>
      </defs>

      {/* Main deformed silhouette */}
      <path d={bodyD} fill={tokens.colors.base} />

      {/* Clipped inner shading, belly patch, top-left highlight, and markings */}
      <g clipPath={`url(#${clipId})`}>
        <Shading tokens={tokens} pose={pose} />

        {/* Optional soft oval belly patch (e.g. Lulu's lighter pink belly) */}
        {tokens.colors.belly && (
          <ellipse
            cx={bellyCenter.x}
            cy={bellyCenter.y}
            rx={w * 0.3 * sx}
            ry={h * 0.27 * sy}
            fill={tokens.colors.belly}
            opacity={0.78}
          />
        )}

        {tokens.spots?.map((sp, idx) => {
          const pt = deformBodyPoint(
            sp.x,
            sp.y,
            w,
            h,
            topTaper,
            pose.squash,
            pose.arc
          );
          return (
            <ellipse
              key={idx}
              cx={pt.x}
              cy={pt.y}
              rx={sp.rx}
              ry={sp.ry}
              fill={tokens.colors.spots ?? tokens.colors.shade}
              opacity={0.55}
              transform={sp.rot ? `rotate(${sp.rot} ${pt.x} ${pt.y})` : undefined}
            />
          );
        })}
      </g>
    </g>
  );
};
