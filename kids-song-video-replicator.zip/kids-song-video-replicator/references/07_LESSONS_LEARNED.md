# 07 — Lessons learned (bugs → root cause → fix)

Read this before debugging. Each item happened in the original run.

| # | Symptom (user words) | Root cause | Fix |
|---|---|---|---|
| 1 | "lyric kok terlambat?" (lyrics late) | line starts derived from a constant 152 BPM grid + assumed 1.5 s interlude; real vocals earlier | Whisper (ffmpeg filter) onsets per line → `STARTS` list; `LEAD=-0.06`; karaoke line lead-in 0.4 s |
| 2 | "dari verse 2 kebelakang masih telat" | phantom interlude delay accumulated after verse 1 | re-anchor verse 2 at 27.05 s, verse 3 52.70, verse 4 77.65, finale 103.55 — measure each block |
| 3 | "verse hot dog … lyric kecepatan" | chorus 4 placed before the spin/trumpet break (1.8 s early) | re-time K4 to real onset after break |
| 4 | "telat sedikit, percepat" (K4 + finale) | over-correction | shift K4 −0.40 s, F1 −0.45 s; update K4→F1 cutFrame 3102 |
| 5 | "di detik 1.17 tiba-tiba muncul 1 frame" (rogue frame after pink drip) | 12-frame gap between K3 end (2318) and C4 start (2330); `getSectionAtFrame` fell back to last section (Outro: Bobo with candy bucket) | sections built contiguous `f0 = prev_frame`; K3 end = 2330 = cutFrame; fallback returns previous section |
| 6 | checkerboard/transparent edges on camera moves | sets sized exactly 1920x1080 | overscan bleed rect −960,−600,3840x2280 on every set; zoom ≥ 1.04 |
| 7 | hat / candy bucket floating off characters | props as separate layers with own transform | attach inside `Character.tsx` via `deformBodyPoint` / `pose.handL` |
| 8 | confusing scenes (wrong/multiple heroes) | gags reused heroes across sections | strict solo progression; removed overlapping gag frames |
| 9 | wipe looked like a hard cut / revealed wrong scene | wipe only inside one section | straddling wipe: 14 f before cut + 14 f after, full cover at cut |
| 10 | "label bukan tulisan di atas, tapi sticker karakter" | interpreted "label" as text banners | die-cut character/food stickers on cue |
| 11 | Boo sax face messy / iris showing Boo after close | draw order | render BooSax only while `irisRadius > 1`, under IrisWipe |
| 12 | `faster-whisper` install fails (Python 3.15, `av` Cython) | wheel unavailable | ffmpeg native `whisper` filter + ggml model |
| 13 | remotion still fails in sandbox (`ENOTFOUND storage.googleapis.com`, `spawn EFTYPE`) | headless shell download | `--browser-executable=<Chrome>` + run outside sandbox |
| 14 | PowerShell syntax errors on `python -c` | nested quotes | write `.py` scripts |
| 15 | user can't open studio at localhost | server started in sandbox | start studio outside sandbox, or render stills |
| 16 | lip-sync mouths flapping on instruments | full-mix envelope | band-pass 400–3200 Hz on mid − 0.75·side; consonant closures at word edges |

## Debug recipe for "glitch at mm:ss.ff"
1. frame = (mm·60+ss)·30 + ff (Remotion timecode `01:17.18` = 77 s + 18 f = 2328).
2. Render frames f−2, f, f+2 as stills.
3. Print section at f: check beats.json sections for gaps/overlaps around f.
4. Check wipe list cutFrames vs section boundaries.
5. Fix data first; only then components.
