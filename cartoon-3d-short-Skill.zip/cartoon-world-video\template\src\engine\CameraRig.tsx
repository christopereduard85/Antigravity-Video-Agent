// ============================================================================
// GLIDING 3D CAMERA RIG.
// Every shot has a continuous camera glide (push, pull, orbit, truck, crane,
// drop, follow, top, low, close, fly, tilt) plus subtle handheld drift and
// impact shake bursts. Also computes depth-of-field focus distance.
// ============================================================================
import React from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { evaluateShotChar, toVec3 } from './CharacterCard';
import { timeOf } from './timing';
import type { Cam, Fx, Pos, Shot, Vec3, WorldSet } from './types';
import { clamp, deg, ease, lerp, noise1 } from './util';
import { findItemPos } from './World';

export function resolveTargetPos(
  target: string | Pos,
  shot: Shot,
  set: WorldSet,
  t: number,
  shotEndT: number,
): Vec3 {
  if (Array.isArray(target)) {
    const v = toVec3(target);
    return target.length === 2 ? [v[0], 0.85, v[2]] : v;
  }
  const sc = shot.cast.find((c) => c.who === target);
  if (sc) {
    const ev = evaluateShotChar(sc, t, shotEndT);
    const s = sc.scale ?? 1;
    return [ev.pos[0], ev.pos[1] + 0.85 * s, ev.pos[2]];
  }
  const itemPos = findItemPos(set, target, t);
  if (itemPos) return [itemPos[0], itemPos[1] + 0.9, itemPos[2]];
  const propItem = (shot.props ?? []).find((p) => p.id === target);
  if (propItem) {
    const v = toVec3(propItem.at);
    return [v[0], v[1] + 0.9, v[2]];
  }
  return [0, 0.85, 0];
}

export function computeCameraState(
  shot: Shot,
  set: WorldSet,
  t: number,
  shotStartT: number,
  shotEndT: number,
  isPortrait: boolean,
): {
  pos: Vec3;
  lookAt: Vec3;
  fov: number;
  focusDist: number;
} {
  const cam: Cam = shot.cam;
  const dur = Math.max(0.1, shotEndT - shotStartT);
  const rawU = clamp((t - shotStartT) / dur);
  const u = ease(cam.ease, rawU);

  const focusTarget = resolveTargetPos(cam.on, shot, set, t, shotEndT);
  const baseAngle = deg(cam.angle ?? 0);
  const baseDist =
    cam.dist ??
    (cam.move === 'close' ? 2.4 : cam.move === 'top' ? 9.5 : cam.move === 'low' ? 3.8 : isPortrait ? 5.6 : 4.8);
  const baseHeight =
    cam.height ??
    (cam.move === 'top' ? 8.5 : cam.move === 'low' ? -0.35 : cam.move === 'close' ? 0.15 : 0.75);

  let dist = baseDist;
  let angle = baseAngle;
  let height = baseHeight;
  let panX = 0;
  let lookAt: Vec3 = [...focusTarget];

  switch (cam.move) {
    case 'push': {
      const amt = cam.amount ?? 0.32;
      dist = lerp(baseDist * (1 + amt * 0.45), baseDist * (1 - amt * 0.55), u);
      angle += lerp(-0.08, 0.08, u);
      break;
    }
    case 'pull': {
      const amt = cam.amount ?? 0.38;
      dist = lerp(baseDist * (1 - amt * 0.45), baseDist * (1 + amt * 0.6), u);
      height = lerp(baseHeight * 0.7, baseHeight * 1.35, u);
      break;
    }
    case 'orbit': {
      const degSpan = cam.amount ?? 38;
      angle = baseAngle + lerp(-deg(degSpan * 0.5), deg(degSpan * 0.5), u);
      break;
    }
    case 'truck':
    case 'pan': {
      const span = cam.amount ?? (isPortrait ? 0.55 : 2.2);
      panX = lerp(-span * 0.5, span * 0.5, u);
      break;
    }
    case 'crane': {
      const rise = cam.amount ?? 2.2;
      height = lerp(baseHeight, baseHeight + rise, u);
      dist = lerp(baseDist * 0.92, baseDist * 1.12, u);
      break;
    }
    case 'drop': {
      const dropAmt = cam.amount ?? 2.4;
      height = lerp(baseHeight + dropAmt, baseHeight, u);
      dist = lerp(baseDist * 1.18, baseDist * 0.92, u);
      break;
    }
    case 'follow': {
      // Smoothly glides alongside moving character
      dist = lerp(baseDist * 1.05, baseDist * 0.95, u);
      angle = baseAngle + Math.sin(u * Math.PI) * 0.12;
      break;
    }
    case 'top': {
      const rotSpan = cam.amount ?? 24;
      angle = baseAngle + lerp(-deg(rotSpan * 0.5), deg(rotSpan * 0.5), u);
      dist = lerp(baseDist * 1.06, baseDist * 0.92, u);
      break;
    }
    case 'low': {
      const amt = cam.amount ?? 0.22;
      dist = lerp(baseDist * (1 + amt * 0.3), baseDist * (1 - amt * 0.4), u);
      lookAt[1] += 0.25;
      break;
    }
    case 'close': {
      const amt = cam.amount ?? 0.18;
      dist = lerp(baseDist * (1 + amt * 0.25), baseDist * (1 - amt * 0.35), u);
      lookAt[1] += 0.18;
      break;
    }
    case 'tilt': {
      const startLook = cam.from ? resolveTargetPos(cam.from, shot, set, t, shotEndT) : [focusTarget[0], focusTarget[1] + 2.2, focusTarget[2]] as Vec3;
      lookAt = [
        lerp(startLook[0], focusTarget[0], u),
        lerp(startLook[1], focusTarget[1], u),
        lerp(startLook[2], focusTarget[2], u),
      ];
      break;
    }
    case 'fly':
    case 'hold':
    default: {
      dist = lerp(baseDist * 1.04, baseDist * 0.96, u);
      angle = baseAngle + lerp(-0.04, 0.04, u);
      break;
    }
  }

  const rightX = Math.cos(angle);
  const rightZ = -Math.sin(angle);

  let pos: Vec3 = [
    focusTarget[0] + Math.sin(angle) * dist + rightX * panX,
    Math.max(0.28, focusTarget[1] + height),
    focusTarget[2] + Math.cos(angle) * dist + rightZ * panX,
  ];
  lookAt = [lookAt[0] + rightX * panX * 0.65, lookAt[1], lookAt[2] + rightZ * panX * 0.65];

  if (cam.move === 'fly' && cam.path && cam.path.length >= 2) {
    const segs = cam.path.length - 1;
    const f = u * segs;
    const idx = Math.min(segs - 1, Math.floor(f));
    const localU = f - idx;
    const p0 = toVec3(cam.path[idx]);
    const p1 = toVec3(cam.path[idx + 1]);
    pos = [lerp(p0[0], p1[0], localU), lerp(p0[1], p1[1], localU), lerp(p0[2], p1[2], localU)];
  }

  // Subtle handheld breathing + impact shake FX bursts
  const hh = cam.shake ?? 0.14;
  let shakeAmp = hh * 0.035;
  for (const fx of shot.fx ?? []) {
    if (fx.k === 'shake' || fx.k === 'explosion' || fx.k === 'impact') {
      const t0 = timeOf(fx.at);
      const d = fx.dur ?? 0.45;
      if (t >= t0 && t <= t0 + d) {
        const decay = 1 - (t - t0) / d;
        shakeAmp += (fx.size ?? 1) * 0.18 * decay * decay;
      }
    }
  }

  pos[0] += noise1(t * 2.1, 11) * shakeAmp + Math.sin(t * 37) * Math.max(0, shakeAmp - 0.02);
  pos[1] += noise1(t * 2.4, 23) * shakeAmp + Math.cos(t * 43) * Math.max(0, shakeAmp - 0.02);

  // Depth-of-field focus point
  const dofTarget = cam.focus ? resolveTargetPos(cam.focus, shot, set, t, shotEndT) : lookAt;
  const dx = pos[0] - dofTarget[0];
  const dy = pos[1] - dofTarget[1];
  const dz = pos[2] - dofTarget[2];
  const focusDist = Math.sqrt(dx * dx + dy * dy + dz * dz);

  const fov = cam.fov ?? (isPortrait ? 42 : 34);
  return { pos, lookAt, fov, focusDist };
}

export const CameraRig: React.FC<{
  shot: Shot;
  set: WorldSet;
  t: number;
  shotStartT: number;
  shotEndT: number;
  isPortrait: boolean;
}> = ({ shot, set, t, shotStartT, shotEndT, isPortrait }) => {
  const { camera } = useThree();
  const state = computeCameraState(shot, set, t, shotStartT, shotEndT, isPortrait);

  camera.position.set(state.pos[0], state.pos[1], state.pos[2]);
  camera.lookAt(state.lookAt[0], state.lookAt[1], state.lookAt[2]);
  if (camera instanceof THREE.PerspectiveCamera && camera.fov !== state.fov) {
    camera.fov = state.fov;
    camera.updateProjectionMatrix();
  }
  camera.updateMatrixWorld();

  return null;
};
