"""Check tempo drift: fit beat period+offset on full-mix onset flux, compare with 152.0 BPM grid."""
import numpy as np
from scipy.io import wavfile
from scipy.signal import stft
sr, x = wavfile.read('Halloween Night.wav'); x = x.astype(np.float64).mean(axis=1)
hop = 220
f, t, Z = stft(x, fs=sr, nperseg=2048, noverlap=2048-hop)
S = np.log1p(np.abs(Z)*100)
flux = np.maximum(0, np.diff(S, axis=1)).sum(axis=0); flux = np.concatenate([[0], flux])
fr = sr/hop
def best(t0, t1):
    out = None
    for bpm in np.arange(150.0, 154.01, 0.02):
        p = 60/bpm
        for off in np.arange(0, p, 0.005):
            g = np.arange(t0+off, t1, p)
            s = flux[(g*fr).astype(int)].mean()
            if out is None or s > out[0]: out = (s, bpm, off)
    return out
for a, b in [(0, 40), (40, 80), (80, 132), (0, 132)]:
    s, bpm, off = best(a, b)
    print(f'{a:3d}-{b:3d}s: bpm {bpm:.2f}  first beat {a+off:.3f}')
