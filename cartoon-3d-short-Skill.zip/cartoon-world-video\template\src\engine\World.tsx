// ============================================================================
// PAINTED 3D WORLD WITH BLACK INK LINES.
// Every 3D mesh gets a painted surface + an inverted-hull black ink outline
// plus hard-edge crease lines so the 3D world matches the 2D cartoon cards.
// ============================================================================
import React, { useMemo } from 'react';
import * as THREE from 'three';
import { INK } from './drawCharacter';
import { timeOf } from './timing';
import type { Ground, Item3D, ItemAnim, Pos, Sky, Vec3, WorldSet } from './types';
import { clamp, deg, easeInOut, hashStr, lerp, rng, shade, spring } from './util';

const INK_COLOR = new THREE.Color(INK);

/** Inverted-hull outline + painted mesh wrapper. */
export const InkMesh: React.FC<{
  geometry: THREE.BufferGeometry;
  color: string;
  map?: THREE.Texture | null;
  position?: Vec3;
  rotation?: Vec3;
  scale?: number | Vec3;
  inkWidth?: number;
  glow?: boolean;
  roughness?: number;
  castShadow?: boolean;
  receiveShadow?: boolean;
}> = ({
  geometry,
  color,
  map = null,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = 1,
  inkWidth = 0.032,
  glow = false,
  roughness = 0.82,
  castShadow = true,
  receiveShadow = true,
}) => {
  const sc: Vec3 = typeof scale === 'number' ? [scale, scale, scale] : scale;
  const outScale: Vec3 = [1 + inkWidth, 1 + inkWidth, 1 + inkWidth];
  const edges = useMemo(() => new THREE.EdgesGeometry(geometry, 42), [geometry]);

  return (
    <group position={position} rotation={rotation} scale={sc}>
      <mesh geometry={geometry} castShadow={castShadow} receiveShadow={receiveShadow}>
        {glow ? (
          <meshStandardMaterial color={color} map={map ?? undefined} emissive={color} emissiveIntensity={1.25} roughness={0.35} />
        ) : (
          <meshStandardMaterial color={color} map={map ?? undefined} roughness={roughness} metalness={0.04} />
        )}
      </mesh>
      {inkWidth > 0 && (
        <mesh geometry={geometry} scale={outScale}>
          <meshBasicMaterial color={INK_COLOR} side={THREE.BackSide} toneMapped={false} />
        </mesh>
      )}
      {inkWidth > 0 && geometry !== GEO.ball && geometry !== GEO.dome && (
        <lineSegments geometry={edges}>
          <lineBasicMaterial color={INK_COLOR} toneMapped={false} />
        </lineSegments>
      )}
    </group>
  );
};

// Shared primitive geometries (created once, smooth 28-segment curves so no polygon corners show)
const GEO = {
  box: new THREE.BoxGeometry(1, 1, 1),
  cyl: new THREE.CylinderGeometry(0.5, 0.5, 1, 28),
  cone: new THREE.ConeGeometry(0.6, 1, 28),
  pyr: new THREE.ConeGeometry(0.75, 1, 4),
  ball: new THREE.SphereGeometry(0.5, 22, 16),
  dome: new THREE.SphereGeometry(0.5, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55),
  plane: new THREE.PlaneGeometry(1, 1),
};

const FACADE_TEX_CACHE = new Map<string, THREE.CanvasTexture>();

/** Procedural painted brick / stone / clapboard building facade texture. */
function getFacadeTexture(style: 'brick' | 'stone' | 'plaster', baseHex: string): THREE.CanvasTexture {
  const key = `${style}:${baseHex}`;
  const cached = FACADE_TEX_CACHE.get(key);
  if (cached) return cached;

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 256, 256);
  const rand = rng(hashStr(key));

  if (style === 'brick' || style === 'stone') {
    const rows = style === 'brick' ? 12 : 8;
    const cols = style === 'brick' ? 6 : 4;
    const rh = 256 / rows;
    const cw = 256 / cols;
    for (let r = 0; r < rows; r++) {
      const ox = (r % 2) * (cw * 0.5);
      for (let k = -1; k <= cols; k++) {
        const x = k * cw + ox;
        const y = r * rh;
        ctx.fillStyle = shade(baseHex, (rand() - 0.5) * 0.14);
        ctx.fillRect(x + 2, y + 2, cw - 4, rh - 4);
      }
      ctx.strokeStyle = shade(baseHex, -0.25);
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, r * rh);
      ctx.lineTo(256, r * rh);
      ctx.stroke();
    }
  } else {
    // Warm storybook plaster with subtle horizontal siding & weather variation
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = shade(baseHex, (rand() - 0.5) * 0.08);
      ctx.fillRect(rand() * 220, rand() * 220, 20 + rand() * 45, 10 + rand() * 25);
    }
    ctx.strokeStyle = shade(baseHex, -0.18);
    ctx.lineWidth = 2;
    for (let r = 1; r < 8; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * 32);
      ctx.lineTo(256, r * 32);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  FACADE_TEX_CACHE.set(key, tex);
  return tex;
}

/** Create a procedural painted canvas texture for ground, signs, or façades. */
function makeSignTexture(text: string, bg = '#FAF3E0', fg = INK): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 512, 256);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 14;
  ctx.strokeRect(10, 10, 492, 236);
  ctx.fillStyle = fg;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const lines = text.split('\n');
  const fontSize = Math.min(68, Math.floor(380 / Math.max(5, ...lines.map((l) => l.length * 0.62))));
  ctx.font = `900 ${fontSize}px Montserrat, Arial Black, sans-serif`;
  lines.forEach((ln, i) => {
    const y = 128 + (i - (lines.length - 1) / 2) * (fontSize * 1.15);
    ctx.fillText(ln, 256, y);
  });
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeGroundTexture(kind: Ground, baseHex: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 512, 512);
  const rand = rng(hashStr(kind + baseHex));

  if (kind === 'grass' || kind === 'dirt' || kind === 'sand' || kind === 'snow') {
    for (let i = 0; i < 160; i++) {
      ctx.fillStyle = rand() > 0.5 ? shade(baseHex, 0.08) : shade(baseHex, -0.09);
      const x = rand() * 512;
      const y = rand() * 512;
      ctx.beginPath();
      ctx.ellipse(x, y, 8 + rand() * 24, 4 + rand() * 10, rand() * 0.5, 0, Math.PI * 2);
      ctx.fill();
    }
    if (kind === 'grass') {
      ctx.strokeStyle = shade(baseHex, -0.22);
      ctx.lineWidth = 3;
      for (let i = 0; i < 90; i++) {
        const x = rand() * 500 + 6;
        const y = rand() * 500 + 6;
        ctx.beginPath();
        ctx.moveTo(x - 4, y);
        ctx.lineTo(x - 7, y - 10);
        ctx.moveTo(x + 2, y);
        ctx.lineTo(x + 6, y - 9);
        ctx.stroke();
      }
    }
  } else if (kind === 'cobble' || kind === 'stone') {
    const rows = 8;
    const cols = 6;
    const w = 512 / cols;
    const h = 512 / rows;
    for (let r = 0; r < rows; r++) {
      for (let k = 0; k < cols; k++) {
        const ox = (r % 2) * (w * 0.5);
        const x = ((k * w + ox) % 512);
        const y = r * h;
        ctx.fillStyle = shade(baseHex, (rand() - 0.5) * 0.16);
        ctx.strokeStyle = INK;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.roundRect(x + 3, y + 3, w - 6, h - 6, 8);
        ctx.fill();
        ctx.stroke();
      }
    }
  } else if (kind === 'wood') {
    const planks = 8;
    const h = 512 / planks;
    for (let r = 0; r < planks; r++) {
      ctx.fillStyle = shade(baseHex, (r % 2 === 0 ? 1 : -1) * 0.05);
      ctx.fillRect(0, r * h, 512, h);
      ctx.strokeStyle = INK;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, r * h);
      ctx.lineTo(512, r * h);
      const joint = ((r * 173) % 420) + 40;
      ctx.moveTo(joint, r * h);
      ctx.lineTo(joint, (r + 1) * h);
      ctx.stroke();
    }
  } else if (kind === 'tile' || kind === 'carpet') {
    const n = 8;
    const s = 512 / n;
    for (let r = 0; r < n; r++) {
      for (let k = 0; k < n; k++) {
        ctx.fillStyle = (r + k) % 2 === 0 ? baseHex : shade(baseHex, -0.09);
        ctx.fillRect(k * s, r * s, s, s);
        ctx.strokeStyle = shade(baseHex, -0.25);
        ctx.lineWidth = 3;
        ctx.strokeRect(k * s, r * s, s, s);
      }
    }
  } else if (kind === 'water') {
    ctx.strokeStyle = 'rgba(255,255,255,0.38)';
    ctx.lineWidth = 5;
    for (let i = 0; i < 45; i++) {
      const x = rand() * 460;
      const y = rand() * 500;
      ctx.beginPath();
      ctx.arc(x, y, 22, -Math.PI * 0.8, -Math.PI * 0.2);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(22, 22);
  return tex;
}

const SKY_PALETTES: Record<Sky, { top: string; mid: string; bot: string; fog: string; sun: string; amb: number; dir: number }> = {
  day: { top: '#1E78E8', mid: '#58B4FF', bot: '#C7EEFF', fog: '#B9E6FF', sun: '#FFF6D6', amb: 0.78, dir: 1.15 },
  morning: { top: '#3B7DE8', mid: '#8FC8FF', bot: '#FFE2B8', fog: '#FFE4C2', sun: '#FFE2A8', amb: 0.76, dir: 1.1 },
  sunset: { top: '#4B2D88', mid: '#E85D56', bot: '#FFC266', fog: '#FFA970', sun: '#FFD07A', amb: 0.68, dir: 1.15 },
  dusk: { top: '#1E2152', mid: '#5C3C92', bot: '#E07A72', fog: '#8A569C', sun: '#FFA07A', amb: 0.58, dir: 0.85 },
  night: { top: '#0D1330', mid: '#1B285E', bot: '#314988', fog: '#1F3068', sun: '#9BB8FF', amb: 0.52, dir: 0.65 },
  overcast: { top: '#5E7288', mid: '#8DA1B5', bot: '#C5D1DC', fog: '#B5C4D1', sun: '#E6EEF5', amb: 0.75, dir: 0.7 },
  storm: { top: '#1E2636', mid: '#38455C', bot: '#5C6C82', fog: '#3F4D63', sun: '#9FB2C9', amb: 0.5, dir: 0.55 },
  indoor: { top: '#D8D2C5', mid: '#E8E2D5', bot: '#F5EFE2', fog: '#E5DFD2', sun: '#FFF8E8', amb: 0.85, dir: 0.9 },
};

const GROUND_COLORS: Record<Ground, string> = {
  grass: '#6CC24A',
  dirt: '#C49358',
  cobble: '#9BA3AE',
  sand: '#EED08A',
  snow: '#EEF5FA',
  wood: '#B57C4A',
  tile: '#B8C7D4',
  carpet: '#2755B8',
  stone: '#8C949E',
  water: '#2B8BE6',
  none: '#6CC24A',
};

function makeSkyDomeTexture(sky: Sky): THREE.CanvasTexture {
  const pal = SKY_PALETTES[sky];
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;
  const g = ctx.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, pal.top);
  g.addColorStop(0.55, pal.mid);
  g.addColorStop(1, pal.bot);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  const rand = rng(hashStr(sky));
  if (sky === 'night' || sky === 'dusk') {
    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 90; i++) {
      ctx.beginPath();
      ctx.arc(rand() * 512, rand() * 280, 1 + rand() * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  if (sky !== 'indoor') {
    // Painted storybook clouds
    ctx.fillStyle = sky === 'night' ? 'rgba(140,170,230,0.22)' : sky === 'sunset' ? 'rgba(255,220,180,0.65)' : 'rgba(255,255,255,0.78)';
    for (let i = 0; i < 10; i++) {
      const cx = (i * 52 + rand() * 25) % 500;
      const cy = 170 + rand() * 110;
      for (let k = -1; k <= 1; k++) {
        ctx.beginPath();
        ctx.arc(cx + k * 18, cy + Math.abs(k) * 4, 16 - Math.abs(k) * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Evaluate item animations at global time `t` (seconds). */
export function evaluateItemAnim(it: Item3D, t: number): {
  pos: Vec3;
  rot: Vec3;
  scale: Vec3;
  visible: boolean;
  glow: boolean;
  collapseAmt: number;
  shakeAmt: number;
  explodeAmt: number;
} {
  const basePos: Vec3 = it.at.length === 2 ? [it.at[0], 0, it.at[1]] : [it.at[0], it.at[1], it.at[2]];
  const baseRot: Vec3 = [0, deg(it.rot ?? 0), 0];
  const baseScale: Vec3 = typeof it.s === 'number' ? [it.s, it.s, it.s] : it.s ?? [1, 1, 1];

  const pos: Vec3 = [...basePos];
  const rot: Vec3 = [...baseRot];
  const scale: Vec3 = [...baseScale];
  let visible = true;
  const firstVis = (it.anim ?? []).find((a) => a.do === 'show' || a.do === 'hide');
  if (firstVis?.do === 'show') visible = false;
  let glow = Boolean(it.glow);
  let collapseAmt = 0;
  let shakeAmt = 0;
  let explodeAmt = 0;

  for (const a of it.anim ?? []) {
    const t0 = timeOf(a.at);
    const t1 = a.to !== undefined ? timeOf(a.to) : t0 + 0.65;
    const amt = a.amt ?? 1;
    if (a.do === 'hide' && t >= t0) visible = false;
    if (a.do === 'show' && t >= t0) visible = true;
    if (t < t0) continue;

    const dur = Math.max(0.05, t1 - t0);
    const u = clamp((t - t0) / dur);
    const active = t <= t1;
    // Bounded animations with an explicit `to` end time reset after `t1`
    if (a.to !== undefined && !active && a.do !== 'hide' && a.do !== 'show') continue;

    switch (a.do) {
      case 'shake':
        if (active) {
          const env = Math.sin(u * Math.PI);
          shakeAmt = Math.max(shakeAmt, amt * env);
          pos[0] += Math.sin((t - t0) * 42) * 0.08 * amt * env;
          pos[1] += Math.cos((t - t0) * 54) * 0.05 * amt * env;
          rot[2] += Math.sin((t - t0) * 38) * 0.04 * amt * env;
        }
        break;
      case 'wobble':
      case 'sway': {
        // Vertical sinusoidal oscillation + twist (ideal for resonant bridge / swaying trees)
        const env = a.to !== undefined ? (active ? Math.sin(u * Math.PI * 0.85 + 0.15) : 0) : 1;
        const w = (t - t0) * Math.PI * 4; // 2 Hz resonance match with marching step
        pos[1] += Math.sin(w) * 0.16 * amt * env;
        rot[2] += Math.sin(w) * 0.045 * amt * env;
        rot[0] += Math.cos(w * 0.5) * 0.03 * amt * env;
        break;
      }
      case 'bounce':
        if (active) {
          pos[1] += Math.abs(Math.sin(u * Math.PI * 2)) * 0.35 * amt;
        }
        break;
      case 'fall': {
        const e = easeInOut(u);
        rot[2] += e * deg(88) * amt;
        pos[1] -= e * 0.25 * Math.abs(amt);
        break;
      }
      case 'tilt': {
        const e = easeInOut(u);
        rot[2] += e * deg(18 * amt);
        break;
      }
      case 'spin':
        rot[1] += (t - t0) * 4.5 * amt;
        break;
      case 'pop': {
        const s = spring(t - t0, 3, 5);
        scale[0] *= s;
        scale[1] *= s;
        scale[2] *= s;
        break;
      }
      case 'squash':
        if (active) {
          const sq = 1 - Math.sin(u * Math.PI) * 0.28 * amt;
          scale[1] *= sq;
          scale[0] /= Math.sqrt(sq);
          scale[2] /= Math.sqrt(sq);
        }
        break;
      case 'move':
      case 'flow':
        if (a.pos) {
          const target: Vec3 = a.pos.length === 2 ? [a.pos[0], 0, a.pos[1]] : [a.pos[0], a.pos[1], a.pos[2]];
          const e = easeInOut(u);
          pos[0] = lerp(basePos[0], target[0], e);
          pos[1] = lerp(basePos[1], target[1], e);
          pos[2] = lerp(basePos[2], target[2], e);
        }
        break;
      case 'collapse':
        collapseAmt = easeInOut(u) * amt;
        break;
      case 'explode':
      case 'rupture':
        explodeAmt = Math.max(explodeAmt, Math.pow(u, 0.65) * amt);
        break;
      case 'glow':
        glow = t >= t0 && (a.to === undefined || t <= t1);
        break;
      case 'open':
        rot[1] += easeInOut(u) * deg(85 * amt);
        break;
      case 'sink':
        explodeAmt = Math.max(explodeAmt, Math.pow(u, 0.65) * amt);
        pos[1] -= easeInOut(u) * 0.65 * amt;
        rot[2] += easeInOut(u) * 0.14 * amt;
        break;
      case 'rise':
        pos[1] += easeInOut(u) * 1.4 * amt;
        break;
    }
  }

  return { pos, rot, scale, visible, glow, collapseAmt, shakeAmt, explodeAmt };
}

/** Resolve world coordinates for a named item id in a WorldSet at time `t`. */
export function findItemPos(set: WorldSet, id: string, t: number): Vec3 | null {
  const found = set.items.find((it) => it.id === id);
  if (!found) return null;
  return evaluateItemAnim(found, t).pos;
}

const GROUND_ANCHORED_KINDS = new Set<Item3D['k']>([
  'tree', 'pine', 'palm', 'bush', 'flowers', 'grass', 'rock', 'hill', 'mountain', 'cliff', 'river', 'road', 'pond',
  'swing', 'bridge', 'chainbridge', 'house', 'shop', 'church', 'building', 'factory', 'tank', 'tower', 'castle',
  'lighthouse', 'wall', 'fence', 'lamp', 'bench', 'tent', 'stall', 'ship', 'boat', 'cannon', 'car', 'train', 'cart',
  'rails', 'room', 'desk', 'table', 'counter', 'chair', 'throne', 'shelf', 'locker', 'door', 'statue', 'column',
  'arch', 'campfire', 'well', 'haystack', 'windmill', 'pier', 'chimney', 'bed', 'rug', 'fireplace', 'animal',
  'horse', 'bird', 'scale', 'seesaw',
]);

const TABLETOP_PROP_KINDS = new Set<Item3D['k']>([
  'bottle', 'jar', 'computer', 'clock', 'frame', 'plant', 'bomb', 'gauge', 'thermometer', 'pendulum', 'spring',
  'box', 'cyl', 'ball', 'cone',
]);

const WorldItemView: React.FC<{ item: Item3D; allItems: Item3D[]; t: number }> = ({ item, allItems, t }) => {
  const ev = evaluateItemAnim(item, t);
  const signTex = useMemo(
    () => (item.text ? makeSignTexture(item.text, item.c2 ?? '#FAF3E0', INK) : null),
    [item.text, item.c2],
  );
  if (!ev.visible) return null;

  const c = item.c;
  const c2 = item.c2;
  const len = item.len ?? 6;

  // Smart semantic promotion for any topic (even if a lightweight AI writes k: 'box' / 'cyl' / 'ball'):
  let effectiveKind = item.k;
  const idLower = `${item.id ?? ''} ${item.text ?? ''}`.toLowerCase();
  if (/bottle|ketchup|soda|wine|potion|flask/.test(idLower)) {
    effectiveKind = 'bottle';
  } else if (/jar|beaker|mug|cup|honey|jam/.test(idLower)) {
    effectiveKind = 'jar';
  } else if (/glue|sticky|tar|mudtrap|quicksand/.test(idLower)) {
    effectiveKind = 'glue';
  } else if (/bomb|dynamite|tnt|grenade|mine/.test(idLower)) {
    effectiveKind = 'bomb';
  } else if (/gauge|thermometer|meter|pressure|dial/.test(idLower)) {
    effectiveKind = 'gauge';
  } else if (/scale|seesaw|balance/.test(idLower)) {
    effectiveKind = 'scale';
  } else if (/pendulum/.test(idLower)) {
    effectiveKind = 'pendulum';
  } else if (/spring|coil/.test(idLower)) {
    effectiveKind = 'spring';
  } else if (/balloon|blimp|zepp/.test(idLower)) {
    effectiveKind = 'balloon';
  } else if (/emu|bird|pigeon|chicken|duck|goose|ostrich|crow|seagull/.test(idLower)) {
    effectiveKind = 'bird';
  } else if (/horse|dog|cat|cow|sheep|pig|rabbit|bunny|goat|wolf|bear|animal/.test(idLower)) {
    effectiveKind = 'animal';
  } else if (item.k === 'cyl' && ev.scale[1] <= 0.15 && ev.scale[0] >= 0.45) {
    effectiveKind = 'puddle';
  } else if (item.k === 'cyl' && (/tank|silo|vat|boiler|coat/.test(idLower) || (ev.scale[0] >= 1.8 && ev.scale[1] >= 2.2))) {
    effectiveKind = 'tank';
  } else if (item.k === 'hill' && (/wave|tsunami|flood|surge/.test(idLower) || (c && /^#(2|3|5|6)/.test(c.toLowerCase())))) {
    effectiveKind = 'wave';
  }

  // Universal Grounding & Tabletop Auto-Snap (prevents floating props on ANY topic):
  const rawBaseY = item.at.length === 2 ? 0 : item.at[1];
  const animDeltaY = ev.pos[1] - rawBaseY;
  let snappedBaseY = rawBaseY;

  if (TABLETOP_PROP_KINDS.has(effectiveKind) && rawBaseY > 0.2) {
    // Check if placed above a desk / table / counter in this set; if so, snap flush to tabletop surface!
    for (const other of allItems) {
      if (other !== item && (other.k === 'desk' || other.k === 'table' || other.k === 'counter')) {
        const ox = other.at[0];
        const oy = Math.max(0, other.at.length === 2 ? 0 : other.at[1]);
        const oz = other.at.length === 2 ? other.at[1] : other.at[2];
        const os: Vec3 = typeof other.s === 'number' ? [other.s, other.s, other.s] : other.s ?? [1, 1, 1];
        const halfW = (other.k === 'counter' ? 1.45 : 0.88) * os[0];
        const halfD = 0.52 * os[2];
        if (Math.abs(ev.pos[0] - ox) <= halfW && Math.abs(ev.pos[2] - oz) <= halfD) {
          snappedBaseY = oy + 0.62 * os[1];
          break;
        }
      }
    }
  } else if (GROUND_ANCHORED_KINDS.has(effectiveKind) && rawBaseY > 0.05) {
    // Ground-standing structures/furniture/trees/vehicles never float above y = 0 at rest
    snappedBaseY = 0;
  }

  const finalPos: Vec3 = [ev.pos[0], snappedBaseY + animDeltaY, ev.pos[2]];

  return (
    <group position={finalPos} rotation={ev.rot} scale={ev.scale}>
      {renderKind(
        effectiveKind,
        c,
        c2,
        len,
        ev.glow,
        ev.collapseAmt,
        ev.shakeAmt,
        ev.explodeAmt,
        t,
        signTex,
        item.id,
        finalPos[1],
        ev.scale[1],
        ev.rot[2],
      )}
    </group>
  );
};

function renderKind(
  k: Item3D['k'],
  c: string | undefined,
  c2: string | undefined,
  len: number,
  glow: boolean,
  collapseAmt: number,
  shakeAmt: number,
  explodeAmt: number,
  t: number,
  signTex: THREE.CanvasTexture | null,
  itemId?: string,
  worldY = 0,
  scaleY = 1,
  rotZ = 0,
) {
  switch (k) {
    case 'tree': {
      const leaf = c ?? '#48B84E';
      const trunk = c2 ?? '#8A5A36';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={trunk} position={[0, 0.75, 0]} scale={[0.36, 1.5, 0.36]} />
          <InkMesh geometry={GEO.ball} color={leaf} position={[0, 2.0, 0]} scale={[1.7, 1.5, 1.7]} />
          <InkMesh geometry={GEO.ball} color={shade(leaf, 0.1)} position={[0.45, 2.35, 0.25]} scale={[1.15, 1.05, 1.15]} />
          <InkMesh geometry={GEO.ball} color={shade(leaf, -0.08)} position={[-0.45, 2.15, -0.2]} scale={[1.2, 1.0, 1.2]} />
        </group>
      );
    }
    case 'pine': {
      const leaf = c ?? '#2E8B52';
      const trunk = c2 ?? '#7A4E2D';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={trunk} position={[0, 0.55, 0]} scale={[0.3, 1.1, 0.3]} />
          <InkMesh geometry={GEO.cone} color={leaf} position={[0, 1.45, 0]} scale={[1.6, 1.35, 1.6]} />
          <InkMesh geometry={GEO.cone} color={shade(leaf, 0.07)} position={[0, 2.2, 0]} scale={[1.25, 1.2, 1.25]} />
          <InkMesh geometry={GEO.cone} color={shade(leaf, 0.14)} position={[0, 2.85, 0]} scale={[0.85, 1.0, 0.85]} />
        </group>
      );
    }
    case 'palm': {
      const leaf = c ?? '#48B84E';
      const trunk = c2 ?? '#A67244';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={trunk} position={[0, 1.2, 0]} scale={[0.3, 2.4, 0.3]} />
          {[0, 1, 2, 3, 4].map((i) => (
            <InkMesh
              key={i}
              geometry={GEO.box}
              color={leaf}
              position={[Math.cos(i * 1.25) * 0.7, 2.4, Math.sin(i * 1.25) * 0.7]}
              rotation={[0.35, -i * 1.25, 0]}
              scale={[0.35, 0.1, 1.4]}
            />
          ))}
        </group>
      );
    }
    case 'bush': {
      const leaf = c ?? '#52B848';
      return (
        <group>
          <InkMesh geometry={GEO.ball} color={leaf} position={[0, 0.42, 0]} scale={[1.1, 0.85, 0.95]} />
          <InkMesh geometry={GEO.ball} color={shade(leaf, 0.1)} position={[0.42, 0.35, 0.12]} scale={[0.75, 0.65, 0.75]} />
          <InkMesh geometry={GEO.ball} color={shade(leaf, -0.08)} position={[-0.38, 0.32, -0.1]} scale={[0.7, 0.6, 0.7]} />
        </group>
      );
    }
    case 'flowers':
    case 'grass': {
      const col = c ?? '#FF6B8B';
      return (
        <group>
          {[-0.35, 0, 0.35].map((x, i) => (
            <group key={i} position={[x, 0, (i - 1) * 0.2]}>
              <InkMesh geometry={GEO.cyl} color="#3FA34D" position={[0, 0.18, 0]} scale={[0.06, 0.36, 0.06]} inkWidth={0.015} />
              {k === 'flowers' && <InkMesh geometry={GEO.ball} color={i === 1 ? (c2 ?? '#FFD23F') : col} position={[0, 0.38, 0]} scale={[0.22, 0.16, 0.22]} inkWidth={0.02} />}
            </group>
          ))}
        </group>
      );
    }
    case 'rock':
      return <InkMesh geometry={GEO.ball} color={c ?? '#8E97A2'} position={[0, 0.35, 0]} scale={[1.1, 0.75, 0.9]} />;
    case 'hill':
      return <InkMesh geometry={GEO.dome} color={c ?? '#5BB546'} position={[0, 0, 0]} scale={[8, 3.2, 6]} inkWidth={0.015} />;
    case 'mountain':
    case 'cliff': {
      const col = c ?? (k === 'cliff' ? '#D67B42' : '#6E7F99');
      const snow = c2 ?? '#F4F8FC';
      return (
        <group>
          <InkMesh geometry={GEO.cone} color={col} position={[0, 3.5, 0]} scale={[6.5, 7, 6.5]} inkWidth={0.015} />
          {k === 'mountain' && <InkMesh geometry={GEO.cone} color={snow} position={[0, 5.7, 0]} scale={[2.45, 2.6, 2.45]} inkWidth={0.015} />}
        </group>
      );
    }
    case 'river':
    case 'road': {
      const col = c ?? (k === 'river' ? '#2498E8' : '#C89E68');
      const w = k === 'river' ? 8.6 : 2.6;
      return (
        <group>
          <InkMesh geometry={GEO.box} color={col} position={[0, k === 'river' ? 0.04 : 0.02, 0]} scale={[len, 0.08, w]} inkWidth={0.006} />
          {k === 'river' && (
            <>
              <InkMesh geometry={GEO.box} color={c2 ?? '#9BA3AE'} position={[0, 0.16, w / 2 + 0.2]} scale={[len, 0.28, 0.38]} inkWidth={0.01} />
              <InkMesh geometry={GEO.box} color={c2 ?? '#9BA3AE'} position={[0, 0.16, -w / 2 - 0.2]} scale={[len, 0.28, 0.38]} inkWidth={0.01} />
              {[-2.4, -0.8, 0.9, 2.5].map((rz, ri) => (
                <InkMesh
                  key={ri}
                  geometry={GEO.box}
                  color="#9EE0FF"
                  position={[((ri * 1.7) % 3) - 1.5, 0.09, rz]}
                  scale={[len * 0.55, 0.02, 0.18]}
                  inkWidth={0}
                />
              ))}
            </>
          )}
        </group>
      );
    }
    case 'swing': {
      const frameCol = c ?? '#C94236';
      const seatCol = c2 ?? '#E8A838';
      return (
        <group position={[0, 0, -0.25]}>
          <InkMesh geometry={GEO.cyl} color={frameCol} position={[-1.45, 1.35, 0]} scale={[0.14, 2.7, 0.14]} />
          <InkMesh geometry={GEO.cyl} color={frameCol} position={[1.45, 1.35, 0]} scale={[0.14, 2.7, 0.14]} />
          <InkMesh geometry={GEO.box} color={frameCol} position={[0, 2.68, 0]} scale={[3.2, 0.16, 0.18]} />
          {/* Ropes & seat slightly behind the kid so they never clip through the character card */}
          <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[-0.28, 1.55, 0]} scale={[0.04, 2.2, 0.04]} inkWidth={0.015} />
          <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[0.28, 1.55, 0]} scale={[0.04, 2.2, 0.04]} inkWidth={0.015} />
          <InkMesh geometry={GEO.box} color={seatCol} position={[0, 0.44, 0]} scale={[0.72, 0.09, 0.36]} />
        </group>
      );
    }
    case 'pond':
      return <InkMesh geometry={GEO.cyl} color={c ?? '#2FA4EC'} position={[0, 0.02, 0]} scale={[4.2, 0.06, 3.2]} inkWidth={0.012} />;

    case 'chainbridge':
    case 'bridge': {
      // Iconic suspension / arch bridge (supports resonant wobble + dramatic snap collapse!)
      const span = len || 10;
      const deckCol = c ?? '#8C6239';
      const ironCol = c2 ?? '#3B424C';
      const towerX = span * 0.44;
      const snapDrop = collapseAmt * 2.2;
      const snapAngle = collapseAmt * 0.58;

      return (
        <group>
          {/* Stone/iron abutments */}
          <InkMesh geometry={GEO.box} color="#9BA3AE" position={[-towerX - 0.7, 0.45, 0]} scale={[1.6, 1.1, 2.5]} />
          <InkMesh geometry={GEO.box} color="#9BA3AE" position={[towerX + 0.7, 0.45, 0]} scale={[1.6, 1.1, 2.5]} />

          {/* Suspension towers placed behind the deck (z = -1.05) + low front bollards (z = +1.05) so front towers never occlude characters */}
          {k === 'chainbridge' &&
            [-towerX, towerX].map((tx, idx) => (
              <group key={idx} position={[tx, 0, 0]}>
                <InkMesh geometry={GEO.box} color={ironCol} position={[0, 0.85, 1.02]} scale={[0.24, 1.7, 0.24]} />
                <InkMesh geometry={GEO.ball} color="#E8B33A" position={[0, 1.78, 1.02]} scale={[0.24, 0.24, 0.24]} />
                <InkMesh geometry={GEO.box} color={ironCol} position={[0, 1.95, -1.02]} scale={[0.38, 3.9, 0.38]} />
                <InkMesh geometry={GEO.ball} color="#E8B33A" position={[0, 4.0, -1.02]} scale={[0.34, 0.34, 0.34]} />
              </group>
            ))}

          {/* Left half deck (tilts down toward center when collapseAmt > 0) */}
          <group position={[-towerX, 0.9, 0]} rotation={[0, 0, -snapAngle]}>
            <InkMesh geometry={GEO.box} color={deckCol} position={[towerX * 0.5, -snapDrop * 0.15, 0]} scale={[towerX * 0.98, 0.18, 2.1]} />
            <InkMesh geometry={GEO.box} color={ironCol} position={[towerX * 0.5, 0.42 - snapDrop * 0.15, 0.96]} scale={[towerX * 0.96, 0.06, 0.06]} />
            <InkMesh geometry={GEO.box} color={ironCol} position={[towerX * 0.5, 0.52 - snapDrop * 0.15, -0.96]} scale={[towerX * 0.96, 0.08, 0.08]} />
          </group>

          {/* Right half deck */}
          <group position={[towerX, 0.9, 0]} rotation={[0, 0, snapAngle]}>
            <InkMesh geometry={GEO.box} color={deckCol} position={[-towerX * 0.5, -snapDrop * 0.15, 0]} scale={[towerX * 0.98, 0.18, 2.1]} />
            <InkMesh geometry={GEO.box} color={ironCol} position={[-towerX * 0.5, 0.42 - snapDrop * 0.15, 0.96]} scale={[towerX * 0.96, 0.06, 0.06]} />
            <InkMesh geometry={GEO.box} color={ironCol} position={[-towerX * 0.5, 0.52 - snapDrop * 0.15, -0.96]} scale={[towerX * 0.96, 0.08, 0.08]} />
          </group>

          {/* Suspension chains & vertical hangers along the back rail (-0.96) + low front posts (+0.96) */}
          {k === 'chainbridge' && (
            <group>
              {[-3, -2, -1, 0, 1, 2, 3].map((step) => {
                const u = step / 3.5;
                const x = u * towerX;
                const catY = 1.65 + u * u * 1.95 - collapseAmt * (1 - Math.abs(u)) * 1.4;
                const deckY = 0.95 - collapseAmt * (1 - Math.abs(u)) * 1.6;
                const hLen = Math.max(0.2, catY - deckY);
                return (
                  <group key={step}>
                    <InkMesh geometry={GEO.cyl} color={ironCol} position={[x, deckY + hLen / 2, -0.96]} scale={[0.05, hLen, 0.05]} inkWidth={0.015} />
                    <InkMesh geometry={GEO.ball} color={ironCol} position={[x, catY, -0.96]} scale={[0.14, 0.14, 0.14]} inkWidth={0.015} />
                    <InkMesh geometry={GEO.cyl} color={ironCol} position={[x, deckY + 0.22, 0.96]} scale={[0.045, 0.44, 0.045]} inkWidth={0.012} />
                  </group>
                );
              })}
            </group>
          )}
        </group>
      );
    }

    case 'house':
    case 'shop':
    case 'church': {
      const wall = c ?? '#F5E9D3';
      const roof = c2 ?? '#D64B3A';
      const h = k === 'church' ? 3.4 : 2.3;
      const w = k === 'shop' ? 3.2 : 2.6;
      const facadeTex = getFacadeTexture('plaster', wall);
      return (
        <group>
          {/* Main textured wall + stone foundation plinth */}
          <InkMesh geometry={GEO.box} color="#FFFFFF" map={facadeTex} position={[0, h / 2, 0]} scale={[w, h, 2.4]} />
          <InkMesh geometry={GEO.box} color={shade(wall, -0.22)} position={[0, 0.14, 0]} scale={[w + 0.08, 0.28, 2.48]} />
          {/* Roof + eaves trim + chimney */}
          <InkMesh geometry={GEO.pyr} color={roof} position={[0, h + 0.85, 0]} rotation={[0, Math.PI / 4, 0]} scale={[w * 0.98, 1.7, 2.4 * 0.98]} />
          <InkMesh geometry={GEO.box} color={shade(roof, -0.25)} position={[w * 0.28, h + 1.15, -0.35]} scale={[0.38, 0.95, 0.38]} />
          {/* Framed wooden door + steps */}
          <InkMesh geometry={GEO.box} color="#5B371E" position={[0, 0.56, 1.22]} scale={[0.62, 1.12, 0.09]} />
          <InkMesh geometry={GEO.box} color="#9BA3AE" position={[0, 0.08, 1.35]} scale={[0.82, 0.16, 0.32]} />
          {/* Multi-pane windows with shutters & sills */}
          {[-0.78, 0.78].map((wx, i) => (
            <group key={i} position={[wx, 1.38, 1.22]}>
              <InkMesh geometry={GEO.box} color={glow ? '#FFE27A' : '#82CCFA'} position={[0, 0, 0]} scale={[0.52, 0.54, 0.07]} glow={glow} />
              <InkMesh geometry={GEO.box} color={roof} position={[-0.32, 0, 0.02]} scale={[0.12, 0.56, 0.06]} inkWidth={0.015} />
              <InkMesh geometry={GEO.box} color={roof} position={[0.32, 0, 0.02]} scale={[0.12, 0.56, 0.06]} inkWidth={0.015} />
              <InkMesh geometry={GEO.box} color="#FAF3E0" position={[0, -0.3, 0.04]} scale={[0.64, 0.08, 0.12]} inkWidth={0.015} />
            </group>
          ))}
          {k === 'shop' && (
            <group position={[0, 1.15, 1.48]} rotation={[0.35, 0, 0]}>
              <InkMesh geometry={GEO.box} color={roof} position={[0, 0, 0]} scale={[w * 0.94, 0.12, 0.72]} />
              {[-1.1, -0.55, 0, 0.55, 1.1].map((sx, si) => (
                <InkMesh key={si} geometry={GEO.box} color="#FAF3E0" position={[sx, 0.02, 0]} scale={[0.24, 0.13, 0.73]} inkWidth={0} />
              ))}
            </group>
          )}
          {signTex && (
            <mesh position={[0, h - 0.35, 1.26]}>
              <planeGeometry args={[w * 0.74, 0.52]} />
              <meshBasicMaterial map={signTex} toneMapped={false} />
            </mesh>
          )}
        </group>
      );
    }

    case 'building':
    case 'factory': {
      const wall = c ?? (k === 'factory' ? '#B24C3A' : '#637996');
      const win = c2 ?? (glow ? '#FFE07D' : '#96D9FF');
      const h = k === 'factory' ? 3.8 : 5.8;
      const w = k === 'factory' ? 4.4 : 3.1;
      const facadeTex = getFacadeTexture('brick', wall);
      const trimCol = shade(wall, -0.25);
      return (
        <group>
          {/* Brick-textured building body + stone cornice + base */}
          <InkMesh geometry={GEO.box} color="#FFFFFF" map={facadeTex} position={[0, h / 2, 0]} scale={[w, h, 2.8]} />
          <InkMesh geometry={GEO.box} color={trimCol} position={[0, h + 0.12, 0]} scale={[w + 0.22, 0.26, 3.0]} />
          <InkMesh geometry={GEO.box} color={trimCol} position={[0, h * 0.5, 0]} scale={[w + 0.12, 0.14, 2.9]} />
          <InkMesh geometry={GEO.box} color="#4A525D" position={[0, 0.2, 0]} scale={[w + 0.14, 0.4, 2.9]} />
          {/* Ground floor door */}
          <InkMesh geometry={GEO.box} color="#4E3220" position={[0, 0.65, 1.42]} scale={[0.75, 1.3, 0.08]} />
          {/* Multi-story windows with sills */}
          {[1.35, 2.45, 3.55, 4.65]
            .filter((wy) => wy < h - 0.45)
            .map((wy) =>
              [-0.92, 0, 0.92].map((wx, j) => (
                <group key={`${wy}-${j}`} position={[wx, wy, 1.42]}>
                  <InkMesh geometry={GEO.box} color={win} position={[0, 0, 0]} scale={[0.48, 0.62, 0.06]} glow={glow} />
                  <InkMesh geometry={GEO.box} color="#E8E2D5" position={[0, -0.34, 0.04]} scale={[0.56, 0.08, 0.1]} inkWidth={0.015} />
                </group>
              )),
            )}
          {k === 'factory' && (
            <group>
              <InkMesh geometry={GEO.cyl} color="#7D3C2C" position={[w * 0.28, h + 1.15, -0.4]} scale={[0.58, 2.3, 0.58]} />
              <InkMesh geometry={GEO.cyl} color="#3B3538" position={[w * 0.28, h + 2.3, -0.4]} scale={[0.68, 0.18, 0.68]} />
              <InkMesh geometry={GEO.cyl} color="#7D3C2C" position={[w * 0.05, h + 0.95, -0.4]} scale={[0.46, 1.9, 0.46]} />
            </group>
          )}
          {signTex && (
            <mesh position={[0, 1.65, 1.46]}>
              <planeGeometry args={[w * 0.75, 0.75]} />
              <meshBasicMaterial map={signTex} toneMapped={false} />
            </mesh>
          )}
        </group>
      );
    }

    case 'tank': {
      // High-detail Industrial Steel Tank with 4 steel bands, 48 3D rivets, ladder,
      // rivet-popping ballistic physics (shakeAmt > 0), and hull-rupture explosion (explodeAmt > 0)!
      const col = c ?? '#5B6673';
      const bandCol = shade(col, -0.22);
      const rivetCol = shade(col, 0.18);
      const ex = clamp(explodeAmt + collapseAmt, 0, 1.5);
      const isOverlayCoat = itemId === 'brownCoat';

      return (
        <group>
          {/* Main cylinder core (splits & shrinks slightly when exploding so flying plates take over) */}
          <InkMesh
            geometry={GEO.cyl}
            color={col}
            position={[0, 0.5 * (1 - ex * 0.22), 0]}
            scale={[1 + shakeAmt * Math.sin(t * 55) * 0.025, 1 - ex * 0.22, 1 + shakeAmt * Math.cos(t * 55) * 0.025]}
            inkWidth={isOverlayCoat ? 0.018 : 0.028}
          />

          {/* 4 Horizontal Steel Reinforcement Bands */}
          {[0.14, 0.38, 0.62, 0.86].map((by, bi) => (
            <InkMesh
              key={`band-${bi}`}
              geometry={GEO.cyl}
              color={bandCol}
              position={[
                ex > 0.01 ? (bi % 2 === 0 ? -1 : 1) * ex * 0.28 : 0,
                by * (1 - ex * 0.18),
                ex > 0.01 ? ex * 0.22 : 0,
              ]}
              rotation={[ex * 0.25 * (bi - 1.5), 0, ex * 0.3 * (bi % 2 === 0 ? 1 : -1)]}
              scale={[1.03, 0.032, 1.03]}
              inkWidth={0.012}
            />
          ))}

          {/* 48 Visible 3D Rivets along the front & sides of the tank */}
          {[0.14, 0.38, 0.62, 0.86].map((ry, ri) =>
            [-1.05, -0.75, -0.45, -0.15, 0.15, 0.45, 0.75, 1.05].map((ang, ai) => {
              const idx = ri * 8 + ai;
              // During shake or explosion, selected rivets pop outward off the hull!
              const popPhase = shakeAmt > 0.05 ? Math.max(0, Math.sin(t * 14 + idx * 1.9)) * shakeAmt : 0;
              const blastOut = ex > 0.01 ? ex * (0.45 + (idx % 5) * 0.22) : popPhase > 0.65 ? (popPhase - 0.65) * 1.4 : 0;
              const dropY = blastOut > 0.05 ? blastOut * blastOut * 0.35 : 0;
              const rRad = 0.518 + blastOut;
              const rx = Math.sin(ang) * rRad;
              const rz = Math.cos(ang) * rRad;
              const isPopping = popPhase > 0.72 || ex > 0.05;

              return (
                <InkMesh
                  key={`riv-${idx}`}
                  geometry={GEO.ball}
                  color={isPopping ? '#FFE14D' : rivetCol}
                  position={[rx, Math.max(0.03, ry - dropY), rz]}
                  scale={[0.032, 0.032, 0.032]}
                  inkWidth={0.015}
                  glow={isPopping}
                />
              );
            }),
          )}

          {/* Side Maintenance Ladder & Pressure Gauge (on base tank) */}
          {!isOverlayCoat && (
            <group position={[-0.48, 0.5, 0.22]} rotation={[0, -0.45, ex * -0.4]}>
              <InkMesh geometry={GEO.box} color="#2F3640" position={[-0.04, 0, 0]} scale={[0.015, 0.92, 0.015]} inkWidth={0.01} />
              <InkMesh geometry={GEO.box} color="#2F3640" position={[0.04, 0, 0]} scale={[0.015, 0.92, 0.015]} inkWidth={0.01} />
              {[-0.36, -0.18, 0, 0.18, 0.36].map((ly, li) => (
                <InkMesh key={li} geometry={GEO.box} color="#2F3640" position={[0, ly, 0]} scale={[0.08, 0.012, 0.015]} inkWidth={0.008} />
              ))}
            </group>
          )}

          {/* Hull Rupture Explosion Shards + Gushing Core when explodeAmt > 0 */}
          {ex > 0.02 && (
            <group position={[0, 0.45, 0.35]}>
              {/* Fiery blast core + dark smoke + gushing molasses column at the breach */}
              <InkMesh
                geometry={GEO.ball}
                color={ex < 0.45 ? '#FFF275' : '#FF6B1A'}
                position={[0, 0.05, 0.15]}
                scale={[0.55 + ex * 0.45, 0.55 + ex * 0.45, 0.45 + ex * 0.35]}
                inkWidth={0.025}
                glow
              />
              {/* 6 Ruptured Steel Hull Plates blasting outward */}
              {[-1, -0.6, -0.2, 0.2, 0.6, 1].map(( dir, si) => (
                <InkMesh
                  key={`shard-${si}`}
                  geometry={GEO.box}
                  color={col}
                  position={[dir * (0.35 + ex * 0.65), (si % 2 === 0 ? 1 : -0.6) * ex * 0.35, 0.2 + ex * 0.45]}
                  rotation={[ex * 1.8 * (si % 2 ? 1 : -1), dir * ex * 1.2, -dir * ex * 1.5]}
                  scale={[0.24, 0.32, 0.04]}
                  inkWidth={0.025}
                />
              ))}
            </group>
          )}
        </group>
      );
    }

    case 'puddle': {
      // Organic 7-lobe glossy liquid pool with concentric surface ripples (no polygon corners!)
      const liqCol = c ?? '#5C2E14';
      const hiCol = c2 ?? shade(liqCol, 0.18);
      const pulse = 1 + Math.sin(t * 3.2) * 0.03;
      const lobes: [number, number, number, number][] = [
        [0, 0, 0.95, 0.88],
        [-0.32, 0.12, 0.58, 0.54],
        [0.34, -0.08, 0.62, 0.56],
        [0.18, 0.28, 0.52, 0.46],
        [-0.22, -0.26, 0.54, 0.48],
        [0.42, 0.18, 0.38, 0.36],
        [-0.44, -0.1, 0.4, 0.36],
      ];
      return (
        <group scale={[pulse, 1, pulse]}>
          {lobes.map(([lx, lz, rx, rz], li) => (
            <InkMesh
              key={li}
              geometry={GEO.ball}
              color={li === 0 ? liqCol : li % 2 === 0 ? shade(liqCol, -0.06) : hiCol}
              position={[lx, 0.35, lz]}
              scale={[rx, 0.7, rz]}
              inkWidth={0.02}
              roughness={0.16}
            />
          ))}
          {/* Glossy liquid specular highlight */}
          <InkMesh
            geometry={GEO.ball}
            color={shade(liqCol, 0.32)}
            position={[-0.14, 0.62, 0.12]}
            scale={[0.28, 0.25, 0.18]}
            inkWidth={0}
            roughness={0.1}
          />
        </group>
      );
    }

    case 'wave': {
      // Multi-layered curling 3D Tsunami Wave with foam rollers & flying liquid droplets!
      const waveCol = c ?? '#633215';
      const foamCol = c2 ?? shade(waveCol, 0.35);
      return (
        <group>
          {/* Main surging wave body */}
          <InkMesh geometry={GEO.dome} color={waveCol} position={[0, 0, 0]} scale={[7.2, 3.2, 4.8]} inkWidth={0.018} roughness={0.2} />
          {/* Secondary rolling wave lobes */}
          <InkMesh geometry={GEO.ball} color={shade(waveCol, 0.08)} position={[-1.8, 1.1, 0.8]} scale={[3.4, 2.2, 2.6]} inkWidth={0.018} roughness={0.2} />
          <InkMesh geometry={GEO.ball} color={shade(waveCol, -0.08)} position={[1.8, 1.0, 0.7]} scale={[3.4, 2.1, 2.6]} inkWidth={0.018} roughness={0.2} />
          {/* Churning foam crest rollers along the top & base */}
          {[-2.1, -1.05, 0, 1.05, 2.1].map((fx, fi) => (
            <InkMesh
              key={`foam-${fi}`}
              geometry={GEO.ball}
              color={foamCol}
              position={[fx, 2.15 + Math.sin(t * 8 + fi) * 0.15, 1.25 + Math.cos(t * 7 + fi) * 0.15]}
              scale={[1.25, 0.75, 0.95]}
              inkWidth={0.022}
              roughness={0.25}
            />
          ))}
          {/* Airborne liquid droplets splashing ahead of the wave */}
          {[-1.8, -1.1, -0.4, 0.4, 1.1, 1.8].map((dx, di) => (
            <InkMesh
              key={`wdrop-${di}`}
              geometry={GEO.ball}
              color={di % 2 === 0 ? waveCol : foamCol}
              position={[
                dx + Math.sin(t * 9 + di) * 0.2,
                1.4 + Math.abs(Math.sin(t * 10 + di * 1.7)) * 1.3,
                1.85 + Math.cos(t * 8 + di) * 0.35,
              ]}
              scale={[0.38, 0.48, 0.38]}
              inkWidth={0.03}
              roughness={0.15}
            />
          ))}
        </group>
      );
    }

    case 'tower':
    case 'castle':
    case 'lighthouse': {
      const stone = c ?? '#C5BFAEE';
      const roof = c2 ?? '#3B5BA5';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={c ?? '#C9C2B2'} position={[0, 2.1, 0]} scale={[2.1, 4.2, 2.1]} />
          <InkMesh geometry={GEO.cone} color={roof} position={[0, 4.9, 0]} scale={[2.4, 1.6, 2.4]} />
          <InkMesh geometry={GEO.box} color="#5B3A25" position={[0, 0.65, 1.02]} scale={[0.65, 1.3, 0.15]} />
        </group>
      );
    }

    case 'wall':
    case 'fence': {
      const col = c ?? (k === 'wall' ? '#B2ABA0' : '#9C6B43');
      if (k === 'wall') {
        return <InkMesh geometry={GEO.box} color={col} position={[0, 0.9, 0]} scale={[len, 1.8, 0.45]} />;
      }
      const posts = Math.max(2, Math.round(len / 1.2));
      return (
        <group>
          {Array.from({ length: posts }).map((_, i) => {
            const x = -len / 2 + (len * i) / (posts - 1);
            return <InkMesh key={i} geometry={GEO.box} color={col} position={[x, 0.5, 0]} scale={[0.14, 1.0, 0.14]} />;
          })}
          <InkMesh geometry={GEO.box} color={col} position={[0, 0.72, 0]} scale={[len, 0.1, 0.08]} />
          <InkMesh geometry={GEO.box} color={col} position={[0, 0.36, 0]} scale={[len, 0.1, 0.08]} />
        </group>
      );
    }

    case 'lamp':
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={c ?? '#2B303A'} position={[0, 1.25, 0]} scale={[0.12, 2.5, 0.12]} />
          <InkMesh geometry={GEO.ball} color={c2 ?? '#FFE27A'} position={[0, 2.6, 0]} scale={[0.42, 0.42, 0.42]} glow />
        </group>
      );

    case 'bench':
      return (
        <group>
          <InkMesh geometry={GEO.box} color={c ?? '#9C6B43'} position={[0, 0.42, 0]} scale={[1.5, 0.1, 0.55]} />
          <InkMesh geometry={GEO.box} color={c ?? '#9C6B43'} position={[0, 0.75, -0.22]} scale={[1.5, 0.45, 0.1]} />
          <InkMesh geometry={GEO.box} color="#2B303A" position={[-0.6, 0.22, 0]} scale={[0.12, 0.44, 0.5]} />
          <InkMesh geometry={GEO.box} color="#2B303A" position={[0.6, 0.22, 0]} scale={[0.12, 0.44, 0.5]} />
        </group>
      );

    case 'barrel':
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={c ?? '#9C6334'} position={[0, 0.48, 0]} scale={[0.68, 0.96, 0.68]} />
          <InkMesh geometry={GEO.cyl} color="#3B4048" position={[0, 0.72, 0]} scale={[0.71, 0.08, 0.71]} />
          <InkMesh geometry={GEO.cyl} color="#3B4048" position={[0, 0.24, 0]} scale={[0.71, 0.08, 0.71]} />
        </group>
      );

    case 'crate':
      return <InkMesh geometry={GEO.box} color={c ?? '#B58046'} position={[0, 0.45, 0]} scale={[0.9, 0.9, 0.9]} />;

    case 'sign':
    case 'board':
    case 'banner': {
      const w = k === 'board' ? 2.4 : 1.5;
      const h = k === 'board' ? 1.35 : 0.9;
      // If item was placed with at[1] > 0.4, keep board comfortably in frame and extend posts all the way down to world y = 0!
      const boardY = worldY > 0.4 ? 0.45 : 1.35;
      const groundLocalY = -worldY / Math.max(0.1, scaleY);
      const postBottomY = Math.min(0, groundLocalY);
      const postTopY = boardY;
      const postLen = Math.max(0.6, postTopY - postBottomY);
      const postCenterY = postBottomY + postLen / 2;
      return (
        <group>
          {/* Ground-anchored wooden support posts + stone plinth bases on y = 0 */}
          <InkMesh geometry={GEO.cyl} color="#7A4E2D" position={[-w * 0.36, postCenterY, -0.02]} scale={[0.12, postLen, 0.12]} />
          <InkMesh geometry={GEO.cyl} color="#7A4E2D" position={[w * 0.36, postCenterY, -0.02]} scale={[0.12, postLen, 0.12]} />
          <InkMesh geometry={GEO.box} color="#5B3A25" position={[-w * 0.36, postBottomY + 0.06, -0.02]} scale={[0.24, 0.12, 0.24]} />
          <InkMesh geometry={GEO.box} color="#5B3A25" position={[w * 0.36, postBottomY + 0.06, -0.02]} scale={[0.24, 0.12, 0.24]} />
          {/* Framed board + sign face */}
          <InkMesh geometry={GEO.box} color="#5B3A25" position={[0, boardY, -0.02]} scale={[w + 0.1, h + 0.1, 0.1]} />
          <InkMesh geometry={GEO.box} color={c ?? '#FAF3E0'} position={[0, boardY, 0.02]} scale={[w, h, 0.1]} />
          {signTex && (
            <mesh position={[0, boardY, 0.085]}>
              <planeGeometry args={[w * 0.94, h * 0.9]} />
              <meshBasicMaterial map={signTex} toneMapped={false} />
            </mesh>
          )}
        </group>
      );
    }

    case 'bottle': {
      // Shaped 3D Ketchup / Sauce Bottle with body, label band, rounded shoulder, narrow neck & squeeze nozzle
      const col = c ?? '#D92632';
      const labelCol = c2 ?? '#FAF3E0';
      const isUniform = Math.abs(scaleY - 1) < 0.15;
      const bScale: [number, number, number] = isUniform ? [0.32, 0.62, 0.32] : [1.35, 1.05, 1.35];
      const isPouring = Math.abs(rotZ) > 0.12 || shakeAmt > 0.05;
      return (
        <group scale={bScale}>
          {/* Main bottle cylinder body */}
          <InkMesh geometry={GEO.cyl} color={col} position={[0, 0.34, 0]} scale={[0.95, 0.68, 0.95]} roughness={0.2} />
          {/* Cream wrap-around label + red tomato badge */}
          <InkMesh geometry={GEO.cyl} color={labelCol} position={[0, 0.35, 0]} scale={[0.99, 0.28, 0.99]} inkWidth={0.015} />
          <InkMesh geometry={GEO.ball} color={col} position={[0, 0.35, 0.49]} scale={[0.34, 0.16, 0.08]} inkWidth={0.015} />
          {/* Rounded shoulder */}
          <InkMesh geometry={GEO.dome} color={col} position={[0, 0.66, 0]} scale={[0.95, 0.24, 0.95]} roughness={0.2} />
          {/* Narrow bottle neck */}
          <InkMesh geometry={GEO.cyl} color={col} position={[0, 0.86, 0]} scale={[0.42, 0.28, 0.42]} roughness={0.2} />
          {/* White cap ring + nozzle */}
          <InkMesh geometry={GEO.cyl} color={labelCol} position={[0, 1.0, 0]} scale={[0.48, 0.08, 0.48]} inkWidth={0.015} />
          <InkMesh geometry={GEO.cone} color={labelCol} position={[0, 1.1, 0]} scale={[0.34, 0.16, 0.34]} inkWidth={0.015} />
          {/* Pouring ketchup stream + droplets when bottle tilts/shakes */}
          {isPouring && (
            <group position={[0, 1.18, 0]}>
              <InkMesh geometry={GEO.cyl} color={col} position={[0.12, -0.35, 0]} rotation={[0, 0, -0.35]} scale={[0.18, 0.75, 0.18]} roughness={0.15} />
              {[0, 1, 2].map((di) => (
                <InkMesh
                  key={di}
                  geometry={GEO.ball}
                  color={col}
                  position={[0.22 + di * 0.12, -0.55 - ((t * 2.5 + di * 0.33) % 0.6), 0]}
                  scale={[0.22, 0.26, 0.22]}
                  roughness={0.15}
                />
              ))}
            </group>
          )}
        </group>
      );
    }

    case 'jar': {
      // Wide-mouth 3D Syrup / Molasses Jar with vintage label, rim & glossy dark syrup fill
      const col = c ?? '#5C2E14';
      const labelCol = c2 ?? '#FAF3E0';
      const isUniform = Math.abs(scaleY - 1) < 0.15;
      const jScale: [number, number, number] = isUniform ? [0.38, 0.56, 0.38] : [1.25, 1.02, 1.25];
      return (
        <group scale={jScale}>
          <InkMesh geometry={GEO.cyl} color={col} position={[0, 0.42, 0]} scale={[1.0, 0.84, 1.0]} roughness={0.2} />
          <InkMesh geometry={GEO.cyl} color={labelCol} position={[0, 0.42, 0]} scale={[1.04, 0.34, 1.04]} inkWidth={0.015} />
          <InkMesh geometry={GEO.cyl} color="#D9822B" position={[0, 0.42, 0]} scale={[1.06, 0.1, 1.06]} inkWidth={0} />
          <InkMesh geometry={GEO.cyl} color={shade(col, 0.12)} position={[0, 0.88, 0]} scale={[0.82, 0.12, 0.82]} />
          <InkMesh geometry={GEO.cyl} color="#D4A24C" position={[0, 0.96, 0]} scale={[0.88, 0.08, 0.88]} />
          <InkMesh geometry={GEO.ball} color={shade(col, -0.15)} position={[0, 0.99, 0]} scale={[0.76, 0.12, 0.76]} roughness={0.12} />
        </group>
      );
    }

    case 'glue': {
      // Sticky Molasses / Glue Trap on the ground with stretched diagonal taffy strands holding characters/props!
      const glueCol = c ?? '#5C2E14';
      const strandCol = c2 ?? shade(glueCol, 0.16);
      const stretch = 1 + Math.sin(t * 5.5) * 0.08;
      const strands: [number, number, number, number, number][] = [
        [-0.32, 0.08, 0.38, 0.28, -0.22],
        [-0.16, 0.14, 0.46, -0.18, 0.15],
        [0, 0.12, 0.48, 0.12, 0.24],
        [0.18, 0.1, 0.44, -0.25, -0.18],
        [0.34, 0.06, 0.36, -0.32, 0.2],
        [-0.24, -0.08, 0.4, 0.22, 0.28],
        [0.24, -0.08, 0.42, -0.2, -0.25],
      ];
      return (
        <group>
          {/* Base sticky molasses pool lobes */}
          <InkMesh geometry={GEO.ball} color={glueCol} position={[0, 0.05, 0]} scale={[1.05, 0.14, 0.78]} inkWidth={0.02} roughness={0.14} />
          <InkMesh geometry={GEO.ball} color={shade(glueCol, -0.08)} position={[-0.36, 0.04, 0.12]} scale={[0.65, 0.12, 0.55]} inkWidth={0.018} roughness={0.14} />
          <InkMesh geometry={GEO.ball} color={shade(glueCol, 0.08)} position={[0.38, 0.04, -0.08]} scale={[0.68, 0.12, 0.56]} inkWidth={0.018} roughness={0.14} />
          {/* Stretched sticky taffy strands pulling on feet/legs */}
          {strands.map(([sx, sz, sh, rx, rz], si) => (
            <group key={si} position={[sx, 0, sz]}>
              <InkMesh
                geometry={GEO.cyl}
                color={strandCol}
                position={[0, (sh * stretch) / 2, 0]}
                rotation={[rx, 0, rz]}
                scale={[0.048, sh * stretch, 0.048]}
                inkWidth={0.015}
                roughness={0.15}
              />
              <InkMesh
                geometry={GEO.ball}
                color={glueCol}
                position={[- Math.sin(rz) * sh * 0.45, sh * stretch * 0.88, Math.sin(rx) * sh * 0.45]}
                scale={[0.09, 0.11, 0.09]}
                inkWidth={0.015}
                roughness={0.12}
              />
            </group>
          ))}
        </group>
      );
    }

    case 'flag': {
      const col = c ?? '#E03A4E';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color="#D8DDE6" position={[0, 1.6, 0]} scale={[0.1, 3.2, 0.1]} />
          <InkMesh
            geometry={GEO.box}
            color={col}
            position={[0.6, 2.75, Math.sin(t * 4) * 0.06]}
            rotation={[0, Math.sin(t * 4) * 0.12, 0]}
            scale={[1.15, 0.68, 0.06]}
          />
        </group>
      );
    }

    case 'tent':
    case 'stall':
      return (
        <group>
          <InkMesh geometry={GEO.cone} color={c ?? '#E84A4A'} position={[0, 1.1, 0]} rotation={[0, Math.PI / 4, 0]} scale={[2.2, 2.2, 2.2]} />
        </group>
      );

    case 'ship':
    case 'boat': {
      const hull = c ?? '#7A4828';
      const sail = c2 ?? '#FAF4E8';
      const s = k === 'ship' ? 1.8 : 0.9;
      return (
        <group scale={[s, s, s]}>
          <InkMesh geometry={GEO.box} color={hull} position={[0, 0.45, 0]} scale={[3.2, 0.9, 1.35]} />
          {k === 'ship' && (
            <>
              <InkMesh geometry={GEO.cyl} color="#5B3A25" position={[0, 1.9, 0]} scale={[0.14, 2.8, 0.14]} />
              <InkMesh geometry={GEO.box} color={sail} position={[0, 2.1, 0.1]} scale={[1.8, 1.5, 0.08]} />
            </>
          )}
        </group>
      );
    }

    case 'cannon':
      return (
        <group>
          <InkMesh geometry={GEO.box} color={c2 ?? '#8A5A36'} position={[0, 0.28, 0]} scale={[0.85, 0.42, 0.55]} />
          <InkMesh geometry={GEO.cyl} color={c ?? '#2E343D'} position={[0.2, 0.58, 0]} rotation={[0, 0, -Math.PI * 0.42]} scale={[0.38, 1.35, 0.38]} />
        </group>
      );

    case 'car':
    case 'train':
    case 'cart': {
      const body = c ?? '#E04242';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={body} position={[0, 0.55, 0]} scale={[2.2, 0.65, 1.1]} />
          {k !== 'cart' && <InkMesh geometry={GEO.box} color={c2 ?? '#8FD3FF'} position={[0, 1.05, 0]} scale={[1.25, 0.5, 0.98]} />}
          {[-0.65, 0.65].map((wx) =>
            [-0.55, 0.55].map((wz, j) => (
              <InkMesh key={`${wx}-${j}`} geometry={GEO.cyl} color="#1E2229" position={[wx, 0.25, wz]} rotation={[Math.PI / 2, 0, 0]} scale={[0.5, 0.14, 0.5]} />
            )),
          )}
        </group>
      );
    }

    case 'rails':
      return (
        <group>
          <InkMesh geometry={GEO.box} color={c ?? '#707882'} position={[0, 0.06, 0.45]} scale={[len, 0.08, 0.08]} />
          <InkMesh geometry={GEO.box} color={c ?? '#707882'} position={[0, 0.06, -0.45]} scale={[len, 0.08, 0.08]} />
        </group>
      );

    case 'room': {
      const wall = c ?? '#8FD19E';
      const floor = c2 ?? '#8DA1B5';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={wall} position={[0, 2.5, -4.5]} scale={[12, 5, 0.25]} inkWidth={0.01} />
          <InkMesh geometry={GEO.box} color={shade(wall, -0.08)} position={[-6, 2.5, 0]} scale={[0.25, 5, 9]} inkWidth={0.01} />
          <InkMesh geometry={GEO.box} color={shade(wall, -0.08)} position={[6, 2.5, 0]} scale={[0.25, 5, 9]} inkWidth={0.01} />
          <InkMesh geometry={GEO.box} color={floor} position={[0, -0.04, 0]} scale={[12, 0.08, 9]} inkWidth={0.005} />
        </group>
      );
    }

    case 'desk':
    case 'table':
    case 'counter': {
      const topCol = c ?? '#C89B6E';
      const legCol = c2 ?? '#49525E';
      const w = k === 'counter' ? 2.8 : 1.55;
      const h = 0.62;
      const d = 0.78;
      return (
        <group>
          <InkMesh geometry={GEO.box} color={topCol} position={[0, h, 0]} scale={[w, 0.09, d]} />
          {k === 'counter' ? (
            <InkMesh geometry={GEO.box} color={legCol} position={[0, h / 2, 0]} scale={[w * 0.95, h, d * 0.9]} />
          ) : (
            <>
              {/* Front modesty panel so stick legs behind the desk don't dangle awkwardly */}
              <InkMesh geometry={GEO.box} color={shade(topCol, -0.18)} position={[0, h * 0.62, 0.08]} scale={[w * 0.84, h * 0.58, 0.06]} />
              {[-w * 0.42, w * 0.42].map((lx) =>
                [-d * 0.38, d * 0.38].map((lz, j) => (
                  <InkMesh key={`${lx}-${j}`} geometry={GEO.box} color={legCol} position={[lx, h / 2, lz]} scale={[0.09, h, 0.09]} />
                )),
              )}
            </>
          )}
        </group>
      );
    }

    case 'chair':
    case 'throne': {
      const col = c ?? (k === 'throne' ? '#C9283E' : '#3E5C76');
      const backH = k === 'throne' ? 1.4 : 0.65;
      return (
        <group>
          <InkMesh geometry={GEO.box} color={col} position={[0, 0.45, 0]} scale={[0.62, 0.1, 0.62]} />
          <InkMesh geometry={GEO.box} color={col} position={[0, 0.45 + backH / 2, -0.26]} scale={[0.62, backH, 0.1]} />
          <InkMesh geometry={GEO.cyl} color="#2B303A" position={[0, 0.22, 0]} scale={[0.14, 0.44, 0.14]} />
        </group>
      );
    }

    case 'shelf':
    case 'locker':
      return <InkMesh geometry={GEO.box} color={c ?? '#8C6239'} position={[0, 1.1, 0]} scale={[1.2, 2.2, 0.45]} />;

    case 'computer':
      return (
        <group>
          <InkMesh geometry={GEO.box} color={c ?? '#2B303A'} position={[0, 0.32, 0]} scale={[0.62, 0.44, 0.08]} />
          <InkMesh geometry={GEO.box} color="#7FD8FF" position={[0, 0.32, 0.05]} scale={[0.54, 0.36, 0.02]} glow />
          <InkMesh geometry={GEO.box} color="#2B303A" position={[0, 0.05, 0]} scale={[0.25, 0.1, 0.2]} />
        </group>
      );

    case 'door':
      return <InkMesh geometry={GEO.box} color={c ?? '#7A4E2D'} position={[0, 1.05, 0]} scale={[1.05, 2.1, 0.12]} />;

    case 'window':
      return <InkMesh geometry={GEO.box} color={c ?? '#8FD3FF'} position={[0, 0, 0]} scale={[1.1, 1.2, 0.1]} glow={glow} />;

    case 'clock':
      return <InkMesh geometry={GEO.cyl} color={c ?? '#FAF3E0'} position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[0.55, 0.08, 0.55]} />;

    case 'frame':
      return <InkMesh geometry={GEO.box} color={c ?? '#D4A24C'} position={[0, 0, 0]} scale={[0.85, 0.65, 0.08]} />;

    case 'plant':
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={c2 ?? '#C86D44'} position={[0, 0.22, 0]} scale={[0.38, 0.44, 0.38]} />
          <InkMesh geometry={GEO.ball} color={c ?? '#44B24E'} position={[0, 0.58, 0]} scale={[0.55, 0.55, 0.55]} />
        </group>
      );

    case 'statue':
    case 'column':
    case 'arch': {
      const col = c ?? '#6E7A8A';
      if (k === 'arch') {
        const beamCol = shade(col, -0.18);
        return (
          <group>
            {/* Riveted steel columns + top girder + cross-bracing */}
            <InkMesh geometry={GEO.box} color={col} position={[-1.1, 1.3, 0]} scale={[0.48, 2.6, 0.48]} />
            <InkMesh geometry={GEO.box} color={col} position={[1.1, 1.3, 0]} scale={[0.48, 2.6, 0.48]} />
            <InkMesh geometry={GEO.box} color={col} position={[0, 2.72, 0]} scale={[3.1, 0.48, 0.68]} />
            <InkMesh geometry={GEO.box} color={beamCol} position={[0, 2.98, 0]} scale={[3.25, 0.12, 0.78]} />
            {/* Steel truss diagonal struts */}
            <InkMesh geometry={GEO.box} color={beamCol} position={[-0.75, 2.25, 0]} rotation={[0, 0, 0.72]} scale={[0.14, 0.85, 0.32]} />
            <InkMesh geometry={GEO.box} color={beamCol} position={[0.75, 2.25, 0]} rotation={[0, 0, -0.72]} scale={[0.14, 0.85, 0.32]} />
          </group>
        );
      }
      return <InkMesh geometry={GEO.cyl} color={col} position={[0, 1.3, 0]} scale={[0.55, 2.6, 0.55]} />;
    }

    case 'campfire':
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color="#6E4427" position={[0, 0.1, 0]} rotation={[0, 0.4, Math.PI / 2]} scale={[0.16, 0.7, 0.16]} />
          <InkMesh geometry={GEO.cone} color="#FF7A2E" position={[0, 0.38, 0]} scale={[0.45, 0.65, 0.45]} glow />
        </group>
      );

    case 'well': {
      const stone = c ?? '#9BA3AE';
      const roof = c2 ?? '#8A4F2E';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={stone} position={[0, 0.35, 0]} scale={[1.1, 0.7, 1.1]} />
          <InkMesh geometry={GEO.cyl} color="#2FA4EC" position={[0, 0.62, 0]} scale={[0.88, 0.08, 0.88]} inkWidth={0} />
          <InkMesh geometry={GEO.box} color="#6E4427" position={[-0.48, 0.95, 0]} scale={[0.1, 1.2, 0.1]} />
          <InkMesh geometry={GEO.box} color="#6E4427" position={[0.48, 0.95, 0]} scale={[0.1, 1.2, 0.1]} />
          <InkMesh geometry={GEO.pyr} color={roof} position={[0, 1.72, 0]} rotation={[0, Math.PI / 4, 0]} scale={[1.35, 0.65, 1.35]} />
          <InkMesh geometry={GEO.cyl} color="#7A4E2D" position={[0, 1.05, 0]} scale={[0.24, 0.28, 0.24]} />
        </group>
      );
    }

    case 'haystack': {
      const hay = c ?? '#E8B84B';
      return (
        <group>
          <InkMesh geometry={GEO.dome} color={hay} position={[0, 0, 0]} scale={[1.35, 1.05, 1.25]} />
          <InkMesh geometry={GEO.ball} color={shade(hay, 0.08)} position={[0.35, 0.35, 0.25]} scale={[0.75, 0.6, 0.75]} />
          <InkMesh geometry={GEO.ball} color={shade(hay, -0.08)} position={[-0.38, 0.3, -0.15]} scale={[0.7, 0.55, 0.7]} />
        </group>
      );
    }

    case 'windmill': {
      const wall = c ?? '#EDE0C8';
      const roof = c2 ?? '#B24636';
      const spinAngle = t * 1.4;
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={wall} position={[0, 1.65, 0]} scale={[1.65, 3.3, 1.65]} />
          <InkMesh geometry={GEO.dome} color={roof} position={[0, 3.25, 0]} scale={[1.75, 0.95, 1.75]} />
          <InkMesh geometry={GEO.box} color="#5B3A25" position={[0, 0.58, 0.82]} scale={[0.58, 1.15, 0.1]} />
          <group position={[0, 2.75, 0.92]} rotation={[0, 0, spinAngle]}>
            <InkMesh geometry={GEO.ball} color="#3B2818" position={[0, 0, 0]} scale={[0.28, 0.28, 0.28]} />
            {[0, 1, 2, 3].map((bi) => (
              <group key={bi} rotation={[0, 0, (bi * Math.PI) / 2]}>
                <InkMesh geometry={GEO.box} color="#6E4427" position={[0, 0.95, 0]} scale={[0.1, 1.9, 0.06]} />
                <InkMesh geometry={GEO.box} color="#FAF3E0" position={[0.18, 1.05, 0.02]} scale={[0.28, 1.45, 0.03]} />
              </group>
            ))}
          </group>
        </group>
      );
    }

    case 'pier': {
      const wood = c ?? '#8C5E38';
      const post = c2 ?? '#5B3A22';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={wood} position={[0, 0.48, 0]} scale={[len * 0.65, 0.16, 1.8]} />
          {[-1.4, 0, 1.4].map((px, pi) =>
            [-0.75, 0.75].map((pz, pj) => (
              <InkMesh key={`${pi}-${pj}`} geometry={GEO.cyl} color={post} position={[px, 0.32, pz]} scale={[0.18, 0.95, 0.18]} />
            )),
          )}
        </group>
      );
    }

    case 'chimney': {
      const brick = c ?? '#9E4736';
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color={brick} position={[0, 1.4, 0]} scale={[0.68, 2.8, 0.68]} />
          <InkMesh geometry={GEO.cyl} color="#3B3538" position={[0, 2.82, 0]} scale={[0.78, 0.22, 0.78]} />
        </group>
      );
    }

    case 'bed': {
      const sheet = c ?? '#E84A5F';
      const wood = c2 ?? '#7A4E2D';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={wood} position={[0, 0.28, 0]} scale={[1.8, 0.26, 1.15]} />
          <InkMesh geometry={GEO.box} color={wood} position={[-0.86, 0.62, 0]} scale={[0.12, 0.92, 1.18]} />
          <InkMesh geometry={GEO.box} color="#FAF6EE" position={[0.04, 0.46, 0]} scale={[1.68, 0.22, 1.06]} />
          <InkMesh geometry={GEO.box} color={sheet} position={[0.26, 0.5, 0]} scale={[1.18, 0.24, 1.08]} />
          <InkMesh geometry={GEO.box} color="#FFFFFF" position={[-0.58, 0.62, 0]} scale={[0.36, 0.14, 0.78]} />
        </group>
      );
    }

    case 'rug': {
      const col = c ?? '#C93B4B';
      const trim = c2 ?? '#F2C94C';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={trim} position={[0, 0.015, 0]} scale={[2.6, 0.03, 1.7]} inkWidth={0.01} />
          <InkMesh geometry={GEO.box} color={col} position={[0, 0.025, 0]} scale={[2.35, 0.03, 1.45]} inkWidth={0.008} />
        </group>
      );
    }

    case 'fireplace': {
      const brick = c ?? '#9E4736';
      const mantel = c2 ?? '#6E4427';
      return (
        <group>
          <InkMesh geometry={GEO.box} color={brick} position={[0, 0.85, 0]} scale={[1.85, 1.7, 0.65]} />
          <InkMesh geometry={GEO.box} color={mantel} position={[0, 1.72, 0.06]} scale={[2.05, 0.16, 0.78]} />
          <InkMesh geometry={GEO.box} color="#231F20" position={[0, 0.52, 0.22]} scale={[1.05, 0.92, 0.3]} />
          <InkMesh geometry={GEO.cone} color="#FF7A2E" position={[0, 0.36, 0.28]} scale={[0.45, 0.55, 0.35]} glow />
        </group>
      );
    }

    case 'chandelier': {
      const gold = c ?? '#E8B33A';
      return (
        <group position={[0, 2.2, 0]}>
          <InkMesh geometry={GEO.cyl} color="#3B4048" position={[0, 0.55, 0]} scale={[0.06, 1.1, 0.06]} />
          <InkMesh geometry={GEO.cyl} color={gold} position={[0, 0, 0]} scale={[1.1, 0.12, 1.1]} />
          {[-0.48, 0.48].map((cx, ci) =>
            [-0.48, 0.48].map((cz, cj) => (
              <group key={`${ci}-${cj}`} position={[cx, 0.16, cz]}>
                <InkMesh geometry={GEO.cyl} color="#FAF3E0" position={[0, 0, 0]} scale={[0.08, 0.24, 0.08]} />
                <InkMesh geometry={GEO.ball} color="#FFE27A" position={[0, 0.18, 0]} scale={[0.12, 0.16, 0.12]} glow />
              </group>
            )),
          )}
        </group>
      );
    }

    case 'animal':
    case 'horse': {
      // Universal 3D Cartoon Quadruped (horse, dog, cow, sheep, rabbit) with bobbing gait!
      const coat = c ?? (k === 'horse' ? '#8C5230' : '#D99B66');
      const mane = c2 ?? shade(coat, -0.28);
      const bob = Math.abs(Math.sin(t * 7)) * 0.06;
      const legSwing = Math.sin(t * 7) * 0.22;
      return (
        <group position={[0, bob, 0]}>
          {/* Body + neck + head + snout + ears + tail */}
          <InkMesh geometry={GEO.ball} color={coat} position={[0, 0.58, 0]} scale={[0.92, 0.52, 0.48]} />
          <InkMesh geometry={GEO.cyl} color={coat} position={[0.36, 0.82, 0]} rotation={[0, 0, -0.35]} scale={[0.24, 0.46, 0.24]} />
          <InkMesh geometry={GEO.ball} color={coat} position={[0.52, 1.02, 0]} scale={[0.38, 0.28, 0.28]} />
          <InkMesh geometry={GEO.ball} color="#231F20" position={[0.58, 1.06, 0.11]} scale={[0.06, 0.06, 0.06]} inkWidth={0} />
          <InkMesh geometry={GEO.ball} color="#231F20" position={[0.58, 1.06, -0.11]} scale={[0.06, 0.06, 0.06]} inkWidth={0} />
          <InkMesh geometry={GEO.cone} color={mane} position={[0.44, 1.22, 0.1]} scale={[0.1, 0.2, 0.1]} />
          <InkMesh geometry={GEO.cone} color={mane} position={[0.44, 1.22, -0.1]} scale={[0.1, 0.2, 0.1]} />
          <InkMesh geometry={GEO.cyl} color={mane} position={[-0.48, 0.58, 0]} rotation={[0, 0, 0.55]} scale={[0.12, 0.38, 0.12]} />
          {/* 4 Animated Legs */}
          {[-0.28, 0.28].map((lx, li) =>
            [-0.14, 0.14].map((lz, lj) => (
              <InkMesh
                key={`${li}-${lj}`}
                geometry={GEO.cyl}
                color={mane}
                position={[lx, 0.24, lz]}
                rotation={[0, 0, (li === lj ? 1 : -1) * legSwing]}
                scale={[0.11, 0.48, 0.11]}
              />
            )),
          )}
        </group>
      );
    }

    case 'bird': {
      // Universal 3D Cartoon Bird / Emu / Pigeon / Duck with bobbing head & beak!
      const feathers = c ?? '#5C4B3B';
      const beakCol = c2 ?? '#F2A93B';
      const bob = Math.abs(Math.sin(t * 8)) * 0.05;
      const step = Math.sin(t * 8) * 0.25;
      return (
        <group position={[0, bob, 0]}>
          <InkMesh geometry={GEO.ball} color={feathers} position={[0, 0.48, 0]} scale={[0.62, 0.46, 0.44]} />
          <InkMesh geometry={GEO.cyl} color={feathers} position={[0.22, 0.78, 0]} rotation={[0, 0, -0.2]} scale={[0.14, 0.45, 0.14]} />
          <InkMesh geometry={GEO.ball} color={feathers} position={[0.28, 1.02, 0]} scale={[0.24, 0.22, 0.22]} />
          <InkMesh geometry={GEO.cone} color={beakCol} position={[0.44, 1.0, 0]} rotation={[0, 0, -Math.PI / 2]} scale={[0.1, 0.22, 0.1]} />
          <InkMesh geometry={GEO.ball} color="#231F20" position={[0.33, 1.05, 0.09]} scale={[0.05, 0.05, 0.05]} inkWidth={0} />
          <InkMesh geometry={GEO.cyl} color={beakCol} position={[-0.04, 0.2, 0.1]} rotation={[0, 0, step]} scale={[0.06, 0.4, 0.06]} />
          <InkMesh geometry={GEO.cyl} color={beakCol} position={[0.04, 0.2, -0.1]} rotation={[0, 0, -step]} scale={[0.06, 0.4, 0.06]} />
        </group>
      );
    }

    case 'balloon': {
      // 3D Hot-Air / Helium Balloon with floating bob & basket
      const col = c ?? '#E84A5F';
      const stripe = c2 ?? '#FFD23F';
      const floatY = Math.sin(t * 2.6) * 0.12;
      return (
        <group position={[0, floatY, 0]}>
          <InkMesh geometry={GEO.ball} color={col} position={[0, 1.55, 0]} scale={[1.15, 1.35, 1.15]} />
          <InkMesh geometry={GEO.cyl} color={stripe} position={[0, 1.55, 0]} scale={[1.18, 0.28, 1.18]} />
          <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[-0.18, 0.72, 0]} scale={[0.03, 0.55, 0.03]} />
          <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[0.18, 0.72, 0]} scale={[0.03, 0.55, 0.03]} />
          <InkMesh geometry={GEO.box} color="#8C5E38" position={[0, 0.35, 0]} scale={[0.48, 0.38, 0.48]} />
        </group>
      );
    }

    case 'scale':
    case 'seesaw': {
      // 3D Physics Balance Scale / Seesaw with tilting beam & fulcrum
      const beamCol = c ?? '#D94B38';
      const baseCol = c2 ?? '#3B424C';
      const tilt = Math.sin(t * 3.2) * 0.24 + rotZ;
      return (
        <group>
          <InkMesh geometry={GEO.cone} color={baseCol} position={[0, 0.28, 0]} scale={[0.55, 0.56, 0.55]} />
          <group position={[0, 0.56, 0]} rotation={[0, 0, tilt]}>
            <InkMesh geometry={GEO.box} color={beamCol} position={[0, 0, 0]} scale={[2.2, 0.1, 0.38]} />
            <InkMesh geometry={GEO.cyl} color="#FAF3E0" position={[-0.92, 0.08, 0]} scale={[0.38, 0.06, 0.38]} />
            <InkMesh geometry={GEO.cyl} color="#FAF3E0" position={[0.92, 0.08, 0]} scale={[0.38, 0.06, 0.38]} />
          </group>
        </group>
      );
    }

    case 'pendulum': {
      // 3D Swinging Physics Pendulum Frame & Bob
      const frameCol = c ?? '#3B424C';
      const bobCol = c2 ?? '#E8B33A';
      const swing = Math.sin(t * 4.2) * 0.48;
      return (
        <group>
          <InkMesh geometry={GEO.box} color={frameCol} position={[0, 0.06, 0]} scale={[1.2, 0.12, 0.65]} />
          <InkMesh geometry={GEO.cyl} color={frameCol} position={[-0.48, 0.85, 0]} scale={[0.08, 1.6, 0.08]} />
          <InkMesh geometry={GEO.cyl} color={frameCol} position={[0.48, 0.85, 0]} scale={[0.08, 1.6, 0.08]} />
          <InkMesh geometry={GEO.box} color={frameCol} position={[0, 1.65, 0]} scale={[1.1, 0.1, 0.14]} />
          <group position={[0, 1.62, 0]} rotation={[0, 0, swing]}>
            <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[0, -0.55, 0]} scale={[0.035, 1.1, 0.035]} />
            <InkMesh geometry={GEO.ball} color={bobCol} position={[0, -1.12, 0]} scale={[0.34, 0.34, 0.34]} />
          </group>
        </group>
      );
    }

    case 'spring': {
      // 3D Coiled Physics Spring that compresses & bounces
      const col = c ?? '#4A90E2';
      const comp = 1 + Math.sin(t * 6) * 0.22;
      return (
        <group scale={[1, comp, 1]}>
          {[0.12, 0.28, 0.44, 0.6, 0.76].map((sy, si) => (
            <InkMesh key={si} geometry={GEO.cyl} color={col} position={[0, sy, 0]} rotation={[0.18 * (si % 2 ? 1 : -1), 0, 0.18]} scale={[0.58, 0.08, 0.58]} />
          ))}
        </group>
      );
    }

    case 'gauge':
    case 'thermometer': {
      // 3D Pressure / Temperature Dial with red danger zone & animated needle
      const bodyCol = c ?? '#FAF3E0';
      const rimCol = c2 ?? '#D92B3A';
      const needleAng = -0.8 + Math.abs(Math.sin(t * 3.5)) * 1.65;
      return (
        <group>
          <InkMesh geometry={GEO.cyl} color="#3B424C" position={[0, 0.45, 0]} scale={[0.14, 0.9, 0.14]} />
          <InkMesh geometry={GEO.cyl} color={rimCol} position={[0, 1.05, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[0.88, 0.14, 0.88]} />
          <InkMesh geometry={GEO.cyl} color={bodyCol} position={[0, 1.05, 0.04]} rotation={[Math.PI / 2, 0, 0]} scale={[0.74, 0.12, 0.74]} />
          <group position={[0, 1.05, 0.12]} rotation={[0, 0, -needleAng]}>
            <InkMesh geometry={GEO.box} color="#D92B3A" position={[0, 0.16, 0]} scale={[0.06, 0.32, 0.04]} />
            <InkMesh geometry={GEO.ball} color="#231F20" position={[0, 0, 0]} scale={[0.1, 0.1, 0.1]} />
          </group>
        </group>
      );
    }

    case 'bomb': {
      // 3D Cartoon Bomb with fuse & glowing spark
      const col = c ?? '#2B303A';
      const pulse = 1 + Math.sin(t * 14) * 0.05;
      return (
        <group scale={[pulse, pulse, pulse]}>
          <InkMesh geometry={GEO.ball} color={col} position={[0, 0.38, 0]} scale={[0.72, 0.72, 0.72]} />
          <InkMesh geometry={GEO.cyl} color="#5B6472" position={[0, 0.74, 0]} scale={[0.24, 0.14, 0.24]} />
          <InkMesh geometry={GEO.cyl} color="#D8CFC0" position={[0.08, 0.88, 0]} rotation={[0, 0, -0.45]} scale={[0.05, 0.26, 0.05]} />
          <InkMesh geometry={GEO.ball} color="#FFE14D" position={[0.16, 1.0, 0]} scale={[0.16, 0.16, 0.16]} glow />
        </group>
      );
    }

    case 'cyl':
      return <InkMesh geometry={GEO.cyl} color={c ?? '#8FA3B8'} position={[0, 0.5, 0]} scale={[1, 1, 1]} glow={glow} />;
    case 'ball':
      return <InkMesh geometry={GEO.ball} color={c ?? '#E85D56'} position={[0, 0.5, 0]} scale={[1, 1, 1]} glow={glow} />;
    case 'cone':
      return <InkMesh geometry={GEO.cone} color={c ?? '#52B848'} position={[0, 0.5, 0]} scale={[1, 1, 1]} glow={glow} />;
    case 'plane':
      return <InkMesh geometry={GEO.plane} color={c ?? '#D8D2C5'} rotation={[-Math.PI / 2, 0, 0]} inkWidth={0} />;
    case 'text':
      return signTex ? (
        <mesh position={[0, 0.6, 0]}>
          <planeGeometry args={[2.0, 1.0]} />
          <meshBasicMaterial map={signTex} toneMapped={false} />
        </mesh>
      ) : null;
    case 'box':
    default:
      return <InkMesh geometry={GEO.box} color={c ?? '#8FA3B8'} position={[0, 0.5, 0]} scale={[1, 1, 1]} glow={glow} />;
  }
}

const BackdropRing: React.FC<{ kind: WorldSet['backdrop']; items: Item3D[] }> = ({ kind, items }) => {
  if (!kind || kind === 'none') return null;

  // Check if an item is already near (x, z) so auto-diorama props never collide with hero props
  const isClear = (x: number, z: number, minDist = 2.8) => {
    for (const it of items) {
      const ix = it.at[0];
      const iz = it.at.length === 2 ? it.at[1] : it.at[2];
      if (Math.hypot(ix - x, iz - z) < minDist) return false;
    }
    return true;
  };

  // 1. Mid-distance Storybook Diorama Streetscape (z = -5.8 .. -10.5, x = -7.5 .. +7.5)
  // Visible inside 9:16 portrait & 16:9 landscape so the background is never empty!
  const midSlots: { x: number; z: number; rot: number; k: Item3D['k']; c: string; c2: string; s?: number }[] =
    kind === 'city'
      ? [
          { x: -3.2, z: -6.8, rot: 10, k: 'house', c: '#F2E3C9', c2: '#C94436', s: 0.95 },
          { x: 3.1, z: -6.6, rot: -12, k: 'shop', c: '#E8D5B7', c2: '#2E5B9E', s: 0.92 },
          { x: -5.8, z: -7.8, rot: 16, k: 'building', c: '#A84A38', c2: '#96D9FF', s: 0.88 },
          { x: 5.6, z: -7.5, rot: -15, k: 'building', c: '#5B7088', c2: '#FFE08A', s: 0.9 },
          { x: -1.4, z: -8.8, rot: 4, k: 'building', c: '#785E4D', c2: '#96D9FF', s: 0.85 },
          { x: 1.6, z: -9.0, rot: -6, k: 'house', c: '#E6D6BE', c2: '#3B6E52', s: 0.95 },
          { x: -2.2, z: -4.8, rot: 0, k: 'tree', c: '#48B84E', c2: '#8A5A36', s: 0.85 },
          { x: 2.3, z: -4.6, rot: 0, k: 'tree', c: '#52C258', c2: '#8A5A36', s: 0.82 },
          { x: -4.2, z: -4.2, rot: 0, k: 'lamp', c: '#2B303A', c2: '#FFE27A', s: 0.9 },
          { x: 4.2, z: -4.2, rot: 0, k: 'lamp', c: '#2B303A', c2: '#FFE27A', s: 0.9 },
        ]
      : [
          { x: -3.0, z: -6.2, rot: 12, k: 'tree', c: '#48B84E', c2: '#8A5A36', s: 1.05 },
          { x: 2.9, z: -6.0, rot: -10, k: 'tree', c: '#3EA844', c2: '#7A4E2D', s: 1.1 },
          { x: -1.5, z: -7.8, rot: 5, k: 'pine', c: '#2E8B52', c2: '#7A4E2D', s: 1.15 },
          { x: 1.6, z: -8.2, rot: -8, k: 'house', c: '#F5E9D3', c2: '#D64B3A', s: 0.9 },
          { x: -4.8, z: -7.5, rot: 14, k: 'house', c: '#EEDCC2', c2: '#3B6E8C', s: 0.88 },
          { x: 4.8, z: -7.4, rot: -14, k: 'pine', c: '#2E8B52', c2: '#7A4E2D', s: 1.1 },
          { x: -2.1, z: -4.5, rot: 0, k: 'bush', c: '#52B848', c2: '#3FA34D', s: 0.95 },
          { x: 2.2, z: -4.4, rot: 0, k: 'bush', c: '#52B848', c2: '#3FA34D', s: 0.95 },
        ];

  const count = 18;
  const radius = 22;

  return (
    <group>
      {/* Mid-distance Storybook Town & Foliage Layer */}
      {midSlots
        .filter((sl) => isClear(sl.x, sl.z, 2.5))
        .map((sl, idx) => (
          <group key={`mid-${idx}`} position={[sl.x, 0, sl.z]} rotation={[0, deg(sl.rot), 0]} scale={sl.s ?? 1}>
            {renderKind(sl.k, sl.c, sl.c2, 6, false, 0, 0, 0, 0, null)}
          </group>
        ))}

      {/* Rolling Painted Horizon Hills & Distant Skyline */}
      {Array.from({ length: count }).map((_, i) => {
        const a = (i / count) * Math.PI * 2;
        const x = Math.cos(a) * radius;
        const z = Math.sin(a) * radius;
        const s = 1 + ((i * 37) % 10) * 0.08;
        if (kind === 'mountains' || kind === 'desert') {
          const col = kind === 'desert' ? '#D97B43' : '#6A7F9B';
          return (
            <group key={i} position={[x, -0.4, z]} rotation={[0, -a, 0]} scale={[s * 1.2, s, s * 1.2]}>
              <InkMesh geometry={GEO.cone} color={col} position={[0, 3.8, 0]} scale={[7.5, 7.5, 7.5]} inkWidth={0.01} />
              {kind === 'mountains' && (
                <InkMesh geometry={GEO.cone} color="#F4F8FC" position={[0, 6.2, 0]} scale={[2.8, 2.8, 2.8]} inkWidth={0.01} />
              )}
            </group>
          );
        }
        return (
          <InkMesh
            key={i}
            geometry={GEO.dome}
            color={kind === 'city' ? (i % 2 === 0 ? '#68B858' : '#52A244') : kind === 'forest' ? '#3B8E44' : '#58B248'}
            position={[x, -0.35, z]}
            scale={[9.5 * s, 3.2 * s, 7.5 * s]}
            inkWidth={0.008}
          />
        );
      })}
    </group>
  );
};

export const WorldView: React.FC<{
  set: WorldSet;
  extraProps?: Item3D[];
  t: number;
}> = ({ set, extraProps, t }) => {
  const pal = SKY_PALETTES[set.sky];
  const groundHex = set.groundColor ?? GROUND_COLORS[set.ground];
  const skyTex = useMemo(() => makeSkyDomeTexture(set.sky), [set.sky]);
  const groundTex = useMemo(() => makeGroundTexture(set.ground, groundHex), [set.ground, groundHex]);
  const fogAmt = set.fog ?? 0.35;
  const fogNear = lerp(28, 12, fogAmt);
  const fogFar = lerp(95, 44, fogAmt);

  const allSceneItems = useMemo(() => [...set.items, ...(extraProps ?? [])], [set.items, extraProps]);

  return (
    <group>
      <color attach="background" args={[pal.bot]} />
      {fogAmt > 0.01 && <fog attach="fog" args={[pal.fog, fogNear, fogFar]} />}

      {/* Warm storybook lighting */}
      <ambientLight intensity={pal.amb} color="#FFFFFF" />
      <hemisphereLight args={[pal.mid, groundHex, 0.45]} />
      <directionalLight position={[14, 24, 16]} intensity={pal.dir} color={pal.sun} />
      <directionalLight position={[-12, 10, -10]} intensity={pal.dir * 0.28} color={pal.mid} />

      {/* Saturated painted sky dome */}
      <mesh scale={[90, 90, 90]}>
        <sphereGeometry args={[1, 24, 18]} />
        <meshBasicMaterial map={skyTex} side={THREE.BackSide} depthWrite={false} fog={false} toneMapped={false} />
      </mesh>

      {/* Painted ground plane */}
      {set.ground !== 'none' && (
        <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[120, 120]} />
          <meshStandardMaterial map={groundTex} roughness={0.92} metalness={0.02} />
        </mesh>
      )}

      {/* Auto-Diorama Town & Horizon Ring */}
      <BackdropRing kind={set.backdrop} items={set.items} />

      {/* Set items + shot-specific props */}
      {set.items.map((it, idx) => (
        <WorldItemView key={it.id ?? `i-${idx}`} item={it} allItems={allSceneItems} t={t} />
      ))}
      {(extraProps ?? []).map((it, idx) => (
        <WorldItemView key={it.id ?? `p-${idx}`} item={it} allItems={allSceneItems} t={t} />
      ))}
    </group>
  );
};
