# Dynamics: how action moves and sounds

Numbers at 30 fps. Fighting-game data (60 fps) is halved; animation data (24 fps) is multiplied by 1.25. These are
starting points synthesised from animation and game-feel sources; genres differ.

## Timing and spacing

Timing is how many frames an action takes; spacing is how far it moves on each frame. Wide gaps read fast and
violent, tight gaps read slow and heavy. A strike only looks fast next to something slow.

| Phase | Frames | Spacing |
|---|---|---|
| Anticipation | 4-10 (up to 18 for a big power-up) | slow in and out, ending in a 1-4 frame hold |
| Strike | 2-5 (weapons up to 6) | accelerates all the way into contact (ease-in) |
| Contact | 1, then hit-stop | — |
| Follow-through and settle | at least 1.5× the strike | fast, then decelerating with a slight overshoot |

- Never slow down into a hit. The limb is fastest on the contact frame.
- Never stop dead after contact. Travel 1-2 more frames, then decelerate.
- Separation: the body winds up and nearly stops, then the limb fires. The centre of mass stays smooth while the
  limb is sharp.
- A body hit by force changes pose with 0-1 in-betweens. More in-betweens read as a dodge.
- Readable vs responsive: the hero's attacks get short anticipation; anything the viewer must read gets more.

## Weight and physics

- One gravity for everything that falls (spacing grows 1, 3, 5, 7… per frame). Something like 2 px/frame² at
  1080 px wide reads as snappy cartoon gravity.
- Jumps and knock-backs are exact parabolas: horizontal speed stays constant in the air.
- Overlap: heads, hats, hair, tails and props trail the body by 1-3 frames and keep moving after it stops. Fade
  overlap out around a strike so the whip lands on time, then let it drag on the follow-through.
- Speed limits keep it physical: bodies ≤ ~60 px/frame, limbs ≤ ~200 px/frame; anything faster gets a smear.
- Spin isn't constant: tucked bodies spin fast, extended ones slow.
- Solve contacts: shift the striker so the fist or projectile lands exactly on its target on the contact frame.

## Impact

- **Hit-stop**: freeze on contact, longer for harder hits (light 4, medium 5-6, heavy 7 frames).
- **Shudder** during the freeze: the victim shakes hard with decay; the attacker trembles slightly.
- **Impact frames**: for big moments, 2-3 frames of inverted or flat colour on contact, then the freeze.
- **Stack the feedback**: flash, shock ring, sparks on gravity arcs (stretched along velocity), camera shake
  decaying over ~5 frames, knock-back, debris and marks that stay.
- **Smears**: a swing too fast to read gets a streak along its real path.
- **Camera**: lead moving subjects, punch in 5-12% on the hit, ease back over ~15 frames.

## Sound (if the piece has sound)

- Generate or place sound from the same timeline as the picture so it can't drift. Impacts start exactly on the
  contact frame (viewers notice audio more than ~45 ms early; one frame is 33 ms).
- A whoosh builds and peaks on the fastest frame of a swing, then cuts.
- Three layers per hit: a sub sine dropping in pitch (about 140→40 Hz over 200 ms) for weight, a mid body
  (filtered noise or material partials) for material, a high click for sharpness.
- Vary pitch about ±8% on repeats; harder hits are louder and lower.
- About 7 frames of near-silence before the biggest hit makes it land harder.
- Normalise the mix to about −14 LUFS, true peak −1 dB.
