#!/usr/bin/env node
// ============================================================================
// AUTOMATED SHOT PLAN & ANIMATION LIVENESS CHECKER (scripts/check-plan.mjs)
// Enforces hard quality rules so even a free-tier AI model cannot produce a
// broken, passive, or out-of-sync video.
// ============================================================================
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

// Run via tsx so we can import the TypeScript project files directly
const runner = `
import fs from 'node:fs';
import path from 'node:path';
import { CONFIG } from '../src/project/config.ts';
import { CAST } from '../src/project/cast.ts';
import { SETS } from '../src/project/world.ts';
import { SHOTS } from '../src/project/shots.ts';
import { WORDS, timeOf, lastWordEnd } from '../src/engine/timing.ts';

const errors: string[] = [];
const warnings: string[] = [];

const totalDur = lastWordEnd() + (CONFIG.tail ?? 1.2);
if (totalDur > 180) {
  errors.push(\`Total duration is \${totalDur.toFixed(1)}s, which exceeds the 180s (3 min) maximum.\`);
}
if (WORDS.length < 20) {
  errors.push(\`words.json only has \${WORDS.length} words. Run npm run timings.\`);
}

const requiredBeats = ['hook', 'setting', 'action', 'snap', 'deadpan', 'explanation', 'consequence', 'twist'];
const presentBeats = new Set(SHOTS.map((s) => s.beat));
for (const b of requiredBeats) {
  if (!presentBeats.has(b as any)) {
    errors.push(\`Missing required story beat in SHOTS: "\${b}". All 8 story beats must be covered.\`);
  }
}

// ----------------------------------------------------------------------------
// A. WORLD SET & 3D ASSET INTEGRITY CHECKS (No Empty Sets / No Defective Assets)
// ----------------------------------------------------------------------------
const PROPORTIONAL_PREFABS = new Set([
  'house', 'shop', 'church', 'building', 'factory', 'tree', 'pine', 'palm', 'car', 'train', 'cart',
  'ship', 'boat', 'animal', 'horse', 'bird', 'windmill', 'well', 'bottle', 'jar', 'board', 'sign',
]);

for (const [setName, setDef] of Object.entries(SETS)) {
  if (!setDef.items || setDef.items.length < 5) {
    errors.push(
      \`Sparse/empty world set "\${setName}": only \${setDef.items?.length ?? 0} item(s). Every set must have at least 5 3D items (hero props + street/room props + background buildings/trees) so the environment never looks empty.\`,
    );
  }
  if (setDef.sky !== 'indoor' && (!setDef.backdrop || setDef.backdrop === 'none')) {
    errors.push(
      \`Outdoor world set "\${setName}" (sky="\${setDef.sky}") has backdrop="none". Set backdrop to "city", "hills", "mountains", "forest", "sea", or "desert" so the horizon is richly populated.\`,
    );
  }
  for (const it of setDef.items ?? []) {
    if (['box', 'cyl', 'ball', 'plane'].includes(it.k) && !it.id) {
      errors.push(
        \`Raw untextured primitive k="\${it.k}" in set "\${setName}" at [\${it.at.join(', ')}]. Use a detailed 3D prefab kind instead (e.g. "tank", "puddle", "wave", "bottle", "jar", "glue", "house", "shop", "factory", "building", "car", "barrel", "crate", "desk", "board", "animal", "bird", "scale", "pendulum", "gauge", "bomb").\`,
      );
    }
    if (PROPORTIONAL_PREFABS.has(it.k) && Array.isArray(it.s)) {
      const maxS = Math.max(...it.s);
      const minS = Math.max(0.01, Math.min(...it.s));
      if (maxS / minS > 1.85) {
        errors.push(
          \`Distorted 3D asset in set "\${setName}": item "\${it.id ?? it.k}" (k="\${it.k}") has squashed/stretched scale [\${it.s.join(', ')}]. Use a uniform number scale (e.g. s: \${maxS.toFixed(2)}) so the 3D model is not deformed.\`,
        );
      }
    }
  }
}

let prevStart = -1;
SHOTS.forEach((shot, i) => {
  const s0 = i === 0 ? 0 : timeOf(shot.from);
  const s1 = i + 1 < SHOTS.length ? timeOf(SHOTS[i + 1].from) : totalDur;
  const dur = s1 - s0;

  if (s0 <= prevStart && i > 0) {
    errors.push(\`Shot "\${shot.id}" starts at \${s0.toFixed(2)}s (\${shot.from}), which is not after previous shot (\${prevStart.toFixed(2)}s).\`);
  }
  prevStart = s0;

  if (dur < 1.2) {
    errors.push(\`Shot "\${shot.id}" is too short (\${dur.toFixed(2)}s). Minimum shot length is 1.2s.\`);
  }
  if (dur > 8.0) {
    errors.push(\`Shot "\${shot.id}" is too long (\${dur.toFixed(2)}s). Split shots longer than 7.5s so pacing stays snappy.\`);
  }

  if (!SETS[shot.set]) {
    errors.push(\`Shot "\${shot.id}" uses unknown set "\${shot.set}".\`);
  }

  if (shot.cam.move === 'hold') {
    warnings.push(\`Shot "\${shot.id}" uses cam.move="hold". Prefer active camera glides (push, pull, orbit, truck, crane, low, close, follow).\`);
  }
  if (
    i >= 2 &&
    shot.cam.move === SHOTS[i - 1].cam.move &&
    shot.cam.move === SHOTS[i - 2].cam.move
  ) {
    errors.push(
      \`Monotonous camera in shot "\${shot.id}": 3 consecutive shots use cam.move="\${shot.cam.move}". Vary camera movement across consecutive shots.\`,
    );
  }
  if (
    CONFIG.format === 'portrait' &&
    ['push', 'pull', 'truck', 'pan', 'close', 'low'].includes(shot.cam.move) &&
    (shot.cam.amount ?? 0) > 1.0
  ) {
    warnings.push(\`Shot "\${shot.id}" has cam.move="\${shot.cam.move}" with amount=\${shot.cam.amount} in 9:16 portrait. Keep amount <= 0.55 so secondary characters are not pushed off-screen.\`);
  }

  if (shot.cast.length === 0) {
    errors.push(\`Shot "\${shot.id}" has no characters in cast[].\`);
  }
  if (!shot.sfx || shot.sfx.length === 0) {
    errors.push(\`Shot "\${shot.id}" has no sfx[]. Every shot must have at least 1 synthesized sound effect.\`);
  }

  const PROP_REQUIRED_ACTS = new Set(['hammer', 'sweep', 'dig', 'drink', 'eat', 'read', 'write', 'phone', 'carry']);
  const STATIONARY_ACTS = new Set(['idle', 'talk', 'sit', 'lie', 'think', 'read', 'drink', 'eat']);
  const LOCOMOTION_ACTS = new Set(['walk', 'run', 'march', 'sneak', 'tiptoe']);

  for (const sc of shot.cast) {
    if (!CAST[sc.who]) {
      errors.push(\`Shot "\${shot.id}" references unknown character "\${sc.who}" not in CAST.\`);
    }
    if (CONFIG.format === 'portrait' && Math.abs(sc.pos[0]) > 0.95) {
      warnings.push(\`Shot "\${shot.id}" places "\${sc.who}" at x=\${sc.pos[0]} in 9:16 portrait (risk of edge clipping; prefer x within [-0.85, 0.85]).\`);
    }
    if (!sc.beats || sc.beats.length < 2) {
      errors.push(\`Passive character detected: "\${sc.who}" in shot "\${shot.id}" has only \${sc.beats?.length ?? 0} beat(s). Every character must have at least 2 beats per shot so they actively react and move.\`);
    } else {
      // Universal Fake-Liveness Guard: ensure beats actually change state (do, face, to, or hold)
      const b0 = sc.beats[0];
      const hasStateChange = sc.beats.slice(1).some(
        (b) =>
          (b.do && b.do !== b0.do) ||
          (b.face && b.face !== b0.face) ||
          b.to !== undefined ||
          (b.hold && b.hold !== b0.hold),
      );
      if (!hasStateChange) {
        errors.push(
          \`Fake liveness in shot "\${shot.id}": character "\${sc.who}" has \${sc.beats.length} beats, but "do", "face", "to", and "hold" never change. Change action/expression/position on each beat.\`,
        );
      }
    }
    let lastBeatT = -1;
    let curX = sc.pos[0];
    let curZ = sc.pos.length === 2 ? sc.pos[1] : sc.pos[2];
    let curAct = 'idle';
    let curHold = 'none';

    for (const b of sc.beats) {
      const bt = timeOf(b.at);
      if (b.do) curAct = b.do;
      if (b.hold) curHold = b.hold;

      if (bt < s0 - 0.5 || bt > s1 + 0.5) {
        errors.push(\`Shot "\${shot.id}" character "\${sc.who}" has a beat at \${b.at} (\${bt.toFixed(2)}s) outside shot window [\${s0.toFixed(2)}s, \${s1.toFixed(2)}s].\`);
      }
      if (bt < lastBeatT) {
        errors.push(\`Shot "\${shot.id}" character "\${sc.who}" has out-of-order beats.\`);
      }
      if (CONFIG.format === 'portrait' && b.to && Math.abs(b.to[0]) > 0.95) {
        warnings.push(\`Shot "\${shot.id}" moves "\${sc.who}" to x=\${b.to[0]} in 9:16 portrait (prefer x within [-0.85, 0.85]).\`);
      }

      // Check empty-hand miming on tool/prop actions
      if (PROP_REQUIRED_ACTS.has(curAct) && (!curHold || curHold === 'none')) {
        errors.push(
          \`Empty-hand mime in shot "\${shot.id}": character "\${sc.who}" performs do="\${curAct}" at \${b.at} with hold="none". Give them a matching prop in hold (e.g. "hammer", "broom", "pickaxe", "cup", "mug", "scroll", "book", "phone", "bucket").\`,
        );
      }

      // Check treadmill walking vs ice-skating sliding
      if (b.to) {
        const tx = b.to[0];
        const tz = b.to.length === 2 ? b.to[1] : b.to[2];
        const moveDist = Math.hypot(tx - curX, tz - curZ);
        if (STATIONARY_ACTS.has(curAct) && moveDist > 0.55) {
          errors.push(
            \`Cheap sliding animation in shot "\${shot.id}": character "\${sc.who}" slides \${moveDist.toFixed(2)}m at \${b.at} while doing stationary action "\${curAct}". Use "walk", "run", "march", "tiptoe", "jump", "recoil", "panic", "push", or "pull" when moving!\`,
          );
        }
        curX = tx;
        curZ = tz;
      } else if (LOCOMOTION_ACTS.has(b.do ?? '')) {
        errors.push(
          \`Treadmill walk in shot "\${shot.id}": character "\${sc.who}" has do="\${b.do}" at \${b.at} without a "to: [x, z]" target position, causing them to walk in place!\`,
        );
      }

      lastBeatT = bt;
    }
  }

  // Universal Character-to-Character Overlap Guard:
  for (let a = 0; a < shot.cast.length; a++) {
    for (let b = a + 1; b < shot.cast.length; b++) {
      const ca = shot.cast[a];
      const cb = shot.cast[b];
      const az = ca.pos.length === 2 ? ca.pos[1] : ca.pos[2];
      const bz = cb.pos.length === 2 ? cb.pos[1] : cb.pos[2];
      const dist = Math.hypot(ca.pos[0] - cb.pos[0], az - bz);
      if (dist < 0.35) {
        errors.push(
          \`Character overlap in shot "\${shot.id}": "\${ca.who}" and "\${cb.who}" start only \${dist.toFixed(2)}m apart. Space characters at least 0.5m apart in X.\`,
        );
      }
    }
  }

  for (const sfx of shot.sfx ?? []) {
    const file = sfx.name.startsWith('user:')
      ? path.join('public/sfx-user', sfx.name.slice(5))
      : path.join('public/audio', \`sfx-\${sfx.name}.wav\`);
    if (!fs.existsSync(file)) {
      errors.push(\`Shot "\${shot.id}" references missing SFX file "\${file}". Run npm run audio.\`);
    }
  }

  // Visual Physics & Environment Interaction Guards (for smaller/free models):
  const setObj = SETS[shot.set];
  const allProps = [...(setObj?.items ?? []), ...(shot.props ?? [])];
  const noteLower = (shot.note ?? '').toLowerCase();

  // 1. Desk / Table clipping guard + Tall Prop Camera Sightline Occlusion guard
  const tallOpaqueKinds = new Set(['house', 'shop', 'church', 'building', 'factory', 'tower', 'castle', 'tank', 'windmill']);
  for (const item of allProps) {
    const ix = item.at[0];
    const iz = item.at.length === 2 ? item.at[1] : item.at[2];
    if (item.k === 'desk' || item.k === 'table' || item.k === 'counter') {
      for (const sc of shot.cast) {
        const cx = sc.pos[0];
        const cz = sc.pos.length === 2 ? sc.pos[1] : sc.pos[2];
        if (Math.abs(cx - ix) < 0.75 && Math.abs(cz - iz) < 0.38) {
          errors.push(
            \`Desk clipping in shot "\${shot.id}": character "\${sc.who}" (z=\${cz}) slices through \${item.k} (z=\${iz}). Move character behind (\` +
              \`z <= \${(iz - 0.42).toFixed(2)}) or in front (\` +
              \`z >= \${(iz + 0.52).toFixed(2)}).\`,
          );
        }
      }
    } else if (tallOpaqueKinds.has(item.k)) {
      for (const sc of shot.cast) {
        const cx = sc.pos[0];
        const cz = sc.pos.length === 2 ? sc.pos[1] : sc.pos[2];
        if (iz > cz + 0.1 && Math.abs(ix - cx) < 1.1) {
          errors.push(
            \`Camera occlusion in shot "\${shot.id}": tall prop "\${item.id ?? item.k}" (z=\${iz}) is in front of character "\${sc.who}" (z=\${cz}), blocking the camera! Keep large buildings/tanks/structures behind characters (z <= -2.0).\`,
          );
        }
      }
    }
  }

  // 2. "Glued / Stuck / Trapped" visual prop guard
  if (/\\b(glue|glued|trapped in glue|stuck in)\\b/.test(noteLower)) {
    const hasGlue = allProps.some((p) => p.k === 'glue' || (p.id ?? '').toLowerCase().includes('glue'));
    if (!hasGlue) {
      errors.push(
        \`Missing visual glue prop in shot "\${shot.id}": note mentions glue/trapped, so add props: [{ k: 'glue', at: [x, 0, z], s: 1.15, c: '#5C2E14' }] at the characters' feet.\`,
      );
    }
  }

  // 3. "Explosion / Boom / Rupture" visual guard on snap beat
  if (shot.beat === 'snap' && /\\b(explode|exploded|explosion|boom|rips wide open)\\b/.test(noteLower)) {
    const hasExplosionFx = (shot.fx ?? []).some((f) => f.k === 'explosion');
    if (!hasExplosionFx) {
      errors.push(
        \`Missing explosion FX in snap shot "\${shot.id}": add { at: '\${shot.from}', k: 'explosion', pos: '<targetId>', size: 1.3 } to fx[].\`,
      );
    }
  }

  // 4. Active Character-Environment Interaction Guard on action / snap / explanation / consequence beats:
  if (['action', 'snap', 'explanation', 'consequence'].includes(shot.beat)) {
    const hasActiveSetAnim = allProps.some((it) =>
      (it.anim ?? []).some((a) => {
        if (a.do === 'hide' || a.do === 'show') return false;
        const a0 = timeOf(a.at);
        const a1 = a.to !== undefined ? timeOf(a.to) : a0 + 0.8;
        return a1 >= s0 && a0 <= s1;
      }),
    );
    const hasShotProps = (shot.props?.length ?? 0) > 0;
    const hasShotFx = (shot.fx?.length ?? 0) > 0;
    if (!hasActiveSetAnim && !hasShotProps && !hasShotFx) {
      errors.push(
        \`Disconnected environment in \${shot.beat} shot "\${shot.id}": characters act while the 3D world is completely static. Add an item.anim (shake, wobble, tilt, flow, explode, collapse), shot props (puddle, glue, wave), or 3D fx (splash, pour, sparks, steam, debris, bubbles)!\`,
      );
    }
  }
});

if (warnings.length) {
  console.warn('[check] Warnings:\\n  - ' + warnings.join('\\n  - '));
}
if (errors.length) {
  console.error('[check] FAILED with ' + errors.length + ' error(s):\\n  - ' + errors.join('\\n  - '));
  process.exit(1);
}
console.log(\`[check] PASSED: \${SHOTS.length} shots, \${WORDS.length} timed words, \${totalDur.toFixed(2)}s total duration, all 8 story beats & character liveness verified.\`);
`;

const tmpFile = path.join(process.cwd(), 'scripts/.tmp-check.ts');
fs.writeFileSync(tmpFile, runner, 'utf8');
try {
  execSync(`npx tsx "${tmpFile}"`, { stdio: 'inherit' });
} finally {
  if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
}
