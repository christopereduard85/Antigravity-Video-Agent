# Kids Song Video Replicator — install & use

Skill package that reproduces the "Halloween Night" kids music video pipeline (Remotion + procedural SVG characters) from start to finish.

## Contents

```
SKILL.md                      main instructions (agent reads this first)
references/01..09_*.md        detailed phase guides, lessons learned, feedback history
scripts/                      setup_project.ps1, analyze_reference.ps1, whisper_onsets.ps1,
                              render_qa_stills.ps1, render_full_gpu.cmd
templates/project/video/      complete working Remotion project (src, package.json, tsconfig, remotion.config.ts)
templates/project/analysis/   timing scripts (audio_beats.py, build_timing.py, …) + sample beats/lyrics JSON
templates/project/docs/       filled PRODUCTION_PLAN / CHARACTER_DESIGN_SYSTEM / NEXT_STEPS / AGENTS / PROMPT_TEMPLATE
templates/project/PROJECTlyric.txt   sample lyrics format
examples/                     approved model sheets + QA sheets (visual target)
```

## Install

| Agent | Where to unzip |
|---|---|
| Antigravity / Gemini | `<workspace>/.agents/skills/kids-song-video-replicator/` (or global `~/.gemini/config/skills/`) |
| Claude Code | `<workspace>/.claude/skills/kids-song-video-replicator/` (or `~/.claude/skills/`) |
| Codex / Cursor / other | put the folder anywhere in the repo and tell the agent: "Read `kids-song-video-replicator/SKILL.md` and follow it." |

## First prompt to give a new chat

> Use the skill `kids-song-video-replicator`. Inputs: `ReferenceVideo.mp4`, `<song>.wav`, `<lyrics>.txt` in the workspace. Follow SKILL.md phases P0→P11 in order, stop for my approval at cast design and before the final render. Reply short, in Indonesian.

## Reproduce the original Halloween video exactly

Template already contains the final data (`video/src/data/*.json`) and code. With `Halloween Night.wav`:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup_project.ps1 -Song "Halloween Night.wav"
cmd /c scripts\render_full_gpu.cmd (Get-Location).Path HalloweenNight
```
