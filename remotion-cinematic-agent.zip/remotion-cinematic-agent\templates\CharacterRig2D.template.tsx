import React, { useId } from 'react';
import { THEME } from '../../constants/theme';
import { Viseme, VisemeType } from './visemes';
import { WalkCycleOutput } from './useWalkCycle';

export type ExpressionType =
  | 'neutral'
  | 'shock'
  | 'suspicious'
  | 'fear'
  | 'creepy_menacing';

export interface CharacterProps {
  x: number;
  y: number;
  scale?: number;
  facing?: 'left' | 'right';
  hoodieColor?: string;
  rimColor?: string;
  walkCycle?: WalkCycleOutput;
  viseme?: VisemeType;
  blink?: number;
  lookAtX?: number; // -1 (kiri layar) s/d +1 (kanan layar)
  lookAtY?: number; // -1 (atas layar) s/d +1 (bawah layar)
  headRotation?: number; // degrees
  expression?: ExpressionType;
  holdingPackage?: boolean;
  holdingPhone?: boolean;
}

export const CharacterRig: React.FC<CharacterProps> = ({
  x,
  y,
  scale = 1,
  facing = 'right',
  hoodieColor = THEME.colors.charHoodie,
  rimColor = THEME.colors.charRimLight,
  walkCycle,
  viseme = 'rest',
  blink = 0,
  lookAtX = 0,
  lookAtY = 0,
  headRotation = 0,
  expression = 'neutral',
  holdingPackage = false,
  holdingPhone = false,
}) => {
  const idPrefix = useId().replace(/:/g, '');
  const flip = facing === 'left' ? -1 : 1;

  // Defaults if no walkCycle provided
  const bounceY = walkCycle ? walkCycle.bounceY : 0;
  const leftThigh = walkCycle ? walkCycle.leftThighAngle : 0;
  const leftCalf = walkCycle ? walkCycle.leftCalfAngle : 0;
  const leftFoot = walkCycle ? walkCycle.leftFootAngle : 0;
  const rightThigh = walkCycle ? walkCycle.rightThighAngle : 0;
  const rightCalf = walkCycle ? walkCycle.rightCalfAngle : 0;
  const rightFoot = walkCycle ? walkCycle.rightFootAngle : 0;

  // Regular swinging arms
  const leftArmAngle = walkCycle ? walkCycle.leftArmAngle : 0;
  const leftForearmAngle = walkCycle ? walkCycle.leftForearmAngle : 0;
  const rightArmAngle = walkCycle ? walkCycle.rightArmAngle : 0;
  const rightForearmAngle = walkCycle ? walkCycle.rightForearmAngle : 0;

  // Orient headTilt and headRotation intuitif di ruang layar (screen space)
  const finalHeadTilt = (walkCycle ? walkCycle.headTilt : 0) + headRotation * flip;

  // Eyebrow and eye configuration based on expression
  let browLeftY = 0;
  let browRightY = 0;
  let browLeftRot = 0;
  let browRightRot = 0;
  let eyeScale = 1;

  if (expression === 'shock') {
    browLeftY = -9;
    browRightY = -9;
    browLeftRot = -14;
    browRightRot = 14;
    eyeScale = 1.25;
  } else if (expression === 'suspicious') {
    browLeftY = 3;
    browRightY = -5;
    browLeftRot = 16;
    browRightRot = -10;
  } else if (expression === 'fear') {
    browLeftY = -7;
    browRightY = -7;
    browLeftRot = 22;
    browRightRot = -22;
    eyeScale = 1.18;
  } else if (expression === 'creepy_menacing') {
    // Alis tajam menukik seram ke arah hidung (V-shape tajam)
    browLeftY = 6;
    browRightY = 6;
    browLeftRot = 26;
    browRightRot = -26;
    eyeScale = 1.05;
  }

  // LookAtX disinkronkan dengan arah layar:
  // lookAtX = -1 (kiri layar), lookAtX = +1 (kanan layar).
  // Karena SVG memiliki scaleX(${flip}), kalikan dengan flip agar arah pupil di layar SELALU benar!
  const localLookAtX = lookAtX * flip;
  const localLookAtY = lookAtY;

  const rawPupilX = localLookAtX * 5.2;
  const rawPupilY = localLookAtY * 3.5;
  const dist = Math.hypot(rawPupilX, rawPupilY);
  const maxDist = 5.2;
  const pupilX = dist > maxDist ? (rawPupilX / dist) * maxDist : rawPupilX;
  const pupilY = dist > maxDist ? (rawPupilY / dist) * maxDist : rawPupilY;

  return (
    <div
      style={{
        position: 'absolute',
        left: `${x}px`,
        top: `${y}px`,
        transform: `scale(${scale})`,
        transformOrigin: 'bottom center',
        zIndex: 20,
        pointerEvents: 'none',
      }}
    >
      <svg
        width="340"
        height="450"
        viewBox="-170 -60 340 450"
        style={{
          overflow: 'visible',
          transform: `scaleX(${flip}) translateY(${bounceY}px)`,
        }}
      >
        <defs>
          <clipPath id={`eye-clip-l-${idPrefix}`}>
            <circle cx="-18" cy="-4" r="13" />
          </clipPath>
          <clipPath id={`eye-clip-r-${idPrefix}`}>
            <circle cx="18" cy="-4" r="13" />
          </clipPath>
          <linearGradient id={`jacketGrad-${idPrefix}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={hoodieColor} />
            <stop offset="70%" stopColor={hoodieColor} />
            <stop offset="100%" stopColor={THEME.colors.charHoodieShadow} />
          </linearGradient>
          <radialGradient id={`screenGlow-${idPrefix}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#60A5FA" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#3B82F6" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#1E3A8A" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* --- 1. BAYANGAN KONTAK LANTAI (TEPAT DI BAWAH KEDUA KAKI) --- */}
        <ellipse
          cx="0"
          cy="388"
          rx="58"
          ry="13"
          fill={THEME.colors.contactShadow}
          style={{
            transform: `scale(${1 - bounceY * 0.02})`,
            transformOrigin: '0px 388px',
            filter: 'blur(5px)',
          }}
        />

        {/* --- 2. KAKI BELAKANG (LEFT LEG) --- */}
        <g id="left-leg" transform="translate(-16, 230)">
          <g transform={`rotate(${leftThigh})`}>
            <rect x="-8" y="0" width="16" height="80" rx="8" fill={THEME.colors.charPants} />
            <g transform="translate(0, 75)">
              <g transform={`rotate(${leftCalf})`}>
                <rect x="-7" y="0" width="14" height="80" rx="7" fill={THEME.colors.charPants} />
                <g transform="translate(0, 75)">
                  <g transform={`rotate(${leftFoot})`}>
                    <ellipse cx="14" cy="4" rx="24" ry="9" fill={THEME.colors.charSkin} />
                  </g>
                </g>
              </g>
            </g>
          </g>
        </g>

        {/* --- 3. LENGAN BELAKANG NORMAL (JIKA TIDAK MEMEGANG PROPS) --- */}
        {!holdingPackage && !holdingPhone && (
          <g id="left-arm" transform="translate(-30, 105)">
            <g transform={`rotate(${leftArmAngle})`}>
              <rect x="-8" y="0" width="16" height="75" rx="8" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1" />
              <g transform="translate(0, 70)">
                <g transform={`rotate(${leftForearmAngle})`}>
                  <rect x="-7" y="0" width="14" height="70" rx="7" fill={THEME.colors.charSkin} />
                  <circle cx="0" cy="70" r="10" fill={THEME.colors.charSkin} />
                </g>
              </g>
            </g>
          </g>
        )}

        {/* --- 4. TUBUH / TORSO --- */}
        <g id="torso" transform="translate(0, 95)">
          <path
            d="M -34 10 Q -36 80 -28 140 Q 0 148 28 140 Q 36 80 34 10 Q 0 -5 -34 10 Z"
            fill={`url(#jacketGrad-${idPrefix})`}
            stroke={rimColor}
            strokeWidth="2"
          />
          <line x1="0" y1="15" x2="0" y2="138" stroke="rgba(0,0,0,0.35)" strokeWidth="3" strokeLinecap="round" />
          <ellipse cx="0" cy="12" rx="20" ry="9" fill={THEME.colors.charSkin} />
        </g>

        {/* --- 5. KAKI DEPAN (RIGHT LEG) --- */}
        <g id="right-leg" transform="translate(16, 230)">
          <g transform={`rotate(${rightThigh})`}>
            <rect x="-8" y="0" width="16" height="80" rx="8" fill={THEME.colors.charPants} />
            <g transform="translate(0, 75)">
              <g transform={`rotate(${rightCalf})`}>
                <rect x="-7" y="0" width="14" height="80" rx="7" fill={THEME.colors.charPants} />
                <g transform="translate(0, 75)">
                  <g transform={`rotate(${rightFoot})`}>
                    <ellipse cx="14" cy="4" rx="24" ry="9" fill={THEME.colors.charSkin} />
                  </g>
                </g>
              </g>
            </g>
          </g>
        </g>

        {/* --- 6. POSE ANATOMIS DUA TANGAN MEMEGANG KARDUS PAKET (HOLDING PACKAGE) --- */}
        {holdingPackage && (
          <g id="package-and-arms">
            {/* 6A. LENGAN KIRI (BELAKANG): Dari Bahu Kiri (-22, 105) menopang bawah/depan kardus */}
            <path
              d="M -22 105 L 8 148 L 68 184"
              stroke={THEME.colors.charSkin}
              strokeWidth="15"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
            {/* Telapak Tangan Kiri di sudut depan-bawah */}
            <circle cx="68" cy="184" r="9" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1.5" />

            {/* 6B. KOTAK KARDUS DI DEPAN BADAN (TEGAK, KOKOH & PROPORSIONAL) */}
            <g id="cardboard-box">
              {/* Bayangan kardus di dada */}
              <rect x="-4" y="122" width="98" height="74" rx="5" fill="rgba(0,0,0,0.4)" filter="blur(4px)" />
              {/* Bodi Kardus Cokelat Tebal */}
              <rect
                x="-4"
                y="118"
                width="98"
                height="74"
                rx="5"
                fill="#9E6B3E"
                stroke="#6B4423"
                strokeWidth="2.5"
              />
              {/* Selotip Kardus Horizontal */}
              <rect x="-4" y="146" width="98" height="18" fill="#B38253" opacity="0.9" />

              {/* LABEL RESI PENGIRIMAN:
                  Pusat label berada di (45, 155).
                  Agar tulisan TIDAK AKAN PERNAH TERBALIK saat character facing left (scaleX(-1)),
                  kita transform balik di titik pusat (45, 155) dengan rumus in-place mirror:
                  translate(45, 155) scale(-1, 1) translate(-45, -155).
                  Sehingga tulisan SELALU terbaca normal dari kiri ke kanan! */}
              <g transform={flip === -1 ? 'translate(45, 155) scale(-1, 1) translate(-45, -155)' : undefined}>
                <rect
                  x="8"
                  y="125"
                  width="74"
                  height="60"
                  rx="3"
                  fill="#F8FAFC"
                  stroke="#CBD5E1"
                  strokeWidth="1"
                />
                <text
                  x="45"
                  y="136"
                  fill="#475569"
                  fontSize="6.5"
                  fontWeight="bold"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  PRIORITY AIR
                </text>
                <text
                  x="45"
                  y="146"
                  fill="#0F172A"
                  fontSize="7.5"
                  fontWeight="900"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  TO: DAVID - APT 404
                </text>

                {/* Stempel Merah Terang TOMORROW */}
                <rect
                  x="14"
                  y="151"
                  width="62"
                  height="18"
                  rx="2"
                  fill="rgba(225, 29, 72, 0.12)"
                  stroke="#E11D48"
                  strokeWidth="1.6"
                />
                <text
                  x="45"
                  y="164"
                  fill="#E11D48"
                  fontSize="9"
                  fontWeight="900"
                  fontFamily="monospace"
                  textAnchor="middle"
                  letterSpacing="0.8"
                >
                  TOMORROW
                </text>

                {/* Garis Barcode */}
                <line
                  x1="18"
                  y1="177"
                  x2="72"
                  y2="177"
                  stroke="#1E293B"
                  strokeWidth="2.5"
                  strokeDasharray="3 1.5 4 1 2 2.5 3"
                />
              </g>
            </g>

            {/* 6C. LENGAN KANAN (DEPAN): Dari Bahu Kanan (24, 105) merangkul tepi dekat kardus */}
            <path
              d="M 24 105 L 48 142 L 20 174"
              stroke={THEME.colors.charSkin}
              strokeWidth="15"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
            <path
              d="M 24 105 L 48 142 L 20 174"
              stroke={rimColor}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
              opacity="0.8"
            />
            {/* Telapak Tangan Kanan menggenggam tepi kardus */}
            <circle cx="20" cy="174" r="9" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1.5" />
          </g>
        )}

        {/* --- 7. POSE MENGANGKAT SMARTPHONE (HOLDING PHONE) --- */}
        {holdingPhone && (
          <g id="phone-raised">
            {/* Lengan Kiri Santai di Samping */}
            <g transform="translate(-30, 105)">
              <rect x="-8" y="0" width="16" height="75" rx="8" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1" />
              <g transform="translate(0, 70)">
                <rect x="-7" y="0" width="14" height="70" rx="7" fill={THEME.colors.charSkin} />
                <circle cx="0" cy="70" r="10" fill={THEME.colors.charSkin} />
              </g>
            </g>

            {/* Lengan Kanan Mengangkat Smartphone ke Depan Dada */}
            <path
              d="M 24 105 L 40 140 L 24 144"
              stroke={THEME.colors.charSkin}
              strokeWidth="15"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />

            {/* Bodi Smartphone */}
            <g transform="translate(24, 136) rotate(-12)">
              <rect x="-15" y="-28" width="30" height="56" rx="6" fill="#0F172A" stroke="#334155" strokeWidth="2" />
              <rect x="-12" y="-25" width="24" height="50" rx="4" fill="#38BDF8" />
              {/* Tangan Kanan Menggenggam Bodi HP */}
              <circle cx="-13" cy="4" r="9.5" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1.5" />
            </g>

            {/* Sorotan Cahaya Layar HP yang Menyala ke Wajah David */}
            <polygon
              points="24,120 -30,-15 30,-25"
              fill={`url(#screenGlow-${idPrefix})`}
              style={{ mixBlendMode: 'screen', pointerEvents: 'none' }}
            />
          </g>
        )}

        {/* --- 8. LENGAN KANAN NORMAL (JIKA TIDAK HOLDING PROPS) --- */}
        {!holdingPackage && !holdingPhone && (
          <g id="right-arm" transform="translate(30, 105)">
            <g transform={`rotate(${rightArmAngle})`}>
              <rect x="-8" y="0" width="16" height="75" rx="8" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="1" />
              <g transform="translate(0, 70)">
                <g transform={`rotate(${rightForearmAngle})`}>
                  <rect x="-7" y="0" width="14" height="70" rx="7" fill={THEME.colors.charSkin} />
                  <circle cx="0" cy="70" r="10" fill={THEME.colors.charSkin} />
                </g>
              </g>
            </g>
          </g>
        )}

        {/* --- 9. KEPALA & EKSPRESI WAJAH (HEAD RIG) --- */}
        <g id="head-rig" transform={`translate(0, 35) rotate(${finalHeadTilt})`}>
          <circle cx="0" cy="0" r="54" fill={THEME.colors.charSkin} stroke={rimColor} strokeWidth="3.5" />

          <g>
            {/* Alis Kiri */}
            <g transform={`translate(-18, ${-22 + browLeftY}) rotate(${browLeftRot})`}>
              <line x1="-12" y1="0" x2="12" y2="0" stroke={THEME.colors.eyeWhite} strokeWidth="4" strokeLinecap="round" />
            </g>

            {/* Alis Kanan */}
            <g transform={`translate(18, ${-22 + browRightY}) rotate(${browRightRot})`}>
              <line x1="-12" y1="0" x2="12" y2="0" stroke={THEME.colors.eyeWhite} strokeWidth="4" strokeLinecap="round" />
            </g>

            {/* Mata Kiri */}
            <g transform={`scale(${eyeScale}, ${(1 - blink) * eyeScale})`}>
              <circle cx="-18" cy="-4" r="13" fill={THEME.colors.eyeWhite} />
              <g clipPath={`url(#eye-clip-l-${idPrefix})`}>
                <circle
                  cx={-18 + pupilX}
                  cy={-4 + pupilY}
                  r={expression === 'creepy_menacing' ? 4.5 : 5.5}
                  fill={THEME.colors.eyePupil}
                />
                {expression !== 'creepy_menacing' && (
                  <circle cx={-18 + pupilX - 1.8} cy={-4 + pupilY - 1.8} r="2" fill="#FFFFFF" />
                )}
              </g>
            </g>

            {/* Mata Kanan */}
            <g transform={`scale(${eyeScale}, ${(1 - blink) * eyeScale})`}>
              <circle cx="18" cy="-4" r="13" fill={THEME.colors.eyeWhite} />
              <g clipPath={`url(#eye-clip-r-${idPrefix})`}>
                <circle
                  cx={18 + pupilX}
                  cy={-4 + pupilY}
                  r={expression === 'creepy_menacing' ? 4.5 : 5.5}
                  fill={THEME.colors.eyePupil}
                />
                {expression !== 'creepy_menacing' && (
                  <circle cx={18 + pupilX - 1.8} cy={-4 + pupilY - 1.8} r="2" fill="#FFFFFF" />
                )}
              </g>
            </g>

            {/* Mulut - Dingin datar / seram / menganga shock */}
            <g transform="translate(0, 24)">
              {expression === 'creepy_menacing' ? (
                <line x1="-8" y1="0" x2="8" y2="0" stroke={THEME.colors.eyeWhite} strokeWidth="2.5" strokeLinecap="round" />
              ) : (
                <Viseme type={viseme} color={THEME.colors.eyeWhite} scale={1.2} />
              )}
            </g>
          </g>
        </g>
      </svg>
    </div>
  );
};
