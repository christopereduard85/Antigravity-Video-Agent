---
name: remotion-cinematic-agent
description: Universal autonomous agent workflow for creating professional storytelling and cinematic animated videos in Remotion (16:9 & 9:16, 720p-4K @ 30fps) with one-shot intake questionnaire, 3-path Whisper/SRT alignment, beat segmentation, story bible, 36 SFX library, and strict 6-stage preview checkpoints.
version: 2.0.0
---

# Universal Remotion Cinematic Storytelling Agent (v2.0)

This skill guides an AI agent to autonomously direct, scaffold, transcribe, plan, animate, sound-design, and render production-grade animated narrative videos in Remotion. It features an automated intake questionnaire, a 3-path timestamp engine (SRT/VTT proportional timing, Whisper alignment with `>=90%` difflib check, and pure Whisper transcription), automated beat segmentation, a story bible and shot director, and an integrated 36-SFX procedural audio library.

---

## 🏛️ CORE PHILOSOPHY & NON-NEGOTIABLE RULES

1. **Pure Code Visuals (Zero External Image/Video Assets)**:
   - All visual elements—characters, environments, rooms, lighting, props, particles, and effects—must be generated 100% via code (React, SVG, Three.js/Fiber, Canvas, CSS).
   - No external PNGs, JPEGs, or stock MP4 footage for visual elements.
2. **Audio Integrity**:
   - The primary voiceover audio (`voiceover.mp3` / `narasi.mp3`) must be preserved **EXACTLY AS IS**.
   - NEVER alter its speed, pitch, words, or duration. Master volume is locked at `1.0`.
   - Video duration in frames is calculated strictly from audio length measured via `ffprobe`: `durationInFrames = Math.ceil(durationSec * FPS)`.
3. **Living Characters (No Stiff Slides)**:
   - Characters must never be flat, static PNGs slid across the screen.
   - Must feature true forward walk cycles (knees flex exclusively on forward swing, double vertical bounce, arms swing in opposition), anticipation, eye tracking, blinks, living idle breathing, and secondary hair/clothes follow-through.
4. **Mandatory Preview Gates**:
   - The agent must complete one stage at a time and provide a runnable preview command (`npx remotion studio`, `npx remotion still ...`, or low-res render).
   - **DO NOT proceed to the next stage until the user explicitly says "lanjut" (continue).** If the user provides feedback, revise and re-preview.

---

## 📋 STAGE-BY-STAGE PRODUCTION WORKFLOW

```
  ┌──────────────────────────────────────────────────────────────────┐
  │  Stage 0: One-Shot Intake Questionnaire & Scaffolding            │
  └────────────────┬─────────────────────────────────────────────────┘
                   │
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 1: 3-Path Timestamping & Beat Segmentation (beats.py)     │ ──► [Preview 1: Text Storyboard & Bible]
  └────────────────┬─────────────────────────────────────────────────┘
                   │ User: "lanjut"
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 2: Keyframe Still & 5-8s Style Preview Clip               │ ──► [Preview 2: Remotion Still & Test Clip]
  └────────────────┬─────────────────────────────────────────────────┘
                   │ User: "lanjut"
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 3: Project Architecture, Design System & Lighting Helpers │ ──► [Preview 3: Helpers & Camera Composition]
  └────────────────┬─────────────────────────────────────────────────┘
                   │ User: "lanjut"
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 4: Living Character Rig, Hooks & Procedural Props         │ ──► [Preview 4: Character Motion & Props Test]
  └────────────────┬─────────────────────────────────────────────────┘
                   │ User: "lanjut"
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 5: Master Scene Assembly, 36-SFX & Ambience Layers        │ ──► [Preview 5: Low-Res Full Video Preview]
  └────────────────┬─────────────────────────────────────────────────┘
                   │ User: "lanjut"
  ┌────────────────▼─────────────────────────────────────────────────┐
  │  Stage 6: Polish, End-to-End Audit & Production MP4 Render       │ ──► [Final Full-Res MP4 Render]
  └──────────────────────────────────────────────────────────────────┘
```

---

### STAGE 0: ONE-SHOT INTAKE QUESTIONNAIRE & SCAFFOLDING

Immediately upon invocation, **ask the user ONCE** (using interactive multiple-choice buttons via `ask_question` tool if available, or a clean structured form):

1. **Voiceover**: Path / upload file audio rekaman suara narasi (Wajib).
2. **Script**: 
   - [A] Bertimestamp (SRT / VTT / JSON / TXT `[mm:ss]`)
   - [B] Teks biasa (tanpa timestamp)
   - [C] Tidak ada script (transkripsi otomatis penuh)
3. **Aspek Rasio**:
   - [A] Landscape (16:9 - 1920x1080 YouTube / Desktop)
   - [B] Portrait (9:16 - 1080x1920 Shorts / TikTok / Reels)
4. **Resolusi**:
   - [A] 1080p (Rekomendasi)
   - [B] 720p (Cepat / Preview)
   - [C] 1440p (2K)
   - [D] 4K (Ultra HD)
5. **Caption Subtitle**:
   - [A] Auto (Default AKTIF untuk 9:16, opsional untuk 16:9)
   - [B] Aktif
   - [C] Nonaktif
6. **Musik & SFX**:
   - Musik: [A] Generate prosedural / [B] File musik sendiri / [C] Tanpa musik
   - SFX: [A] ON (36 efek library) / [B] OFF
7. **Judul / Slug Project**: (contoh: `the-package-from-tomorrow`).

#### Otomatisasi Scaffolding Proyek (`new_project.py`):
Jalankan skrip scaffolding untuk membuat struktur folder terisolasi:
```bash
python scripts/new_project.py --slug "<slug>" --audio "<audio_path>" --script "<script_path>" --aspect "16:9" --resolution "1080p" --title "<Judul>"
```
Struktur folder yang dihasilkan di `projects/<slug>/`:
```
projects/<slug>/
├── input/       # File voiceover & script mentah
├── timeline/    # words.json, sentences.json, transcript.txt, beats.json
├── story/       # bible.md, shots.json
├── scenes/      # cast.js, komponen adegan React/SVG
├── build/       # Temporary assets
├── out/         # Render output video MP4
├── audio/       # File SFX & BGM yang digunakan
└── config.json  # Metadata dimensi, fps, durasi ffprobe, setting
```

---

### STAGE 1: DEEP REFERENCE VIDEO FORENSICS, 3-PATH TIMESTAMPS & BEATS

#### A. Analisis Forensik Video Referensi (Wajib 30fps & Bukan Sekadar Gambar Acak)
Ketika user memberikan video referensi, **Chat DILARANG HANYA melihat beberapa gambar statis acak**. Chat wajib melakukan inspeksi mendalam berbasis 30fps di sepanjang timeline video menggunakan `scripts/analyze_reference.py`:
```bash
python scripts/analyze_reference.py --video "<path_to_reference.mp4>" --outdir "projects/<slug>/story"
```
Chat menganalisis secara komprehensif:
1. **Struktur Cerita & Hook (0 - 5s)**: Bagaimana video memancing rasa penasaran di detik-detik awal, eskalasi konflik, klimaks, dan ending dilema/CTA.
2. **Pencahayaan & Kontras (Lighting & Contrast)**: Rasio gelap/terang, lampu plafon volumetrik (`clipPath`), pantulan lantai, rim light pemisah karakter dari background, dan pendaran celah pintu.
3. **Kamera & Angle**: Gerak kamera (side tracking pan, slow creeping push-in zoom, micro-shake), sudut (eye-level, low angle dramatis, close-up makro properti).
4. **Gaya Visual & Palet Warna**: Pilihan mesin animasi (2D Vector SVG, Three.js 3D, atau Canvas), token warna HEX (`bgDeep`, `bgMid`, `rimLight`, aksen).
5. **Biomekanika Gerak**: Ayunan langkah kaki alami (lutut hanya menekuk saat swing ke depan), antisipasi mata sebelum kepala menoleh, gerak sekunder baju/rambut.
6. **Efek & Ritme Potongan (Cuts)**: Intensitas vignette, partikel debu melayang, durasi rata-rata shot (median 2.0 - 3.5s), pacing (15 - 25 cut/menit), serta pemotongan visual 0.1 - 0.2 detik sebelum frasa narasi.

**Penyimpanan Dokumen Pengingat (Memory File)**:
Hasil analisis WAJIB disimpan menjadi satu dokumen resmi:
- `projects/<slug>/story/reference_analysis.json`
- `projects/<slug>/story/reference_analysis.md`
> **ATURAN PENGINGAT**: File ini menjadi **kitab aturan baku permanen** yang wajib dibaca dan dipatuhi oleh Chat di setiap tahap pembuatan adegan berikutnya.

---

#### B. Pilih Salah Satu dari 3 Jalur Pembuatan Timestamp:

#### Jalur A: Script Bertimestamp (`parse_script.py`)
Jika user menyediakan file SRT / VTT / JSON / TXT bertimestamp:
```bash
python scripts/parse_script.py --input "projects/<slug>/input/script.srt" --outdir "projects/<slug>/timeline"
```
- Mengimpor cue kalimat dengan waktu mulai dan selesai.
- **Distribusi Kata Proporsional**: Waktu per kata dihitung proporsional berdasarkan panjang karakter kata (`len(word) / total_chars`).

#### Jalur B: Script Teks Biasa (`transcribe.py --script`)
Jika user hanya menyediakan naskah teks polos tanpa waktu:
```bash
python scripts/transcribe.py --audio "projects/<slug>/input/voiceover.mp3" --script "projects/<slug>/input/script.txt" --outdir "projects/<slug>/timeline"
```
- Menjalankan Whisper untuk mendeteksi timing kata asli dari audio.
- Menyelaraskan kata-kata naskah script ke timing Whisper menggunakan `difflib.SequenceMatcher`.
- **Aturan Validasi**: Tingkat kecocokan harus **>= 90%**. Jika `< 90%`, Chat WAJIB memberi tahu user bahwa naskah teks dan rekaman audio memiliki perbedaan kata yang signifikan.

#### Jalur C: Tanpa Script (`transcribe.py` murni)
Jika user tidak memiliki naskah:
```bash
python scripts/transcribe.py --audio "projects/<slug>/input/voiceover.mp3" --model small --device auto --outdir "projects/<slug>/timeline"
```
- Model default: `small` (akurasi seimbang), `base` (mesin lambat / CPU), `large-v3` (audio sulit / aksen berat).
- Menggunakan GPU CUDA bila tersedia; fallback otomatis ke CPU int8.
- *Catatan: Model Whisper diunduh otomatis dari huggingface.co saat transkripsi pertama (~75MB base, ~500MB small, butuh koneksi internet).*

**Pemeriksaan Integritas Akhir Transkrip**:
Chat memeriksa apakah timestamp kata/kalimat terakhir dekat dengan durasi total audio dari `config.json` (toleransi ±1.5s).

#### Pemecahan Beat Sinematik (`beats.py`):
```bash
python scripts/beats.py --sentences "projects/<slug>/timeline/sentences.json" --outdir_timeline "projects/<slug>/timeline" --outdir_story "projects/<slug>/story"
```
- Memecah kalimat menjadi "beat" (frasa yang mendapat 1 gambar/shot visual).
- Target durasi: **3.0 detik**, Maksimum: **6.5 detik**, Minimum: **1.2 detik**.
- Menghasilkan `timeline/beats.json` dan draf `story/shots.json` dengan `scene: "TODO"`.

#### Penulisan Story Bible & Shot Planning:
Chat membaca gaya visual dari referensi, lalu:
1. Menulis `story/bible.md`:
   - Logline cerita.
   - Cast: Nama karakter dengan 1 warna khas (*signature hoodie/clothes color*) per karakter.
   - Lokasi: Mood visual, pencahayaan utama (lampu, bayangan, celah pintu).
   - Visual Motifs & Rencana Musik.
2. Menulis `scenes/cast.js`: Kostum, proporsi tubuh, dan palet rig.
3. Menulis ulang `story/shots.json` dengan aturan sutradara:
   - Shot berurutan tanpa celah (*continuous timeline*).
   - **Pre-cut**: Potong visual **0.1 - 0.2 detik sebelum frasa narasi dimulai**.
   - Median durasi shot: **2.0 - 3.5 detik**.
   - Shot pembuka (*establishing shot*) untuk tiap lokasi baru.
   - Ritme pacing: **15 - 25 shot per menit**.
   - Spesifikasi kamera, transisi, bar sinematik, SFX cues (`at` dan `gain`), serta ambience.

**Mandatory Output - Preview 1**:
Kirim ringkasan 5 - 10 baris storyboard & bible ke chat. **TUNGGU user bilang "lanjut" sebelum melangkah ke Tahap 2.**

---

### STAGE 2: STYLE PREVIEW (KEYFRAME STILL & TEST KLIP 5-8s)

Sebelum membangun seluruh adegan, buat pembuktian visual singkat:
1. **Key Frame Still (`KeyFramePreview`)**:
   - Render adegan paling dramatis: karakter, lingkungan, properti, dan pencahayaan volumetrik.
2. **Klip Tes 5-8 Detik (`TestClipPreview`)**:
   - Menampilkan karakter berjalan (*walk cycle*), menoleh, dan berekspresi.
3. **Mandatory Output - Preview 2**:
   ```bash
   npx remotion still KeyFramePreview out/style_preview.png
   npx remotion studio
   ```
   Tanyakan apakah gaya sudah cocok dengan referensi. **TUNGGU user bilang "lanjut".**

---

### STAGE 3: SETUP PROYEK & DESIGN SYSTEM

1. **Responsif Rasio Aspek**:
   - **Portrait (9:16 - 1080x1920)**: Safe zone atas 180px, safe zone bawah 380px, subtitle di `y ≈ 1400px - 1520px`.
   - **Landscape (16:9 - 1920x1080)**: Framing horizontal lebar, subtitle di `y ≈ 920px - 980px`.
2. **Helper Pencahayaan & Kamera**:
   - Volumetric lighting cones (`clipPath: polygon(...)`).
   - Ambient floating particles & cinematic vignette.
   - Camera rig wrapper (pan, creeping zoom, shake).
3. **Mandatory Output - Preview 3**:
   Preview helper pencahayaan di studio. **TUNGGU user bilang "lanjut".**

---

### STAGE 4: RIG KARAKTER BIOMEKANIS & PROPERTI

Terapkan hukum anatomi dan geometri rig:
1. **Sinkronisasi Ruang Layar (`lookAtX * flip`)**:
   Saat `facing="left"` menerapkan `scaleX(-1)`, kalikan `lookAtX * flip` dan `headRotation * flip` agar arah mata dan gelengan kepala selalu intuitif di ruang layar.
2. **Pencegahan Bola Mata Tembus (`<clipPath>`)**:
   Pupil hitam dipotong menggunakan `<clipPath id="eye-clip">` seukuran sklera mata putih dan divektor-clamp (`maxDist = 5.2px`).
3. **Bayangan Kontak Lantai**:
   Terkunci tepat di bawah telapak kaki (`cx="0", cy="388"`) di dalam SVG root agar kaki tidak melayang.
4. **Walk Cycle Maju Alami**:
   Lutut kaki berayun hanya menekuk saat fase pemulihan ke depan. Pantulan vertikal ganda per langkah.
5. **Interaksi Properti (Dua Tangan & Tanpa Teks Terbalik)**:
   - Konstruksi *sandwich*: Lengan belakang menopang bawah -> Properti di tengah -> Lengan depan merangkul tepi.
   - **Transformasi In-Place Reflection**:
     `translate(cx, cy) scale(-1, 1) translate(-cx, -cy)`
     Menjamin teks label/resi/layar **selalu tegak lurus dari kiri ke kanan** saat karakter menghadap kiri.
6. **Mandatory Output - Preview 4**:
   Uji gerak karakter dan props. **TUNGGU user bilang "lanjut".**

---

### STAGE 5: PERAKITAN ADEGAN, 36-SFX LIBRARY & AMBIENCE

1. **Sinkronisasi Garis Waktu**: Seluruh shot di `FullVideo.tsx` disusun membaca `story/shots.json` dan `timeline/words.json`.
2. **Library 36 Sound Effects (`sfx_library.py`)**:
   Setiap SFX ditempatkan per shot dengan parameter:
   - `at`: detik dari awal shot dimulai.
   - `gain`: volume desibel / amplifikasi (0.0 s/d 1.0).
   - Daftar 36 SFX: `whoosh_light`, `whoosh_heavy`, `whoosh_transition`, `impact_sub_boom`, `impact_cinematic_hit`, `impact_wood_thud`, `impact_metal`, `riser_short`, `riser_long`, `riser_tension`, `heartbeat_single`, `heartbeat_loop`, `footstep_leather_tile`, `footstep_wood`, `footstep_concrete`, `door_locked_rattle`, `door_creak_open`, `door_slam`, `door_latch_click`, `phone_vibrate_dual`, `phone_ring`, `message_pop_chime`, `notification_bell`, `glitch_analog`, `glitch_digital`, `glass_shatter`, `breath_heavy`, `clock_tick`, `clock_ticking_loop`, `danger_sting_minor`, `horror_screech`, `drone_sub_bass`, `drone_dissonant`, `light_flicker_buzz`, `package_tape_rip`, `paper_rustle`.
3. **Ambience Loops**:
   `rain`, `wind`, `city`, `roomtone`, `murmur`, `hum` di-loop mulus dengan **crossfade 0.4 detik**.
4. **Hierarki Mixing Audio**:
   - Voiceover: `volume = 1.0` (Dominan).
   - SFX: `volume = 0.35 - 0.75` (Sesuai `gain`).
   - BGM Suspense: `volume = 0.12 - 0.15` (Frekuensi vokal 300Hz-2.5kHz di-scoop out).
5. **Mandatory Output - Preview 5**:
   Render low-res preview keseluruhan. **TUNGGU user bilang "lanjut".**

---

### STAGE 6: POLISH, AUDIT CHECKLIST & PRODUCTION RENDER

1. **Audit Checklist**:
   - `npx tsc --noEmit` exit code 0.
   - Cek sinkronisasi kata narasi dengan visual.
   - Pintu terkunci berbunyi kayu padat (bukan pipa besi).
   - Langkah kaki berbunyi tap sol sepatu (bukan radio rusak).
   - Tidak ada teks terbalik pada properti.
2. **Render Production MP4**:
   ```bash
   npx remotion render <CompositionID> out/<CompositionID>_Final.mp4
   ```
3. **Publishing Package**: Judul, deskripsi, dan hashtag untuk upload.
