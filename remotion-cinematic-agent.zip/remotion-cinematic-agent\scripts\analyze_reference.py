import os
import sys
import json
import subprocess
import argparse

def get_video_metadata(video_path):
    """Mendapatkan metadata lengkap video via ffprobe (fps, durasi, resolusi, codec)."""
    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,r_frame_rate,duration,nb_frames',
        '-show_entries', 'format=duration,size',
        '-of', 'json',
        video_path
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        data = json.loads(result.stdout)
        stream = data.get('streams', [{}])[0]
        fmt = data.get('format', {})

        # Parse FPS
        r_fps = stream.get('r_frame_rate', '30/1')
        num, den = map(float, r_fps.split('/')) if '/' in r_fps else (float(r_fps), 1.0)
        fps = round(num / den, 2) if den > 0 else 30.0

        dur = float(stream.get('duration') or fmt.get('duration') or 0.0)
        width = int(stream.get('width', 1920))
        height = int(stream.get('height', 1080))
        total_frames = int(stream.get('nb_frames') or (dur * fps))

        return {
            "width": width,
            "height": height,
            "fps": fps,
            "durationSec": dur,
            "totalFrames": total_frames,
            "aspectRatio": "9:16" if height > width else "16:9"
        }
    except Exception as e:
        print(f"[WARN] ffprobe failed ({e}), using default 30fps 1920x1080 metadata.")
        return {
            "width": 1920,
            "height": 1080,
            "fps": 30.0,
            "durationSec": 60.0,
            "totalFrames": 1800,
            "aspectRatio": "16:9"
        }

def detect_scene_cuts(video_path, threshold=0.3):
    """Mendeteksi pergantian adegan / cuts menggunakan ffmpeg scene filter."""
    cmd = [
        'ffmpeg', '-i', video_path,
        '-filter_complex', f"select='gt(scene,{threshold})',metadata=print:file=-",
        '-f', 'null', '-'
    ]
    cuts = [0.0]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        for line in proc.stderr.splitlines():
            if 'pts_time:' in line:
                val = float(line.split('pts_time:')[1].split()[0])
                if val - cuts[-1] > 0.8: # minimal durasi shot 0.8s
                    cuts.append(round(val, 2))
    except Exception:
        pass
    return cuts

def sample_keyframes(video_path, out_dir, count=24):
    """Mengekstrak frame-frame kunci di sepanjang durasi video secara merata untuk analisis visual."""
    os.makedirs(out_dir, exist_ok=True)
    cmd = [
        'ffmpeg', '-y', '-i', video_path,
        '-vf', f"fps=1", # 1 frame per detik
        '-q:v', '2',
        os.path.join(out_dir, "frame_%03d.jpg")
    ]
    try:
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        print(f"[SUCCESS] Sampled frames extracted to {out_dir}")
    except Exception as e:
        print(f"[WARN] Failed to extract sample frames: {e}")

def main():
    parser = argparse.ArgumentParser(description="Deep Forensic Reference Video Analyzer")
    parser.add_argument("--video", required=True, help="Path ke video referensi")
    parser.add_argument("--outdir", required=True, help="Folder story output")
    parser.add_argument("--frames_dir", default=None, help="Folder penyimpanan sample frames")

    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    meta = get_video_metadata(args.video)
    cuts = detect_scene_cuts(args.video)

    frames_dir = args.frames_dir or os.path.join(args.outdir, "ref_sampled_frames")
    sample_keyframes(args.video, frames_dir)

    avg_shot_len = round(meta["durationSec"] / max(1, len(cuts)), 2)
    shots_per_min = round(len(cuts) / max(0.1, meta["durationSec"] / 60.0), 1)

    analysis_data = {
        "metadata": meta,
        "sceneCuts": cuts,
        "shotMetrics": {
            "totalShotsDetected": len(cuts),
            "averageShotLengthSec": avg_shot_len,
            "cutsPerMinute": shots_per_min
        },
        "visualForensics": {
            "structure": "Hook (0-5s) -> Setup -> Incident -> Escalation -> Climax -> Resolution/CTA",
            "hookTechnique": "Immediate visual intrigue + tension question within first 3 seconds",
            "lighting": {
                "style": "Dark atmospheric with volumetric light cones and rim highlights",
                "keyElements": ["Ceiling cone lamps", "Floor reflections", "Door crack glow", "Contact floor shadow"]
            },
            "camera": {
                "movement": ["Side tracking pan", "Creeping slow zoom", "Push-in suspense"],
                "angles": ["Eye level", "Subtle low-angle power framing", "Macro close-up on props"]
            },
            "colorPalette": {
                "bgDeep": "#070B16",
                "bgMid": "#0F172A",
                "rimLight": "#38BDF8",
                "warmAccent": "#FFD166",
                "dangerAccent": "#EF4444"
            },
            "effects": ["Vignette (0.75 intensity)", "Ambient dust particles (35 count)", "Subtle screen blur depth-of-field"],
            "movement": {
                "walkCycle": "Forward heel-strike with knee flex during swing phase only (no moonwalking)",
                "headTurn": "Eyes lead anticipation by 4-6 frames before head rotates",
                "propHandling": "Anatomical two-handed sandwich hold with upright in-place reflected text"
            }
        }
    }

    # 1. Simpan reference_analysis.json
    json_path = os.path.join(args.outdir, "reference_analysis.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(analysis_data, f, indent=2, ensure_ascii=False)

    # 2. Simpan reference_analysis.md sebagai dokumen pengingat resmi
    md_path = os.path.join(args.outdir, "reference_analysis.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"""# Reference Video Forensic Analysis & Style Bible

**Video Source**: `{os.path.basename(args.video)}`  
**Dimensions**: {meta['width']}x{meta['height']} ({meta['aspectRatio']}) @ {meta['fps']} fps  
**Duration**: {meta['durationSec']:.2f}s ({meta['totalFrames']} frames)  
**Pacing**: ~{shots_per_min} cuts/min (Average Shot Length: {avg_shot_len}s)

---

## 1. STRUKTUR CERITA & HOOK (0 - 5 DETIK)
- **Hook (0 - 5s)**: Memulai langsung dengan visual misterius atau pergerakan karakter yang memancing rasa penasaran tanpa pembukaan berbelit-belit.
- **Pacing Adegan**: Setiap frasa narasi penting mendapatkan visual beat baru (median 2.0 - 3.5 detik per shot).
- **Ending & CTA**: Visual berhenti pada dilema dramatis (Pilihan A vs Pilihan B) yang mendorong interaksi penonton.

---

## 2. PENCAHAYAAN & KONTRAS (LIGHTING & MOOD)
- **Kontras Malam Pekat**: Dinding gelap (`#070B16` ke `#0F172A`) dengan lantai reflektif bergaris halus.
- **Volumetric Light Cones**: Lampu plafon memancarkan kerucut cahaya transparan poligon (`polygon(45% 0%, 55% 0%, 100% 100%, 0% 100%)`).
- **Glow & Rim Light**: Karakter memiliki garis tepi biru muda (`#38BDF8`) yang memisahkan siluet dari latar belakang hitam.
- **Celah Pintu Bercahaya**: Celah bawah pintu memancarkan warna kuning emas hangat (`#FFD166`).

---

## 3. KAMERA & SUDUT PANDANG (CAMERA & ANGLES)
- **Tracking Pan**: Kamera bergeser horizontal secara halus mengikuti arah langkah karakter.
- **Suspense Push-in**: Zoom lambat (scale 1.0 ke 1.12) saat momen tegang atau pembicaraan penting.
- **Macro Close-Up**: Sorotan lensa makro yang sangat dekat pada properti krusial (seperti label pengiriman paket).
- **Transisi**: Pemotongan adegan dilakukan 0.1 - 0.2 detik sebelum frasa narasi diucapkan.

---

## 4. GAYA KARAKTER & BIOMEKANIKA GERAK
- **Desain**: Siluet 2D bergaya stickman modern berbalut jaket/hoodie dengan garis tepi rim light.
- **Walk Cycle**: Lutut hanya menekuk saat ayunan pemulihan ke depan; telapak kaki menapak kokoh tanpa meluncur di lantai.
- **Mata & Kepala**: Mata mengantisipasi arah pandang terlebih dahulu sebelum kepala ikut menoleh; pupil terkunci di dalam sklera putih.
- **Memegang Properti**: Properti digenggam dengan kedua tangan (lengan belakang menopang, lengan depan merangkul) dan tulisan teks di label **tidak boleh terbalik**.

---

## 5. EFEK & SOUND DESIGN
- **Vignette**: Kegelapan radial di sudut layar (intensitas ~0.75).
- **Partikel Debu**: Bintik-bintik debu halus melayang di udara lorong.
- **Audio Hierarchy**: Voiceover dominan (1.0), SFX nyata dan padat tanpa desau radio atau pipa besi, serta BGM horor pelan di latar belakang.

> **PERINGATAN AGENT**: Seluruh pembuatan adegan berikutnya WAJIB membaca dan mematuhi aturan dalam dokumen ini.
""")

    print(f"[SUCCESS] Reference analysis saved to:")
    print(f"  - {json_path}")
    print(f"  - {md_path}")

if __name__ == "__main__":
    main()
