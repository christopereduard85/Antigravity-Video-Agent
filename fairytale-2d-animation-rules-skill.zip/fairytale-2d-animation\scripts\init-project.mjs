#!/usr/bin/env node
/**
 * Scaffolds a new Remotion + Three.js 2D fairy-tale episode project from the skill's `template/`
 * and generates all default SFX WAVs.
 *
 * Usage: node scripts/init-project.mjs <targetDir>
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const target = path.resolve(process.argv[2] ?? "./fairytale-episode");
const skillRoot = path.resolve(import.meta.dirname, "..");
const tpl = path.join(skillRoot, "template");

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    if (ent.name === "node_modules" || ent.name === "out" || ent.name === ".remotion") continue;
    const s = path.join(src, ent.name);
    const d = path.join(dst, ent.name);
    if (ent.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

copyDir(tpl, target);
fs.mkdirSync(path.join(target, "public", "vo"), { recursive: true });

spawnSync(process.execPath, [path.join(skillRoot, "scripts", "generate-sfx.mjs"), target], { stdio: "inherit" });
spawnSync(process.execPath, [path.join(skillRoot, "scripts", "build-timeline.mjs"), target], { stdio: "inherit" });

console.log(`\nProject ready at: ${target}`);
console.log(`Next steps:\n  cd "${target}"\n  npm install\n  npx remotion still CharacterSheet out/char-sheet.png --gl=angle`);
