#!/usr/bin/env node
// ============================================================================
// PROCEDURAL AUDIO SYNTHESIZER (scripts/make-audio.mjs)
// Generates 44.1 kHz 16-bit PCM WAV files from pure code (zero external assets
// required):
//  - public/audio/music.wav        (mood-matched instrumental background bed)
//  - public/audio/sfx-<name>.wav   (20 cartoon & physics sound effects)
//  - public/audio/vo.wav           (copies user's public/vo.mp3|wav if present,
//                                   or generates a rhythmic speech guide track)
// ============================================================================
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, 'public/audio');
const SR = 44100;

function writeWav(filePath, samples) {
  const numSamples = samples.length;
  const buffer = Buffer.alloc(44 + numSamples * 2);
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + numSamples * 2, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20); // PCM
  buffer.writeUInt16LE(1, 22); // Mono
  buffer.writeUInt32LE(SR, 24);
  buffer.writeUInt32LE(SR * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(numSamples * 2, 40);

  for (let i = 0; i < numSamples; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buffer.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, buffer);
}

// Deterministic pseudo-random noise
let nSeed = 1337;
function noise() {
  nSeed = (nSeed * 1664525 + 1013904223) >>> 0;
  return (nSeed / 2147483648) - 1;
}

function synthSfx(name) {
  switch (name) {
    case 'pop': {
      const N = Math.floor(SR * 0.16);
      const out = new Float32Array(N);
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const f = 260 + 520 * Math.min(1, t / 0.06);
        phase += (2 * Math.PI * f) / SR;
        const env = Math.exp(-t * 28);
        out[i] = Math.sin(phase) * env * 0.75;
      }
      return out;
    }
    case 'ding': {
      const N = Math.floor(SR * 0.65);
      const out = new Float32Array(N);
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const env = Math.exp(-t * 6.5);
        out[i] = (Math.sin(2 * Math.PI * 1046.5 * t) * 0.6 + Math.sin(2 * Math.PI * 2093 * t) * 0.25) * env;
      }
      return out;
    }
    case 'boing': {
      const N = Math.floor(SR * 0.55);
      const out = new Float32Array(N);
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const f = 190 + 180 * t + Math.sin(t * 52) * 55;
        phase += (2 * Math.PI * f) / SR;
        const env = Math.exp(-t * 5.2);
        out[i] = (Math.sin(phase) + 0.35 * Math.sin(phase * 2)) * env * 0.6;
      }
      return out;
    }
    case 'whoosh': {
      const N = Math.floor(SR * 0.38);
      const out = new Float32Array(N);
      let lp = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const u = t / 0.38;
        const env = Math.sin(u * Math.PI);
        const alpha = 0.04 + 0.18 * env;
        lp += alpha * (noise() - lp);
        out[i] = lp * env * 1.4;
      }
      return out;
    }
    case 'thud':
    case 'stomp': {
      const N = Math.floor(SR * 0.32);
      const out = new Float32Array(N);
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const f = 52 + 120 * Math.exp(-t * 32);
        phase += (2 * Math.PI * f) / SR;
        const env = Math.exp(-t * 15);
        const transient = name === 'stomp' ? noise() * Math.exp(-t * 55) * 0.45 : 0;
        out[i] = (Math.sin(phase) * env + transient) * 0.85;
      }
      return out;
    }
    case 'march': {
      // 4 crisp boot steps in rhythm (0.5s apart)
      const N = Math.floor(SR * 1.9);
      const out = new Float32Array(N);
      for (let step = 0; step < 4; step++) {
        const offset = Math.floor(step * 0.46 * SR);
        let phase = 0;
        for (let i = 0; i < Math.floor(SR * 0.25) && offset + i < N; i++) {
          const t = i / SR;
          const f = 65 + 110 * Math.exp(-t * 35);
          phase += (2 * Math.PI * f) / SR;
          const env = Math.exp(-t * 18);
          out[offset + i] += (Math.sin(phase) * 0.6 + noise() * Math.exp(-t * 45) * 0.4) * env;
        }
      }
      return out;
    }
    case 'creak': {
      const N = Math.floor(SR * 0.65);
      const out = new Float32Array(N);
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const f = 180 + Math.sin(t * 28) * 45 - t * 50;
        phase += (2 * Math.PI * f) / SR;
        const env = Math.sin((t / 0.65) * Math.PI);
        out[i] = Math.tanh(Math.sin(phase) * 2.5) * env * 0.45;
      }
      return out;
    }
    case 'whistle': {
      const N = Math.floor(SR * 0.7);
      const out = new Float32Array(N);
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const f = t < 0.32 ? 1180 + t * 420 : 1480 - (t - 0.32) * 320 + Math.sin(t * 42) * 24;
        phase += (2 * Math.PI * f) / SR;
        const env = Math.sin((t / 0.7) * Math.PI);
        out[i] = Math.sin(phase) * env * 0.55;
      }
      return out;
    }
    case 'snap': {
      const N = Math.floor(SR * 0.45);
      const out = new Float32Array(N);
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const crack = noise() * Math.exp(-t * 55) * 0.95;
        const metal = (Math.sin(2 * Math.PI * 440 * t) + Math.sin(2 * Math.PI * 690 * t)) * Math.exp(-t * 14) * 0.45;
        out[i] = crack + metal;
      }
      return out;
    }
    case 'crash':
    case 'explosion': {
      const N = Math.floor(SR * 1.1);
      const out = new Float32Array(N);
      let lp = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        lp += 0.14 * (noise() - lp);
        const boom = Math.sin(2 * Math.PI * (58 * Math.exp(-t * 3)) * t) * Math.exp(-t * 4);
        out[i] = (lp * Math.exp(-t * 3.5) * 0.8 + boom * 0.6);
      }
      return out;
    }
    case 'splash': {
      const N = Math.floor(SR * 0.95);
      const out = new Float32Array(N);
      let bp = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const n = noise();
        bp += (0.18 + 0.1 * Math.sin(t * 25)) * (n - bp);
        const env = Math.exp(-t * 3.6) * (1 - Math.exp(-t * 45));
        out[i] = bp * env * 1.1;
      }
      return out;
    }
    case 'bubbles': {
      const N = Math.floor(SR * 0.8);
      const out = new Float32Array(N);
      for (let b = 0; b < 6; b++) {
        const off = Math.floor(b * 0.11 * SR);
        const baseF = 380 + (b % 3) * 140;
        let phase = 0;
        for (let i = 0; i < Math.floor(SR * 0.11) && off + i < N; i++) {
          const t = i / SR;
          phase += (2 * Math.PI * (baseF + t * 1800)) / SR;
          out[off + i] += Math.sin(phase) * Math.sin((t / 0.11) * Math.PI) * 0.55;
        }
      }
      return out;
    }
    case 'sad': {
      // Classic 3-note descending trombone ("wah-wah-waaah")
      const N = Math.floor(SR * 1.15);
      const out = new Float32Array(N);
      const notes = [
        { s: 0.0, e: 0.3, f0: 311, f1: 293 },
        { s: 0.34, e: 0.64, f0: 293, f1: 277 },
        { s: 0.68, e: 1.12, f0: 277, f1: 233 },
      ];
      let phase = 0;
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        for (const n of notes) {
          if (t >= n.s && t <= n.e) {
            const u = (t - n.s) / (n.e - n.s);
            const f = n.f0 + (n.f1 - n.f0) * u + Math.sin(t * 32) * 4;
            phase += (2 * Math.PI * f) / SR;
            const env = Math.sin(u * Math.PI);
            out[i] = (Math.sin(phase) * 0.5 + Math.sin(phase * 2) * 0.3 + Math.sin(phase * 3) * 0.15) * env * 0.7;
          }
        }
      }
      return out;
    }
    case 'stamp':
    case 'clang': {
      const N = Math.floor(SR * 0.42);
      const out = new Float32Array(N);
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        const hit = Math.sin(2 * Math.PI * 95 * Math.exp(-t * 18) * t) * Math.exp(-t * 14);
        const snap = noise() * Math.exp(-t * 48) * 0.6;
        out[i] = (hit + snap) * 0.85;
      }
      return out;
    }
    default: {
      const N = Math.floor(SR * 0.25);
      const out = new Float32Array(N);
      for (let i = 0; i < N; i++) {
        const t = i / SR;
        out[i] = Math.sin(2 * Math.PI * 520 * t) * Math.exp(-t * 16) * 0.5;
      }
      return out;
    }
  }
}

function synthMusic(durationSec, mood = 'whimsical', bpm = 116) {
  const N = Math.ceil((durationSec + 2.5) * SR);
  const out = new Float32Array(N);
  const stepSec = 60 / bpm / 2; // 8th-note grid

  // Scale frequencies (Hz) by mood
  const scales = {
    whimsical: [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25], // C major pentatonic
    mystery: [220.0, 246.94, 261.63, 329.63, 349.23, 440.0, 493.88, 523.25], // A minor
    tense: [196.0, 207.65, 246.94, 261.63, 293.66, 311.13, 392.0, 415.3],
    night: [261.63, 311.13, 349.23, 392.0, 466.16, 523.25, 622.25, 698.46],
    medieval: [293.66, 329.63, 349.23, 392.0, 440.0, 493.88, 523.25, 587.33], // D dorian
    shanty: [293.66, 349.23, 392.0, 440.0, 523.25, 587.33, 698.46, 783.99],
  };
  const scale = scales[mood] || scales.whimsical;
  const pattern = [0, 2, 4, 5, 4, 2, 3, 1, 0, 4, 6, 5, 4, 3, 2, 1];
  const bassPat = [0, 0, 3, 3, 4, 4, 0, 2];

  const totalSteps = Math.floor((durationSec + 2) / stepSec);
  for (let s = 0; s < totalSteps; s++) {
    const startSample = Math.floor(s * stepSec * SR);
    const noteDur = Math.floor(stepSec * 0.92 * SR);
    const melFreq = scale[pattern[s % pattern.length]];

    // Plucked pizzicato / marimba note
    for (let i = 0; i < noteDur && startSample + i < N; i++) {
      const t = i / SR;
      const env = Math.exp(-t * 9.5) * Math.min(1, t / 0.006);
      const sig = Math.sin(2 * Math.PI * melFreq * t) * 0.55 + Math.sin(4 * Math.PI * melFreq * t) * 0.2;
      out[startSample + i] += sig * env * 0.35;
    }

    // Walking bass on quarter notes
    if (s % 2 === 0) {
      const bassFreq = scale[bassPat[(s / 2) % bassPat.length]] * 0.5;
      const bDur = Math.floor(stepSec * 1.8 * SR);
      for (let i = 0; i < bDur && startSample + i < N; i++) {
        const t = i / SR;
        const env = Math.exp(-t * 5.5) * Math.min(1, t / 0.008);
        out[startSample + i] += Math.sin(2 * Math.PI * bassFreq * t) * env * 0.38;
      }
    }

    // Light woodblock / shaker groove
    if (s % 4 === 2) {
      for (let i = 0; i < Math.floor(0.05 * SR) && startSample + i < N; i++) {
        const t = i / SR;
        out[startSample + i] += Math.sin(2 * Math.PI * 820 * t) * Math.exp(-t * 65) * 0.14;
      }
    }
  }
  return out;
}

function synthGuideVoice(wordsFile) {
  const words = wordsFile.words || [];
  const totalSec = (wordsFile.totalDuration || 48) + 1.5;
  const N = Math.ceil(totalSec * SR);
  const out = new Float32Array(N);

  // Synthesize warm formant-like syllable pulses for preview when user hasn't dropped vo.mp3 yet
  for (let k = 0; k < words.length; k++) {
    const w = words[k];
    const i0 = Math.floor(w.start * SR);
    const i1 = Math.min(N, Math.floor(w.end * SR));
    const dur = Math.max(0.06, w.end - w.start);
    const f0 = 135 + ((k * 17) % 5) * 9;
    for (let i = i0; i < i1; i++) {
      const t = (i - i0) / SR;
      const u = t / dur;
      const env = Math.sin(u * Math.PI) * 0.22;
      out[i] =
        (Math.sin(2 * Math.PI * f0 * t) * 0.5 +
          Math.sin(2 * Math.PI * f0 * 2 * t) * 0.3 +
          Math.sin(2 * Math.PI * f0 * 3 * t) * 0.15) *
        env;
    }
  }
  return out;
}

function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const wordsPath = path.join(ROOT, 'src/project/words.json');
  const wordsFile = fs.existsSync(wordsPath)
    ? JSON.parse(fs.readFileSync(wordsPath, 'utf8'))
    : { totalDuration: 48, words: [] };

  // 1. Generate all SFX
  const sfxList = [
    'pop', 'ding', 'boing', 'whoosh', 'thud', 'stomp', 'march', 'creak',
    'whistle', 'snap', 'crash', 'explosion', 'splash', 'bubbles', 'sad', 'stamp', 'clang',
  ];
  for (const name of sfxList) {
    writeWav(path.join(OUT_DIR, `sfx-${name}.wav`), synthSfx(name));
  }

  // 2. Generate background music bed
  const musicSamples = synthMusic(wordsFile.totalDuration || 48, 'whimsical', 116);
  writeWav(path.join(OUT_DIR, 'music.wav'), musicSamples);

  // 3. Prepare public/audio/vo.wav from user's public/vo.mp3|wav if provided, else guide voice
  const userMp3 = path.join(ROOT, 'public/vo.mp3');
  const userWav = path.join(ROOT, 'public/vo.wav');
  const outVo = path.join(OUT_DIR, 'vo.wav');

  if (fs.existsSync(userMp3)) {
    execSync(`ffmpeg -y -v error -i "${userMp3}" -ar ${SR} -ac 1 "${outVo}"`);
    console.log('[audio] Converted user public/vo.mp3 -> public/audio/vo.wav');
  } else if (fs.existsSync(userWav)) {
    execSync(`ffmpeg -y -v error -i "${userWav}" -ar ${SR} -ac 1 "${outVo}"`);
    console.log('[audio] Converted user public/vo.wav -> public/audio/vo.wav');
  } else {
    writeWav(outVo, synthGuideVoice(wordsFile));
    console.log('[audio] Generated preview guide voice -> public/audio/vo.wav (drop public/vo.mp3 to use real VO)');
  }

  console.log(`[audio] Synthesized ${sfxList.length} SFX + music.wav in public/audio/`);
}

main();
