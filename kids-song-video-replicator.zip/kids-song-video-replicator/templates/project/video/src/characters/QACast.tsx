import React from 'react';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';
import { Bobo } from './bobo/Bobo';
import { boboTokens } from './bobo/tokens';
import { Lulu } from './lulu/Lulu';
import { luluTokens } from './lulu/tokens';
import { Ziggy } from './ziggy/Ziggy';
import { ziggyTokens } from './ziggy/tokens';
import { Grub } from './grub/Grub';
import { grubTokens } from './grub/tokens';
import {
  BonesDrummer,
  SpinnyBassist,
  BooSax,
  PipBat,
} from './band/BandCharacters';
import { makeBeatDancePose } from '../rig/poses';
import { theme } from '../theme';

export const QACast: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const openEyes = <T extends { blink: number }>(p: T): T => ({ ...p, blink: 0 });

  const boboBase = openEyes(makeBeatDancePose(boboTokens, frame, { x: 160, y: 465 }, 'idle', fps));
  const boboBurg = openEyes(makeBeatDancePose(boboTokens, frame, { x: 390, y: 465 }, 'dance', fps));

  const luluBase = openEyes(makeBeatDancePose(luluTokens, frame, { x: 630, y: 465 }, 'idle', fps));
  const luluIce = openEyes(makeBeatDancePose(luluTokens, frame, { x: 860, y: 465 }, 'dance', fps));

  const ziggyBase = openEyes(makeBeatDancePose(ziggyTokens, frame, { x: 1110, y: 465 }, 'idle', fps));
  const ziggyDonut = openEyes(makeBeatDancePose(ziggyTokens, frame, { x: 1350, y: 465 }, 'dance', fps));

  const grubBase = openEyes(makeBeatDancePose(grubTokens, frame, { x: 1590, y: 465 }, 'idle', fps));
  const grubDog = openEyes(makeBeatDancePose(grubTokens, frame, { x: 1800, y: 465 }, 'dance', fps));

  return (
    <AbsoluteFill style={{ backgroundColor: theme.sheetBg }}>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080">
        <text
          x={60}
          y={64}
          fontFamily="Arial Black, sans-serif"
          fontSize={42}
          fill="#2B2D38"
        >
          FULL CAST STUDIO RIG LINEUP (8 CHARACTERS + 4 COSTUMES)
        </text>
        <text
          x={60}
          y={98}
          fontFamily="sans-serif"
          fontSize={20}
          fontWeight="bold"
          fill="#5A5A6E"
        >
          Row 1: Heroes Base &amp; Food Costumes (Bobo / Burger · Lulu / Ice Cream · Ziggy / Donut · Grub / Hot Dog)
        </text>

        <Bobo pose={boboBase} frame={frame} costume="none" scale={0.78} instanceId="c-b1" />
        <Bobo pose={boboBurg} frame={frame} costume="burger" scale={0.78} instanceId="c-b2" />
        <text x={275} y={512} textAnchor="middle" fontFamily="sans-serif" fontSize={19} fontWeight="bold" fill="#2B2D38">
          H1: Bobo (Base &amp; Burger)
        </text>

        <Lulu pose={luluBase} frame={frame} costume="none" scale={0.74} instanceId="c-l1" />
        <Lulu pose={luluIce} frame={frame} costume="icecream" scale={0.74} instanceId="c-l2" />
        <text x={745} y={512} textAnchor="middle" fontFamily="sans-serif" fontSize={19} fontWeight="bold" fill="#2B2D38">
          H2: Lulu (Base &amp; Ice Cream)
        </text>

        <Ziggy pose={ziggyBase} frame={frame} costume="none" scale={0.8} instanceId="c-z1" />
        <Ziggy pose={ziggyDonut} frame={frame} costume="donut" scale={0.8} instanceId="c-z2" />
        <text x={1230} y={512} textAnchor="middle" fontFamily="sans-serif" fontSize={19} fontWeight="bold" fill="#2B2D38">
          H3: Ziggy (Base &amp; Donut)
        </text>

        <Grub pose={grubBase} frame={frame} costume="none" scale={0.76} instanceId="c-g1" />
        <Grub pose={grubDog} frame={frame} costume="hotdog" scale={0.76} instanceId="c-g2" />
        <text x={1695} y={512} textAnchor="middle" fontFamily="sans-serif" fontSize={19} fontWeight="bold" fill="#2B2D38">
          H4: Grub (D5 Horns + Hot Dog)
        </text>

        {/* Row 2: Band & Mascot on Theatre Stage Backdrop so White Skeleton & Ghost Pop! */}
        <text
          x={60}
          y={578}
          fontFamily="sans-serif"
          fontSize={20}
          fontWeight="bold"
          fill="#5A5A6E"
        >
          Row 2: Halloween Band &amp; Intro Mascot (B1 Bones Drummer · B2 Spinny Spider Bassist · B3 Boo Sax Ghost · M1 Pip Bat)
        </text>

        <rect x={40} y={596} width={1840} height={384} rx={20} fill={theme.stage.curtainDark} />
        <rect x={40} y={890} width={1840} height={90} rx={12} fill={theme.stage.woodBase} />

        <BonesDrummer x={320} y={940} frame={frame} fps={fps} scale={0.95} />
        <text x={320} y={1020} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
          B1: Bones (Drummer)
        </text>

        <SpinnyBassist x={780} y={940} frame={frame} fps={fps} scale={0.95} />
        <text x={780} y={1020} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
          B2: Spinny (6-Leg Spider Bass)
        </text>

        <BooSax x={1220} y={940} frame={frame} fps={fps} scale={0.95} />
        <text x={1220} y={1020} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
          B3: Boo (Ghost Saxophone)
        </text>

        <PipBat x={1620} y={785} frame={frame} fps={fps} scale={1.15} holdingMiniBurger />
        <text x={1620} y={1020} textAnchor="middle" fontFamily="sans-serif" fontSize={20} fontWeight="bold" fill="#2B2D38">
          M1: Pip (Intro Bat)
        </text>
      </svg>
    </AbsoluteFill>
  );
};
