import React from 'react';
import { AppendageSpec, CharacterTokens, Pose } from './types';
import { deformBodyPoint } from './geom';
import { evalSpringSwings } from './spring';

/**
 * Rule 5: Spring-driven secondary motion for antennae, floppy bunny/dog ears, horns, tails, and hair curls.
 */
export const Appendage: React.FC<{
  spec: AppendageSpec;
  tokens: CharacterTokens;
  pose: Pose;
  frame: number;
  fps: number;
  beatPeriodSec: number;
}> = ({ spec, tokens, pose, frame, fps, beatPeriodSec }) => {
  const anchorNorm = tokens.anchors.appendages[spec.anchor] ?? { x: 0, y: -0.95 };
  const root = deformBodyPoint(
    anchorNorm.x,
    anchorNorm.y,
    tokens.body.w,
    tokens.body.h,
    tokens.body.topTaper,
    pose.squash,
    pose.arc
  );

  const phaseOffset = spec.anchor * 0.16;
  const { angleDeg, stretch } = evalSpringSwings(
    frame,
    fps,
    beatPeriodSec,
    spec.stiffness,
    spec.damping,
    phaseOffset,
    spec.kind === 'horn' ? 4 : 13
  );

  const stalkColor = spec.color ?? tokens.colors.limb;
  const tipColor = spec.tipColor ?? tokens.colors.shade;

  // 1. Monster Horn (curved two-tone cone for Ziggy & Grub)
  if (spec.kind === 'horn') {
    const rot = spec.splay - pose.lean * 0.35 + angleDeg * 0.35;
    const hLen = spec.length;
    const hw = spec.width * 0.5;
    return (
      <g
        transform={`translate(${root.x.toFixed(2)}, ${(root.y - 6).toFixed(
          2
        )}) rotate(${rot.toFixed(2)})`}
      >
        <path
          d={`M ${(-hw).toFixed(2)} 8 Q ${(-hw * 0.7).toFixed(2)} ${(
            -hLen * 0.65
          ).toFixed(2)} 0 ${(-hLen).toFixed(2)} Q ${(hw * 0.85).toFixed(2)} ${(
            -hLen * 0.6
          ).toFixed(2)} ${hw.toFixed(2)} 8 Z`}
          fill={stalkColor}
        />
        {/* Golden/cream tip stripe */}
        <path
          d={`M ${(-hw * 0.58).toFixed(2)} ${(-hLen * 0.42).toFixed(2)} Q 0 ${(
            -hLen
          ).toFixed(2)} ${(hw * 0.62).toFixed(2)} ${(-hLen * 0.42).toFixed(
            2
          )} Q 0 ${(-hLen * 0.28).toFixed(2)} ${(-hw * 0.58).toFixed(2)} ${(
            -hLen * 0.42
          ).toFixed(2)} Z`}
          fill={tipColor}
        />
      </g>
    );
  }

  // 2. Floppy Bunny / Hound Ear (for Lulu & Grub)
  if (spec.kind === 'ear') {
    const rot = spec.splay - pose.lean * 0.75 + angleDeg;
    const eLen = spec.length * (1 + stretch * 0.6);
    const ew = spec.width;
    const bend = Math.sin(((spec.splay + angleDeg) * Math.PI) / 180) * 18;
    return (
      <g
        transform={`translate(${root.x.toFixed(2)}, ${(root.y + 6).toFixed(
          2
        )}) rotate(${rot.toFixed(2)})`}
      >
        {/* Outer floppy ear petal */}
        <path
          d={`M ${(-ew * 0.32).toFixed(2)} 0
              C ${(-ew * 0.75).toFixed(2)} ${(-eLen * 0.45).toFixed(2)}, ${(
            -ew * 0.65 +
            bend
          ).toFixed(2)} ${(-eLen).toFixed(2)}, ${bend.toFixed(2)} ${(
            -eLen
          ).toFixed(2)}
              C ${(ew * 0.65 + bend).toFixed(2)} ${(-eLen).toFixed(2)}, ${(
            ew * 0.75
          ).toFixed(2)} ${(-eLen * 0.45).toFixed(2)}, ${(ew * 0.32).toFixed(
            2
          )} 0 Z`}
          fill={stalkColor}
        />
        {/* Soft inner ear pink/shade */}
        <path
          d={`M ${(-ew * 0.18).toFixed(2)} -6
              C ${(-ew * 0.42).toFixed(2)} ${(-eLen * 0.45).toFixed(2)}, ${(
            -ew * 0.36 +
            bend * 0.85
          ).toFixed(2)} ${(-eLen * 0.84).toFixed(2)}, ${(bend * 0.85).toFixed(
            2
          )} ${(-eLen * 0.84).toFixed(2)}
              C ${(ew * 0.36 + bend * 0.85).toFixed(2)} ${(
            -eLen * 0.84
          ).toFixed(2)}, ${(ew * 0.42).toFixed(2)} ${(-eLen * 0.45).toFixed(
            2
          )}, ${(ew * 0.18).toFixed(2)} -6 Z`}
          fill={tipColor}
          opacity={0.75}
        />
      </g>
    );
  }

  // 3. Cute Bouncy Hair Curl (Lulu & Ziggy top tuft)
  if (spec.kind === 'curl') {
    const rot = spec.splay + angleDeg * 0.8;
    const s = spec.length / 42;
    return (
      <g
        transform={`translate(${root.x.toFixed(2)}, ${(root.y + 4).toFixed(
          2
        )}) rotate(${rot.toFixed(2)}) scale(${s.toFixed(2)})`}
      >
        <path
          d="M 0 0 C -14 -18, 18 -38, 2 -46 C -14 -52, -20 -30, -4 -26 C 12 -22, 16 -42, 0 -54"
          fill="none"
          stroke={stalkColor}
          strokeWidth={spec.width}
          strokeLinecap="round"
        />
      </g>
    );
  }

  // 4. Antenna or Wagging Tail (default 2-segment spring curve + optional ball tip)
  const totalAngle = spec.splay - pose.lean * 0.65 + angleDeg;
  const rad = ((totalAngle - 90) * Math.PI) / 180;
  const len = spec.length * (1 + stretch - pose.squash * 0.12);
  const midRad = ((totalAngle * 0.6 - 90) * Math.PI) / 180;
  const ctrl = {
    x: root.x + Math.cos(midRad) * (len * 0.55),
    y: root.y + Math.sin(midRad) * (len * 0.55),
  };
  const tip = {
    x: root.x + Math.cos(rad) * len,
    y: root.y + Math.sin(rad) * len,
  };

  return (
    <g>
      <path
        d={`M ${root.x.toFixed(2)} ${(root.y + 8).toFixed(2)} Q ${ctrl.x.toFixed(
          2
        )} ${ctrl.y.toFixed(2)} ${tip.x.toFixed(2)} ${tip.y.toFixed(2)}`}
        fill="none"
        stroke={stalkColor}
        strokeWidth={spec.width}
        strokeLinecap="round"
      />
      {spec.tipR > 0 && (
        <g transform={`translate(${tip.x.toFixed(2)}, ${tip.y.toFixed(2)})`}>
          <circle cx={0} cy={0} r={spec.tipR} fill={tipColor} />
          <circle
            cx={-spec.tipR * 0.28}
            cy={-spec.tipR * 0.28}
            r={spec.tipR * 0.32}
            fill={tokens.colors.highlight}
            opacity={0.45}
          />
        </g>
      )}
    </g>
  );
};
