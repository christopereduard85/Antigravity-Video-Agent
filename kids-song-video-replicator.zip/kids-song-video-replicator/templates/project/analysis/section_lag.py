"""Find exact lag of each verse/chorus relative to Verse1/Chorus1 (which user confirmed in sync)."""
import json, numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfiltfilt
sr, x = wavfile.read('Halloween Night.wav'); x = x.astype(np.float64)
mid = (x[:,0]+x[:,1])*0.5; side = (x[:,0]-x[:,1])*0.5
voc = sosfiltfilt(butter(4, [300, 4000], btype='bandpass', fs=sr, output='sos'), mid - 0.85*side)
h = sr // 100
env = np.array([np.sqrt(np.mean(voc[i:i+h]**2)) for i in range(0, len(voc)-h, h)])
env = np.log1p(env / np.median(env))
lyr = json.load(open('analysis/lyrics_timed.json', encoding='utf-8'))
first = {}
for l in lyr: first.setdefault(l['section'], l['startSec'])
def seg(t, d): i = int(t*100); s = env[i:i+int(d*100)]; return (s - s.mean()) / (s.std()+1e-9)
for ref, tgts, d in [('C1', ['C2','C3','C4','F1'], 9.0), ('K1', ['K2','K3','K4'], 9.0)]:
    r = seg(first[ref], d)
    for t in tgts:
        cur = first[t]
        lags = np.arange(-0.8, 0.801, 0.01)
        c = [np.mean(r * seg(cur + L, d)) for L in lags]
        b = lags[int(np.argmax(c))]
        print(f'{t}: current {cur:7.2f}s  best shift {b:+.2f}s  corr {max(c):.2f}')
