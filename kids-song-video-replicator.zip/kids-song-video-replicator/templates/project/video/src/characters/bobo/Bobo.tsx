import React from 'react';
import { Character } from '../../rig/Character';
import { Pose } from '../../rig/types';
import { boboTokens } from './tokens';
import { burgerCostume } from './costume/Burger';

export interface BoboProps {
  pose: Pose;
  frame: number;
  fps?: number;
  costume?: 'none' | 'burger';
  hasMic?: boolean;
  hatTipProgress?: number;
  hasCandyBucket?: boolean;
  scale?: number;
  instanceId?: string;
}

export const Bobo: React.FC<BoboProps> = ({
  pose,
  frame,
  fps = 30,
  costume = 'none',
  hasMic = false,
  hatTipProgress,
  hasCandyBucket = false,
  scale = 1,
  instanceId = 'bobo',
}) => {
  return (
    <Character
      tokens={boboTokens}
      pose={pose}
      frame={frame}
      fps={fps}
      costume={costume === 'burger' ? burgerCostume : null}
      hasMic={hasMic}
      hatTipProgress={hatTipProgress}
      hasCandyBucket={hasCandyBucket}
      scale={scale}
      instanceId={instanceId}
    />
  );
};
