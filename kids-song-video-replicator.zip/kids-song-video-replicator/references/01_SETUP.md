# 01 — Setup, tools, scaffold

## Tools (verify first, print versions)

```powershell
node -v            # tested v26 (>=18 ok)
npm -v
python --version   # tested 3.14/3.15; needs numpy + scipy
python -c "import numpy, scipy; print(numpy.__version__, scipy.__version__)"
ffmpeg -version    # ffmpeg >= 8 has the built-in `whisper` audio filter (used for lyric onsets)
ffprobe -version
# Chrome (Remotion uses it for rendering)
Test-Path "C:\Program Files\Google\Chrome\Application\chrome.exe"
```

Missing python libs: `pip install numpy scipy pillow`. Do NOT depend on `librosa` or `faster-whisper` (faster-whisper failed to build `av` on Python 3.15). Use ffmpeg `whisper` filter instead (see 03).

Whisper model for ffmpeg: download `ggml-base.en.bin` (or `ggml-small.en.bin`) from https://huggingface.co/ggerganov/whisper.cpp/tree/main into `analysis/models/`.

## Workspace layout (target)

```
<workspace>/
  ReferenceVideo.mp4
  <Song>.wav
  PROJECTlyric.txt
  AGENTS.md  NEXT_STEPS.md  PRODUCTION_PLAN.md  CHARACTER_DESIGN_SYSTEM.md   (from templates/project/docs)
  analysis/   *.py, beats.json, lyrics_timed.json, contact/, qa/, audio_check/
  characters/design/   model sheets (jpg) + PROMPT_TEMPLATE.md
  reference_frames/    (gitignored)
  video/      Remotion project (from templates/project/video)
  out/        renders (gitignored)
```

## Scaffold (automated)

`scripts/setup_project.ps1 -Song "<Song>.wav"` does:
1. copies `templates/project/video` → `video/`, `templates/project/analysis` → `analysis/`, docs → root.
2. copies the song to `video/public/HalloweenNight.wav` (filename referenced in `Root.tsx` → `staticFile('HalloweenNight.wav')`; rename consistently if you change it).
3. `npm install` in `video/` (needs network; in sandboxed agents run with network permission).
4. computes total frames with ffprobe and prints the value to put in `theme.ts` (`durationInFrames`) and `build_timing.py` (`3997` constants).

Manual equivalent:
```powershell
Copy-Item -Recurse <skill>/templates/project/video ./video
Copy-Item -Recurse <skill>/templates/project/analysis ./analysis
Copy-Item "<Song>.wav" video/public/HalloweenNight.wav
cd video; npm install; cd ..
ffprobe -v error -show_entries format=duration -of csv=p=0 "<Song>.wav"   # seconds -> frames = round(sec*30)
```

## Package versions (locked, known good)

`remotion 4.0.242`, `@remotion/cli 4.0.242`, `@remotion/motion-blur 4.0.242`, `react 18.3.1`, `react-dom 18.3.1`, `typescript 5.6.3`, `@types/react 18.3.12`. Keep all `@remotion/*` on the same version.

## Sandbox / agent notes (Windows)

- `remotion still|render` in a no-network sandbox fails (`ENOTFOUND storage.googleapis.com`, `spawn EFTYPE`) because it tries to download headless shell. Fix: pass `--browser-executable="C:\Program Files\Google\Chrome\Application\chrome.exe"` AND run outside sandbox (with user approval).
- A dev server started inside a sandbox is not reachable from the user's browser. Start `remotion studio` outside sandbox if user wants live preview: `./video/node_modules/.bin/remotion studio video/src/index.ts --public-dir=video/public --port=3000`.
- PowerShell breaks complex `python -c "..."` quoting. Always write a `.py` file and run it.
- Never round-trip UTF-8 docs via `Get-Content`/`Set-Content` (corrupts ✅ ⬜ —). Use the editor tool.

## Typecheck

```powershell
./video/node_modules/.bin/tsc -p video/tsconfig.json --noEmit
```
Must exit 0 before every render.
