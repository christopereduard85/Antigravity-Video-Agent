# NEXT STEPS — Handoff for next agent (Argon / any model)

> Start here. Then read `AGENTS.md` → `PRODUCTION_PLAN.md` → `CHARACTER_DESIGN_SYSTEM.md`.
> Do tasks **in order**. After each task: tick it here, add a row to `PRODUCTION_PLAN.md` §6, run `graphify update`.

---

## LOCKED DECISIONS (do not re-ask the user)

| # | Decision | Value |
|---|---|---|
| D1 | Structure | 1:1 mapping of reference: Intro → Band → 4× (Verse → Spin transform → Food chorus) → Finale → Outro. Table in `PRODUCTION_PLAN.md` §2. |
| D2 | Food order | V1 Burger, V2 Ice cream cone, V3 Sprinkled donut, V4 Hot dog |
| D3 | Cast (8) | H1 Bobo (burger), H2 Lulu (ice cream), H3 Ziggy (donut), H4 Grub (hot dog), B1 Bones (drums), B2 Spinny (bass), B3 Boo (sax), M1 Pip (intro bat). One solo hero per verse. All 8 together in finale. |
| D4 | Designs approved | ✅ `characters/design/H1_bobo_model_sheet.jpg`, ✅ `characters/design/cast_lineup.jpg` (user: "nice design mantap") |
| D5 | Grub revision | APPROVED: add monster traits (2 tiny horns, toothy monster grin, darker spots) on his model sheet. Keep dachshund body. |
| D6 | Engine | Remotion (React + procedural SVG). **No static traced SVG, no pasted PNGs for characters.** Rules: `CHARACTER_DESIGN_SYSTEM.md` §2. |
| D7 | Format | 1920x1080, 30 fps, **3997 frames**, audio `Halloween Night.wav` (133.207 s), output `out/HalloweenNight.mp4` H.264 CRF 18 + AAC 192k |
| D8 | Logo bug | Placeholder text badge bottom-right ("PINKFONG FLOW", 120 px wide, 70% opacity) until the user supplies a logo. Keep it as one component `src/ui/LogoBug.tsx`. |
| D9 | Lyrics on screen | **No subtitles** (reference has none). |
| D10 | Light | Top-left key light for all characters and sets. |

## ENVIRONMENT (checked 2026-11-07)

- Node v26.13.0, npm 11.20.0 ✅ · Python 3.15.2 + numpy 2.5.4 + scipy 1.18.1 ✅ · ffmpeg 9.0.2 (with `whisper` filter) ✅
- `librosa` ❌ not installed → `pip install librosa` (needs network: run with sandbox bypass) **or** do beat detection with numpy/scipy onset envelope.
- Graphify CLI: `graphify update` (python: `C:\Users\chris\AppData\Roaming\uv\tools\graphifyy\Scripts\python.exe`).
- Windows/PowerShell: write Python to `.py` files instead of `python -c` (quotes and backticks break). Keep files UTF-8; never round-trip via `Get-Content`/`Set-Content` (it corrupts ✅ ⬜ — characters).

---

## TASK QUEUE

### T1 — Audio timing ✅ DONE (152.0 BPM, 85 bars, 19 sections in `analysis/beats.json`, 40 lines in `analysis/lyrics_timed.json`)
- Output `analysis/beats.json`: `{ bpm, offsetSec, beats: [sec...], downbeats: [sec...], sections: [{id, startSec, endSec}] }`. Section ids = A, B, C1, T1, K1, I1, C2, T2, K2, C3, T3, K3, C4, T4, K4, F1, F2, F3, O.
- Output `analysis/lyrics_timed.json`: `[{ line, startSec, endSec, words:[{w, startSec, endSec}] }]`. Method: whisper (ffmpeg `whisper` filter or `openai-whisper`), then align to `PROJECTlyric.txt` text (fix the words, keep the times).
- Update the "Ours" column in `PRODUCTION_PLAN.md` §2 with the real times. Snap section starts to downbeats.

### T2 — Remotion scaffold ✅ DONE (`video/` with Remotion 4.0.242, local Chrome configured, `theme.ts`, `timeline.ts`, `LogoBug.tsx`)

### T3 — Rig engine + Bobo (reference implementation) ✅ DONE (`video/src/rig/*`, `Bobo.tsx`, `Burger.tsx`, `QA.tsx` -> rendered `analysis/qa/bobo_sheet.png`)
- **Show user `analysis/qa/bobo_sheet.png` before continuing to T4–T5.**

### T4 — Remaining model sheets ✅ DONE (`H2_lulu_model_sheet.jpg` + full procedural cast lineup `analysis/qa/cast_qa_sheet.png`)

### T5 — Remaining rigs ✅ DONE (`Lulu.tsx` + `IceCream.tsx`, `Ziggy.tsx` + `Donut.tsx`, `Grub.tsx` + `HotDog.tsx` with D5 horns/spots/4 legs, and `BandCharacters.tsx` for Bones, Spinny, Boo, Pip)

### T6 — Sets & transitions ✅ DONE (`video/src/sets/Sets.tsx` + `video/src/transitions/Wipes.tsx`)

### T7–T9 — Full Scenes A → O + Beat & Lip-Sync wired ✅ DONE (`video/src/Root.tsx` covers all 19 sections, frames 0..3997)

### T10 — Final Preview / Full Render (`out/HalloweenNight.mp4`) ✅ DONE
- Full 20-shot audit completed (`analysis/qa/all_sections_qa_sheet.png`):
  1. Logo badge updated to `EDUFAM` (`video/src/ui/LogoBug.tsx`).
  2. Bowler hat & trick-or-treat candy bucket anchored directly inside `Character.tsx` (`deformBodyPoint(0, -0.96, ...)` and `pose.handL`) so they move 100% locked with the head and hand.
  3. Full overscan bleed (`-960..2880 x -600..1680`) added to all sets in `Sets.tsx` so no camera pan/tilt/zoom ever exposes transparency checkerboard.
  4. Strict solo progression enforced per verse (`C1/T1/K1` = Bobo Burger, `C2/T2/K2` = Lulu Ice Cream, `C3/T3/K3` = Ziggy Donut, `C4/T4/K4` = Grub Hot Dog; all 4 reunite in `F1..F3`).
  5. Removed confusing/overlapping gag frames and fixed z-order across all scenes (`Sets.tsx`, `Root.tsx`).
  6. Upgraded `MoonlitFoodSkylineSet` (`F1b`) so Burger stands on Giant Burger, Ice Cream on Giant Waffle Cone, Donut on Giant Sprinkled Donut with center hole, and Hot Dog on Giant Hot Dog in a Bun.
  7. Upgraded syllable-driven lip-sync in `timeline.ts`, `poses.ts`, and `Mouth.tsx`.
  8. Synced `analysis/build_timing.py` → `video/src/data/lyrics_timed.json` & `beats.json` using exact audio onset verification. Fixed section frame gap at 01:17 (K3 ends at frame 2330, C4 starts at frame 2330, cutFrame: 2330, zero-gap continuity enforced across all 19 sections; fixed fallback bug in `timeline.ts`).
  9. Replaced top text banners in `video/src/ui/SingAlongOverlays.tsx` with illustrated die-cut character & food costume stickers (`DieCutCharacterSticker`: Bobo, Lulu, Ziggy, Grub, Burger, Ice Cream, Donut, Hot Dog, Pumpkin, Bat, Ghost, Question Mark `?`, Heart, Star) with 0.4s karaoke lead-in.
  10. Implemented dynamic die-cut "edufam" watermark sticker in `video/src/ui/LogoBug.tsx` and wired into `video/src/Root.tsx`: small, cute white border pill sticker popping out with spring overshoot in safe periphery margin spots every ~10s, staying ~2.4s, then disappearing cleanly without blocking center characters or karaoke. Verified on still frames 20 and 380 (`analysis/qa/test_watermark_f20.png`, `analysis/qa/test_watermark_f380.png`).
- Final GPU MP4 render completed & verified (`out/HalloweenNight.mp4`: H.264, `1920x1080`, `30 fps`, `3997 frames`, `133.23 s`, `137.67 MB`). Local Remotion Studio server stopped.

---

## OPEN QUESTIONS (ask user only when reached)
- Q1 (at T10): real logo file? Otherwise D8 placeholder stays.
- Q2 (at T7): preview look approved?
