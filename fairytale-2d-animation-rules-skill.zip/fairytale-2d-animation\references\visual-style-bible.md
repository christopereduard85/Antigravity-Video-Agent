# Visual Style & Motion Bible (Reverse-Engineered from Reference 1, 2, 3 + Motion-Director)

This document codifies the exact visual, kinematic, staging, typography, and audio rules extracted from the 3 reference episodes (`REFERENCE1.mp4`, `REFERENCE2.mp4`, `REFERENCE3.mp4`) combined with `motion-director` animation mechanics. Every generated episode MUST follow these specifications.

---

## 1. Frame, Language & Episode Length Spec

| Property | Exact Value |
| --- | --- |
| Resolution & FPS | `1920 × 1080` (16:9 Full HD) at `30 fps` |
| Language | **100% English** (all dialogue, VO prompts, titles, and subtitles, regardless of the legend's country of origin) |
| Episode Length | **Full-length unshortened story** (typically **5 to 8 minutes**, **40–75 shots**, **80–140 dialogue lines**) |
| Average Shot Length | `5–8 seconds`, with **2–3 internal `ActorBeat`s per shot** so action never freezes |
| Top-Left Watermark | **NONE** — never render a top-left face logo (`CornerBadge` is prohibited) |
| Main Character / Narrator | **Signature Chubby Giant Panda (`PANDA_MAIN` / `createMainPanda`)** — fluffy creamy-white head with crown & cheek fur tufts, warm espresso linework (`#2B1B12`), round charcoal ears, angled dark eye patches, warm chestnut/amber eyes with crisp white sclera, signature red knotted storyteller neckerchief (`scarf: "#E03124"`), plump white belly, and stubby charcoal limbs with tan paw pads |
| Supporting Cast | **Unlocked** — design fresh, story-authentic characters for every episode (human villagers/royalty, enchanted animals, `species: "fish"`, etc.; never use old characters like "Rubi") |

---

## 2. Character Design Rules (Smooth Cel-Shaded Storybook Illustration)

1. **Smooth Warm-Espresso Linework & Volumetric Gradients**:
   - Every character uses clean, consistent **warm espresso ink contours (`#2B1B12`)** paired with subtle linear/radial SVG gradients (`skinGrad`, `hairGrad`, `topGrad`, `blushGrad`) for a polished, broadcast-ready 2D storybook look ("mulus").
   - Bare wrists fuse seamlessly into **sculpted cartoon hands** (palm + thumb + 3 scalloped fingers, clenched fist with thumb crease, or index-finger point), while long sleeves (`kebaya`, `robe`) terminate cleanly at a cuffed wrist so hands are always readable.
2. **Chibi Storybook Proportions**:
   - `chibi`: head = **54%** of total height (`H = 295px`), plus dedicated `<FishCharacter/>` (`species: "fish"`) with radial golden shading, scalloped tail, and pose-driven pectoral fins.
   - `kid`: head = **48%** of total height (`H = 370px`).
   - `chubby` (`PANDA_MAIN`): head = **46.5%** of total height (`H = 405px`), stubby legs (`leg: 0.142`), plump belly.
   - `adult` / `elder`: head = **43–44%** of total height (`H = 435–470px`).
   - `big` (giant/wolf/tiger): head = **36%** of total height (`H = 610px`), broad chest with jagged lighter chest fur (`chestFur: true`), visible claws (`claws: true`).
3. **Multi-Angle Views (`view: "front" | "threeQuarter" | "side" | "back"`)**:
   - Do not stage every character flat to the camera (`front`).
   - Use `"threeQuarter"` for dialogue & acting, `"side"` for chases, walks, and blowing wind, and `"back"` with `layer: "front"` for cinematic **over-the-shoulder foreground framing** (just like the reference videos when characters watch a house or hide behind bushes!).
4. **Open Escape Hatches (`customHeadSvg`, `customTorsoSvg`)**:
   - In addition to 18 species presets and 14 hat / 11 top / 5 bottom presets, any character can render bespoke SVG paths on their head or torso via `customHeadSvg` and `customTorsoSvg`.

---

## 3. Reference-Accurate Acting, Editorial Coverage & Full-Body Kinematics

1. **Pose-to-Pose Phrase Acting (`src/kit/acting.ts`) — Never Sine-Wave Arm Wobble**:
   - In `REFERENCE1–3`, speaking characters snap between distinct, readable silhouette key poses (`explain`, `armsWide`, `presentR`, `pointOut`, `pointUp`, `handChest`, `bothChest`, `handChin`, `scratchHead`, `handsCheeks`, `fistPump`, `fistsBoth`, `stopPalm`, `armsCrossed`, etc.) every `~0.5–1.1s` (4 frames ahead of each VO phrase start using `easeOutBack`), firing a 5-frame natural head-turn blink on transitions.
   - Per-arm z-ordering (`armsFront`) automatically renders inward/raised gesturing arms **in front of** the torso and head so hands visibly rest over the chest, chin, or cheeks, and `side` view renders far arm `L` behind the torso and near arm `R` in front.
   - Listeners track the active speaker with automatic eye-gaze (`lookX`), nod 5 frames after speaker phrases begin, and shift resting posture naturally.
   - Avoid setting `defaultProp` on a `CharacterSpec` unless the character carries that prop in every scene; pass `prop` on specific shots/beats so hands remain free for dialogue acting.
2. **Editorial Multi-Camera Coverage (`Stage.tsx`)**:
   - Matches `REFERENCE1–3` shot-coverage density (~55% close-ups & tight two-shots): `Stage.tsx` starts shots in Establishing Wide (`1.0–1.15x`) and hard-cuts cleanly on dialogue phrase/line boundaries to Tight Two-Shots (`1.42x`), Medium Close-Ups (`1.66x`), and Emotional Bust Close-Ups (`1.88x`, rule-of-thirds eye-line `fy = ay - charH * 0.58`), plus `1.82x` close-ups on `emotion` cards (`fire`, `starburst`, `speedlines`, `split`).
   - Wide physical staging (`run`, `climb`, `tumble`, `projectiles`, `collapseAtFrame`, `thoughtBubble`, `view: "back"`, or `camera: { lock: true }`) stays wide so physical action is never cropped.
3. **2-Bone Articulated Legs & Arms (Anatomical Backward Knee Flexion)**:
   - Legs bend at the hip and knee (`hip -> knee -> foot`) with negative `kneeBendDeg` on `walk`, `run`, `sneak`, `push`, and `carry` so calves tuck anatomically backward during high forward knee drive (`REFERENCE1` `075.9s`), with ground contact shadows shrinking as `lift` increases.
4. **Full Vocabulary of 38 Poses & Multi-Beat Choreography (`beats: ActorBeat[]`)**:
   - **Locomotion**: `walk`, `run` (high forward knee drive, backward tucked calf, airborne phase, dust puffs), `sneak`, `climb`.
   - **Level Changes**: `crouch`, `sit`, `sitGround`, `kneel`, `lie`.
   - **Action & Interaction**: `jump` (anticipation crouch -> parabolic `arc()` -> mid-air stretch -> damped landing squash), `fall`, `tumble`, `carry`, `push`, `pull`, `knock`, `peek`, `blow`, `throw`, `reach`, `tied`.
5. **Hit-Stops, Impact Bursts & Comic Emotion Icons**:
   - Use `hitStops: [[hitFrame, 5]]` with `projectiles` and `<ImpactBurst/>`, bold red lightning temple bolts (`fx: ["anger"]`), tapered red alert rays (`fx: ["exclaim"]`), and rounded 5-point golden star wipes (`starWipeOut: true`).

---

## 4. Living Environments, Staging Zones & Interactive Set Pieces

1. **Wind-Alive Layered Nature**:
   - Outdoor presets (`cottage`, `village`, `meadow`, `river`, `lake`, `mountainPath`) feature distant scalloped forest treelines, rolling hills, flower clusters, and swaying dark-green foreground corner bushes (`Bush` at bottom-left/right) matching `REFERENCE1` & `REFERENCE3`.
   - Interior presets (`livingRoom`, `bedroom`, `kitchen`, `palace`) include wood floor planks, wainscoting, curtains, framed art/clock, and furniture depth.
2. **River & Lake Vertical Zones (`backdrop: "river" | "lake"`)**:
   - Sparkling blue water channel spans `y = 596..775` (place swimming characters, fish, lily pads, and `waterSplash` at `y = 715..740`).
   - Dry foreground grassy bank spans `y = 792..1080` (place standing/kneeling land characters at `y = 855..870` so they never stand on water).
3. **Interactive `<SetPieceView/>` (`shot.setPieces`)**:
   - `strawHouse`, `woodHouse`, `brickHouse`, `cottage`, `pendopo` (`doorOpen`, `shake`, `collapseAtFrame`), `sofa`, `bed`, `diningTable`, `cartStraw`, `cartWood`, `cartBrick`, `bushCover`, `rockPile`, `cauldron`, `waterSplash`, `treeTrunkFg`, `doorFrameFg`.

---

## 5. Typography & Single-Line Phrase Subtitles

- **Subtitles (`<SubtitleBar/>` + `activeSubtitlePhrase()`)**:
  - Font: `Fredoka` Bold (`700`), `50px`, `whiteSpace: "nowrap"`, `color: #FFFFFF`, `-webkit-text-stroke: 10px #232323`, `paint-order: stroke fill`, `bottom: 34px`.
  - Written in **100% English**; long sentences automatically split at natural clause/phrase boundaries (never ending on dangling articles/prepositions) into crisp **single-line 3–7 word captions (`<= 42 chars`)** synced to the VO speech envelope just like `REFERENCE1–3`.
