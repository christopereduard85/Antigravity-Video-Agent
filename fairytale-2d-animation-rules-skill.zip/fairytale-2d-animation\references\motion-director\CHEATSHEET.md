# Direct, don't describe: the one-page cheat sheet

AI animation looks cheap when you **describe the scene** and Claude turns every move into a smooth, even slide.
It looks pro when you **direct it**: say what happens on which frame, how it gets there, and what it hits.

## The prompt formula

```
Animate [SUBJECT] for [PLATFORM], [LENGTH] at 30 fps, [FORMAT]. Code only.
CONCEPT: [one sentence: the idea everything serves]
BEATS:
  f0-20   [setup: what we see, what's alive]
  f20-38  [anticipation: the wind-up before the big move, ending in a short hold]
  f38-44  [action: fast, accelerating INTO the contact]
  f44     [contact: 3-5 frames of hit-stop, squash on both sides]
  f44-80  [reaction: what flies off on arcs, what settles, what stays changed]
  f80-end [ending: a payoff or a twist, held long enough to read]
RULES: anticipation, arcs (nothing straight), squash & stretch, follow-through, hit-stop, shadows follow height
AVOID: linear tweens → eased keys · fades → things grow out of each other · random flicker → seeded noise
REVIEW: show me one still per beat and check them against the rules before the final render.
```

## Before and after

| Described (cheap) | Directed (pro) |
|---|---|
| "A mage throws a fireball and it hits the other mage." | "18 frames of wind-up while the orb swells, a 4-frame hold trembling, a 4-frame whip with a smear, the ball on a gravity arc, the target flinches 10 frames early, 2 impact frames + 3 of hit-stop, then sparks on arcs and a scorch that stays." |
| "Animate my logo appearing." | "A drop falls on gravity and stretches, splashes with a 3-frame hold, the puddle gathers and grows into the badge with a small overshoot, letters pop in 3 frames apart, the tagline rises from behind a mask." |
| "Make the text animate in." | "Each word falls for 7 frames and lands with a squash; the line dips when a word lands; the last word gets a 4-frame hit-stop, a camera punch-in and an underline swipe." |
| "Show someone using the app." | "The phone swings in on an arc and settles. The finger curves in, lifts, taps; the button squashes and rings; the result grows out of the button and the number counts up with an ease-out." |

## Fix words

| It looks... | Say this |
|---|---|
| floaty | "Use gravity: ease-in falls, parabolic arcs, squash on landing." |
| stiff | "Add overlap: parts lag 1-3 frames and settle at different times on a spring." |
| weak on impact | "Accelerate into the hit, never slow down. Add 4 frames of hit-stop and a shudder." |
| cheap VFX | "Sparks follow gravity arcs and stretch along their speed. Leave a mark that stays." |
| boring | "Give every beat a reaction. Eyes act. End on a twist." |

With the **motion-director** skill installed, Claude does all of this for you: just say what you want and add
"use motion-director".
