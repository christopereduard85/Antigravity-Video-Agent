import React from 'react';
import { interpolate, useCurrentFrame, Easing } from 'remotion';
import { THEME } from '../../constants/theme';

interface DoorDetailProps {
  handleJiggle?: boolean;
  shadowMoving?: boolean;
}

export const DoorDetail: React.FC<DoorDetailProps> = ({
  handleJiggle = true,
  shadowMoving = true,
}) => {
  const frame = useCurrentFrame();

  // Handle berderit/bergerak turun pelan seolah sedang dibuka dari dalam
  const handleAngle = handleJiggle
    ? interpolate(
        frame % 45,
        [0, 15, 25, 45],
        [0, 18, 14, 0],
        { easing: Easing.bezier(0.4, 0, 0.2, 1) }
      )
    : 0;

  // Bayangan kaki/makhluk melintas di celah bawah pintu
  const shadowX = shadowMoving
    ? interpolate(frame % 70, [0, 70], [-250, 450], {
        extrapolateLeft: 'clamp',
        extrapolateRight: 'clamp',
      })
    : 0;

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        backgroundColor: '#070A14',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {/* Pintu Apartemen Close-Up */}
      <div
        style={{
          width: '750px',
          height: '1000px',
          backgroundColor: '#111728',
          border: '12px solid #080D1A',
          boxShadow: 'inset 0 0 60px rgba(0,0,0,0.85), 0 0 100px rgba(0,0,0,0.9)',
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        {/* Plat Nomor Emas 404 */}
        <div
          style={{
            marginTop: '80px',
            padding: '10px 40px',
            backgroundColor: '#090D18',
            borderRadius: '6px',
            border: `2px solid ${THEME.colors.doorGold}`,
            boxShadow: `0 0 25px rgba(194, 155, 56, 0.4)`,
          }}
        >
          <span
            style={{
              fontFamily: THEME.typography.fontFamily,
              fontWeight: 900,
              fontSize: '44px',
              color: THEME.colors.doorGold,
              letterSpacing: '8px',
            }}
          >
            404
          </span>
        </div>

        {/* Panel Hiasan Pintu Kayu */}
        <div
          style={{
            marginTop: '50px',
            width: '580px',
            height: '240px',
            border: '4px solid rgba(255,255,255,0.03)',
            borderRadius: '4px',
            boxShadow: 'inset 4px 4px 10px rgba(0,0,0,0.5)',
          }}
        />

        {/* Gagang Pintu Logam (Handle) */}
        <div
          style={{
            position: 'absolute',
            right: '60px',
            top: '460px',
            width: '28px',
            height: '110px',
            backgroundColor: '#5C6B80',
            borderRadius: '14px',
            boxShadow: '4px 4px 15px rgba(0,0,0,0.8)',
          }}
        >
          {/* Lever yang bergerak turun */}
          <div
            style={{
              position: 'absolute',
              left: '-70px',
              top: '12px',
              width: '85px',
              height: '22px',
              backgroundColor: '#8898B0',
              borderRadius: '11px',
              transformOrigin: 'right center',
              transform: `rotate(${handleAngle}deg)`,
              boxShadow: '0 4px 10px rgba(0,0,0,0.5)',
              borderBottom: '2px solid #3F4C5E',
            }}
          />
        </div>

        {/* Celah Bawah Pintu Menyala Kuning Emas */}
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: '14px',
            backgroundColor: '#FFAE33',
            boxShadow: '0 0 35px #FFAE33, 0 8px 30px rgba(255, 174, 51, 0.8)',
            overflow: 'hidden',
          }}
        >
          {/* Bayangan Hitam yang Menyeberangi Celah Cahaya */}
          <div
            style={{
              position: 'absolute',
              left: `${shadowX}px`,
              top: 0,
              width: '180px',
              height: '100%',
              backgroundColor: '#070A14',
              filter: 'blur(10px)',
              borderRadius: '50%',
            }}
          />
        </div>
      </div>
    </div>
  );
};
